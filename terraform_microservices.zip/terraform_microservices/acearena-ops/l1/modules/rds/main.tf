resource "aws_db_instance" "this" {
  identifier = "ace-${var.environment}-sqlserver"

  engine         = "sqlserver-ex"
  engine_version = var.engine_version
  instance_class = var.instance_class
  license_model  = "license-included"

  allocated_storage = var.allocated_storage
  storage_type      = "gp3"
  storage_encrypted = true

  # SQL Server doesn't support db_name parameter
  username = var.db_username

  manage_master_user_password = true

  db_subnet_group_name   = var.db_subnet_group_name
  vpc_security_group_ids = var.vpc_security_group_ids

  multi_az            = var.multi_az
  publicly_accessible = false
  skip_final_snapshot = true

  backup_retention_period = 7

  tags = merge(var.tags, {
    Name = "ace-${var.environment}-sqlserver"
  })
}
