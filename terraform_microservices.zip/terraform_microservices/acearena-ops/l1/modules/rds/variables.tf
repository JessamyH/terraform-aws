variable "environment" {
  type = string
}

variable "instance_class" {
  type = string
}

variable "engine_version" {
  type    = string
  default = "16.00"
}

variable "allocated_storage" {
  type    = number
  default = 20
}

variable "db_name" {
  type    = string
  default = ""
}

variable "db_username" {
  type    = string
  default = "aceadmin"
}

variable "db_subnet_group_name" {
  type = string
}

variable "vpc_security_group_ids" {
  type = list(string)
}

variable "multi_az" {
  type    = bool
  default = false
}

variable "tags" {
  type    = map(string)
  default = {}
}
