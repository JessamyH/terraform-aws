resource "aws_service_discovery_http_namespace" "this" {
  name        = var.service_connect_namespace_name
  description = "Service Connect namespace for ECS cluster"

  tags = var.tags
}

resource "aws_ecs_cluster" "this" {
  name = var.cluster_name

  setting {
    name  = "containerInsights"
    value = var.container_insights
  }

  service_connect_defaults {
    namespace = aws_service_discovery_http_namespace.this.arn
  }

  # Optional: Uncomment for compliance — enables KMS encryption for ECS Exec,
  # managed storage, and Fargate ephemeral storage. Also add back the matching
  # variables in variables.tf.
  #
  # dynamic "configuration" {
  #   for_each = (
  #     var.execute_command_configuration != null ||
  #     var.managed_storage_kms_key_id != null ||
  #     var.fargate_ephemeral_storage_kms_key_id != null
  #   ) ? [1] : []
  #
  #   content {
  #     dynamic "execute_command_configuration" {
  #       for_each = var.execute_command_configuration != null ? [var.execute_command_configuration] : []
  #       content {
  #         kms_key_id = try(execute_command_configuration.value.kms_key_id, null)
  #         logging    = try(execute_command_configuration.value.logging, "DEFAULT")
  #
  #         dynamic "log_configuration" {
  #           for_each = try(execute_command_configuration.value.log_configuration, null) != null ? [execute_command_configuration.value.log_configuration] : []
  #           content {
  #             cloud_watch_encryption_enabled = try(log_configuration.value.cloud_watch_encryption_enabled, null)
  #             cloud_watch_log_group_name     = try(log_configuration.value.cloud_watch_log_group_name, null)
  #             s3_bucket_name                 = try(log_configuration.value.s3_bucket_name, null)
  #             s3_bucket_encryption_enabled   = try(log_configuration.value.s3_bucket_encryption_enabled, null)
  #             s3_key_prefix                  = try(log_configuration.value.s3_key_prefix, null)
  #           }
  #         }
  #       }
  #     }
  #
  #     dynamic "managed_storage_configuration" {
  #       for_each = (
  #         var.managed_storage_kms_key_id != null ||
  #         var.fargate_ephemeral_storage_kms_key_id != null
  #       ) ? [1] : []
  #
  #       content {
  #         kms_key_id                           = var.managed_storage_kms_key_id
  #         fargate_ephemeral_storage_kms_key_id = var.fargate_ephemeral_storage_kms_key_id
  #       }
  #     }
  #   }
  # }

  tags = var.tags
}

resource "aws_ecs_cluster_capacity_providers" "this" {
  cluster_name = aws_ecs_cluster.this.name

  capacity_providers = var.capacity_providers

  default_capacity_provider_strategy {
    capacity_provider = var.default_capacity_provider_strategy.capacity_provider
    weight            = try(var.default_capacity_provider_strategy.weight, 1)
    base              = try(var.default_capacity_provider_strategy.base, 0)
  }
}