variable "cluster_name" {
  description = "ECS cluster name"
  type        = string
}

variable "container_insights" {
  description = "Container insights setting"
  type        = string
  default     = "enabled"
}

variable "service_connect_namespace_name" {
  description = "Name of the Cloud Map HTTP namespace to create for Service Connect"
  type        = string
  default     = "test02"
}

variable "capacity_providers" {
  description = "Capacity providers for the ECS cluster"
  type        = list(string)
  default     = ["FARGATE", "FARGATE_SPOT"]
}

variable "default_capacity_provider_strategy" {
  description = "Default capacity provider strategy"
  type = object({
    capacity_provider = string
    weight            = optional(number, 1)
    base              = optional(number, 0)
  })

  default = {
    capacity_provider = "FARGATE"
    weight            = 1
    base              = 0
  }
}

# Optional: Uncomment for compliance requirements (KMS encryption, ECS Exec audit logging)
# variable "execute_command_configuration" { ... }
# variable "managed_storage_kms_key_id" { ... }
# variable "fargate_ephemeral_storage_kms_key_id" { ... }

variable "tags" {
  description = "Tags for ECS cluster resources"
  type        = map(string)
  default     = {}
}