resource "aws_elasticache_cluster" "this" {
  cluster_id = "ace-${var.environment}-redis"

  engine               = "redis"
  engine_version       = var.engine_version
  node_type            = var.node_type
  num_cache_nodes      = var.num_cache_nodes
  port                 = 6379
  parameter_group_name = "default.redis7"

  subnet_group_name  = var.subnet_group_name
  security_group_ids = var.security_group_ids

  tags = merge(var.tags, {
    Name = "ace-${var.environment}-redis"
  })
}
