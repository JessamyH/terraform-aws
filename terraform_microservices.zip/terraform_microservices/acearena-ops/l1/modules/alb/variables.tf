variable "name" {
  type = string
}

variable "vpc_id" {
  type = string
}

variable "internal" {
  type    = bool
  default = false
}

variable "security_group_ids" {
  type = list(string)
}

variable "subnet_ids" {
  type = list(string)
}

variable "enable_deletion_protection" {
  type    = bool
  default = false
}

variable "idle_timeout" {
  type    = number
  default = 60
}

variable "create_http_listener" {
  type    = bool
  default = true
}

variable "http_listener_port" {
  type    = number
  default = 80
}

variable "create_https_listener" {
  type    = bool
  default = false
}

variable "https_listener_port" {
  type    = number
  default = 443
}

variable "ssl_policy" {
  type    = string
  default = "ELBSecurityPolicy-2016-08"
}

variable "certificate_arn" {
  type    = string
  default = null
}

# Optional — if null the HTTP listener uses a fixed-response 404 default.
# Set this once L2 has created a target group to act as the catch-all.
variable "default_target_group_arn" {
  type    = string
  default = null
}

variable "tags" {
  type    = map(string)
  default = {}
}
