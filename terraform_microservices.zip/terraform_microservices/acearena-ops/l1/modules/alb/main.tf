resource "aws_lb" "this" {
  name               = var.name
  internal           = var.internal
  load_balancer_type = "application"
  security_groups    = var.security_group_ids
  subnets            = var.subnet_ids

  enable_deletion_protection = var.enable_deletion_protection
  idle_timeout               = var.idle_timeout

  tags = var.tags
}

# HTTP listener — redirects to HTTPS when HTTPS is enabled,
# otherwise serves traffic directly (dev without ACM).
resource "aws_lb_listener" "http" {
  count = var.create_http_listener ? 1 : 0

  load_balancer_arn = aws_lb.this.arn
  port              = var.http_listener_port
  protocol          = "HTTP"

  # When HTTPS is enabled, redirect HTTP → HTTPS
  dynamic "default_action" {
    for_each = var.create_https_listener ? [1] : []
    content {
      type = "redirect"
      redirect {
        port        = tostring(var.https_listener_port)
        protocol    = "HTTPS"
        status_code = "HTTP_301"
      }
    }
  }

  # When HTTPS is NOT enabled, forward or fixed-response
  dynamic "default_action" {
    for_each = !var.create_https_listener && var.default_target_group_arn != null ? [1] : []
    content {
      type             = "forward"
      target_group_arn = var.default_target_group_arn
    }
  }

  dynamic "default_action" {
    for_each = !var.create_https_listener && var.default_target_group_arn == null ? [1] : []
    content {
      type = "fixed-response"
      fixed_response {
        content_type = "text/plain"
        message_body = "AceArena — no route matched"
        status_code  = "404"
      }
    }
  }
}

# HTTPS listener — serves traffic when ACM cert is available
resource "aws_lb_listener" "https" {
  count = var.create_https_listener ? 1 : 0

  load_balancer_arn = aws_lb.this.arn
  port              = var.https_listener_port
  protocol          = "HTTPS"
  ssl_policy        = var.ssl_policy
  certificate_arn   = var.certificate_arn

  dynamic "default_action" {
    for_each = var.default_target_group_arn != null ? [1] : []
    content {
      type             = "forward"
      target_group_arn = var.default_target_group_arn
    }
  }

  dynamic "default_action" {
    for_each = var.default_target_group_arn == null ? [1] : []
    content {
      type = "fixed-response"
      fixed_response {
        content_type = "text/plain"
        message_body = "AceArena — no route matched"
        status_code  = "404"
      }
    }
  }
}
