variable "environment" {
  type = string
}

variable "public_subnet_id" {
  description = "Public subnet to place the NAT Gateway in"
  type        = string
}

variable "private_route_table_id" {
  description = "Private route table to add the NAT route to"
  type        = string
}

variable "internet_gateway_id" {
  description = "IGW dependency — NAT must wait for IGW"
  type        = string
}

variable "tags" {
  type    = map(string)
  default = {}
}
