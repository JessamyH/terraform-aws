terraform {
  required_version = ">= 1.10.0"

  backend "s3" {
    bucket       = "acearena-terraform-state"
    key          = "L1/terraform.tfstate"
    region       = "ap-southeast-2"
    encrypt      = true
    use_lockfile = true
    # Workspace auto-prefixes:
    #   dev → env:/dev/L1/terraform.tfstate
    #   qa  → env:/qa/L1/terraform.tfstate
  }
}
