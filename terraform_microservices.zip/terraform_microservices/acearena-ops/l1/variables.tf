# ── ACM / HTTPS ─────────────────────────────────────────────────────────────

variable "enable_https" {
  description = "Enable HTTPS listener on ALB with ACM certificate"
  type        = bool
  default     = false
}

variable "domain_name" {
  description = "Domain name for ACM certificate (e.g. dev.acearena.com)"
  type        = string
  default     = ""
}

# ── RDS ─────────────────────────────────────────────────────────────────────

variable "db_instance_class" {
  description = "RDS instance class"
  type        = string
}

variable "db_engine_version" {
  description = "MySQL engine version"
  type        = string
  default     = "8.0"
}

variable "db_allocated_storage" {
  description = "Allocated storage in GB"
  type        = number
  default     = 20
}

variable "db_name" {
  description = "Name of the default database"
  type        = string
  default     = "acearena"
}

variable "db_multi_az" {
  description = "Enable Multi-AZ for RDS"
  type        = bool
  default     = false
}

