# L1 outputs — consumed by L2 via terraform_remote_state

# ECS
output "ecs_cluster_arn" { value = module.ecs_cluster.cluster_arn }
output "ecs_cluster_name" { value = module.ecs_cluster.cluster_name }
output "ecs_task_execution_role_arn" { value = module.ecs_task_execution_role.arn }
output "ecs_task_role_arn" { value = module.ecs_task_role.arn }
output "ecs_service_sg_id" { value = module.ecs_service_sg.id }
output "service_connect_namespace_arn" { value = module.ecs_cluster.service_connect_namespace_arn }

# ALB
output "alb_arn" { value = module.alb.arn }
output "http_listener_arn" { value = module.alb.http_listener_arn }
output "https_listener_arn" { value = module.alb.https_listener_arn }

output "alb_dns_name" {
  description = "Point the environment domain CNAME here"
  value       = module.alb.dns_name
}

# RDS
output "rds_endpoint" { value = module.rds.endpoint }
output "rds_address" { value = module.rds.address }
output "rds_port" { value = module.rds.port }
output "rds_db_name" { value = module.rds.db_name }
output "rds_master_user_secret_arn" { value = module.rds.master_user_secret_arn }
output "rds_username" { value = module.rds.username }


# ACM
output "acm_certificate_arn" {
  value = var.enable_https ? module.acm[0].certificate_arn : null
}
