# L1 dev environment — cheap but functional

# HTTPS — disabled for dev (no domain delegation yet, saves nothing but avoids DNS dependency)
# Flip to true once Route 53 is delegated
enable_https = false
domain_name  = "dev.acearena.com"

# RDS SQL Server Express — free license, smallest tier, no Multi-AZ
db_instance_class    = "db.t3.micro"
db_engine_version    = "16.00"
db_allocated_storage = 20
db_name              = ""
db_multi_az          = false
