# L1 qa environment

enable_https = false
domain_name  = "qa.acearena.com"

# RDS — slightly larger than dev for QA load
db_instance_class    = "db.t3.micro"
db_engine_version    = "16.00"
db_allocated_storage = 20
db_name              = ""
db_multi_az          = false
