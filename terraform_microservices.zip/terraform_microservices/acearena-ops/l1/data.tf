data "aws_caller_identity" "current" {}

# Read L0 outputs for the same workspace (e.g., dev reads env:/dev/L0/...)
data "terraform_remote_state" "l0" {
  backend   = "s3"
  workspace = terraform.workspace
  config = {
    bucket = "acearena-terraform-state"
    key    = "L0/terraform.tfstate"
    region = "ap-southeast-2"
  }
}
