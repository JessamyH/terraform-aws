provider "aws" {
  region = "ap-southeast-2"
}

locals {
  environment = terraform.workspace

  common_tags = {
    Project     = "AceArena"
    Environment = local.environment
    Tier        = "L1"
  }

  l0 = data.terraform_remote_state.l0.outputs
}

# ---------------------------------------------------------------------------
# L1 — Shared Platform
# ---------------------------------------------------------------------------

# ── NAT Gateway (costs ~$32/mo — destroyed with L1 to save money) ───────────

module "nat" {
  source = "./modules/nat"

  environment            = local.environment
  public_subnet_id       = local.l0.public_subnet_ids[0]
  private_route_table_id = local.l0.private_route_table_id
  internet_gateway_id    = local.l0.internet_gateway_id
  tags                   = local.common_tags
}

# ── Security Groups ─────────────────────────────────────────────────────────

module "alb_sg" {
  source = "./modules/security_group"

  name        = "alb-sg-ace-${local.environment}"
  description = "ALB - HTTP/HTTPS from internet"
  vpc_id      = local.l0.vpc_id

  ingress_rules = [
    {
      ip_protocol = "tcp"
      from_port   = 80
      to_port     = 80
      cidr_ipv4   = "0.0.0.0/0"
      description = "HTTP from internet"
    },
    {
      ip_protocol = "tcp"
      from_port   = 443
      to_port     = 443
      cidr_ipv4   = "0.0.0.0/0"
      description = "HTTPS from internet"
    },
    {
      ip_protocol = "tcp"
      from_port   = 5201
      to_port     = 5212
      cidr_ipv4   = "0.0.0.0/0"
      description = "Dev: per-service listeners for Swagger UI"
    }
  ]

  egress_rules = [{
    ip_protocol = "-1"
    cidr_ipv4   = "0.0.0.0/0"
    description = "All outbound"
  }]

  tags = local.common_tags
}

module "ecs_service_sg" {
  source = "./modules/security_group"

  name        = "ecs-sg-ace-${local.environment}"
  description = "ECS tasks - service ports from ALB + intra-VPC"
  vpc_id      = local.l0.vpc_id

  ingress_rules = [
    {
      ip_protocol                  = "tcp"
      from_port                    = 5201
      to_port                      = 5212
      referenced_security_group_id = module.alb_sg.id
      description                  = "Service HTTP ports from ALB"
    },
    {
      ip_protocol = "tcp"
      from_port   = 5201
      to_port     = 5260
      cidr_ipv4   = local.l0.vpc_cidr
      description = "Service-to-service within VPC (HTTP 5201-5212, gRPC 5251-5260)"
    }
  ]

  egress_rules = [{
    ip_protocol = "-1"
    cidr_ipv4   = "0.0.0.0/0"
    description = "All outbound (ECR via NAT, Secrets Manager)"
  }]

  tags = local.common_tags
}

module "rds_sg" {
  source = "./modules/security_group"

  name        = "rds-sg-ace-${local.environment}"
  description = "RDS - SQL Server from ECS tasks"
  vpc_id      = local.l0.vpc_id

  ingress_rules = [{
    ip_protocol                  = "tcp"
    from_port                    = 1433
    to_port                      = 1433
    referenced_security_group_id = module.ecs_service_sg.id
    description                  = "SQL Server from ECS tasks"
  }]

  egress_rules = []

  tags = local.common_tags
}

# ── ALB ─────────────────────────────────────────────────────────────────────

module "alb" {
  source = "./modules/alb"

  name               = "ace-${local.environment}-alb"
  vpc_id             = local.l0.vpc_id
  subnet_ids         = local.l0.public_subnet_ids
  security_group_ids = [module.alb_sg.id]

  create_http_listener  = true
  create_https_listener = var.enable_https
  certificate_arn       = var.enable_https ? module.acm[0].certificate_arn : null

  tags = local.common_tags
}

# ── ACM (SSL certificate) ──────────────────────────────────────────────────

module "acm" {
  count  = var.enable_https ? 1 : 0
  source = "./modules/acm"

  domain_name     = var.domain_name
  route53_zone_id = local.l0.route53_zone_id
  tags            = local.common_tags
}

# ── ECS Cluster ─────────────────────────────────────────────────────────────

module "ecs_cluster" {
  source = "./modules/ecs_cluster"

  cluster_name                   = "ace-${local.environment}-cluster"
  container_insights             = "enabled"
  service_connect_namespace_name = "ace-${local.environment}-ns"

  capacity_providers = ["FARGATE"]

  default_capacity_provider_strategy = {
    capacity_provider = "FARGATE"
    weight            = 1
    base              = 0
  }

  tags = local.common_tags
}


# ── RDS SQL Server Express ───────────────────────────────────────────────────

module "rds" {
  source = "./modules/rds"

  environment            = local.environment
  instance_class         = var.db_instance_class
  engine_version         = var.db_engine_version
  allocated_storage      = var.db_allocated_storage
  multi_az               = var.db_multi_az
  db_subnet_group_name   = local.l0.database_subnet_group_name
  vpc_security_group_ids = [module.rds_sg.id]

  tags = local.common_tags
}

