data "aws_iam_policy_document" "ecs_tasks_assume_role" {
  statement {
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
    actions = ["sts:AssumeRole"]
  }
}

module "ecs_task_execution_role" {
  source = "./modules/iam_role"

  name               = "ecs-execution-role-ace-${local.environment}"
  assume_role_policy = data.aws_iam_policy_document.ecs_tasks_assume_role.json

  managed_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
  ]

  inline_policies = {
    secrets_read = jsonencode({
      Version = "2012-10-17"
      Statement = [{
        Effect   = "Allow"
        Action   = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
        Resource = "arn:aws:secretsmanager:ap-southeast-2:${data.aws_caller_identity.current.account_id}:secret:acearena/${local.environment}/*"
      }]
    })
  }
}

module "ecs_task_role" {
  source = "./modules/iam_role"

  name               = "ecs-task-role-ace-${local.environment}"
  assume_role_policy = data.aws_iam_policy_document.ecs_tasks_assume_role.json

  inline_policies = {
    app_runtime = jsonencode({
      Version = "2012-10-17"
      Statement = [{
        Effect   = "Allow"
        Action   = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
        Resource = "arn:aws:secretsmanager:ap-southeast-2:${data.aws_caller_identity.current.account_id}:secret:acearena/${local.environment}/*"
      }]
    })
  }
}
