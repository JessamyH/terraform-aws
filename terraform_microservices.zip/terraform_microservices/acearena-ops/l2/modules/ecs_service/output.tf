output "id" {
  value = aws_ecs_service.this.id
}

output "name" {
  value = aws_ecs_service.this.name
}

output "cluster" {
  value = aws_ecs_service.this.cluster
}

output "service_arn" {
  value = aws_ecs_service.this.id
}

output "service_name" {
  value = aws_ecs_service.this.name
}