variable "name" {
  description = "ECS service name"
  type        = string
}

variable "cluster_arn" {
  description = "ECS cluster ARN"
  type        = string
}

variable "task_definition_arn" {
  description = "ECS task definition ARN"
  type        = string
}

variable "desired_count" {
  description = "Desired task count"
  type        = number
  default     = 1
}

variable "subnet_ids" {
  description = "Subnet IDs for ECS service"
  type        = list(string)
}

variable "security_group_ids" {
  description = "Security group IDs for ECS service"
  type        = list(string)
}

variable "assign_public_ip" {
  description = "Assign public IP to tasks"
  type        = bool
  default     = false
}

variable "enable_execute_command" {
  description = "Enable ECS Exec"
  type        = bool
  default     = true
}

variable "deployment_minimum_healthy_percent" {
  description = "Lower limit on healthy tasks during deployment"
  type        = number
  default     = 100
}

variable "deployment_maximum_percent" {
  description = "Upper limit on running tasks during deployment"
  type        = number
  default     = 200
}

variable "health_check_grace_period_seconds" {
  description = "Grace period for load balancer health checks"
  type        = number
  default     = null
}

variable "propagate_tags" {
  description = "Tag propagation setting"
  type        = string
  default     = "SERVICE"
}

variable "wait_for_steady_state" {
  description = "Wait for service to reach steady state"
  type        = bool
  default     = false
}

variable "load_balancers" {
  description = "Load balancer attachments"
  type = list(object({
    target_group_arn = string
    container_name   = string
    container_port   = number
  }))
  default = []
}

variable "service_connect_configuration" {
  description = "Optional ECS Service Connect configuration"
  type = object({
    enabled   = bool
    namespace = optional(string)
    services = optional(list(object({
      port_name      = string
      discovery_name = optional(string)
      client_alias = optional(list(object({
        port     = number
        dns_name = optional(string)
      })), [])
    })), [])
  })
  default = null
}

variable "tags" {
  description = "Tags for ECS service"
  type        = map(string)
  default     = {}
}