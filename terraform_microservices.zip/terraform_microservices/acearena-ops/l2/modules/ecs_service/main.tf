###Ref: https://registry.terraform.io/providers/-/aws/latest/docs/resources/ecs_service

resource "aws_ecs_service" "this" {
  name            = var.name
  cluster         = var.cluster_arn
  task_definition = var.task_definition_arn
  desired_count   = var.desired_count
  launch_type     = "FARGATE"

  enable_execute_command             = var.enable_execute_command
  deployment_minimum_healthy_percent = var.deployment_minimum_healthy_percent
  deployment_maximum_percent         = var.deployment_maximum_percent
  health_check_grace_period_seconds  = var.health_check_grace_period_seconds
  propagate_tags                     = var.propagate_tags
  wait_for_steady_state              = var.wait_for_steady_state

  network_configuration {
    subnets          = var.subnet_ids
    security_groups  = var.security_group_ids
    assign_public_ip = var.assign_public_ip
  }

  dynamic "load_balancer" {
    for_each = var.load_balancers
    content {
      target_group_arn = load_balancer.value.target_group_arn
      container_name   = load_balancer.value.container_name
      container_port   = load_balancer.value.container_port
    }
  }

  dynamic "service_connect_configuration" {
    for_each = var.service_connect_configuration == null ? [] : [var.service_connect_configuration]

    content {
      enabled   = service_connect_configuration.value.enabled
      namespace = try(service_connect_configuration.value.namespace, null)

      dynamic "service" {
        for_each = try(service_connect_configuration.value.services, [])

        content {
          port_name      = service.value.port_name
          discovery_name = try(service.value.discovery_name, null)

          dynamic "client_alias" {
            for_each = try(service.value.client_alias, [])

            content {
              port     = client_alias.value.port
              dns_name = try(client_alias.value.dns_name, null)
            }
          }
        }
      }
    }
  }

  tags = var.tags
  # Prevent Terraform from overriding desired_count
  # This is required when using Application Auto Scaling
  lifecycle {
    ignore_changes = [
      desired_count
    ]
  }
}