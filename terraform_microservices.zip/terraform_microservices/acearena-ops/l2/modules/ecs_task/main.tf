resource "aws_cloudwatch_log_group" "this" {
  count = var.create_log_group ? 1 : 0

  name              = var.log_group_name
  retention_in_days = var.log_retention_in_days

  tags = var.tags
}

resource "aws_ecs_task_definition" "this" {
  family                   = var.family
  cpu                      = var.cpu
  memory                   = var.memory
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]

  execution_role_arn = var.execution_role_arn
  task_role_arn      = var.task_role_arn

  runtime_platform {
    operating_system_family = var.operating_system_family
    cpu_architecture        = var.cpu_architecture
  }

  container_definitions = jsonencode([
    {
      name      = var.container_name
      image     = var.container_image
      essential = true

      portMappings = [
        for p in var.port_mappings : {
          name          = try(p.name, null)
          containerPort = p.container_port
          hostPort      = try(p.host_port, p.container_port)
          protocol      = try(p.protocol, "tcp")
          appProtocol   = try(p.app_protocol, null)
        }
      ]

      environment = [
        for k, v in var.environment : {
          name  = k
          value = v
        }
      ]

      secrets = [
        for s in var.secrets : {
          name      = s.name
          valueFrom = s.value_from
        }
      ]

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          awslogs-group         = var.log_group_name
          awslogs-region        = var.aws_region
          awslogs-stream-prefix = var.log_stream_prefix
        }
      }

      command    = var.command
      entryPoint = var.entry_point

      healthCheck = var.health_check == null ? null : {
        command     = var.health_check.command
        interval    = try(var.health_check.interval, 30)
        timeout     = try(var.health_check.timeout, 5)
        retries     = try(var.health_check.retries, 3)
        startPeriod = try(var.health_check.start_period, 0)
      }
    }
  ])

  tags = var.tags

  depends_on = [
    aws_cloudwatch_log_group.this
  ]
}