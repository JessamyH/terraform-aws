variable "aws_region" {
  description = "AWS region for CloudWatch logs"
  type        = string
}

variable "family" {
  description = "Task definition family"
  type        = string
}

variable "cpu" {
  description = "Task CPU units for Fargate"
  type        = string
}

variable "memory" {
  description = "Task memory for Fargate"
  type        = string
}

variable "execution_role_arn" {
  description = "Execution role ARN for ECS task"
  type        = string
}

variable "task_role_arn" {
  description = "Task role ARN for ECS task"
  type        = string
  default     = null
}

variable "operating_system_family" {
  description = "Operating system family"
  type        = string
  default     = "LINUX"
}

variable "cpu_architecture" {
  description = "CPU architecture"
  type        = string
  default     = "X86_64"
}

variable "container_name" {
  description = "Container name"
  type        = string
}

variable "container_image" {
  description = "Container image"
  type        = string
}

variable "port_mappings" {
  description = "Container port mappings"
  type = list(object({
    container_port = number
    host_port      = optional(number)
    protocol       = optional(string, "tcp")
    app_protocol   = optional(string)
    name           = optional(string)
  }))
  default = []
}

variable "environment" {
  description = "Environment variables for container"
  type        = map(string)
  default     = {}
}

variable "secrets" {
  description = "Secrets for container"
  type = list(object({
    name       = string
    value_from = string
  }))
  default = []
}

variable "command" {
  description = "Container command"
  type        = list(string)
  default     = null
}

variable "entry_point" {
  description = "Container entry point"
  type        = list(string)
  default     = null
}

variable "health_check" {
  description = "Optional container health check"
  type = object({
    command      = list(string)
    interval     = optional(number)
    timeout      = optional(number)
    retries      = optional(number)
    start_period = optional(number)
  })
  default = null
}

variable "create_log_group" {
  description = "Whether to create CloudWatch log group"
  type        = bool
  default     = true
}

variable "log_group_name" {
  description = "CloudWatch log group name"
  type        = string
}

variable "log_stream_prefix" {
  description = "CloudWatch log stream prefix"
  type        = string
  default     = "ecs"
}

variable "log_retention_in_days" {
  description = "CloudWatch log retention"
  type        = number
  default     = 7
}

variable "tags" {
  description = "Tags"
  type        = map(string)
  default     = {}
}