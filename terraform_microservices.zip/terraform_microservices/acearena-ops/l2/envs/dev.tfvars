# L2 dev environment — minimum resources to run

# ECS task sizing
default_cpu     = "256"  # 0.25 vCPU — enough for dev
default_memory  = "512"  # 512 MB
identity_cpu    = "512"  # identity needs more (auth, JWT, admin seed, gRPC)
identity_memory = "1024" # 1 GB
