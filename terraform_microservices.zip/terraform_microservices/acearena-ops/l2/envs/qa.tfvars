# L2 qa environment

# ECS task sizing
default_cpu     = "256"
default_memory  = "512"
identity_cpu    = "512"
identity_memory = "1024"
