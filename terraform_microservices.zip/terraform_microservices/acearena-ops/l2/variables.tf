variable "default_cpu" {
  description = "Default Fargate CPU units for services"
  type        = string
  default     = "256"
}

variable "default_memory" {
  description = "Default Fargate memory (MB) for services"
  type        = string
  default     = "512"
}

variable "identity_cpu" {
  description = "CPU units for identity service (handles auth, needs more)"
  type        = string
  default     = "512"
}

variable "identity_memory" {
  description = "Memory (MB) for identity service"
  type        = string
  default     = "1024"
}
