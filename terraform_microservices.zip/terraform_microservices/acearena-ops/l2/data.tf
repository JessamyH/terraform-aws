data "aws_caller_identity" "current" {}

data "terraform_remote_state" "l0" {
  backend   = "s3"
  workspace = terraform.workspace
  config = {
    bucket = "acearena-terraform-state"
    key    = "L0/terraform.tfstate"
    region = "ap-southeast-2"
  }
}

data "terraform_remote_state" "l1" {
  backend   = "s3"
  workspace = terraform.workspace
  config = {
    bucket = "acearena-terraform-state"
    key    = "L1/terraform.tfstate"
    region = "ap-southeast-2"
  }
}

# Per-service image tag — written by <Service>-push Makefile target after each ECR push.
# Uses a static set to avoid circular dependency with local.services.
data "aws_ssm_parameter" "service_image_tag" {
  for_each = toset([
    "identityservice",
    "clubservice",
    "eventservice",
    "orderservice",
    "paymentservice",
    "mediaservice",
    "shopservice",
    "tournamentservice",
    "trainingservice",
    "adminservice",
    "notificationservice",
    "venueservice",
  ])
  name = "/acearena/${local.environment}/${each.key}/image_tag"
}
