# ── Database connection string secrets ────────────────────────────────────────
# Reads the RDS-managed master password, then creates a per-service secret
# containing the full SQL Server connection string for ASP.NET Core.

data "aws_secretsmanager_secret_version" "rds_master" {
  secret_id = local.l1.rds_master_user_secret_arn
}

locals {
  rds_credentials = jsondecode(data.aws_secretsmanager_secret_version.rds_master.secret_string)
}

resource "aws_secretsmanager_secret" "db_connection" {
  for_each = local.services

  name                    = "acearena/${local.environment}/${each.key}-db-conn"
  recovery_window_in_days = 0

  tags = merge(local.common_tags, { Service = each.key })
}

resource "aws_secretsmanager_secret_version" "db_connection" {
  for_each = local.services

  secret_id     = aws_secretsmanager_secret.db_connection[each.key].id
  secret_string = "Server=${local.l1.rds_address},${local.l1.rds_port};Database=${each.value.db_name};User Id=${local.rds_credentials["username"]};Password=${local.rds_credentials["password"]};TrustServerCertificate=True"
}

# ── Shared secrets (created manually in AWS Console) ──────────────────────────
# These data sources reference secrets that must exist before deploying L2.
# Create them once manually:
#   acearena/<env>/jwt-key
#   acearena/<env>/admin-seed-email
#   acearena/<env>/admin-seed-password
#   acearena/<env>/twilio-account-sid
#   acearena/<env>/twilio-auth-token
#   acearena/<env>/twilio-service-sid

data "aws_secretsmanager_secret" "jwt_key" {
  name = "acearena/${local.environment}/jwt-key"
}

data "aws_secretsmanager_secret" "admin_seed_email" {
  name = "acearena/${local.environment}/admin-seed-email"
}

data "aws_secretsmanager_secret" "admin_seed_password" {
  name = "acearena/${local.environment}/admin-seed-password"
}

data "aws_secretsmanager_secret" "twilio_account_sid" {
  name = "acearena/${local.environment}/twilio-account-sid"
}

data "aws_secretsmanager_secret" "twilio_auth_token" {
  name = "acearena/${local.environment}/twilio-auth-token"
}

data "aws_secretsmanager_secret" "twilio_service_sid" {
  name = "acearena/${local.environment}/twilio-service-sid"
}
