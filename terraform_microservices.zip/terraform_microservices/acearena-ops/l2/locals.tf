locals {
  environment = terraform.workspace

  common_tags = {
    Project     = "AceArena"
    Environment = local.environment
    Tier        = "L2"
  }

  l0       = data.terraform_remote_state.l0.outputs
  l1       = data.terraform_remote_state.l1.outputs
  ecr_urls = local.l0.ecr_repository_urls

  # Use HTTPS listener if available, fall back to HTTP
  listener_arn = try(local.l1.https_listener_arn, null) != null ? local.l1.https_listener_arn : local.l1.http_listener_arn

  # Secrets Manager ARN prefix for manually-created shared secrets
  secrets_prefix = "arn:aws:secretsmanager:ap-southeast-2:${data.aws_caller_identity.current.account_id}:secret:acearena/${local.environment}"

  services = {
    identityservice = {
      image     = "${local.ecr_urls["identityservice"]}:${data.aws_ssm_parameter.service_image_tag["identityservice"].value}"
      cpu       = var.identity_cpu
      memory    = var.identity_memory
      port      = 5210
      grpc_port = 5260
      paths     = ["/api/auth/*", "/api/identity/*"]
      priority  = 10
      db_name   = "IdentityDb"
      grpc_deps = {
        ClubService  = "http://clubservice-grpc:5251"
        AdminService = "http://adminservice-grpc:5259"
      }
    }
    clubservice = {
      image     = "${local.ecr_urls["clubservice"]}:${data.aws_ssm_parameter.service_image_tag["clubservice"].value}"
      cpu       = var.default_cpu
      memory    = var.default_memory
      port      = 5201
      grpc_port = 5251
      paths     = ["/api/v1/clubs/*", "/api/clubs/*"]
      priority  = 20
      db_name   = "ClubServiceDb"
      grpc_deps = {
        IdentityService = "http://identityservice-grpc:5260"
      }
    }
    eventservice = {
      image     = "${local.ecr_urls["eventservice"]}:${data.aws_ssm_parameter.service_image_tag["eventservice"].value}"
      cpu       = var.default_cpu
      memory    = var.default_memory
      port      = 5202
      grpc_port = null
      paths     = ["/api/events/*"]
      priority  = 30
      db_name   = "EventServiceDb"
      grpc_deps = {
        ClubService     = "http://clubservice-grpc:5251"
        IdentityService = "http://identityservice-grpc:5260"
      }
    }
    orderservice = {
      image     = "${local.ecr_urls["orderservice"]}:${data.aws_ssm_parameter.service_image_tag["orderservice"].value}"
      cpu       = var.default_cpu
      memory    = var.default_memory
      port      = 5203
      grpc_port = 5253
      paths     = ["/api/v1/orders/*", "/api/orders/*"]
      priority  = 40
      db_name   = "OrderServiceDb"
      grpc_deps = {
        PaymentService = "http://paymentservice-grpc:5254"
        ShopService    = "http://shopservice-grpc:5256"
      }
    }
    paymentservice = {
      image     = "${local.ecr_urls["paymentservice"]}:${data.aws_ssm_parameter.service_image_tag["paymentservice"].value}"
      cpu       = var.default_cpu
      memory    = var.default_memory
      port      = 5204
      grpc_port = 5254
      paths     = ["/api/payments/*"]
      priority  = 50
      db_name   = "PaymentServiceDb"
      grpc_deps = {
        OrderService = "http://orderservice-grpc:5253"
      }
    }
    mediaservice = {
      image     = "${local.ecr_urls["mediaservice"]}:${data.aws_ssm_parameter.service_image_tag["mediaservice"].value}"
      cpu       = var.default_cpu
      memory    = var.default_memory
      port      = 5205
      grpc_port = null
      paths     = ["/api/media/*"]
      priority  = 60
      db_name   = "MediaServiceDb"
      grpc_deps = {}
    }
    shopservice = {
      image     = "${local.ecr_urls["shopservice"]}:${data.aws_ssm_parameter.service_image_tag["shopservice"].value}"
      cpu       = var.default_cpu
      memory    = var.default_memory
      port      = 5206
      grpc_port = 5256
      paths     = ["/api/shop/*"]
      priority  = 70
      db_name   = "ShopServiceDb"
      grpc_deps = {}
    }
    tournamentservice = {
      image     = "${local.ecr_urls["tournamentservice"]}:${data.aws_ssm_parameter.service_image_tag["tournamentservice"].value}"
      cpu       = var.default_cpu
      memory    = var.default_memory
      port      = 5207
      grpc_port = null
      paths     = ["/api/tournament/*", "/api/tournaments/*"]
      priority  = 80
      db_name   = "TournamentServiceDb"
      grpc_deps = {}
    }
    trainingservice = {
      image     = "${local.ecr_urls["trainingservice"]}:${data.aws_ssm_parameter.service_image_tag["trainingservice"].value}"
      cpu       = var.default_cpu
      memory    = var.default_memory
      port      = 5208
      grpc_port = null
      paths     = ["/api/training/*"]
      priority  = 90
      db_name   = "TrainingServiceDb"
      grpc_deps = {
        ClubService = "http://clubservice-grpc:5251"
      }
    }
    adminservice = {
      image     = "${local.ecr_urls["adminservice"]}:${data.aws_ssm_parameter.service_image_tag["adminservice"].value}"
      cpu       = var.default_cpu
      memory    = var.default_memory
      port      = 5209
      grpc_port = 5259
      paths     = ["/api/v1/admin/*", "/api/admin/*"]
      priority  = 100
      db_name   = "AdminServiceDb"
      grpc_deps = {
        ClubService = "http://clubservice-grpc:5251"
      }
    }
    # notificationservice — disabled: Microsoft.OpenApi version conflict
    # (Swashbuckle 10.1.0 vs Microsoft.AspNetCore.OpenApi 9.0.12)
    # Re-enable after dev team fixes the .csproj dependency conflict.
    # notificationservice = {
    #   image     = "${local.ecr_urls["notificationservice"]}:${data.aws_ssm_parameter.service_image_tag["notificationservice"].value}"
    #   cpu       = var.default_cpu
    #   memory    = var.default_memory
    #   port      = 5211
    #   grpc_port = null
    #   paths     = ["/api/notification/*", "/api/notifications/*"]
    #   priority  = 110
    #   db_name   = "NotificationServiceDb"
    #   grpc_deps = {}
    # }
    venueservice = {
      image     = "${local.ecr_urls["venueservice"]}:${data.aws_ssm_parameter.service_image_tag["venueservice"].value}"
      cpu       = var.default_cpu
      memory    = var.default_memory
      port      = 5212
      grpc_port = null
      paths     = ["/api/v1/venues/*", "/api/venues/*"]
      priority  = 120
      db_name   = "VenueServiceDb"
      grpc_deps = {}
    }
  }
}
