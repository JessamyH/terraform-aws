# L2 outputs — consumed by the ops pipeline for observability / smoke tests

output "service_names" {
  description = "Names of all deployed ECS services"
  value       = { for k, v in module.ecs_service : k => v.service_name }
}

output "target_group_arns" {
  description = "ALB target group ARNs per service"
  value       = { for k, v in aws_lb_target_group.services : k => v.arn }
}
