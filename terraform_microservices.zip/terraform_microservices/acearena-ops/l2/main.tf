provider "aws" {
  region = "ap-southeast-2"
}

# ---------------------------------------------------------------------------
# L2 — Application Services
# ---------------------------------------------------------------------------

resource "aws_lb_target_group" "services" {
  for_each = local.services

  name        = "tg-ace-${local.environment}-${substr(each.key, 0, 14)}"
  port        = each.value.port
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = local.l0.vpc_id

  lifecycle { create_before_destroy = true }

  health_check {
    enabled             = true
    path                = "/"
    protocol            = "HTTP"
    matcher             = "200-404"
    interval            = 30
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }

  tags = merge(local.common_tags, { Service = each.key })
}

resource "aws_lb_listener_rule" "services" {
  for_each = local.services

  listener_arn = local.listener_arn
  priority     = each.value.priority

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.services[each.key].arn
  }

  condition {
    path_pattern {
      values = each.value.paths
    }
  }
}

# ── Per-service listeners for Swagger UI access (dev only) ────────────────────
# Each service gets its own listener on its own port, forwarding all traffic
# to that service. Mirrors local docker-compose URLs:
#   http://<alb>:5210/swagger   → identityservice
#   http://<alb>:5201/          → clubservice (swagger at root)
#   http://<alb>:5204/swagger   → paymentservice
#   ... etc
resource "aws_lb_listener" "service_direct" {
  for_each = local.services

  load_balancer_arn = local.l1.alb_arn
  port              = each.value.port
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.services[each.key].arn
  }

  tags = merge(local.common_tags, { Service = each.key, Purpose = "swagger-dev" })
}

module "ecs_task_definition" {
  for_each = local.services
  source   = "./modules/ecs_task"

  aws_region         = "ap-southeast-2"
  family             = each.key
  cpu                = each.value.cpu
  memory             = each.value.memory
  execution_role_arn = local.l1.ecs_task_execution_role_arn
  task_role_arn      = local.l1.ecs_task_role_arn
  container_name     = each.key
  container_image    = each.value.image

  port_mappings = concat(
    [{
      container_port = each.value.port
      host_port      = each.value.port
      protocol       = "tcp"
      app_protocol   = "http"
      name           = "${each.key}-http"
    }],
    each.value.grpc_port != null ? [{
      container_port = each.value.grpc_port
      host_port      = each.value.grpc_port
      protocol       = "tcp"
      app_protocol   = "grpc"
      name           = "${each.key}-grpc"
    }] : []
  )

  environment = merge(
    {
      ASPNETCORE_ENVIRONMENT = "Development"
      ENV                    = local.environment
      SERVICE                = each.key
    },
    {
      for svc, addr in each.value.grpc_deps :
      "Grpc__Services__${svc}__Address" => addr
    }
  )

  secrets = concat(
    [
      {
        name       = "ConnectionStrings__DefaultConnection"
        value_from = aws_secretsmanager_secret.db_connection[each.key].arn
      },
      {
        name       = "Jwt__Key"
        value_from = data.aws_secretsmanager_secret.jwt_key.arn
      }
    ],
    # Identity service needs admin seed + Twilio credentials
    each.key == "identityservice" ? [
      {
        name       = "Seed__AdminUser__Email"
        value_from = data.aws_secretsmanager_secret.admin_seed_email.arn
      },
      {
        name       = "Seed__AdminUser__Password"
        value_from = data.aws_secretsmanager_secret.admin_seed_password.arn
      },
      {
        name       = "Twilio__Verify__AccountSid"
        value_from = data.aws_secretsmanager_secret.twilio_account_sid.arn
      },
      {
        name       = "Twilio__Verify__AuthToken"
        value_from = data.aws_secretsmanager_secret.twilio_auth_token.arn
      },
      {
        name       = "Twilio__Verify__ServiceSid"
        value_from = data.aws_secretsmanager_secret.twilio_service_sid.arn
      }
    ] : []
  )

  log_group_name        = "/ecs/${local.environment}/${each.key}"
  log_retention_in_days = 7
  create_log_group      = true

  tags = merge(local.common_tags, { Service = each.key })
}

module "ecs_service" {
  for_each = local.services
  source   = "./modules/ecs_service"

  name                = each.key
  cluster_arn         = local.l1.ecs_cluster_arn
  task_definition_arn = module.ecs_task_definition[each.key].task_definition_arn
  subnet_ids          = local.l0.private_subnet_ids
  security_group_ids  = [local.l1.ecs_service_sg_id]
  assign_public_ip    = false

  load_balancers = [{
    target_group_arn = aws_lb_target_group.services[each.key].arn
    container_name   = each.key
    container_port   = each.value.port
  }]

  service_connect_configuration = {
    enabled   = true
    namespace = local.l1.service_connect_namespace_arn

    services = concat(
      [{
        port_name = "${each.key}-http"
        client_alias = [{
          port     = each.value.port
          dns_name = each.key
        }]
      }],
      each.value.grpc_port != null ? [{
        port_name = "${each.key}-grpc"
        client_alias = [{
          port     = each.value.grpc_port
          dns_name = "${each.key}-grpc"
        }]
      }] : []
    )
  }

  depends_on = [aws_lb_listener_rule.services]
}
