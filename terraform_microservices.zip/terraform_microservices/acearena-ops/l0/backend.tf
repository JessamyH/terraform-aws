terraform {
  required_version = ">= 1.10.0"

  backend "s3" {
    bucket       = "acearena-terraform-state"
    key          = "L0/terraform.tfstate"
    region       = "ap-southeast-2"
    encrypt      = true
    use_lockfile = true
    # Workspace auto-prefixes the key:
    #   dev  → env:/dev/L0/terraform.tfstate
    #   qa   → env:/qa/L0/terraform.tfstate
  }
}
