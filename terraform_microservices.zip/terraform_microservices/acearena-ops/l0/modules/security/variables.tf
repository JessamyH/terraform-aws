variable "vpc_id" {
  description = "The ID of the VPC where security groups will be created"
  type        = string
}

variable "environment" {
  description = "The environment name (e.g., dev, qa)"
  type        = string
}