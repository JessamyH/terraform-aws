# 1. Lock down the default security group (Security Baseline)
resource "aws_default_security_group" "default" {
  vpc_id = var.vpc_id

  # Leaving ingress and egress blocks completely empty 
  # removes all default rules, restricting all traffic.
  tags = {
    Name        = "${var.environment}-default-sg-locked"
    Environment = var.environment
    Project     = "AceArena"
    Tier        = "L0"
    Note        = "Intentionally locked - no rules"
  }
}

