output "route53_zone_id" {
  description = "The Hosted Zone ID of the created Route 53 zone"
  value       = aws_route53_zone.main.zone_id
}

output "route53_zone_name_servers" {
  description = "A list of name servers for the delegation set"
  value       = aws_route53_zone.main.name_servers
}