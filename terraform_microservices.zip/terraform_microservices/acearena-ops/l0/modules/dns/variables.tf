variable "domain_name" {
  description = "The domain name for the hosted zone (e.g., dev.acearena.com)"
  type        = string
}

variable "environment" {
  description = "The environment name (e.g., dev, qa)"
  type        = string
}