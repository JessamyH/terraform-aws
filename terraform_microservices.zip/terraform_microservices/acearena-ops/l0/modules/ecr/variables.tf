variable "name" {
  type = string
}

variable "image_tag_mutability" {
  type    = string
  default = "MUTABLE"
}

variable "scan_on_push" {
  type    = bool
  default = true
}

variable "encryption_type" {
  type    = string
  default = "AES256"
}

variable "create_lifecycle_policy" {
  type    = bool
  default = true
}

variable "lifecycle_policy" {
  type = any

  default = {
    rules = [
      {
        rulePriority = 1
        description  = "Keep last 10 images"
        selection = {
          tagStatus   = "any"
          countType   = "imageCountMoreThan"
          countNumber = 10
        }
        action = {
          type = "expire"
        }
      }
    ]
  }
}

variable "force_delete" {
  description = "Allow terraform destroy to delete repos even if they contain images"
  type        = bool
  default     = true
}

variable "tags" {
  type    = map(string)
  default = {}
}