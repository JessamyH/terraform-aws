variable "environment" {
  description = "The environment name (e.g., dev, qa)"
  type        = string
}

variable "vpc_cidr" {
  description = "The CIDR block for the VPC"
  type        = string
}

variable "public_subnet_cidrs" {
  description = "List of CIDR blocks for public subnets"
  type        = list(string)
}

variable "private_subnet_cidrs" {
  description = "List of CIDR blocks for private subnets (ECS)"
  type        = list(string)
}

variable "database_subnet_cidrs" {
  description = "List of CIDR blocks for database subnets (RDS)"
  type        = list(string)
}


variable "availability_zones" {
  description = "List of Availability Zones to use"
  type        = list(string)
}
