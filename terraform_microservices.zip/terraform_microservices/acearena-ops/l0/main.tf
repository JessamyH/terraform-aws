provider "aws" {
  region = "ap-southeast-2"
}

locals {
  environment = terraform.workspace

  common_tags = {
    Project     = "AceArena"
    Environment = local.environment
    Tier        = "L0"
  }
}

# ---------------------------------------------------------------------------
# L0 — Foundation
# ---------------------------------------------------------------------------

module "networking" {
  source = "./modules/networking"

  environment           = local.environment
  vpc_cidr              = var.vpc_cidr
  public_subnet_cidrs   = var.public_subnet_cidrs
  private_subnet_cidrs  = var.private_subnet_cidrs
  database_subnet_cidrs = var.database_subnet_cidrs
  availability_zones    = var.availability_zones
}

module "security" {
  source = "./modules/security"

  vpc_id      = module.networking.vpc_id
  environment = local.environment
}

module "dns" {
  source = "./modules/dns"

  domain_name = var.domain_name
  environment = local.environment
}

# ECR repos — kept in L0 so images survive L1/L2 destroy
module "ecr" {
  for_each = toset([
    "identityservice", "clubservice", "eventservice", "orderservice",
    "paymentservice", "mediaservice", "shopservice", "tournamentservice",
    "trainingservice", "adminservice", "notificationservice", "venueservice"
  ])
  source = "./modules/ecr"

  name = "ace-${local.environment}-${each.key}"
  tags = merge(local.common_tags, { Service = each.key })
}
