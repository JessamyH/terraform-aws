# L0 outputs — consumed by L1 via terraform_remote_state

output "vpc_id" {
  value = module.networking.vpc_id
}

output "public_subnet_ids" {
  value = module.networking.public_subnet_ids
}

output "private_subnet_ids" {
  value = module.networking.private_subnet_ids
}

output "vpc_cidr" {
  value = var.vpc_cidr
}

output "database_subnet_ids" {
  value = module.networking.database_subnet_ids
}

output "database_subnet_group_name" {
  value = module.networking.database_subnet_group_name
}

output "private_route_table_id" {
  value = module.networking.private_route_table_id
}

output "internet_gateway_id" {
  value = module.networking.internet_gateway_id
}

output "ecr_repository_urls" {
  description = "Map of service name → ECR repo URL"
  value       = { for k, v in module.ecr : k => v.repository_url }
}

output "route53_zone_id" {
  value = module.dns.route53_zone_id
}

output "route53_name_servers" {
  description = "Delegate the domain to these name servers"
  value       = module.dns.route53_zone_name_servers
}
