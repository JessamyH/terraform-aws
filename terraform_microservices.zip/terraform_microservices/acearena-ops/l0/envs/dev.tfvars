# L0 dev environment — matching aws.png architecture
domain_name        = "dev.acearena.com"
vpc_cidr           = "10.0.0.0/16"
availability_zones = ["ap-southeast-2a", "ap-southeast-2b"]

public_subnet_cidrs   = ["10.0.1.0/24", "10.0.2.0/24"]   # ALB, NAT Gateway
private_subnet_cidrs  = ["10.0.11.0/24", "10.0.21.0/24"] # ECS Fargate
database_subnet_cidrs = ["10.0.31.0/24", "10.0.32.0/24"] # RDS MySQL
