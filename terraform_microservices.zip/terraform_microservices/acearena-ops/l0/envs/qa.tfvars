# L0 qa environment
domain_name        = "qa.acearena.com"
vpc_cidr           = "10.1.0.0/16"
availability_zones = ["ap-southeast-2a", "ap-southeast-2b"]

public_subnet_cidrs   = ["10.1.1.0/24", "10.1.2.0/24"]   # ALB, NAT Gateway
private_subnet_cidrs  = ["10.1.11.0/24", "10.1.21.0/24"] # ECS Fargate
database_subnet_cidrs = ["10.1.31.0/24", "10.1.32.0/24"] # RDS MySQL
