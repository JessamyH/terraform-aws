# ── L2: App ───────────────────────────────────────────────────────────────────
# Owns: Container Apps Environment, API Container App.
# This is the most frequently changing layer — image tags, scaling, env vars.
# The CI/CD pipeline can optionally run `terraform apply` here for config drift,
# but image updates go through `az containerapp update` in the Makefile.
#
# Reads L0 and L1 outputs via terraform_remote_state.
#
# Usage:
#   terraform workspace select dev
#   terraform apply -var="api_image_tag=dev-api-abc1234"

terraform {
  required_version = ">= 1.6"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.100"
    }
  }

  backend "azurerm" {
    resource_group_name  = "rg-smartcompare-tfstate"
    storage_account_name = "sttfstatesmartcompare"
    container_name       = "tfstate"
    key                  = "smartcompare-api-l2.tfstate"
  }
}

provider "azurerm" {
  features {}
}
