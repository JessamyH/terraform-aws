# Image tag is the only value that changes on every deploy.
# In CI/CD this is passed as: -var="api_image_tag=dev-api-abc1234"
variable "api_image_tag" {
  type        = string
  description = "Image tag to deploy, e.g. dev-api-abc1234. Built and pushed by the pipeline. No default — must be explicit."
}

# Auth0 — non-sensitive, env-specific values passed via TF_VAR or -var-file
variable "auth0_domain" {
  type    = string
  default = "dcoding.au.auth0.com"
}

variable "auth0_client_id" {
  type        = string
  description = "Auth0 client ID for this environment. Set via TF_VAR_auth0_client_id."
}

variable "auth0_audience" {
  type    = string
  default = "https://dcoding.au.auth0.com/api/v2/"
}

# Set after smartcompare-ai l2 is applied
variable "ai_service_url" {
  type    = string
  default = ""
}

variable "aspnetcore_environment" {
  type        = string
  description = "ASP.NET Core environment name: Development, Staging, Production."
  default     = "Development"
}

variable "min_replicas" {
  type        = number
  description = "Minimum Container App replicas. 0 = scale to zero."
  default     = 0
}

variable "max_replicas" {
  type        = number
  description = "Maximum Container App replicas."
  default     = 1
}

variable "cpu" {
  type        = number
  description = "CPU cores allocated per replica."
  default     = 0.5
}

variable "memory" {
  type        = string
  description = "Memory allocated per replica, e.g. 1Gi."
  default     = "1Gi"
}

variable "frontend_base_url" {
  type        = string
  description = "Base URL of the Next.js frontend, used for CORS and redirect URIs."
  default     = "https://dev.smartcompare.app"
}

variable "front_door_id" {
  type        = string
  description = "AFD profile resource_guid (from smartcompare-app L2 output 'front_door_id'). Set via TF_VAR_front_door_id in CI. Empty = no FDID enforcement."
  default     = ""
}

