# Consumed by smartcompare-app and smartcompare-ai l2 layers
# via terraform_remote_state to wire up their Container Apps to the same environment

output "container_apps_environment_id" {
  description = "Shared Container Apps Environment ID (app/ai deploy into this same environment)"
  value       = module.container_apps.environment_id
}

output "container_apps_environment_static_ip" {
  description = "Static IP of the Container Apps Environment — App Gateway backend pool target"
  value       = module.container_apps.environment_static_ip
}

output "container_apps_environment_default_domain" {
  value = module.container_apps.environment_default_domain
}

output "api_container_app_name" {
  value = module.container_apps.api_container_app_name
}

output "api_internal_fqdn" {
  description = "Internal FQDN of the API Container App — used by App Container App for server-side calls"
  value       = module.container_apps.api_fqdn
}

output "resource_group_name" {
  value = data.terraform_remote_state.l0.outputs.resource_group_name
}

output "nat_gateway_public_ip" {
  description = "Outbound IP — add to third-party allow-lists (Stripe, Auth0 etc.)"
  value       = azurerm_public_ip.nat.ip_address
}
