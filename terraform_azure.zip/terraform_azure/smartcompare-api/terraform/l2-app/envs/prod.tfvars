aspnetcore_environment   = "Production"
min_replicas             = 2
max_replicas             = 10
cpu                      = 2.0
memory                   = "4Gi"
frontend_base_url        = "https://smartcompare.app"
