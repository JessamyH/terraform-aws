aspnetcore_environment   = "Development"
min_replicas             = 1
max_replicas             = 1
cpu                      = 0.5
memory                   = "1Gi"
# Public base URL for the entire app — both frontend (/) and API (/api/*)
# share this hostname (single Front Door endpoint, path-based routing).
# Used by .NET API for: Frontend.BaseUrl, Cors.FrontendOrigins, OIDC redirect_uri.
# TODO: replace with custom domain (e.g. https://dev.smartcompare.app) once DNS
# + AFD custom domain are configured. Until then, use the auto-generated AFD URL.
frontend_base_url = "https://smartcompare-dev-ehgvgaarhgbqfaa8.z02.azurefd.net"
