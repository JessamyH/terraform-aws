locals {
  environment = terraform.workspace

  tags = {
    Environment = local.environment
    Project     = "smartcompare"
    ManagedBy   = "terraform"
    Layer       = "l2-app"
  }
}

# ── Read L0 and L1 outputs ───────────────────────────────────────────────────
data "terraform_remote_state" "l0" {
  backend   = "azurerm"
  workspace = terraform.workspace

  config = {
    resource_group_name  = "rg-smartcompare-tfstate"
    storage_account_name = "sttfstatesmartcompare"
    container_name       = "tfstate"
    key                  = "smartcompare-api-l0.tfstate"
  }
}

data "terraform_remote_state" "l1" {
  backend   = "azurerm"
  workspace = terraform.workspace

  config = {
    resource_group_name  = "rg-smartcompare-tfstate"
    storage_account_name = "sttfstatesmartcompare"
    container_name       = "tfstate"
    key                  = "smartcompare-api-l1.tfstate"
  }
}

# ── NAT Gateway (destroyed with L2 to save cost in dev) ──────────────────────
resource "azurerm_public_ip" "nat" {
  name                = "pip-smartcompare-${local.environment}-nat"
  location            = data.terraform_remote_state.l0.outputs.location
  resource_group_name = data.terraform_remote_state.l0.outputs.resource_group_name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = local.tags
}

resource "azurerm_nat_gateway" "this" {
  name                = "ng-smartcompare-${local.environment}"
  location            = data.terraform_remote_state.l0.outputs.location
  resource_group_name = data.terraform_remote_state.l0.outputs.resource_group_name
  sku_name            = "Standard"
  tags                = local.tags
}

resource "azurerm_nat_gateway_public_ip_association" "this" {
  nat_gateway_id       = azurerm_nat_gateway.this.id
  public_ip_address_id = azurerm_public_ip.nat.id
}

resource "azurerm_subnet_nat_gateway_association" "private" {
  subnet_id      = data.terraform_remote_state.l0.outputs.private_subnet_id
  nat_gateway_id = azurerm_nat_gateway.this.id
}

# ── Container Apps ───────────────────────────────────────────────────────────
module "container_apps" {
  source = "../modules/container_apps"

  resource_group_name            = data.terraform_remote_state.l0.outputs.resource_group_name
  location                       = data.terraform_remote_state.l0.outputs.location
  environment                    = local.environment
  infrastructure_subnet_id       = data.terraform_remote_state.l0.outputs.private_subnet_id
  vnet_id                        = data.terraform_remote_state.l0.outputs.vnet_id
  log_analytics_workspace_id     = data.terraform_remote_state.l1.outputs.log_analytics_workspace_id
  managed_identity_id            = data.terraform_remote_state.l1.outputs.api_managed_identity_id
  managed_identity_client_id     = data.terraform_remote_state.l1.outputs.api_managed_identity_client_id
  acr_login_server               = data.terraform_remote_state.l1.outputs.acr_login_server
  acr_name                       = data.terraform_remote_state.l1.outputs.acr_name
  image_tag                      = var.api_image_tag
  key_vault_name                 = data.terraform_remote_state.l1.outputs.key_vault_name
  app_insights_connection_string = data.terraform_remote_state.l1.outputs.app_insights_connection_string
  aspnetcore_environment         = var.aspnetcore_environment
  auth0_domain                   = var.auth0_domain
  auth0_client_id                = var.auth0_client_id
  auth0_audience                 = var.auth0_audience
  # AI Container App is internal-only — its FQDN includes ".internal" between
  # the app name and the env default domain. Without it, the Container Apps env
  # LB routes by Host header and returns 404.
  # Must be https:// — AI ingress has allow_insecure=false, so an http request
  # gets a 301 to https, which .NET HttpClient follows as GET (POST body
  # dropped), causing 405 Method Not Allowed at /ocr/quote.
  ai_service_url                 = "https://ca-smartcompare-ai-${local.environment}.internal.${module.container_apps.environment_default_domain}"
  frontend_base_url              = var.frontend_base_url
  front_door_id                  = var.front_door_id
  min_replicas                   = var.min_replicas
  max_replicas                   = var.max_replicas
  cpu                            = var.cpu
  memory                         = var.memory
  tags                           = local.tags
}

# Front Door is owned by the App repo (the only public-facing service).
# API L2 just creates the API container — internal-only.
