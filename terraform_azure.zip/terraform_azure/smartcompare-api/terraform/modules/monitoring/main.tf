# ── Monitoring Module ────────────────────────────────────────────────────────
# Log Analytics Workspace: ingests logs from all Container Apps + NSG flow logs.
# Application Insights: APM for the .NET API (request tracing, exceptions, deps).
# Dev retention: 30 days (cost-effective). Prod: increase to 90+.

resource "azurerm_log_analytics_workspace" "this" {
  name                = "log-smartcompare-${var.environment}"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = var.log_retention_days
  tags                = var.tags
}

resource "azurerm_application_insights" "this" {
  name                = "appi-smartcompare-${var.environment}"
  location            = var.location
  resource_group_name = var.resource_group_name
  workspace_id        = azurerm_log_analytics_workspace.this.id
  application_type    = "web"
  tags                = var.tags
}
