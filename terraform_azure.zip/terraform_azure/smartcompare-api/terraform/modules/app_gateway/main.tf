# ── App Gateway Module ────────────────────────────────────────────────────────
# Standard_v2 with autoscaling (min_capacity=0 for dev, 1 for prod).
# One backend pool pointing to the Container Apps environment static IP.
# Path-based routing: /api/* → API container (8080), /* → App container (3000).
# Host header override tells the internal LB which container app to route to.
# Front Door sits in front and handles HTTPS — App Gateway uses HTTP internally.

locals {
  # External-enabled Container Apps use the regular subdomain (no .internal).
  # Public DNS resolves to the env's internal LB IP — only VNet traffic actually reaches it.
  api_host = "ca-smartcompare-api-${var.environment}.${var.environment_default_domain}"
  app_host = "ca-smartcompare-app-${var.environment}.${var.environment_default_domain}"
}

resource "azurerm_public_ip" "app_gw" {
  name                = "pip-smartcompare-${var.environment}-appgw"
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_application_gateway" "this" {
  name                = "agw-smartcompare-${var.environment}"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  sku {
    name = "Standard_v2"
    tier = "Standard_v2"
  }

  ssl_policy {
    policy_type = "Predefined"
    policy_name = "AppGwSslPolicy20220101"
  }

  # min_capacity=0 (dev) → no cost when idle. min_capacity=1 (prod) → always warm.
  autoscale_configuration {
    min_capacity = var.min_capacity
    max_capacity = var.max_capacity
  }

  gateway_ip_configuration {
    name      = "gateway-ip-config"
    subnet_id = var.public_subnet_id
  }

  frontend_ip_configuration {
    name                 = "frontend-ip"
    public_ip_address_id = azurerm_public_ip.app_gw.id
  }

  frontend_port {
    name = "port-80"
    port = 80
  }

  # Single pool targeting the Container Apps environment static IP.
  # The host header in each backend_http_settings selects the individual app.
  backend_address_pool {
    name         = "container-apps-pool"
    ip_addresses = [var.environment_static_ip]
  }

  # Container Apps env with internal LB listens on HTTP 80 + HTTPS 443.
  # We use HTTP 80 internally — TLS termination happens at Front Door externally.
  backend_http_settings {
    name                  = "api-http-settings"
    cookie_based_affinity = "Disabled"
    port                  = 80
    protocol              = "Http"
    request_timeout       = 30
    host_name             = local.api_host
    probe_name            = "api-health-probe"
  }

  backend_http_settings {
    name                  = "app-http-settings"
    cookie_based_affinity = "Disabled"
    port                  = 80
    protocol              = "Http"
    request_timeout       = 30
    host_name             = local.app_host
    probe_name            = "app-health-probe"
  }

  probe {
    name                = "api-health-probe"
    protocol            = "Http"
    host                = local.api_host
    path                = "/index.html"
    interval            = 30
    timeout             = 10
    unhealthy_threshold = 3
  }

  probe {
    name                = "app-health-probe"
    protocol            = "Http"
    host                = local.app_host
    path                = "/"
    interval            = 30
    timeout             = 10
    unhealthy_threshold = 3
  }

  http_listener {
    name                           = "http-listener"
    frontend_ip_configuration_name = "frontend-ip"
    frontend_port_name             = "port-80"
    protocol                       = "Http"
  }

  # Path-based: /api/* → API, everything else → App (Next.js)
  url_path_map {
    name                               = "path-map"
    default_backend_address_pool_name  = "container-apps-pool"
    default_backend_http_settings_name = "app-http-settings"

    path_rule {
      name                       = "api-rule"
      paths                      = ["/api/*"]
      backend_address_pool_name  = "container-apps-pool"
      backend_http_settings_name = "api-http-settings"
    }
  }

  request_routing_rule {
    name               = "routing-rule"
    rule_type          = "PathBasedRouting"
    http_listener_name = "http-listener"
    url_path_map_name  = "path-map"
    priority           = 100
  }
}
