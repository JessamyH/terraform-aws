variable "resource_group_name" {
  type = string
}

variable "location" {
  type = string
}

variable "environment" {
  type = string
}

variable "public_subnet_id" {
  type        = string
  description = "Public subnet ID where App Gateway is deployed"
}

variable "environment_static_ip" {
  type        = string
  description = "Internal static IP of the Container Apps Environment"
}

variable "environment_default_domain" {
  type        = string
  description = "Default domain of the Container Apps Environment for host header routing"
}

variable "min_capacity" {
  type        = number
  description = "Minimum autoscale instances. 0 = scale to zero (dev), 1 = always warm (prod)."
  default     = 0
}

variable "max_capacity" {
  type        = number
  description = "Maximum autoscale instances."
  default     = 2
}

variable "tags" {
  type    = map(string)
  default = {}
}
