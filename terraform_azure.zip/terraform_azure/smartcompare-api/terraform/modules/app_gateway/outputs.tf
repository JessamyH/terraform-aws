output "public_ip_address" {
  description = "Public IP address of the App Gateway — used as Front Door origin"
  value       = azurerm_public_ip.app_gw.ip_address
}

output "public_ip_id" {
  value = azurerm_public_ip.app_gw.id
}
