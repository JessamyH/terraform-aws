variable "resource_group_name" {
  type        = string
  description = "Name of the resource group"
}

variable "location" {
  type        = string
  description = "Azure region"
}

variable "environment" {
  type        = string
  description = "Environment name (dev, staging, prod)"
}

variable "infrastructure_subnet_id" {
  type        = string
  description = "Private subnet ID for Container Apps Environment VNet injection"
}

variable "vnet_id" {
  type        = string
  description = "VNet ID for linking the Container Apps private DNS zone"
}

variable "log_analytics_workspace_id" {
  type        = string
  description = "Log Analytics Workspace resource ID"
}

variable "managed_identity_id" {
  type        = string
  description = "Full resource ID of the user-assigned managed identity"
}

variable "managed_identity_client_id" {
  type        = string
  description = "Client ID of the managed identity (passed as AZURE_CLIENT_ID)"
}

variable "acr_login_server" {
  type        = string
  description = "ACR login server (e.g. acrsmartcomparedev.azurecr.io)"
}

variable "acr_name" {
  type        = string
  description = "ACR resource name"
}

variable "image_tag" {
  type        = string
  description = "Docker image tag to deploy (e.g. dev-api-abc1234)"
}

variable "key_vault_name" {
  type        = string
  description = "Key Vault name for secret references"
}

variable "app_insights_connection_string" {
  type        = string
  description = "Application Insights connection string"
  sensitive   = true
}

# Runtime config
variable "aspnetcore_environment" {
  type        = string
  description = "ASPNETCORE_ENVIRONMENT value injected into the container"
  default     = "Development"
}

variable "auth0_domain" {
  type        = string
  description = "Auth0 domain"
}

variable "auth0_client_id" {
  type        = string
  description = "Auth0 client ID (non-secret)"
}

variable "auth0_audience" {
  type        = string
  description = "Auth0 API audience"
}

variable "ai_service_url" {
  type        = string
  description = "Internal URL of the AI Container App"
  default     = ""
}

variable "frontend_base_url" {
  type        = string
  description = "Frontend base URL for CORS and redirect configuration"
}

variable "front_door_id" {
  type        = string
  description = "AFD profile resource_guid; injected as FrontDoor__ExpectedId so the API rejects requests not coming through Front Door. Empty disables the check (local/dev without AFD)."
  default     = ""
}

# Scaling
variable "min_replicas" {
  type        = number
  description = "Minimum replicas (0 = scale to zero when idle)"
  default     = 0
}

variable "max_replicas" {
  type        = number
  description = "Maximum replicas"
  default     = 3
}

variable "cpu" {
  type        = number
  description = "CPU cores per replica"
  default     = 0.5
}

variable "memory" {
  type        = string
  description = "Memory per replica"
  default     = "1Gi"
}

variable "tags" {
  type        = map(string)
  description = "Resource tags"
  default     = {}
}
