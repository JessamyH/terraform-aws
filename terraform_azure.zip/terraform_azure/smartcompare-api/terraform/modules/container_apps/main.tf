# ── Container Apps Module ────────────────────────────────────────────────────
# Container Apps Environment (shared, VNet-injected into private subnet).
# API Container App (serverless / consumption plan) pulling from ACR via managed identity.
# Secrets are injected from Key Vault references — no plaintext values in Terraform state.

resource "azurerm_container_app_environment" "this" {
  name                       = "cae-smartcompare-${var.environment}"
  location                   = var.location
  resource_group_name        = var.resource_group_name
  log_analytics_workspace_id = var.log_analytics_workspace_id

  # VNet injection with public LB so Front Door (Microsoft edge) can reach it.
  # Container Apps individually have ip_security_restrictions to only allow Front Door
  # via X-Azure-FDID header, so the public IP is locked down.
  infrastructure_subnet_id       = var.infrastructure_subnet_id
  internal_load_balancer_enabled = false

  tags = var.tags

  lifecycle {
    # Azure auto-populates infrastructure_resource_group_name (e.g. ME_cae-...).
    # It's read-only but Terraform sees it as a diff and tries to force replacement.
    ignore_changes = [infrastructure_resource_group_name]
  }
}

# Note: With internal_load_balancer_enabled = false, Azure publishes the
# Container App FQDNs in public DNS automatically. No private DNS zone needed.

# ── API Container App ────────────────────────────────────────────────────────
resource "azurerm_container_app" "api" {
  name                         = "ca-smartcompare-api-${var.environment}"
  container_app_environment_id = azurerm_container_app_environment.this.id
  resource_group_name          = var.resource_group_name
  revision_mode                = "Single"

  tags = var.tags

  # Authenticate to ACR using the managed identity (no admin credentials)
  registry {
    server   = var.acr_login_server
    identity = var.managed_identity_id
  }

  identity {
    type         = "UserAssigned"
    identity_ids = [var.managed_identity_id]
  }

  # Secrets pulled from Key Vault at runtime via managed identity
  # The secret "value" is the Key Vault secret URI (versioned or latest)
  secret {
    name                = "db-connection-string"
    key_vault_secret_id = "https://${var.key_vault_name}.vault.azure.net/secrets/db-connection-string"
    identity            = var.managed_identity_id
  }

  secret {
    name                = "app-insights-connection-string"
    key_vault_secret_id = "https://${var.key_vault_name}.vault.azure.net/secrets/app-insights-connection-string"
    identity            = var.managed_identity_id
  }

  secret {
    name                = "auth0-client-secret"
    key_vault_secret_id = "https://${var.key_vault_name}.vault.azure.net/secrets/auth0-client-secret"
    identity            = var.managed_identity_id
  }

  secret {
    name                = "sentry-dsn"
    key_vault_secret_id = "https://${var.key_vault_name}.vault.azure.net/secrets/sentry-dsn"
    identity            = var.managed_identity_id
  }

  secret {
    name                = "stripe-secret-key"
    key_vault_secret_id = "https://${var.key_vault_name}.vault.azure.net/secrets/stripe-secret-key"
    identity            = var.managed_identity_id
  }

  secret {
    name                = "stripe-webhook-secret"
    key_vault_secret_id = "https://${var.key_vault_name}.vault.azure.net/secrets/stripe-webhook-secret"
    identity            = var.managed_identity_id
  }

  template {
    min_replicas = var.min_replicas
    max_replicas = var.max_replicas

    container {
      name   = "api"
      image  = "${var.acr_login_server}/smartcompare-api:${var.image_tag}"
      cpu    = var.cpu
      memory = var.memory

      # Environment — injected at runtime, NOT baked into the image
      env {
        name  = "ASPNETCORE_ENVIRONMENT"
        value = var.aspnetcore_environment
      }

      env {
        name  = "AZURE_CLIENT_ID"
        value = var.managed_identity_client_id
      }

      env {
        name        = "ConnectionStrings__DefaultConnection"
        secret_name = "db-connection-string"
      }

      env {
        name        = "ApplicationInsights__ConnectionString"
        secret_name = "app-insights-connection-string"
      }

      env {
        name        = "Sentry__Dsn"
        secret_name = "sentry-dsn"
      }

      env {
        name        = "Auth0__ClientSecret"
        secret_name = "auth0-client-secret"
      }

      env {
        name  = "Auth0__Domain"
        value = var.auth0_domain
      }

      env {
        name  = "Auth0__ClientId"
        value = var.auth0_client_id
      }

      env {
        name  = "Auth0__Audience"
        value = var.auth0_audience
      }

      env {
        name        = "Stripe__SecretKey"
        secret_name = "stripe-secret-key"
      }

      env {
        name        = "Stripe__WebhookSecret"
        secret_name = "stripe-webhook-secret"
      }

      env {
        name  = "AiService__BaseUrl"
        value = var.ai_service_url
      }

      env {
        name  = "Frontend__BaseUrl"
        value = var.frontend_base_url
      }

      # CORS allowed origins — same hostname as Frontend.BaseUrl since browser
      # talks to /api/* on the AFD endpoint (same-origin from browser POV).
      env {
        name  = "Cors__FrontendOrigins__0"
        value = var.frontend_base_url
      }

      # Auth0 OIDC sign-in callback path. Must match Auth0 dashboard "Allowed
      # Callback URLs" entry: ${frontend_base_url}/callback
      env {
        name  = "Auth0__Callback"
        value = "/callback"
      }

      # Reject any request that didn't come through our AFD instance.
      # Empty value = middleware is no-op (local dev).
      env {
        name  = "FrontDoor__ExpectedId"
        value = var.front_door_id
      }

      # Liveness probe — restart container if unhealthy
      liveness_probe {
        transport = "HTTP"
        port      = 8080
        path      = "/index.html"

        initial_delay           = 15
        interval_seconds        = 30
        failure_count_threshold = 3
      }

      # Readiness probe — hold traffic until app is ready
      readiness_probe {
        transport = "HTTP"
        port      = 8080
        path      = "/index.html"

        interval_seconds        = 10
        failure_count_threshold = 3
      }
    }
  }

  ingress {
    # API is publicly reachable (so Front Door can route to it). Defense layers:
    #   1. FrontDoorRestrictionMiddleware rejects requests missing/invalid X-Azure-FDID
    #   2. /swagger disabled outside Development (Program.cs)
    #   3. All endpoints require Auth0 cookie auth (controllers default to [Authorize])
    #   4. WAF on Front Door (when on Premium SKU) blocks scanner traffic
    external_enabled = true
    target_port      = 8080
    transport        = "auto"

    traffic_weight {
      percentage      = 100
      latest_revision = true
    }
  }
}
