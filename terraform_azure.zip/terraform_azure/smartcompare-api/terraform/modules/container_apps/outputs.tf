output "environment_id" {
  description = "Resource ID of the Container Apps Environment"
  value       = azurerm_container_app_environment.this.id
}

output "environment_name" {
  description = "Name of the Container Apps Environment"
  value       = azurerm_container_app_environment.this.name
}

output "environment_static_ip" {
  description = "Internal static IP of the Container Apps Environment (App Gateway backend target)"
  value       = azurerm_container_app_environment.this.static_ip_address
}

output "environment_default_domain" {
  description = "Default domain of the Container Apps Environment"
  value       = azurerm_container_app_environment.this.default_domain
}

output "api_container_app_name" {
  description = "Name of the API Container App"
  value       = azurerm_container_app.api.name
}

output "api_latest_revision_fqdn" {
  description = "FQDN of the latest revision of the API Container App"
  value       = azurerm_container_app.api.latest_revision_fqdn
}

output "api_fqdn" {
  description = "Stable FQDN of the API Container App (does not change between revisions)"
  value       = azurerm_container_app.api.ingress[0].fqdn
}
