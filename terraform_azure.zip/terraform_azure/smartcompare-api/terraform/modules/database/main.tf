# ── Database Module ──────────────────────────────────────────────────────────
# Azure SQL Server + Database with Private Endpoint (no public internet access).
# As per architecture: "Private Endpoint, Port 1433, No Public".
# Managed identity is granted db_datareader/db_datawriter via contained user
# (configured separately in SQL — Terraform handles the network/RBAC layer).

resource "azurerm_mssql_server" "this" {
  name                         = "sql-smartcompare-${var.environment}"
  location                     = var.location
  resource_group_name          = var.resource_group_name
  version                      = "12.0"
  administrator_login          = var.admin_login
  administrator_login_password = var.admin_password
  minimum_tls_version          = "1.2"

  # Public access enabled but firewall denies all by default (see firewall_rule below).
  # Production: set to false and use only private endpoint.
  public_network_access_enabled = var.public_network_access_enabled

  azuread_administrator {
    login_username = var.aad_admin_login
    object_id      = var.aad_admin_object_id
    tenant_id      = var.tenant_id
  }

  tags = var.tags
}

# Allow specific IPs through SQL firewall (for Terraform mssql provider running locally).
# In CI/CD with OIDC, the pipeline IP would be added here. In prod, leave empty.
resource "azurerm_mssql_firewall_rule" "allowed_ips" {
  for_each         = var.allowed_ip_ranges
  name             = "allow-${each.key}"
  server_id        = azurerm_mssql_server.this.id
  start_ip_address = each.value
  end_ip_address   = each.value
}

# Allow Azure services (Container Apps in same region) to bypass firewall.
resource "azurerm_mssql_firewall_rule" "azure_services" {
  name             = "AllowAzureServices"
  server_id        = azurerm_mssql_server.this.id
  start_ip_address = "0.0.0.0"
  end_ip_address   = "0.0.0.0"
}

resource "azurerm_mssql_database" "this" {
  name      = "sqldb-smartcompare-${var.environment}"
  server_id = azurerm_mssql_server.this.id
  sku_name  = var.db_sku # GP_S_Gen5_1 (serverless) for dev — auto-pauses when idle

  # Auto-pause after 60 min idle (serverless only) — saves cost in dev
  auto_pause_delay_in_minutes = var.auto_pause_delay_minutes
  min_capacity                = var.min_vcores

  max_size_gb    = var.max_size_gb
  zone_redundant = false # Single AZ for dev

  tags = var.tags
}

# ── Private Endpoint ─────────────────────────────────────────────────────────
resource "azurerm_private_endpoint" "sql" {
  name                = "pe-sql-smartcompare-${var.environment}"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint_subnet_id

  private_service_connection {
    name                           = "psc-sql-smartcompare-${var.environment}"
    private_connection_resource_id = azurerm_mssql_server.this.id
    subresource_names              = ["sqlServer"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "sql-dns-zone-group"
    private_dns_zone_ids = [azurerm_private_dns_zone.sql.id]
  }

  tags = var.tags
}

# Private DNS zone so Container Apps resolve the SQL FQDN to the private IP
resource "azurerm_private_dns_zone" "sql" {
  name                = "privatelink.database.windows.net"
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sql" {
  name                  = "pdns-link-sql-${var.environment}"
  resource_group_name   = var.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.sql.name
  virtual_network_id    = var.vnet_id
  registration_enabled  = false
  tags                  = var.tags
}
