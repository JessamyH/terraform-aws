variable "resource_group_name" {
  type        = string
  description = "Name of the resource group"
}

variable "location" {
  type        = string
  description = "Azure region"
}

variable "environment" {
  type        = string
  description = "Environment name (dev, staging, prod)"
}

variable "vnet_id" {
  type        = string
  description = "VNet ID for Private DNS zone link"
}

variable "private_endpoint_subnet_id" {
  type        = string
  description = "Subnet ID for the SQL Private Endpoint (dedicated PE subnet, not the delegated Container Apps subnet)"
}

variable "admin_login" {
  type        = string
  description = "SQL administrator login name"
  sensitive   = true
}

variable "admin_password" {
  type        = string
  description = "SQL administrator password — stored in state; prefer Key Vault rotation in prod"
  sensitive   = true
}

variable "aad_admin_login" {
  type        = string
  description = "Azure AD admin display name for SQL (e.g. the Entra group name)"
}

variable "aad_admin_object_id" {
  type        = string
  description = "Object ID of the Azure AD admin (user or group)"
}

variable "tenant_id" {
  type        = string
  description = "Azure AD tenant ID"
}

variable "db_sku" {
  type        = string
  description = "Database SKU. Dev: GP_S_Gen5_1 (serverless, auto-pause). Prod: GP_Gen5_2+"
  default     = "GP_S_Gen5_1"
}

variable "auto_pause_delay_minutes" {
  type        = number
  description = "Minutes of inactivity before auto-pause. -1 = disabled. Serverless SKU only."
  default     = 60
}

variable "min_vcores" {
  type        = number
  description = "Minimum vCores for serverless auto-scale. Serverless SKU only."
  default     = 0.5
}

variable "max_size_gb" {
  type        = number
  description = "Maximum database size in GB"
  default     = 32
}

variable "public_network_access_enabled" {
  type        = bool
  description = "Enable public network access. True for dev (Terraform mssql provider needs this). False for prod."
  default     = true
}

variable "allowed_ip_ranges" {
  type        = map(string)
  description = "Map of name -> single IP allowed through SQL firewall (for Terraform mssql provider)"
  default     = {}
}

variable "tags" {
  type        = map(string)
  description = "Resource tags"
  default     = {}
}
