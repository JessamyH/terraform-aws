variable "resource_group_name" {
  type        = string
  description = "Name of the resource group"
}

variable "location" {
  type        = string
  description = "Azure region"
}

variable "environment" {
  type        = string
  description = "Environment name (dev, staging, prod)"
}

variable "sku" {
  type        = string
  description = "ACR SKU: Basic (dev), Standard (staging/prod)"
  default     = "Basic"

  validation {
    condition     = contains(["Basic", "Standard", "Premium"], var.sku)
    error_message = "ACR SKU must be Basic, Standard, or Premium."
  }
}

variable "managed_identity_principal_ids" {
  type        = map(string)
  description = "Map of service name → principal ID for managed identities granted AcrPull"
}

variable "tags" {
  type        = map(string)
  description = "Resource tags"
  default     = {}
}
