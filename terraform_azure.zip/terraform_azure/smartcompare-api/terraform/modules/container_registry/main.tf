# ── Container Registry Module ────────────────────────────────────────────────
# ACR is shared across all three services (api, app, ai).
# Basic SKU for dev (~$8/mo). Upgrade to Standard for geo-replication in prod.
# The managed identity is granted AcrPull so Container Apps can pull images
# without storing credentials.

resource "azurerm_container_registry" "this" {
  # ACR name: lowercase alphanumeric, globally unique, max 50 chars
  name                = "acrsmartcompare${var.environment}"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = var.sku
  admin_enabled       = false # Use managed identity — no admin credentials needed
  tags                = var.tags
}

# Grant AcrPull to each service identity independently
resource "azurerm_role_assignment" "acr_pull" {
  for_each             = toset(var.managed_identity_principal_ids)
  scope                = azurerm_container_registry.this.id
  role_definition_name = "AcrPull"
  principal_id         = each.value
}
