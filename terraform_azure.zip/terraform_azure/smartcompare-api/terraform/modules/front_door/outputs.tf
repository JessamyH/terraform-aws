output "endpoint_hostname" {
  description = "Front Door endpoint hostname — this is the public URL of your app"
  value       = azurerm_cdn_frontdoor_endpoint.this.host_name
}

output "front_door_id" {
  description = "Front Door resource_guid — used as X-Azure-FDID header for origin restriction"
  value       = azurerm_cdn_frontdoor_profile.this.resource_guid
}
