variable "resource_group_name" {
  type = string
}

variable "environment" {
  type = string
}

variable "sku_name" {
  type        = string
  description = "Front Door SKU. Standard_AzureFrontDoor (dev) or Premium_AzureFrontDoor (prod — enables WAF managed rules)."
  default     = "Standard_AzureFrontDoor"

  validation {
    condition     = contains(["Standard_AzureFrontDoor", "Premium_AzureFrontDoor"], var.sku_name)
    error_message = "SKU must be Standard_AzureFrontDoor or Premium_AzureFrontDoor."
  }
}

variable "app_origin_host_name" {
  type        = string
  description = "FQDN of the App (Next.js frontend) Container App — the only public-facing service"
}

variable "tags" {
  type    = map(string)
  default = {}
}
