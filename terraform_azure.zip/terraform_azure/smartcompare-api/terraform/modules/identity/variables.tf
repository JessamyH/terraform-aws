variable "resource_group_name" {
  type        = string
  description = "Name of the resource group"
}

variable "location" {
  type        = string
  description = "Azure region"
}

variable "environment" {
  type        = string
  description = "Environment name (dev, staging, prod)"
}

variable "service_name" {
  type        = string
  description = "Service this identity belongs to: api, ai, app"
}

variable "tags" {
  type        = map(string)
  description = "Resource tags"
  default     = {}
}
