output "managed_identity_id" {
  description = "Full resource ID of the user-assigned managed identity"
  value       = azurerm_user_assigned_identity.this.id
}

output "managed_identity_principal_id" {
  description = "Service principal (object) ID — used for RBAC role assignments"
  value       = azurerm_user_assigned_identity.this.principal_id
}

output "managed_identity_object_id" {
  description = "Alias for principal_id (used in Key Vault access policies)"
  value       = azurerm_user_assigned_identity.this.principal_id
}

output "managed_identity_client_id" {
  description = "Client ID — passed to Container App as AZURE_CLIENT_ID for SDK auth"
  value       = azurerm_user_assigned_identity.this.client_id
}
