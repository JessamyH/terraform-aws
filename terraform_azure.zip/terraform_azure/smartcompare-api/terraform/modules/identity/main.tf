# ── Identity Module ──────────────────────────────────────────────────────────
# User-assigned Managed Identity shared by all Container Apps.
# Using user-assigned (vs system-assigned) means the identity persists if a
# Container App is recreated, and it can be pre-granted roles before the app
# is deployed — important for Key Vault / ACR access at startup.

resource "azurerm_user_assigned_identity" "this" {
  name                = "id-smartcompare-${var.service_name}-${var.environment}"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}
