variable "resource_group_name" {
  type        = string
  description = "Name of the resource group"
}

variable "location" {
  type        = string
  description = "Azure region"
}

variable "environment" {
  type        = string
  description = "Environment name (dev, staging, prod)"
}

variable "subnet_ids" {
  type        = list(string)
  description = "Subnet IDs allowed to access Storage via Service Endpoint"
}

variable "managed_identity_principal_id" {
  type        = string
  description = "Principal ID of the managed identity granted Storage Blob Data Contributor"
}

variable "replication_type" {
  type        = string
  description = "Storage replication type: LRS (dev/staging), GRS (prod)"
  default     = "LRS"

  validation {
    condition     = contains(["LRS", "GRS", "ZRS", "RAGRS", "RAGZRS"], var.replication_type)
    error_message = "Invalid replication type."
  }
}

variable "blob_soft_delete_days" {
  type        = number
  description = "Blob soft-delete retention in days"
  default     = 7
}

variable "allowed_ip_ranges" {
  type        = list(string)
  description = "Public IPs allowed through Storage firewall (for Terraform to create containers)"
  default     = []
}

variable "tags" {
  type        = map(string)
  description = "Resource tags"
  default     = {}
}
