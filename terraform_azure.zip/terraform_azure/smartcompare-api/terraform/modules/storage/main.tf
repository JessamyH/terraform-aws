# ── Storage Module ───────────────────────────────────────────────────────────
# Blob Storage for PDFs and uploaded files (as shown in architecture diagram).
# Accessible only from the private subnet via Service Endpoint — no public internet.
# Managed identity is granted Storage Blob Data Contributor for read/write access.

resource "azurerm_storage_account" "this" {
  # Storage account name: lowercase alphanumeric only, max 24 chars, globally unique
  name                     = "stsmartcompare${var.environment}"
  location                 = var.location
  resource_group_name      = var.resource_group_name
  account_tier             = "Standard"
  account_replication_type = var.replication_type # LRS for dev, GRS for prod
  min_tls_version          = "TLS1_2"

  blob_properties {
    delete_retention_policy {
      days = var.blob_soft_delete_days
    }
  }

  network_rules {
    default_action             = "Deny"
    bypass                     = ["AzureServices"]
    virtual_network_subnet_ids = var.subnet_ids
    ip_rules                   = [for ip in var.allowed_ip_ranges : replace(ip, "/32", "")]
  }

  tags = var.tags
}

resource "azurerm_storage_container" "uploads" {
  name                  = "uploads"
  storage_account_name  = azurerm_storage_account.this.name
  container_access_type = "private"
}

# Managed identity can read/write blobs (no SAS tokens or keys in code)
resource "azurerm_role_assignment" "blob_contributor" {
  scope                = azurerm_storage_account.this.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = var.managed_identity_principal_id
}
