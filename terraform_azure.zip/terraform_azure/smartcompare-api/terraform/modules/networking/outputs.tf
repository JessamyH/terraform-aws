output "vnet_id" {
  description = "ID of the Virtual Network"
  value       = azurerm_virtual_network.this.id
}

output "vnet_name" {
  description = "Name of the Virtual Network"
  value       = azurerm_virtual_network.this.name
}

output "public_subnet_id" {
  description = "ID of the public subnet"
  value       = azurerm_subnet.public.id
}

output "private_subnet_id" {
  description = "ID of the private subnet (Container Apps)"
  value       = azurerm_subnet.private.id
}

output "private_endpoint_subnet_id" {
  description = "ID of the private endpoint subnet (SQL, Storage)"
  value       = azurerm_subnet.private_endpoints.id
}
