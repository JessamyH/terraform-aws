# ── Networking Module ────────────────────────────────────────────────────────
# Creates the Virtual Network, public/private subnets, NSG, NAT Gateway.
# Architecture: public subnet hosts App Gateway; private subnet hosts Container Apps.

resource "azurerm_virtual_network" "this" {
  name                = "vnet-smartcompare-${var.environment}"
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = [var.vnet_address_space]
  tags                = var.tags
}

# Public subnet — App Gateway + NAT Gateway
resource "azurerm_subnet" "public" {
  name                 = "snet-smartcompare-${var.environment}-public"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = [var.public_subnet_cidr]

  service_endpoints = [
    "Microsoft.KeyVault",
    "Microsoft.Storage",
    "Microsoft.Sql",
  ]
}

# Private subnet — Container Apps Environment (delegated, no other resources allowed)
resource "azurerm_subnet" "private" {
  name                 = "snet-smartcompare-${var.environment}-private"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = [var.private_subnet_cidr]

  service_endpoints = [
    "Microsoft.KeyVault",
    "Microsoft.Storage",
    "Microsoft.Sql",
  ]

  delegation {
    name = "container-apps"
    service_delegation {
      name    = "Microsoft.App/environments"
      actions = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
    }
  }
}

# Private endpoint subnet — SQL, Storage private endpoints live here
# Separate from Container Apps subnet (delegated) and public subnet (internet-facing)
resource "azurerm_subnet" "private_endpoints" {
  name                 = "snet-smartcompare-${var.environment}-pe"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = [var.private_endpoint_subnet_cidr]
}

# NSG for the private endpoint subnet — only allow traffic from Container Apps subnet
resource "azurerm_network_security_group" "private_endpoints" {
  name                = "nsg-smartcompare-${var.environment}-pe"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowContainerAppsInbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["1433", "443"]
    source_address_prefix      = var.private_subnet_cidr
    destination_address_prefix = var.private_endpoint_subnet_cidr
  }

  security_rule {
    name                       = "DenyAllInbound"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet_network_security_group_association" "private_endpoints" {
  subnet_id                 = azurerm_subnet.private_endpoints.id
  network_security_group_id = azurerm_network_security_group.private_endpoints.id
}

# NSG for the private subnet — deny all inbound except from App Gateway subnet
resource "azurerm_network_security_group" "private" {
  name                = "nsg-smartcompare-${var.environment}-private"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowAppGatewayInbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["80", "443", "8080", "3000"]
    source_address_prefix      = var.public_subnet_cidr
    destination_address_prefix = var.private_subnet_cidr
  }

  security_rule {
    name                       = "AllowAzureLoadBalancer"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "AzureLoadBalancer"
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "DenyAllInbound"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet_network_security_group_association" "private" {
  subnet_id                 = azurerm_subnet.private.id
  network_security_group_id = azurerm_network_security_group.private.id
}
