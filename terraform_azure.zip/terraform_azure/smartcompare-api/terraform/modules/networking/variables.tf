variable "resource_group_name" {
  type        = string
  description = "Name of the resource group"
}

variable "location" {
  type        = string
  description = "Azure region"
}

variable "environment" {
  type        = string
  description = "Environment name (dev, staging, prod)"
}

variable "vnet_address_space" {
  type        = string
  description = "CIDR for the virtual network"
  default     = "10.0.0.0/8"
}

variable "public_subnet_cidr" {
  type        = string
  description = "CIDR for the public subnet (App Gateway + NAT)"
  default     = "10.0.3.0/24"
}

variable "private_subnet_cidr" {
  type        = string
  description = "CIDR for the private subnet (Container Apps — delegated)"
  default     = "10.0.2.0/24"
}

variable "private_endpoint_subnet_cidr" {
  type        = string
  description = "CIDR for the private endpoint subnet (SQL, Storage private endpoints)"
  default     = "10.0.4.0/24"
}

variable "tags" {
  type        = map(string)
  description = "Resource tags"
  default     = {}
}
