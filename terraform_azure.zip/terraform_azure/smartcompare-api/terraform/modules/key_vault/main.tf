# ── Key Vault Module ─────────────────────────────────────────────────────────
# Stores all secrets (DB connection string, Auth0, Stripe, Sentry, AI URL).
# Access model: RBAC (not legacy access policies) — more granular and auditable.
# The managed identity gets Key Vault Secrets User so Container Apps can read secrets.
# Terraform SP gets Key Vault Secrets Officer so it can write secrets during apply.
# Network: accessible from the private subnet via Service Endpoint (no public internet).

data "azurerm_client_config" "current" {}

resource "azurerm_key_vault" "this" {
  name                       = "kv-smartcompare-${var.environment}"
  location                   = var.location
  resource_group_name        = var.resource_group_name
  tenant_id                  = var.tenant_id
  sku_name                   = "standard"
  enable_rbac_authorization  = true
  soft_delete_retention_days = 7
  purge_protection_enabled   = false # Keep false for dev so TF destroy works cleanly

  network_acls {
    default_action             = "Deny"
    bypass                     = "AzureServices"
    virtual_network_subnet_ids = var.subnet_ids
    # Add your CI/CD runner IP here if Terraform runs outside Azure
    ip_rules = var.allowed_ip_ranges
  }

  tags = var.tags
}

# Each service identity can READ secrets independently
resource "azurerm_role_assignment" "secrets_user" {
  for_each             = var.managed_identity_object_ids
  scope                = azurerm_key_vault.this.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = each.value
}

# Terraform service principal can WRITE secrets (used during terraform apply)
resource "azurerm_role_assignment" "secrets_officer" {
  scope                = azurerm_key_vault.this.id
  role_definition_name = "Key Vault Secrets Officer"
  principal_id         = var.terraform_sp_object_id
}
