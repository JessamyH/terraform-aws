variable "resource_group_name" {
  type        = string
  description = "Name of the resource group"
}

variable "location" {
  type        = string
  description = "Azure region"
}

variable "environment" {
  type        = string
  description = "Environment name (dev, staging, prod)"
}

variable "tenant_id" {
  type        = string
  description = "Azure AD tenant ID"
}

variable "managed_identity_object_ids" {
  type        = map(string)
  description = "Map of service name → object ID for managed identities granted Key Vault Secrets User"
}

variable "terraform_sp_object_id" {
  type        = string
  description = "Object ID of the Terraform service principal granted Key Vault Secrets Officer"
}

variable "subnet_ids" {
  type        = list(string)
  description = "Subnet IDs allowed to access Key Vault via Service Endpoint"
}

variable "vnet_id" {
  type        = string
  description = "VNet ID (used for Private DNS zone link if needed)"
}

variable "allowed_ip_ranges" {
  type        = list(string)
  description = "Public IPs allowed to access Key Vault (e.g. CI/CD runner IPs, developer IPs)"
  default     = []
}

variable "tags" {
  type        = map(string)
  description = "Resource tags"
  default     = {}
}
