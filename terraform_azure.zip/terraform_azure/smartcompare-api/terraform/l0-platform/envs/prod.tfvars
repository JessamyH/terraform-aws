vnet_address_space  = "10.2.0.0/8"
public_subnet_cidr  = "10.2.3.0/24"
private_subnet_cidr = "10.2.2.0/24"
acr_sku             = "Standard"
