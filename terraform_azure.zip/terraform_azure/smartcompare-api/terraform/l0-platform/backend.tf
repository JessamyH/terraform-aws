# ── L0: Platform ─────────────────────────────────────────────────────────────
# Owns: Resource Group, VNet, Subnets, NSG, NAT Gateway.
# These are the slowest-changing resources — touch maybe once per quarter.
#
# Workspace = environment. Switch with:
#   terraform workspace new dev
#   terraform workspace select dev
#   terraform apply
#
# State is stored per workspace automatically by the azurerm backend:
#   dev  → env:/dev/smartcompare-api-l0.tfstate
#   prod → env:/prod/smartcompare-api-l0.tfstate
#
# Bootstrap (one-time, manual):
#   az group create -n rg-smartcompare-tfstate -l australiasoutheast
#   az storage account create -n sttfstatesmartcompare \
#     -g rg-smartcompare-tfstate --sku Standard_LRS --min-tls-version TLS1_2
#   az storage container create -n tfstate --account-name sttfstatesmartcompare

terraform {
  required_version = ">= 1.6"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.100"
    }
  }

  backend "azurerm" {
    resource_group_name  = "rg-smartcompare-tfstate"
    storage_account_name = "sttfstatesmartcompare"
    container_name       = "tfstate"
    key                  = "smartcompare-api-l0.tfstate"
    # Workspace name is auto-prefixed: env:/<workspace>/smartcompare-api-l0.tfstate
  }
}

provider "azurerm" {
  features {
    resource_group {
      prevent_deletion_if_contains_resources = false
    }
  }
}
