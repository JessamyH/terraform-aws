locals {
  environment = terraform.workspace # "dev", "staging", "prod"

  tags = {
    Environment = local.environment
    Project     = "smartcompare"
    ManagedBy   = "terraform"
    Layer       = "l0-platform"
  }
}

resource "azurerm_resource_group" "main" {
  name     = "rg-smartcompare-${local.environment}"
  location = var.location
  tags     = local.tags
}

module "networking" {
  source = "../modules/networking"

  resource_group_name = azurerm_resource_group.main.name
  location            = var.location
  environment         = local.environment
  vnet_address_space  = var.vnet_address_space
  public_subnet_cidr  = var.public_subnet_cidr
  private_subnet_cidr = var.private_subnet_cidr
  tags                = local.tags
}

# ── Container Registry (kept in L0 so images survive L1/L2 destroy) ──────────
resource "azurerm_container_registry" "this" {
  name                = "acrsmartcompare${local.environment}"
  location            = var.location
  resource_group_name = azurerm_resource_group.main.name
  sku                 = var.acr_sku
  admin_enabled       = false
  tags                = local.tags
}
