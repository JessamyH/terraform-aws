variable "location" {
  type        = string
  description = "Azure region."
  default     = "australiaeast" # Sydney
}

variable "vnet_address_space" {
  type        = string
  description = "CIDR for the virtual network."
}

variable "public_subnet_cidr" {
  type        = string
  description = "CIDR for the public subnet (NAT Gateway, App Gateway)."
}

variable "private_subnet_cidr" {
  type        = string
  description = "CIDR for the private subnet (Container Apps, SQL Private Endpoint)."
}

variable "acr_sku" {
  type        = string
  description = "ACR SKU: Basic (dev ~$8/mo), Standard (prod)."
  default     = "Basic"
}
