locals {
  environment = terraform.workspace

  tags = {
    Environment = local.environment
    Project     = "smartcompare"
    ManagedBy   = "terraform"
    Layer       = "l1-services"
  }
}

# ── Read L0 outputs ──────────────────────────────────────────────────────────
data "terraform_remote_state" "l0" {
  backend   = "azurerm"
  workspace = terraform.workspace

  config = {
    resource_group_name  = "rg-smartcompare-tfstate"
    storage_account_name = "sttfstatesmartcompare"
    container_name       = "tfstate"
    key                  = "smartcompare-api-l0.tfstate"
  }
}

data "azurerm_client_config" "current" {}

# ── Managed Identities (one per service — least privilege) ───────────────────
module "identity_api" {
  source = "../modules/identity"

  resource_group_name = data.terraform_remote_state.l0.outputs.resource_group_name
  location            = data.terraform_remote_state.l0.outputs.location
  environment         = local.environment
  service_name        = "api"
  tags                = local.tags
}

module "identity_ai" {
  source = "../modules/identity"

  resource_group_name = data.terraform_remote_state.l0.outputs.resource_group_name
  location            = data.terraform_remote_state.l0.outputs.location
  environment         = local.environment
  service_name        = "ai"
  tags                = local.tags
}

module "identity_app" {
  source = "../modules/identity"

  resource_group_name = data.terraform_remote_state.l0.outputs.resource_group_name
  location            = data.terraform_remote_state.l0.outputs.location
  environment         = local.environment
  service_name        = "app"
  tags                = local.tags
}

# ── ACR Role Assignments (ACR itself lives in L0) ────────────────────────────
resource "azurerm_role_assignment" "acr_pull_api" {
  scope                = data.terraform_remote_state.l0.outputs.acr_id
  role_definition_name = "AcrPull"
  principal_id         = module.identity_api.managed_identity_principal_id
}

resource "azurerm_role_assignment" "acr_pull_ai" {
  scope                = data.terraform_remote_state.l0.outputs.acr_id
  role_definition_name = "AcrPull"
  principal_id         = module.identity_ai.managed_identity_principal_id
}

resource "azurerm_role_assignment" "acr_pull_app" {
  scope                = data.terraform_remote_state.l0.outputs.acr_id
  role_definition_name = "AcrPull"
  principal_id         = module.identity_app.managed_identity_principal_id
}

# ── Monitoring ───────────────────────────────────────────────────────────────
module "monitoring" {
  source = "../modules/monitoring"

  resource_group_name = data.terraform_remote_state.l0.outputs.resource_group_name
  location            = data.terraform_remote_state.l0.outputs.location
  environment         = local.environment
  log_retention_days  = var.log_retention_days
  tags                = local.tags
}

# ── Key Vault ────────────────────────────────────────────────────────────────
module "key_vault" {
  source = "../modules/key_vault"

  resource_group_name        = data.terraform_remote_state.l0.outputs.resource_group_name
  location                   = data.terraform_remote_state.l0.outputs.location
  environment                = local.environment
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  managed_identity_object_ids = {
    api = module.identity_api.managed_identity_object_id
    ai  = module.identity_ai.managed_identity_object_id
    app = module.identity_app.managed_identity_object_id
  }
  terraform_sp_object_id     = data.azurerm_client_config.current.object_id
  subnet_ids = [
    data.terraform_remote_state.l0.outputs.public_subnet_id,
    data.terraform_remote_state.l0.outputs.private_subnet_id,
  ]
  vnet_id                    = data.terraform_remote_state.l0.outputs.vnet_id
  allowed_ip_ranges          = var.kv_allowed_ip_ranges
  tags                       = local.tags
}

# ── Storage ──────────────────────────────────────────────────────────────────
module "storage" {
  source = "../modules/storage"

  resource_group_name           = data.terraform_remote_state.l0.outputs.resource_group_name
  location                      = data.terraform_remote_state.l0.outputs.location
  environment                   = local.environment
  subnet_ids = [
    data.terraform_remote_state.l0.outputs.public_subnet_id,
    data.terraform_remote_state.l0.outputs.private_subnet_id,
  ]
  managed_identity_principal_id = module.identity_api.managed_identity_principal_id
  replication_type              = var.storage_replication_type
  allowed_ip_ranges             = var.kv_allowed_ip_ranges
  tags                          = local.tags
}

# ── Auto-populate Key Vault secrets that Terraform knows ─────────────────────
# App Insights connection string is created by Terraform so we store it automatically.
# All other secrets (Auth0, Stripe, OpenAI, etc.) must be added manually — see README.
resource "azurerm_key_vault_secret" "app_insights_connection_string" {
  name         = "app-insights-connection-string"
  value        = module.monitoring.app_insights_connection_string
  key_vault_id = module.key_vault.id

  # Role assignment propagation in Azure AD can take 30-60s.
  # If first apply fails with 403 on this resource, re-run terraform apply.
  depends_on = [module.key_vault]
}

# DB connection string with the API managed identity's client_id baked in.
# Without `User Id=<client_id>`, .NET can't pick which user-assigned identity to use.
resource "azurerm_key_vault_secret" "db_connection_string" {
  name         = "db-connection-string"
  value        = "Server=${module.database.server_fqdn};Database=${module.database.database_name};Authentication=Active Directory Managed Identity;User Id=${module.identity_api.managed_identity_client_id};Encrypt=True;"
  key_vault_id = module.key_vault.id

  depends_on = [module.key_vault]
}

# ── Database ─────────────────────────────────────────────────────────────────
module "database" {
  source = "../modules/database"

  resource_group_name      = data.terraform_remote_state.l0.outputs.resource_group_name
  location                 = data.terraform_remote_state.l0.outputs.location
  environment              = local.environment
  vnet_id                  = data.terraform_remote_state.l0.outputs.vnet_id
  private_endpoint_subnet_id = data.terraform_remote_state.l0.outputs.private_endpoint_subnet_id
  admin_login              = var.sql_admin_login
  admin_password           = var.sql_admin_password
  aad_admin_login          = var.sql_aad_admin_login
  aad_admin_object_id      = var.sql_aad_admin_object_id
  tenant_id                = data.azurerm_client_config.current.tenant_id
  db_sku                   = var.db_sku
  auto_pause_delay_minutes = var.auto_pause_delay_minutes
  min_vcores               = var.min_vcores
  max_size_gb              = var.max_size_gb
  allowed_ip_ranges        = { for i, ip in var.kv_allowed_ip_ranges : "ip${i}" => replace(ip, "/32", "") }
  tags                     = local.tags
}

# ── SQL Contained Users for Managed Identities ───────────────────────────────
# Each managed identity needs a contained user inside the SQL database to
# actually connect (Azure RBAC is not enough — SQL has its own user table).
# Uses betr-io/mssql provider with AAD auth (the Terraform SP is the SQL admin).
resource "mssql_user" "api" {
  server {
    host = module.database.server_fqdn
    azuread_default_chain_auth {}
  }
  database  = module.database.database_name
  username  = "id-smartcompare-api-${local.environment}"
  # Use client_id (not principal_id) as the SID for managed identity SQL auth
  object_id = module.identity_api.managed_identity_client_id
  roles     = ["db_datareader", "db_datawriter", "db_ddladmin"]

  depends_on = [module.database]
}

resource "mssql_user" "ai" {
  server {
    host = module.database.server_fqdn
    azuread_default_chain_auth {}
  }
  database  = module.database.database_name
  username  = "id-smartcompare-ai-${local.environment}"
  object_id = module.identity_ai.managed_identity_client_id
  roles     = ["db_datareader"]

  depends_on = [module.database]
}

resource "mssql_user" "app" {
  server {
    host = module.database.server_fqdn
    azuread_default_chain_auth {}
  }
  database  = module.database.database_name
  username  = "id-smartcompare-app-${local.environment}"
  object_id = module.identity_app.managed_identity_client_id
  roles     = ["db_datareader"]

  depends_on = [module.database]
}
