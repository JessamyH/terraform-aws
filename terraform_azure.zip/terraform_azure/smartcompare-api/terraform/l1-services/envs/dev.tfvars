log_retention_days       = 30
storage_replication_type = "LRS"
db_sku                   = "GP_S_Gen5_1"
auto_pause_delay_minutes = 60
min_vcores               = 0.5
max_size_gb              = 32
