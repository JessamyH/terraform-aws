log_retention_days       = 90
storage_replication_type = "GRS"
db_sku                   = "GP_Gen5_4"
auto_pause_delay_minutes = -1
min_vcores               = 2
max_size_gb              = 256
