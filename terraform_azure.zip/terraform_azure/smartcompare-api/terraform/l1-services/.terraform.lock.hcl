# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/betr-io/mssql" {
  version     = "0.3.1"
  constraints = "~> 0.3"
  hashes = [
    "h1:hIUTu2tsDcSjM+IfmiKsh9f73Kdh4RwCJC3aLAB+8RA=",
    "zh:0b853146da2fbf003882220109d0bb4db1e65c57994d2fa289c7f25852888288",
    "zh:1ab4b98fd0a8999579d3b097ff826b5855372197a8c6bc8e0f740d0d5c9dfe11",
    "zh:38406c9a689a1a39f95bd1e9dad36708950155010ce022913b4fc072d9d8e3a7",
    "zh:3b468f8f6e5ec046ad33a0fc09315f2edb280f6079ffb56996a558dfb9604ee6",
    "zh:493933c08c2ab40f6d097aefd45c7dbc70eb25401f6fb0a11f4dc7cd7be33604",
    "zh:510a6411f78bb5bd7700acc7d0ae376835010e72abd34a0f09b10d835e1bccfb",
    "zh:5faaeddb17fa583a98c9bf095515e7c4eb946401e2820e2573ae54f91d1b43e2",
    "zh:95ce6d83385acd28474766ab86b03f3055e8e1b3da56f0e0c5314ebd308b4602",
    "zh:b7e8d2a7abf6930e80cdca186e2ed7255533e918a837ee96350d0e19a70fcbfd",
    "zh:badc2a04d591840f242a1e7716a40b0a3596b2f16de5af940f152628809118c7",
    "zh:e53dc9f36e2dd2c8ed6d3f2ce4e9a52fbf6f0ce8c5520ea85ce18f36b49579cd",
    "zh:f65b28f6ab454a992f008714cb846c3da2f23a6b80f585ac5ec77249959e1629",
  ]
}

provider "registry.terraform.io/hashicorp/azurerm" {
  version     = "3.117.1"
  constraints = "~> 3.100"
  hashes = [
    "h1:3c9iOEtBMnHrpJLlhbQ0sCZPWhE/2dvEPcL8KkXAh7w=",
    "zh:0c513676836e3c50d004ece7d2624a8aff6faac14b833b96feeac2e4bc2c1c12",
    "zh:50ea01ada95bae2f187db9e926e463f45d860767a85ebc59160414e00e76c35d",
    "zh:52c2a9edacc06b3f72153f5ef6daca0761c6292158815961fe37f60bc576a3d7",
    "zh:618eed2a06b19b1a025b45b05891846d570a6a1cca4d23f4942f5a99e1f747ae",
    "zh:61cde5d3165d7e5ec311d5d89486819cd605c1b2d54611b5c97bd4e97dba2762",
    "zh:6a873358d5031fc222f5e05f029d1237f3dce8345c767665f393283dfa2627f6",
    "zh:afdd80064b2a04da311856feb4ed45f77ff4df6c356e8c2b10afb51fe7e61c70",
    "zh:b09113df7e0e8c8959539bd22bae6c39faeb269ba3c4cd948e742f5cf58c35fb",
    "zh:d340db7973109761cfc27d52aa02560363337c908b2c99b3628adc5a70a99d5b",
    "zh:d5a577226ebc8c65e8f19384878a86acc4b51ede4b4a82d37c3b331b0efcd4a7",
    "zh:e2962b147f9e71732df8dbc74940c10d20906f3c003cbfaa1eb9fabbf601a9f0",
    "zh:f569b65999264a9416862bca5cd2a6177d94ccb0424f3a4ef424428912b9cb3c",
  ]
}
