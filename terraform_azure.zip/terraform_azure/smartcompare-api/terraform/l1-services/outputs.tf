# ── Per-service managed identities ───────────────────────────────────────────
output "api_managed_identity_id" {
  value = module.identity_api.managed_identity_id
}

output "api_managed_identity_client_id" {
  value = module.identity_api.managed_identity_client_id
}

output "api_managed_identity_principal_id" {
  value = module.identity_api.managed_identity_principal_id
}

output "ai_managed_identity_id" {
  value = module.identity_ai.managed_identity_id
}

output "ai_managed_identity_client_id" {
  value = module.identity_ai.managed_identity_client_id
}

output "ai_managed_identity_principal_id" {
  value = module.identity_ai.managed_identity_principal_id
}

output "app_managed_identity_id" {
  value = module.identity_app.managed_identity_id
}

output "app_managed_identity_client_id" {
  value = module.identity_app.managed_identity_client_id
}

output "app_managed_identity_principal_id" {
  value = module.identity_app.managed_identity_principal_id
}

# ── Shared infrastructure ─────────────────────────────────────────────────────
# Re-exported from L0 so L2/AI/App repos don't need to read L0 directly
output "acr_login_server" {
  value = data.terraform_remote_state.l0.outputs.acr_login_server
}

output "acr_name" {
  value = data.terraform_remote_state.l0.outputs.acr_name
}

output "log_analytics_workspace_id" {
  value = module.monitoring.log_analytics_workspace_id
}

output "app_insights_connection_string" {
  value     = module.monitoring.app_insights_connection_string
  sensitive = true
}

output "key_vault_name" {
  value = module.key_vault.name
}

output "key_vault_uri" {
  value = module.key_vault.vault_uri
}

output "storage_account_name" {
  value = module.storage.storage_account_name
}

output "sql_server_fqdn" {
  value = module.database.server_fqdn
}

output "sql_database_name" {
  value = module.database.database_name
}
