# ── L1: Services ─────────────────────────────────────────────────────────────
# Owns: Managed Identity, ACR, Monitoring, Key Vault, Storage, Database.
# Changes occasionally (new service, scaling tier change).
# Reads L0 outputs via terraform_remote_state.
#
# Usage:
#   terraform workspace select dev
#   terraform apply

terraform {
  required_version = ">= 1.6"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.100"
    }
    mssql = {
      source  = "betr-io/mssql"
      version = "~> 0.3"
    }
  }

  backend "azurerm" {
    resource_group_name  = "rg-smartcompare-tfstate"
    storage_account_name = "sttfstatesmartcompare"
    container_name       = "tfstate"
    key                  = "smartcompare-api-l1.tfstate"
  }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy    = false
      recover_soft_deleted_key_vaults = true
    }
  }
}

provider "mssql" {
  debug = false
}
