# Sensitive values — pass via environment variables, never commit values:
#   export TF_VAR_sql_admin_login="sqladmin"
#   export TF_VAR_sql_admin_password="..."
#   export TF_VAR_sql_aad_admin_object_id="<entra-group-object-id>"

variable "sql_admin_login" {
  type      = string
  sensitive = true
}

variable "sql_admin_password" {
  type      = string
  sensitive = true
}

variable "sql_aad_admin_login" {
  type        = string
  description = "Entra group name for SQL AAD admin (e.g. SmartCompare-Dev-DBAdmins)"
}

variable "sql_aad_admin_object_id" {
  type        = string
  description = "Object ID of the Entra group for SQL AAD admin"
}

variable "kv_allowed_ip_ranges" {
  type        = list(string)
  description = "Public IPs allowed through Key Vault network ACL (dev machines, CI runner IPs)"
  default     = []
}


variable "log_retention_days" {
  type        = number
  description = "Log Analytics workspace retention in days."
  default     = 30
}

variable "storage_replication_type" {
  type        = string
  description = "Storage account replication: LRS (dev), GRS (prod)."
  default     = "LRS"
}

variable "db_sku" {
  type        = string
  description = "Azure SQL SKU. Serverless GP_S_Gen5_1 for dev (auto-pauses), provisioned for prod."
  default     = "GP_S_Gen5_1"
}

variable "auto_pause_delay_minutes" {
  type        = number
  description = "Minutes of inactivity before serverless DB auto-pauses. -1 = disabled."
  default     = 60
}

variable "min_vcores" {
  type        = number
  description = "Minimum vCores for serverless DB."
  default     = 0.5
}

variable "max_size_gb" {
  type        = number
  description = "Maximum database size in GB."
  default     = 32
}
