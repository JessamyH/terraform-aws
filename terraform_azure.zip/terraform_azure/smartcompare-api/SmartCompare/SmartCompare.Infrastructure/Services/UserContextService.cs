﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SmartCompare.Application.Interfaces;
using System.Security.Claims;

namespace SmartCompare.Infrastructure.Services
{
    public sealed class UserContextService : IUserContextService
    {
        private const string ClaimEmail = "email";
        private const string ClaimName = "name";
        private const string ClaimPicture = "picture";

        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger<UserContextService> _logger;

        public UserContextService(
            IHttpContextAccessor httpContextAccessor,
            ILogger<UserContextService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
        }

        private ClaimsPrincipal? CurrentUser => _httpContextAccessor.HttpContext?.User;

        public bool IsAuthenticated()
            => CurrentUser?.Identity?.IsAuthenticated == true;

        public string GetRequiredAuth0SubjectId()
        {
            var httpContext = _httpContextAccessor.HttpContext;
            var httpMethod = httpContext?.Request.Method ?? "Unknown";
            var requestPath = httpContext?.Request.Path.Value ?? "Unknown";
            

            if (!IsAuthenticated())
            {
                _logger.LogWarning("Unauthorized access: Subject ID claim requested but user not authenticated. Endpoint: {HttpMethod} {RequestPath}",
                    httpMethod,
                    requestPath);
                throw new UnauthorizedAccessException("User is not authenticated.");
            }

            var subjectId = GetClaimValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrWhiteSpace(subjectId))
            {
                _logger.LogError("CRITICAL: Authenticated user missing '{Claim}' claim. Endpoint: {HttpMethod} {RequestPath}",
                    ClaimTypes.NameIdentifier,
                    httpMethod,
                    requestPath);
                throw new UnauthorizedAccessException("User subject ID (NameIdentifier claim) is missing.");
            }

            return subjectId;
        }

        public string? GetEmail() => GetClaimValue(ClaimEmail);

        public string? GetName() => GetClaimValue(ClaimName);

        public string? GetPicture() => GetClaimValue(ClaimPicture);

        private string? GetClaimValue(string claimType)
            => CurrentUser?.FindFirst(claimType)?.Value;
    }
}
