using System.Net;
using Microsoft.Extensions.Logging;
using SmartCompare.Application.Interfaces;

namespace SmartCompare.Infrastructure.Services;

public sealed class LogoDownloadService : ILogoDownloadService
{
    private const int MaxLogoSizeBytes = 5 * 1024 * 1024; // 5 MB

    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<LogoDownloadService> _logger;

    public LogoDownloadService(
        IHttpClientFactory httpClientFactory,
        ILogger<LogoDownloadService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }

    public async Task<byte[]?> DownloadLogoAsync(string? logoUrl, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrEmpty(logoUrl) || !Uri.TryCreate(logoUrl, UriKind.Absolute, out var uri))
            return null;

        if (uri.Scheme != Uri.UriSchemeHttps && uri.Scheme != Uri.UriSchemeHttp)
            return null;

        if (!IsAllowedHost(uri))
        {
            _logger.LogWarning("Logo URL host {Host} is blocked (private/reserved address)", uri.Host);
            return null;
        }

        try
        {
            using var client = _httpClientFactory.CreateClient("LogoDownload");
            using var response = await client.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
            response.EnsureSuccessStatusCode();

            if (response.Content.Headers.ContentLength > MaxLogoSizeBytes)
            {
                _logger.LogWarning("Logo at {LogoUrl} exceeds max size ({Size} bytes)", logoUrl, response.Content.Headers.ContentLength);
                return null;
            }

            using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
            using var memoryStream = new MemoryStream();
            var buffer = new byte[8192];
            var totalBytesRead = 0;
            int bytesRead;

            while ((bytesRead = await stream.ReadAsync(buffer, cancellationToken)) > 0)
            {
                totalBytesRead += bytesRead;
                if (totalBytesRead > MaxLogoSizeBytes)
                {
                    _logger.LogWarning("Logo download from {LogoUrl} exceeded {MaxSize} byte limit", logoUrl, MaxLogoSizeBytes);
                    return null;
                }
                memoryStream.Write(buffer, 0, bytesRead);
            }

            return memoryStream.ToArray();
        }
        catch (HttpRequestException ex)
        {
            _logger.LogWarning(ex, "Failed to download logo from {LogoUrl}", logoUrl);
            return null;
        }
        catch (TaskCanceledException ex) when (!cancellationToken.IsCancellationRequested)
        {
            _logger.LogWarning(ex, "Logo download timed out for {LogoUrl}", logoUrl);
            return null;
        }
    }

    private static bool IsAllowedHost(Uri uri)
    {
        if (IPAddress.TryParse(uri.Host, out var ip) && IsPrivateOrReservedIp(ip))
            return false;

        // Block cloud metadata endpoints
        if (uri.Host is "169.254.169.254" or "metadata.google.internal" or "metadata.azure.com")
            return false;

        return true;
    }

    private static bool IsPrivateOrReservedIp(IPAddress ip)
    {
        if (IPAddress.IsLoopback(ip))
            return true;

        if (ip.IsIPv6LinkLocal || ip.IsIPv6SiteLocal)
            return true;

        // Extract IPv4 from IPv4-mapped IPv6 (e.g., ::ffff:169.254.169.254)
        if (ip.IsIPv4MappedToIPv6)
            ip = ip.MapToIPv4();

        var bytes = ip.GetAddressBytes();
        if (bytes.Length != 4)
            return true; // Block unknown address families

        return bytes[0] == 0 ||                                           // 0.0.0.0/8
               bytes[0] == 10 ||                                          // 10.0.0.0/8
               (bytes[0] == 100 && bytes[1] >= 64 && bytes[1] <= 127) ||  // 100.64.0.0/10 (CGNAT)
               bytes[0] == 127 ||                                         // 127.0.0.0/8
               (bytes[0] == 169 && bytes[1] == 254) ||                    // 169.254.0.0/16
               (bytes[0] == 172 && bytes[1] >= 16 && bytes[1] <= 31) ||   // 172.16.0.0/12
               (bytes[0] == 192 && bytes[1] == 168);                      // 192.168.0.0/16
    }
}
