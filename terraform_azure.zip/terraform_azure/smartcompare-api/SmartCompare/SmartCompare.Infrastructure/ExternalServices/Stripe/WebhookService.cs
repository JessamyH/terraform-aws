using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SharedKernel.Errors;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.PaymentAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Enums;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.SharedKernel.Results;
using Stripe;

namespace SmartCompare.Infrastructure.ExternalServices.Stripe;

/// <summary>
/// Handles Stripe webhook events for subscription lifecycle management.
/// <para>
/// Supported events:
/// <list type="bullet">
///   <item><c>invoice.paid</c> — record successful payment, create/renew/upgrade subscription</item>
///   <item><c>invoice.payment_failed</c> — record failed payment attempt (subscription status untouched)</item>
///   <item><c>customer.subscription.deleted</c> — cancel subscription, downgrade user to Free tier</item>
/// </list>
/// </para>
/// <para>
/// Idempotency: Each handler checks <c>StripeInvoiceId</c> (backed by a unique DB index) before
/// creating payment records. Duplicate deliveries are logged and acknowledged.
/// </para>
/// <para>
/// Error policy: Permanent errors (user not found, unknown price) return <see cref="Result.Success()"/>
/// to acknowledge receipt and prevent Stripe retry storms. These are logged at Error/Warning level
/// for manual investigation.
/// </para>
/// </summary>
public sealed class StripeWebhookService : IStripeWebhookService
{
    private readonly StripeOptions _options;
    private readonly IStripePriceResolver _priceResolver;
    private readonly IPaymentRepository _paymentRepository;
    private readonly IUserRepository _userRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<StripeWebhookService> _logger;

    public StripeWebhookService(
        IOptions<StripeOptions> options,
        IStripePriceResolver priceResolver,
        IPaymentRepository paymentRepository,
        IUserRepository userRepository,
        IUnitOfWork unitOfWork,
        ILogger<StripeWebhookService> logger)
    {
        _options = options.Value;
        _priceResolver = priceResolver;
        _paymentRepository = paymentRepository;
        _userRepository = userRepository;
        _unitOfWork = unitOfWork;
        _logger = logger;
    }

    /// <inheritdoc />
    public async Task<Result> HandleWebhookAsync(
        string json,
        string signatureHeader,
        CancellationToken cancellationToken = default)
    {
        Event stripeEvent;
        try
        {
            stripeEvent = EventUtility.ConstructEvent(json, signatureHeader, _options.WebhookSecret);
        }
        catch (StripeException ex)
        {
            _logger.LogWarning(ex, "Stripe webhook signature verification failed");
            return Result.Failure(new Error(ErrorType.Validation, "Invalid webhook signature."));
        }

        switch (stripeEvent.Type)
        {
            case EventTypes.InvoicePaid:
                if (stripeEvent.Data.Object is not Invoice paidInvoice)
                {
                    _logger.LogError("Event {EventId} expected Invoice but got {Type}",
                        stripeEvent.Id, stripeEvent.Data.Object?.GetType().Name);
                    return Result.Success();
                }
                return await HandleInvoicePaid(paidInvoice, stripeEvent.Id, stripeEvent.Type, cancellationToken);

            case EventTypes.InvoicePaymentFailed:
                if (stripeEvent.Data.Object is not Invoice failedInvoice)
                {
                    _logger.LogError("Event {EventId} expected Invoice but got {Type}",
                        stripeEvent.Id, stripeEvent.Data.Object?.GetType().Name);
                    return Result.Success();
                }
                return await HandleInvoicePaymentFailed(failedInvoice, stripeEvent.Id, stripeEvent.Type, cancellationToken);

            case EventTypes.CustomerSubscriptionDeleted:
                if (stripeEvent.Data.Object is not global::Stripe.Subscription subscription)
                {
                    _logger.LogError("Event {EventId} expected Subscription but got {Type}",
                        stripeEvent.Id, stripeEvent.Data.Object?.GetType().Name);
                    return Result.Success();
                }
                return await HandleSubscriptionDeleted(subscription, stripeEvent.Id, stripeEvent.Type, cancellationToken);

            default:
                _logger.LogInformation("Unhandled Stripe event type: {EventType}", stripeEvent.Type);
                return Result.Success();
        }
    }

    // ─── invoice.paid ───────────────────────────────────────────────

    /// <summary>
    /// Records a successful payment and updates the user's subscription.
    /// <para>
    /// Flow:
    /// 1. Idempotency — skip if a Succeeded payment already exists for this InvoiceId.
    /// 2. Validation — extract subscription line item, resolve price ID (all before writes).
    /// 3. Payment — mark existing record as succeeded, or create a new one.
    /// 4. Subscription — if StripeSubscriptionId changed: new/upgrade/downgrade (full update);
    ///    if same: renewal (extend period only via <see cref="Subscription.Renew"/>).
    /// </para>
    /// </summary>
    private async Task<Result> HandleInvoicePaid(Invoice invoice, string eventId, string eventType, CancellationToken cancellationToken)
    {
        var existingPayment = await _paymentRepository.GetByStripeInvoiceIdAsync(
            invoice.Id, cancellationToken);

        // Idempotency: already processed successfully
        if (existingPayment?.Status == PaymentStatus.Succeeded)
        {
            _logger.LogInformation("Invoice {InvoiceId} already processed, skipping", invoice.Id);
            return Result.Success();
        }

        // ── Validation phase (all checks before any writes) ──

        var lineItem = ExtractSubscriptionLineItem(invoice);
        if (lineItem is null)
        {
            _logger.LogWarning("Invoice {InvoiceId} has no subscription line item, skipping", invoice.Id);
            return Result.Success();
        }

        var user = await TryGetUserAsync(invoice.CustomerId, eventId, eventType, cancellationToken);
        if (user is null) return Result.Success();

        if (user.Subscription is null)
        {
            _logger.LogError("User {UserId} has no subscription for invoice {InvoiceId}",
                user.Id, invoice.Id);
            return Result.Success();
        }

        var resolved = lineItem.PriceId is not null ? _priceResolver.Resolve(lineItem.PriceId) : null;
        var isNewSubscription = user.Subscription.StripeSubscriptionId != lineItem.SubscriptionId;

        // New subscription always needs a valid price; renewal/upgrade can proceed without
        // (falls back to period-only renewal if price is unresolvable)
        if (isNewSubscription && resolved is null)
        {
            _logger.LogWarning("Cannot resolve Price {PriceId} to tier/duration, skipping", lineItem.PriceId);
            return Result.Success();
        }

        // ── Write phase (all validation passed) ──

        if (existingPayment != null)
        {
            existingPayment.MarkAsSucceeded();
            _logger.LogInformation("Payment {PaymentId} marked as succeeded for Invoice {InvoiceId}",
                existingPayment.Id, invoice.Id);
        }
        else
        {
            var payment = Payment.Create(
                amount: invoice.AmountPaid / 100m,
                currency: invoice.Currency ?? "aud",
                status: PaymentStatus.Succeeded,
                type: PaymentType.Subscription,
                stripeInvoiceId: invoice.Id,
                subscriptionId: user.Subscription.Id,
                paidAt: invoice.StatusTransitions?.PaidAt ?? DateTime.UtcNow,
                description: lineItem.Description);

            await _paymentRepository.AddAsync(payment, cancellationToken);
            _logger.LogInformation("Payment created for Invoice {InvoiceId}, User: {UserId}",
                invoice.Id, user.Id);
        }

        var periodStart = lineItem.PeriodStart ?? DateTime.UtcNow;
        var duration = resolved?.Duration ?? user.Subscription.SubscriptionDuration;
        var fallbackEnd = duration == SubscriptionDuration.Year
            ? DateTime.UtcNow.AddYears(1)
            : DateTime.UtcNow.AddMonths(1);
        var periodEnd = lineItem.PeriodEnd ?? fallbackEnd;

        if (isNewSubscription)
        {
            user.AddSubscription(
                subscriptionTier: resolved!.Value.Tier,
                subscriptionDuration: resolved!.Value.Duration,
                subscriptionStatus: SubscriptionStatus.Active,
                startDate: periodStart,
                endDate: periodEnd,
                stripeSubscriptionId: lineItem.SubscriptionId);

            _logger.LogInformation("Subscription created {Tier}/{Duration} for User {UserId}",
                resolved!.Value.Tier, resolved!.Value.Duration, user.Id);
        }
        else if (resolved is not null &&
                 (resolved.Value.Tier != user.Subscription.SubscriptionTier ||
                  resolved.Value.Duration != user.Subscription.SubscriptionDuration))
        {
            user.Subscription.Update(
                subscriptionTier: resolved.Value.Tier,
                subscriptionDuration: resolved.Value.Duration,
                subscriptionStatus: SubscriptionStatus.Active,
                startDate: periodStart,
                endDate: periodEnd,
                stripeSubscriptionId: lineItem.SubscriptionId);

            _logger.LogInformation("Subscription changed from {OldTier}/{OldDuration} to {NewTier}/{NewDuration} for User {UserId}",
                user.Subscription.SubscriptionTier, user.Subscription.SubscriptionDuration,
                resolved.Value.Tier, resolved.Value.Duration, user.Id);
        }
        else
        {
            user.Subscription.Renew(periodStart, periodEnd);

            _logger.LogInformation("Subscription renewed until {EndDate} for User {UserId}",
                periodEnd, user.Id);
        }

        _logger.LogInformation(
            "Invoice paid: {InvoiceId}, Subscription: {SubscriptionId}, User: {UserId}",
            invoice.Id, lineItem.SubscriptionId, user.Id);

        return await SaveChangesWithIdempotencyAsync(invoice.Id, cancellationToken);
    }

    // ─── invoice.payment_failed ─────────────────────────────────────

    /// <summary>
    /// Records a failed payment attempt. Subscription status is intentionally left unchanged —
    /// Stripe will retry the charge automatically; permanent failures eventually trigger
    /// <c>customer.subscription.deleted</c>.
    /// <para>
    /// Note: Uses <c>invoice.AmountDue</c> (not <c>AmountPaid</c>) because the paid amount is 0 on failure.
    /// </para>
    /// </summary>
    private async Task<Result> HandleInvoicePaymentFailed(Invoice invoice, string eventId, string eventType, CancellationToken cancellationToken)
    {
        var existingPayment = await _paymentRepository.GetByStripeInvoiceIdAsync(
            invoice.Id, cancellationToken);

        // A later invoice.paid already succeeded — ignore stale failure
        if (existingPayment?.Status == PaymentStatus.Succeeded)
        {
            _logger.LogInformation("Invoice {InvoiceId} already succeeded, skipping failed event",
                invoice.Id);
            return Result.Success();
        }

        var user = await TryGetUserAsync(invoice.CustomerId, eventId, eventType, cancellationToken);
        if (user is null) return Result.Success();

        if (user.Subscription is null)
        {
            _logger.LogError("User {UserId} has no subscription for invoice {InvoiceId}",
                user.Id, invoice.Id);
            return Result.Success();
        }

        var failureReason = invoice.LastFinalizationError?.Message;

        if (existingPayment != null)
        {
            existingPayment.MarkAsFailed(failureReason);
            _logger.LogWarning("Payment {PaymentId} marked as failed for Invoice {InvoiceId}: {Reason}",
                existingPayment.Id, invoice.Id, failureReason);
        }
        else
        {
            var payment = Payment.Create(
                amount: invoice.AmountDue / 100m,
                currency: invoice.Currency ?? "aud",
                status: PaymentStatus.Failed,
                type: PaymentType.Subscription,
                stripeInvoiceId: invoice.Id,
                subscriptionId: user.Subscription.Id,
                description: failureReason);

            await _paymentRepository.AddAsync(payment, cancellationToken);
            _logger.LogWarning("Failed payment created for Invoice {InvoiceId}, User: {UserId}: {Reason}",
                invoice.Id, user.Id, failureReason);
        }

        return await SaveChangesWithIdempotencyAsync(invoice.Id, cancellationToken);
    }

    // ─── customer.subscription.deleted ──────────────────────────────

    /// <summary>
    /// Cancels the user's subscription and downgrades to Free tier.
    /// <para>
    /// Idempotency: <see cref="Subscription.Cancel"/> sets <c>StripeSubscriptionId = null</c>,
    /// so re-delivered events are detected by checking <c>Status == Cancelled &amp;&amp; StripeSubscriptionId is null</c>.
    /// </para>
    /// </summary>
    private async Task<Result> HandleSubscriptionDeleted(
        global::Stripe.Subscription subscription,
        string eventId, string eventType,
        CancellationToken cancellationToken)
    {
        var user = await TryGetUserAsync(subscription.CustomerId, eventId, eventType, cancellationToken);
        if (user is null) return Result.Success();

        var sub = user.Subscription;

        if (sub is null)
        {
            _logger.LogWarning("User {UserId} has no subscription, skipping deletion of {SubscriptionId}",
                user.Id, subscription.Id);
            return Result.Success();
        }

        if (sub.StripeSubscriptionId == subscription.Id)
        {
            sub.Cancel();
            _logger.LogInformation("Subscription {SubscriptionId} cancelled, User {UserId} downgraded to Free",
                subscription.Id, user.Id);
        }
        else if (sub.SubscriptionStatus == SubscriptionStatus.Cancelled && sub.StripeSubscriptionId is null)
        {
            _logger.LogInformation("Subscription {SubscriptionId} already cancelled for User {UserId}, skipping",
                subscription.Id, user.Id);
        }
        else
        {
            _logger.LogWarning("Subscription {SubscriptionId} not matched current {CurrentSubscriptionId} on User {UserId}, skipping",
                subscription.Id, sub.StripeSubscriptionId, user.Id);
        }

        await _unitOfWork.SaveChangesAsync(cancellationToken);
        return Result.Success();
    }

    // ─── Shared helpers ─────────────────────────────────────────────

    /// <summary>
    /// Persists changes, treating unique-key violations as idempotent success (concurrent webhook delivery).
    /// </summary>
    private async Task<Result> SaveChangesWithIdempotencyAsync(string invoiceId, CancellationToken cancellationToken)
    {
        try
        {
            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException ex) when (ex.InnerException is SqlException { Number: 2601 or 2627 })
        {
            _logger.LogWarning("Duplicate payment for invoice {InvoiceId}, treating as idempotent", invoiceId);
        }

        return Result.Success();
    }

    /// <summary>
    /// Looks up a user by Stripe customer ID. Returns <c>null</c> (instead of throwing) when
    /// not found, because a missing user is a permanent error — retrying the webhook won't help.
    /// Logs at Error level with full event context for manual investigation.
    /// </summary>
    private async Task<User?> TryGetUserAsync(
        string stripeCustomerId, string eventId, string eventType, CancellationToken cancellationToken)
    {
        var user = await _userRepository.GetByStripeCustomerIdWithSubscriptionAsync(
            stripeCustomerId, cancellationToken);

        if (user is null)
            _logger.LogError(
                "No user found for Stripe Customer {CustomerId}. Event {EventType} ({EventId}) skipped. Data inconsistency.",
                stripeCustomerId, eventType, eventId);

        return user;
    }

    /// <summary>
    /// Extracted subscription details from an invoice line item.
    /// </summary>
    private sealed record SubscriptionLineItem(
        string SubscriptionId,
        string? PriceId,
        DateTime? PeriodStart,
        DateTime? PeriodEnd,
        string? Description);

    /// <summary>
    /// Extracts subscription info from the first subscription-related line item on the invoice.
    /// <para>
    /// Field paths are for Stripe API version 2026-01-28 (clover):
    /// <list type="bullet">
    ///   <item>Subscription ID: <c>line.Parent.SubscriptionItemDetails.Subscription</c></item>
    ///   <item>Price ID: <c>line.Pricing.PriceDetails.Price</c></item>
    /// </list>
    /// </para>
    /// </summary>
    private static SubscriptionLineItem? ExtractSubscriptionLineItem(Invoice invoice)
    {
        if (invoice.Lines?.Data is null) return null;

        foreach (var line in invoice.Lines.Data)
        {
            var subId = line.Parent?.SubscriptionItemDetails?.Subscription;
            if (string.IsNullOrEmpty(subId)) continue;

            return new SubscriptionLineItem(
                SubscriptionId: subId,
                PriceId: line.Pricing?.PriceDetails?.Price,
                PeriodStart: line.Period?.Start,
                PeriodEnd: line.Period?.End,
                Description: line.Description);
        }

        return null;
    }
}
