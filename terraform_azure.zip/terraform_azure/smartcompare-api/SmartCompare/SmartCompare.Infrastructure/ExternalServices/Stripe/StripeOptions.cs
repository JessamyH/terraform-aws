﻿namespace SmartCompare.Infrastructure.ExternalServices.Stripe;

public class StripeOptions
{
    public const string SectionName = "Stripe";

    public string SecretKey { get; set; } = string.Empty;
    public string PublishableKey { get; set; } = string.Empty;
    public string WebhookSecret { get; set; } = string.Empty;
    public string SuccessUrl { get; set; } = string.Empty;
    public string CancelUrl { get; set; } = string.Empty;

    public string BasicMonthlyPriceId { get; set; } = string.Empty;
    public string BasicYearlyPriceId { get; set; } = string.Empty;
    public string ProMonthlyPriceId { get; set; } = string.Empty;
    public string ProYearlyPriceId { get; set; } = string.Empty;
}