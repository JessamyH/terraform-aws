﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SharedKernel.Errors;
using SmartCompare.SharedKernel.Results;
using SmartCompare.Application.DTOs.Payment;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Enums;
using Stripe;
using Stripe.Checkout;

namespace SmartCompare.Infrastructure.ExternalServices.Stripe;

/// <summary>
/// Manages Stripe Checkout Sessions for subscription payments.
/// Handles session creation with configured Stripe Price IDs and session status retrieval.
/// </summary>
public class CheckoutSessionService : ICheckoutSessionService
{
    private readonly IStripeCustomerService _customerService;
    private readonly IStripePriceResolver _priceResolver;
    private readonly StripeOptions _options;
    private readonly ILogger<CheckoutSessionService> _logger;
    private readonly SessionService _sessionService;

    public CheckoutSessionService(
        IStripeCustomerService customerService,
        IStripePriceResolver priceResolver,
        IOptions<StripeOptions> options,
        ILogger<CheckoutSessionService> logger,
        IStripeClient stripeClient)
    {
        _customerService = customerService;
        _priceResolver = priceResolver;
        _options = options.Value;
        _logger = logger;
        _sessionService = new SessionService(stripeClient);
    }

    /// <inheritdoc />
    public async Task<Result<CheckoutSessionResponseDto>> CreateCheckoutSessionAsync(
        string auth0SubjectId,
        SubscriptionTier tier,
        SubscriptionDuration duration,
        CancellationToken cancellationToken = default)
    {
        var customerResult = await _customerService.GetOrCreateCustomerAsync(
            auth0SubjectId, cancellationToken);

        if (!customerResult.Succeed)
            return Result.Failure<CheckoutSessionResponseDto>(customerResult.Error!);

        var priceId = _priceResolver.GetPriceId(tier, duration);
        if (priceId is null)
            return Result.Failure<CheckoutSessionResponseDto>(
                new Error(ErrorType.Validation, $"No Stripe Price configured for {tier}/{duration}"));

        try
        {
            var session = await _sessionService.CreateAsync(new SessionCreateOptions
            {
                Customer = customerResult.Value,
                Mode = "subscription",
                LineItems = new List<SessionLineItemOptions>
                {
                    new() { Price = priceId, Quantity = 1 }
                },
                SuccessUrl = _options.SuccessUrl,
                CancelUrl = _options.CancelUrl,
            }, cancellationToken: cancellationToken);

            _logger.LogInformation(
                "Created Checkout Session {SessionId} for Customer {CustomerId}, Plan: {Tier}/{Duration}",
                session.Id, customerResult.Value, tier, duration);

            return Result.Success(new CheckoutSessionResponseDto(session.Id, session.Url));
        }
        catch (StripeException ex)
        {
            _logger.LogError(ex,
                "Stripe API error creating checkout session for {Auth0SubjectId}: {StripeErrorCode}",
                auth0SubjectId, ex.StripeError?.Code);
            return Result.Failure<CheckoutSessionResponseDto>(
                new Error(ErrorType.Unexpected, ex.StripeError?.Message ?? "Failed to create checkout session."));
        }
    }

    /// <inheritdoc />
    public async Task<Result<CheckoutSessionStatusDto>> GetSessionStatusAsync(
        string sessionId,
        string stripeCustomerId,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var session = await _sessionService.GetAsync(sessionId, cancellationToken: cancellationToken);
            
            if (session.CustomerId != stripeCustomerId)
                return Result.Failure<CheckoutSessionStatusDto>(
                    new Error(ErrorType.Forbidden, "Session does not belong to current user."));

            return Result.Success(new CheckoutSessionStatusDto(
                session.Id,
                session.Status,
                session.PaymentStatus,
                session.CustomerDetails?.Email));
        }
        catch (StripeException ex)
        {
            _logger.LogError(ex,
                "Stripe API error getting session status {SessionId}: {StripeErrorCode}",
                sessionId, ex.StripeError?.Code);
            return Result.Failure<CheckoutSessionStatusDto>(
                new Error(ErrorType.Unexpected, ex.StripeError?.Message ?? "Failed to retrieve session status."));
        }
    }

}