﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.SharedKernel.Results;
using Stripe;

namespace SmartCompare.Infrastructure.ExternalServices.Stripe;

/// <summary>
/// Manages Stripe Customer creation and retrieval.
/// Ensures each SmartCompare user has a corresponding Stripe Customer for payment processing.
/// Uses IdempotencyKey to prevent duplicate Stripe customers and optimistic concurrency
/// on StripeCustomerId to handle race conditions at the database level.
/// </summary>
public class StripeCustomerService : IStripeCustomerService
{
    private readonly IUserRepository _userRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<StripeCustomerService> _logger;
    private readonly CustomerService _customerService;

    public StripeCustomerService(
        IUserRepository userRepository,
        IUnitOfWork unitOfWork,
        ILogger<StripeCustomerService> logger,
        IStripeClient stripeClient)
    {
        _userRepository = userRepository;
        _unitOfWork = unitOfWork;
        _logger = logger;
        _customerService = new CustomerService(stripeClient);
    }

    /// <inheritdoc />
    public async Task<Result<string>> GetOrCreateCustomerAsync(
        string auth0SubjectId,
        CancellationToken cancellationToken = default)
    {
        var user = await _userRepository.GetBySubjectIdAsync(auth0SubjectId, cancellationToken);
        if (user is null)
            return Result.Failure<string>(
                new Error(ErrorType.NotFound, $"User not found for Auth0SubjectId: {auth0SubjectId}"));

        if (!string.IsNullOrEmpty(user.StripeCustomerId))
            return Result.Success<string>(user.StripeCustomerId!);

        try
        {
            var customer = await _customerService.CreateAsync(
                new CustomerCreateOptions
                {
                    Email = user.Email.Value,
                    Name = user.UserName,
                    Metadata = new Dictionary<string, string>
                    {
                        { "auth0_subject_id", auth0SubjectId },
                        { "smartcompare_user_id", user.Id.ToString() },
                    }
                },
                new RequestOptions
                {
                    IdempotencyKey = $"create-customer-{user.Id}"
                },
                cancellationToken);

            user.SetStripeCustomerId(customer.Id);
            await _unitOfWork.SaveChangesAsync(cancellationToken);

            _logger.LogInformation(
                "Created Stripe Customer {StripeCustomerId} for User {UserId}",
                customer.Id,
                user.Id);

            return Result.Success<string>(customer.Id);
        }
        catch (DbUpdateConcurrencyException)
        {
            _logger.LogWarning(
                "Concurrency conflict for user {Auth0SubjectId}. Another request already created the Stripe customer. Retrying read.",
                auth0SubjectId);

            var refreshedUser = await _userRepository.GetBySubjectIdAsync(auth0SubjectId, cancellationToken);
            if (refreshedUser?.StripeCustomerId is not null)
                return Result.Success<string>(refreshedUser.StripeCustomerId);

            return Result.Failure<string>(
                new Error(ErrorType.Unexpected, "Concurrency conflict and unable to retrieve Stripe customer."));
        }
        catch (StripeException ex)
        {
            _logger.LogError(ex,
                "Stripe API error creating customer for user {Auth0SubjectId}: {StripeErrorCode}",
                auth0SubjectId,
                ex.StripeError?.Code);
            return Result.Failure<string>(
                new Error(ErrorType.Unexpected, ex.StripeError?.Message ?? "Failed to create Stripe customer."));
        }
    }
}