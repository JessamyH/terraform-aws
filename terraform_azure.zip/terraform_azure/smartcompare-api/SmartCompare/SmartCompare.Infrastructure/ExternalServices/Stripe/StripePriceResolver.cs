using Microsoft.Extensions.Options;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Enums;

namespace SmartCompare.Infrastructure.ExternalServices.Stripe;

/// <summary>
/// Resolves Stripe Price IDs using values from <see cref="StripeOptions"/> configuration.
/// </summary>
public sealed class StripePriceResolver : IStripePriceResolver
{
    private readonly StripeOptions _options;

    public StripePriceResolver(IOptions<StripeOptions> options)
    {
        _options = options.Value;
    }

    /// <inheritdoc />
    public string? GetPriceId(SubscriptionTier tier, SubscriptionDuration duration)
    {
        return (tier, duration) switch
        {
            (SubscriptionTier.Basic, SubscriptionDuration.Month) => _options.BasicMonthlyPriceId,
            (SubscriptionTier.Basic, SubscriptionDuration.Year) => _options.BasicYearlyPriceId,
            (SubscriptionTier.Pro, SubscriptionDuration.Month) => _options.ProMonthlyPriceId,
            (SubscriptionTier.Pro, SubscriptionDuration.Year) => _options.ProYearlyPriceId,
            _ => null
        };
    }

    /// <inheritdoc />
    public (SubscriptionTier Tier, SubscriptionDuration Duration)? Resolve(string priceId)
    {
        if (string.IsNullOrEmpty(priceId)) return null;
        if (priceId == _options.BasicMonthlyPriceId) return (SubscriptionTier.Basic, SubscriptionDuration.Month);
        if (priceId == _options.BasicYearlyPriceId) return (SubscriptionTier.Basic, SubscriptionDuration.Year);
        if (priceId == _options.ProMonthlyPriceId) return (SubscriptionTier.Pro, SubscriptionDuration.Month);
        if (priceId == _options.ProYearlyPriceId) return (SubscriptionTier.Pro, SubscriptionDuration.Year);
        return null;
    }
}
