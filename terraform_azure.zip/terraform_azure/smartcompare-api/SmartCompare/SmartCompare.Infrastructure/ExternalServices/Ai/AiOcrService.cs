using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Ocr;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Infrastructure.ExternalServices.Ai;

public class AiOcrService : IAiOcrService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<AiOcrService> _logger;

    public AiOcrService(HttpClient httpClient, ILogger<AiOcrService> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<Result<OcrPrefillDto>> AnalyseImageAsync(
        byte[] imageBytes,
        string mimeType,
        CancellationToken cancellationToken = default)
    {
        using var content = new MultipartFormDataContent();
        using var fileContent = new ByteArrayContent(imageBytes);
        fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(mimeType);
        content.Add(fileContent, "file", "upload");

        HttpResponseMessage response;
        try
        {
            response = await _httpClient.PostAsync("/ocr/quote", content, cancellationToken);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Failed to reach AI service at {BaseUrl}", _httpClient.BaseAddress);
            return Result.Failure<OcrPrefillDto>(
                new Error(ErrorType.Unexpected, "AI service is unavailable."));
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            _logger.LogWarning("AI service request timed out");
            return Result.Failure<OcrPrefillDto>(
                new Error(ErrorType.Unexpected, "AI service request timed out."));
        }

        using (response)
        {
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("AI service returned {StatusCode}", response.StatusCode);
                return Result.Failure<OcrPrefillDto>(
                    new Error(ErrorType.Unexpected, $"AI service returned {(int)response.StatusCode}."));
            }

            AiOcrQuoteResponse? aiResponse;
            try
            {
                aiResponse = await response.Content.ReadFromJsonAsync<AiOcrQuoteResponse>(
                    cancellationToken: cancellationToken);
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "Failed to deserialise AI service response");
                return Result.Failure<OcrPrefillDto>(
                    new Error(ErrorType.Unexpected, "AI service returned an unexpected response format."));
            }

            if (aiResponse?.QuoteResult?.Quote is null)
            {
                return Result.Failure<OcrPrefillDto>(
                    new Error(ErrorType.Unexpected, "AI service returned an empty quote result."));
            }

            var quote = aiResponse.QuoteResult.Quote;

            var scopeItems = (quote.ScopeOfWorks ?? [])
                .Select(s => BuildScopeText(s))
                .Where(text => !string.IsNullOrWhiteSpace(text))
                .Select(text => new OcrScopeItemDto(Guid.NewGuid().ToString(), text))
                .ToList();

            var exclusions = (quote.Exclusions ?? [])
                .Select(e => new OcrExclusionDto(Guid.NewGuid().ToString(), e))
                .ToList();

            return Result.Success(new OcrPrefillDto(scopeItems, exclusions, []),
                "Image analysed successfully.");
        }
    }

    private static string BuildScopeText(AiScopeOfWorkItem item)
    {
        if (string.IsNullOrWhiteSpace(item.Item) &&
            string.IsNullOrWhiteSpace(item.Quantity) &&
            string.IsNullOrWhiteSpace(item.Rate) &&
            item.Amount is null)
            return string.Empty;

        var parts = new List<string>();
        if (!string.IsNullOrWhiteSpace(item.Item)) parts.Add(item.Item);
        if (!string.IsNullOrWhiteSpace(item.Quantity)) parts.Add(item.Quantity);
        if (!string.IsNullOrWhiteSpace(item.Rate)) parts.Add($"@ {item.Rate}");
        if (item.Amount is not null) parts.Add($"${item.Amount:F0}");
        return string.Join(" — ", parts);
    }
}

// Internal models for deserialising the AI response
internal class AiOcrQuoteResponse
{
    [JsonPropertyName("quote_result")]
    public AiQuoteResult? QuoteResult { get; set; }
}

internal class AiQuoteResult
{
    [JsonPropertyName("quote")]
    public AiQuote? Quote { get; set; }
}

internal class AiQuote
{
    [JsonPropertyName("scope_of_works")]
    public List<AiScopeOfWorkItem>? ScopeOfWorks { get; set; }

    [JsonPropertyName("exclusions")]
    public List<string>? Exclusions { get; set; }
}

internal class AiScopeOfWorkItem
{
    [JsonPropertyName("item")]
    public string? Item { get; set; }

    [JsonPropertyName("quantity")]
    public string? Quantity { get; set; }

    [JsonPropertyName("rate")]
    public string? Rate { get; set; }

    [JsonPropertyName("amount")]
    public decimal? Amount { get; set; }
}
