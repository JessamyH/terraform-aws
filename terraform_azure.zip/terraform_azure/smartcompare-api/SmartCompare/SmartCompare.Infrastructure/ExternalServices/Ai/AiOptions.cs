namespace SmartCompare.Infrastructure.ExternalServices.Ai;

public class AiOptions
{
    public const string SectionName = "AiService";

    public string BaseUrl { get; set; } = string.Empty;
}
