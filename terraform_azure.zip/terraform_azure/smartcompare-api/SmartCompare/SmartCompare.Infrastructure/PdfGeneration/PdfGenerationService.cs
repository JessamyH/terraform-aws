using System.Diagnostics;
using System.Reflection;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using QuestPDF.Drawing;
using QuestPDF.Fluent;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;

namespace SmartCompare.Infrastructure.PdfGeneration;

public sealed partial class PdfGenerationService : IPdfGenerationService
{
    private readonly ILogger<PdfGenerationService> _logger;

    public PdfGenerationService(ILogger<PdfGenerationService> logger)
    {
        _logger = logger;
    }

    static PdfGenerationService()
    {
        RegisterEmbeddedFonts();
    }

    public byte[] GenerateQuotePdf(QuoteDto data, byte[]? logoBytes = null)
    {
        var sw = Stopwatch.StartNew();

        // Probe pass: natural flow, no page numbers, no spacer — determine page count
        var probeDocument = new ModernQuoteDocument(data, logoBytes, showPageNumbers: false, pushPaymentToBottom: false);
        var probeBytes = probeDocument.GeneratePdf();
        var pageCount = CountPdfPages(probeBytes);

        byte[] result;

        if (pageCount <= 1)
        {
            // Single page: re-render with payment pushed to bottom (frontend flex-1 spacer)
            var singlePageDocument = new ModernQuoteDocument(data, logoBytes, showPageNumbers: false, pushPaymentToBottom: true);
            var singlePageBytes = singlePageDocument.GeneratePdf();

            // Guard: if pushPaymentToBottom caused content to overflow onto a second page,
            // fall back to multi-page layout with page numbers
            if (CountPdfPages(singlePageBytes) > 1)
            {
                var fallbackDocument = new ModernQuoteDocument(data, logoBytes, showPageNumbers: true, pushPaymentToBottom: false);
                result = fallbackDocument.GeneratePdf();
                _logger.LogInformation("PDF generated for quote {QuoteNumber}: fallback layout, {Pages} pages, {Elapsed}ms",
                    data.QuoteNumber, CountPdfPages(result), sw.ElapsedMilliseconds);
                return result;
            }

            _logger.LogInformation("PDF generated for quote {QuoteNumber}: single page, {Elapsed}ms",
                data.QuoteNumber, sw.ElapsedMilliseconds);
            return singlePageBytes;
        }

        // Multi-page: re-render with page numbers, no spacer
        var multiPageDocument = new ModernQuoteDocument(data, logoBytes, showPageNumbers: true, pushPaymentToBottom: false);
        result = multiPageDocument.GeneratePdf();
        _logger.LogInformation("PDF generated for quote {QuoteNumber}: {Pages} pages, {Elapsed}ms",
            data.QuoteNumber, pageCount, sw.ElapsedMilliseconds);
        return result;
    }

    private static int CountPdfPages(byte[] pdfBytes)
    {
        var content = System.Text.Encoding.Latin1.GetString(pdfBytes);
        return PageCountRegex().Matches(content).Count;
    }

    [GeneratedRegex(@"/Type\s*/Page(?!s)")]
    private static partial Regex PageCountRegex();

    private static void RegisterEmbeddedFonts()
    {
        var assembly = Assembly.GetExecutingAssembly();
        var fontNames = new[]
        {
            "SmartCompare.Infrastructure.PdfGeneration.Fonts.Inter-Regular.ttf",
            "SmartCompare.Infrastructure.PdfGeneration.Fonts.Inter-SemiBold.ttf",
            "SmartCompare.Infrastructure.PdfGeneration.Fonts.Inter-Bold.ttf"
        };

        foreach (var fontName in fontNames)
        {
            using var stream = assembly.GetManifestResourceStream(fontName)
                ?? throw new InvalidOperationException($"Embedded font resource '{fontName}' not found in assembly.");
            FontManager.RegisterFontWithCustomName("Inter", stream);
        }
    }
}
