using System.Globalization;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using SmartCompare.Application.DTOs.Quote;

namespace SmartCompare.Infrastructure.PdfGeneration;

public sealed class ModernQuoteDocument : IDocument
{
    private readonly QuoteDto _data;
    private readonly byte[]? _logoBytes;
    private readonly bool _showPageNumbers;
    private readonly bool _pushPaymentToBottom;

    // Colors matching frontend globals.css
    private const string BgColor = "#202020";
    private const string PrimaryColor = "#3AADD4";
    private const string PrimaryDarkColor = "#2E82A2";
    private const string AccentColor = "#4DB8DB";
    private const string TextColor = "#202938";

    private const string FontFamily = "Inter";
    private const float PageWidth = 595.5f;
    private const float PageHeight = 842.25f;
    private const float HorizontalPadding = 36f;

    public ModernQuoteDocument(QuoteDto data, byte[]? logoBytes = null, bool showPageNumbers = false, bool pushPaymentToBottom = false)
    {
        _data = data;
        _logoBytes = logoBytes;
        _showPageNumbers = showPageNumbers;
        _pushPaymentToBottom = pushPaymentToBottom;
    }

    public DocumentMetadata GetMetadata() => new()
    {
        Title = $"Quote {_data.QuoteNumber}",
        Author = _data.IssuedBy
    };

    public void Compose(IDocumentContainer container)
    {
        container.Page(page =>
        {
            page.Size(PageWidth, PageHeight, Unit.Point);
            page.MarginHorizontal(0);
            page.MarginVertical(0);
            page.DefaultTextStyle(x => x.FontFamily(FontFamily).FontSize(10).FontColor(TextColor));

            page.Header().Element(ComposeHeader);
            page.Content().Element(ComposeContent);
            page.Footer().Element(ComposeFooter);
        });
    }

    // ─── HEADER ───────────────────────────────────────────────────────────

    private void ComposeHeader(IContainer container)
    {
        // Same pattern as footer: one SVG draws entire background + all decorations
        // Text overlaid separately — zero seams
        const float headerH = 148f;

        container.Layers(layers =>
        {
            // Size anchor with partial dark bg (like footer pattern)
            // Top dark (matches SVG dark), bottom transparent (matches content white)
            layers.PrimaryLayer().Height(headerH).Column(anchor =>
            {
                anchor.Item().Height(headerH - 16).Background(BgColor);
                anchor.Item().Height(16);
            });

            // ONE SVG: dark bg + top decoration + bottom decoration
            // Uses delegate to get EXACT container dimensions — no right-edge gap
            layers.Layer().Element(c => RenderSvg(c, DrawFullHeader));

            // Text overlay (no background, transparent)
            layers.Layer()
                .PaddingHorizontal(HorizontalPadding)
                .PaddingTop(50)
                .Column(inner =>
                {
                    inner.Item().Text(_data.IssuedBy)
                        .FontSize(18).Bold().LetterSpacing(0.06f).FontColor(AccentColor);

                    inner.Item().PaddingTop(10).Text($"ABN: {_data.ABN}")
                        .FontSize(9).FontColor(Colors.White).LineHeight(1.6f);

                    inner.Item().Text($"Licence: {_data.LicenseNumber}")
                        .FontSize(9).FontColor(Colors.White).LineHeight(1.6f);
                });

            // Logo overlay (optional, top-right) — matches frontend: absolute right-10 top-4
            if (_logoBytes is { Length: > 0 })
            {
                var logo = _logoBytes;
                layers.Layer()
                    .AlignRight().AlignTop()
                    .PaddingRight(HorizontalPadding)
                    .PaddingTop(12)
                    .Width(146).Height(98)
                    .Image(logo).FitArea();
            }
        });
    }

    // ─── CONTENT ──────────────────────────────────────────────────────────

    private void ComposeContent(IContainer container)
    {
        container.PaddingHorizontal(HorizontalPadding).PaddingTop(6).Column(col =>
        {
            col.Spacing(0);

            const float dividerGap = 10f;

            col.Item().ShowEntire().Element(ComposeQuoteInfo);

            col.Item().PaddingVertical(dividerGap).LineHorizontal(0.3f).LineColor(Colors.Black);

            ComposeBulletSection(col, "Scope of Works", _data.ScopeOfWorks.Select(s => s.Description).ToList(), paddingTop: 0);
            ComposeBulletSection(col, "Exclusion", _data.Exclusions.Select(e => e.Description).ToList(), paddingTop: 12);

            if (!_pushPaymentToBottom)
            {
                col.Item().ShowEntire().Column(group =>
                {
                    group.Item().PaddingVertical(dividerGap).LineHorizontal(0.3f).LineColor(Colors.Black);
                    group.Item().Element(ComposePaymentSummary);
                });
            }
            // When _pushPaymentToBottom, payment is rendered in the footer instead
        });
    }

    // ─── QUOTE INFO ───────────────────────────────────────────────────────

    private void ComposeQuoteInfo(IContainer container)
    {
        container.Row(row =>
        {
            row.RelativeItem().Column(left =>
            {
                left.Item().Text("QUOTATION").FontSize(22).Bold().LetterSpacing(-0.01f);

                left.Item().PaddingTop(4).PaddingVertical(1.5f).Row(r =>
                {
                    r.ConstantItem(60).Text("To:").FontSize(10).SemiBold();
                    r.RelativeItem().Text(_data.IssuedTo).FontSize(10);
                });

                left.Item().PaddingVertical(1.5f).Row(r =>
                {
                    r.ConstantItem(60).Text("Project:").FontSize(10).SemiBold();
                    r.RelativeItem().Text(_data.ProjectName).FontSize(10);
                });
            });

            row.ConstantItem(200).AlignRight().AlignBottom().Column(right =>
            {
                ComposeInfoRow(right, "Quote No:", _data.QuoteNumber);
                ComposeInfoRow(right, "Issued Date:", _data.IssuedDate.ToString("dd MMM yyyy", CultureInfo.InvariantCulture));
                ComposeInfoRow(right, "Valid Until:", _data.ValidDate.ToString("dd MMM yyyy", CultureInfo.InvariantCulture));
            });
        });
    }

    private static void ComposeInfoRow(ColumnDescriptor col, string label, string value)
    {
        col.Item().PaddingVertical(1.5f).Row(r =>
        {
            r.RelativeItem().AlignRight().PaddingRight(8).Text(label).FontSize(10).SemiBold();
            r.ConstantItem(80).AlignRight().Text(value).FontSize(10);
        });
    }

    private static void ComposeBulletSection(ColumnDescriptor col, string title, IReadOnlyList<string> items, float paddingTop)
    {
        if (items.Count == 0)
            return;

        col.Item().PaddingTop(paddingTop).ShowEntire().Column(section =>
        {
            section.Item().Text(title).FontSize(11).Bold();
            section.Item().PaddingTop(4).Element(c => ComposeBulletItem(c, items[0]));
        });

        for (var i = 1; i < items.Count; i++)
        {
            var item = items[i];
            col.Item().Element(c => ComposeBulletItem(c, item));
        }
    }

    private static void ComposeBulletItem(IContainer container, string text)
    {
        container.PaddingVertical(1.5f).Row(row =>
        {
            row.ConstantItem(12).AlignMiddle().Text("•").FontSize(8);
            row.RelativeItem().Text(text).FontSize(10).LineHeight(1.4f);
        });
    }

    // ─── PAYMENT SUMMARY ──────────────────────────────────────────────────

    private void ComposePaymentSummary(IContainer container)
    {
        var hasPayments = _data.ProgressPayments.Count > 0;

        container.PaddingBottom(8).Row(row =>
        {
            if (hasPayments)
            {
                row.RelativeItem().Column(left =>
                {
                    left.Item().Text("Progress Payment").FontSize(11).Bold();

                    foreach (var payment in _data.ProgressPayments)
                    {
                        left.Item().Element(c =>
                            ComposeBulletItem(c, $"{payment.Description} - {payment.Percentage}%"));
                    }
                });
            }
            else
            {
                row.RelativeItem();
            }

            row.ConstantItem(200).AlignRight().Column(right =>
            {
                if (hasPayments)
                {
                    // Spacer to align Sub-Total with first bullet item (skip "Progress Payment" title height)
                    right.Item().Text("").FontSize(11).Bold();
                }

                right.Item().BorderBottom(0.3f).BorderColor(Colors.Black).PaddingVertical(2).Row(r =>
                {
                    r.RelativeItem().Text("Sub-Total").FontSize(10);
                    r.ConstantItem(100).AlignRight().Text(FormatCurrency(_data.SubTotal)).FontSize(10);
                });

                right.Item().BorderBottom(0.3f).BorderColor(Colors.Black).PaddingVertical(2).Row(r =>
                {
                    r.RelativeItem().Text("Total GST 10%").FontSize(10);
                    r.ConstantItem(100).AlignRight().Text(FormatCurrency(_data.GST)).FontSize(10);
                });

                right.Item().PaddingTop(4).Row(r =>
                {
                    r.RelativeItem().Text("Total AUD").FontSize(10).Bold();
                    r.ConstantItem(100).AlignRight().Text(FormatCurrency(_data.Total)).FontSize(10).Bold();
                });
            });
        });
    }

    // ─── FOOTER ───────────────────────────────────────────────────────────

    private void ComposeFooter(IContainer container)
    {
        container.Column(col =>
        {
            if (_pushPaymentToBottom)
            {
                const float dividerGap = 10f;
                col.Item().PaddingHorizontal(HorizontalPadding)
                    .PaddingVertical(dividerGap).LineHorizontal(0.3f).LineColor(Colors.Black);
                col.Item().PaddingHorizontal(HorizontalPadding)
                    .Element(ComposePaymentSummary);
            }

            if (_showPageNumbers)
            {
                col.Item().PaddingBottom(4).AlignCenter()
                    .Text(text =>
                    {
                        text.DefaultTextStyle(x => x.FontSize(9).FontColor(Colors.Grey.Medium));
                        text.Span("Page ");
                        text.CurrentPageNumber();
                        text.Span(" of ");
                        text.TotalPages();
                    });
            }

            col.Item().Layers(layers =>
            {
                // Layer 1 (bottom): size anchor with partial dark bg
                // Top 1/3 transparent (matches SVG white), bottom 2/3 dark (matches SVG dark)
                layers.PrimaryLayer().Height(42).Column(anchor =>
                {
                    anchor.Item().Height(14);
                    anchor.Item().Height(28).Background(BgColor);
                });

                // Layer 2: SVG decoration — uses delegate for exact container dimensions
                layers.Layer().Element(c => RenderSvg(c, DrawFooter));

                // Layer 3 (top): contact text on top of everything
                layers.Layer()
                    .PaddingTop(24)
                    .PaddingHorizontal(HorizontalPadding)
                    .PaddingBottom(6)
                    .Row(row =>
                    {
                        row.RelativeItem();
                        row.AutoItem().Text($"Contact: {_data.ContactName} {_data.ContactPhone}")
                            .FontSize(9).FontColor(Colors.White);
                        row.AutoItem().PaddingLeft(20).Text($"Email: {_data.ContactEmail}")
                            .FontSize(9).FontColor(Colors.White);
                    });
            });
        });
    }

    // ─── SVG GENERATION ───────────────────────────────────────────────────

    /// <summary>
    /// Renders SVG using container size delegate — gets EXACT container dimensions,
    /// eliminating all dimension mismatch and right-edge gap issues.
    /// </summary>
    private static void RenderSvg(IContainer container, Func<float, float, string> drawContent)
    {
        container.Svg(size =>
        {
            var w = size.Width;
            var h = size.Height;
            var content = drawContent(w, h);
            return $"""<svg viewBox="0 0 {F(w)} {F(h)}" xmlns="http://www.w3.org/2000/svg">{content}</svg>""";
        });
    }

    // Proportional X coordinate from frontend 794-wide viewBox
    private static float X(float frontendX, float actualWidth) => actualWidth * frontendX / 794f;

    private static string DrawFullHeader(float w, float h)
    {
        const float decoTopH = 33f;
        const float decoBottomH = 32f;
        var bottomY = h - decoBottomH;
        // Matches frontend QuoteHeader.tsx z-order exactly:
        // Bottom decoration: triangle → dark rect (covers top half) → blue trapezoid (top layer)
        var halfBottom = decoBottomH / 2;

        return $"""
            <rect x="0" y="0" width="{F(w)}" height="{F(bottomY)}" fill="{BgColor}" />
            <polygon points="0,0 {F(X(357, w))},0 {F(X(397, w))},{F(decoTopH)} 0,{F(decoTopH)}" fill="{PrimaryColor}" />
            <polygon points="{F(X(357, w))},0 {F(X(397, w))},{F(decoTopH)} {F(X(437, w))},0" fill="{PrimaryDarkColor}" />
            <polygon points="{F(X(437, w))},{F(bottomY)} {F(X(397, w))},{F(h)} {F(X(357, w))},{F(bottomY)}" fill="{PrimaryDarkColor}" />
            <rect x="0" y="{F(bottomY)}" width="{F(w)}" height="{F(halfBottom)}" fill="{BgColor}" />
            <polygon points="{F(w)},{F(h)} {F(X(397, w))},{F(h)} {F(X(437, w))},{F(bottomY)} {F(w)},{F(bottomY)}" fill="{PrimaryColor}" />
            """;
    }

    private static string DrawFooter(float w, float h)
    {
        var oneThird = h / 3;
        // White bg (no transparent gaps)
        // Dark triangle: 265,45 → 305,0 → 345,45
        // Dark rect: bottom 2/3
        // Blue trapezoid on left: 0,45 → 265,45 → 305,0 → 0,0
        return $"""
            <rect x="0" y="0" width="{F(w)}" height="{F(h)}" fill="white" />
            <polygon points="{F(X(265, w))},{F(h)} {F(X(305, w))},0 {F(X(345, w))},{F(h)}" fill="{PrimaryDarkColor}" />
            <rect x="0" y="{F(oneThird)}" width="{F(w)}" height="{F(h - oneThird)}" fill="{BgColor}" />
            <polygon points="0,{F(h)} {F(X(265, w))},{F(h)} {F(X(305, w))},0 0,0" fill="{PrimaryColor}" />
            """;
    }

    private static string FormatCurrency(decimal value) => $"$ {value:N2}";

    private static string F(float v) => v.ToString("F1", System.Globalization.CultureInfo.InvariantCulture);
}
