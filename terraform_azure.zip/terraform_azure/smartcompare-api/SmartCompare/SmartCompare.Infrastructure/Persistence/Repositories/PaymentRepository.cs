using Microsoft.EntityFrameworkCore;
using SmartCompare.Domain.Entities.PaymentAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Infrastructure.Persistence.Repositories;

public class PaymentRepository : BaseRepository<Payment, int>, IPaymentRepository
{
    public PaymentRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
    {
    }

    public async Task<Payment?> GetByStripeInvoiceIdAsync(string stripeInvoiceId, CancellationToken cancellationToken = default)
    {
        return await DbContext.Set<Payment>()
            .FirstOrDefaultAsync(p => p.StripeInvoiceId == stripeInvoiceId, cancellationToken);
    }
}
