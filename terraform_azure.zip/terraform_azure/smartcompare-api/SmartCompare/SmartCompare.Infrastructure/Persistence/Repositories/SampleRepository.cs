using SmartCompare.Domain.Entities;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Infrastructure.Persistence.Repositories;
public class SampleRepository : BaseRepository<SampleAggregate, Guid>, ISampleEntityRepository
{
    public SampleRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
    {
        
        
    }
}