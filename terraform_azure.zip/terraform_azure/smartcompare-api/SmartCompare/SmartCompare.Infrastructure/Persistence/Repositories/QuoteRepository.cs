using Microsoft.EntityFrameworkCore;
using SmartCompare.Domain.Interfaces;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.SharedKernel.Interfaces;


namespace SmartCompare.Infrastructure.Persistence.Repositories;

public class QuoteRepository : BaseRepository<Quote, int>, IQuoteRepository
{
    public QuoteRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
    {
    }
    public Task AddAsync(Quote entity, CancellationToken cancellationToken = default)
    {
        return base.AddAsync(entity, cancellationToken);
    }

    public Task Delete(Quote quote)
    {
        return base.Delete(quote);
    }

    public override Task<Quote> FirstOrDefaultAsync(Func<IQueryable<Quote>, IQueryable<Quote>> predicate, CancellationToken cancellationToken = default)
    {
        return base.FirstOrDefaultAsync(predicate, cancellationToken);
    }

    public async Task<Quote?> GetQuoteByIdAsync(Guid quoteId, CancellationToken cancellationToken = default)
    {
        return await FirstOrDefaultAsync(
            q => q.Where(qu => qu.PublicId == quoteId),
            cancellationToken);
    }

    public async Task<Quote?> GetQuoteWithScopeOfWorkAsync(Guid quoteId, CancellationToken cancellationToken = default)
    {
        return await FirstOrDefaultAsync(
            q => q.Where(qu => qu.PublicId == quoteId)
                    .Include(q => q.ScopeOfWorks),
            cancellationToken);
    }

    public async Task<Quote?> GetQuoteWithExclusionsAsync(Guid quoteId, CancellationToken cancellationToken = default)
    {
        return await FirstOrDefaultAsync(
            q => q.Where(qu => qu.PublicId == quoteId)
                .Include(qu => qu.Exclusions),
            cancellationToken);
    }


    public async Task<Quote?> GetQuoteWithProgressPaymentsAsync(Guid quoteId, CancellationToken cancellationToken = default)
    {
        return await FirstOrDefaultAsync(
            q => q.Where(quote => quote.PublicId == quoteId)
            .Include(quote => quote.ProgressPayments),
            cancellationToken);
    }
}
