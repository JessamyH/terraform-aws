using Microsoft.EntityFrameworkCore;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Infrastructure.Persistence.Repositories;

public class UserRepository : BaseRepository<User, Guid>, IUserRepository
{
    public UserRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
    {
    }

    public override Task AddAsync(User entity, CancellationToken cancellationToken = default)
    {
        return base.AddAsync(entity, cancellationToken);
    }

    public async Task<User?> GetBySubjectIdAsync(string auth0SubjectId, CancellationToken cancellationToken = default)
    {
        return await base.FirstOrDefaultAsync(
            q => q.Where(u => u.Auth0SubjectId == auth0SubjectId),
            cancellationToken);
    }

    public async Task<User?> GetBySubjectIdWithSubscriptionAsync(string auth0SubjectId, CancellationToken cancellationToken = default)
    {
        return await base.FirstOrDefaultAsync(
            q => q.Include(u => u.Subscription)
                  .Where(u => u.Auth0SubjectId == auth0SubjectId),
            cancellationToken);
    }

    public async Task<User?> GetByStripeCustomerIdWithSubscriptionAsync(string stripeCustomerId, CancellationToken cancellationToken = default)
    {
        return await base.FirstOrDefaultAsync(
            q => q.Include(u => u.Subscription)
                  .Where(u => u.StripeCustomerId == stripeCustomerId),
            cancellationToken);
    }

}
