using Microsoft.EntityFrameworkCore;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Infrastructure.Persistence.Repositories
{

    public class RoleRepository : IRoleRepository
    {
        private readonly IUnitOfWork _unitOfWork;

        public RoleRepository(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<Role?> GetByIdAsync(Guid roleId, CancellationToken cancellationToken = default)
        {
            return await _unitOfWork.DbContext.Set<Role>()
                .FirstOrDefaultAsync(r => r.Id == roleId, cancellationToken);
        }
    }
}

