﻿using Microsoft.EntityFrameworkCore;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Infrastructure.Persistence.Repositories;

public class ProjectRepository : BaseRepository<Project, int>, IProjectRepository
{
    public ProjectRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
    {
    }

    public override Task AddAsync(Project project, CancellationToken cancellationToken = default)
    {
        return base.AddAsync(project, cancellationToken);
    }

    public override Task<Project> FirstOrDefaultAsync(Func<IQueryable<Project>, IQueryable<Project>> predicate, CancellationToken cancellationToken = default)
    {
        return base.FirstOrDefaultAsync(predicate, cancellationToken);
    }

    // All basic CRUD operations are inherited from BaseRepository<Projects>
    // Add custom project-specific methods here if needed

    public async Task<Project?> GetProjectByPublicIdAsync(Guid projectId, CancellationToken cancellationToken = default)
    {
        var project = await FirstOrDefaultAsync(
            q => q.Where(p => p.PublicId == projectId && !p.IsDeleted), cancellationToken);

        return project;
    }
}
