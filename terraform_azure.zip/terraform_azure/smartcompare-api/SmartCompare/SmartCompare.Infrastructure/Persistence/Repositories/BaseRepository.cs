using Microsoft.EntityFrameworkCore;
using SmartCompare.SharedKernel.Common;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Infrastructure.Persistence.Repositories;

/// <summary>
/// Base repository class providing common database operations.
/// </summary>
/// <typeparam name="T">The entity type, must be an aggregate root.</typeparam>
public class BaseRepository<T, TId> : IRepository<T, TId> where T : AggregateRoot<TId>
{
    
    /// <summary>
    /// The unit of work that provides the database context.
    /// </summary>
    protected readonly IUnitOfWork _unitOfWork;
    

    /// <summary>
    /// Initializes a new instance of the <see cref="BaseRepository{T}"/> class.
    /// </summary>
    /// <param name="unitOfWork">The unit of work instance.</param>
    public BaseRepository(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
    }
    
    /// <summary>
    /// Gets the database context.
    /// </summary>
    protected DbContext DbContext => _unitOfWork.DbContext;
    
    /// <summary>
    /// Gets an entity by its primary key.
    /// </summary>
    /// <param name="id">The primary key of the entity.</param>
    /// <param name="cancellationToken">A cancellation token to cancel the operation.</param>
    /// <returns>The entity with the given ID.</returns>
    public virtual async Task<T> GetByIdAsync(TId id, CancellationToken cancellationToken = default)
    {
        var dbSet = DbContext.Set<T>();
        return await dbSet.FindAsync(new object[] { id }, cancellationToken: cancellationToken);
    }
    
    /// <summary>
    /// Gets the first entity that matches the specified predicate, or the default value if no entity is found.
    /// </summary>
    /// <param name="predicate">The query predicate to filter the entities.</param>
    /// <param name="cancellationToken">A cancellation token to cancel the operation.</param>
    /// <returns>The first matching entity, or default if no entity is found.</returns>
    public virtual async Task<T> FirstOrDefaultAsync(Func<IQueryable<T>, IQueryable<T>> predicate, CancellationToken cancellationToken = default)
    {
        var dbSet = DbContext.Set<T>();

        if (predicate == null)
            return await dbSet.FirstOrDefaultAsync(cancellationToken);

        var query = predicate(dbSet.AsQueryable());
        return await query.FirstOrDefaultAsync(cancellationToken);
    }
    
    /// <summary>
    /// Adds a new entity to the context.
    /// </summary>
    /// <param name="entity">The entity to add.</param>
    /// <param name="cancellationToken">A cancellation token to cancel the operation.</param>
    public virtual async Task AddAsync(T entity, CancellationToken cancellationToken = default)
    {
        var dbSet = DbContext.Set<T>();
        await dbSet.AddAsync(entity, cancellationToken);
    }
    
    /// <summary>
    /// Delete entity from context.
    /// </summary>
    /// <param name="entity">The entity to be deleted.</param>
    /// <param name="cancellationToken">A cancellation token to cancel the operation.</param>
    public virtual Task Delete(T entity, CancellationToken cancellationToken = default)
    {
        DbContext.Set<T>().Remove(entity);
        return Task.CompletedTask; 
    }
    
}