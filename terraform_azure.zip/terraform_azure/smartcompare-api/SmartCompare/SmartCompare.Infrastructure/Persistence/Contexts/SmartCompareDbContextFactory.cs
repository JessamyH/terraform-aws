using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace SmartCompare.Infrastructure.Persistence.Contexts;

/// <summary>
/// DbContext Factory implementation.
/// 
/// Responsibilities:
/// • Creates and configures SmartCompareDbContext instances
/// • Supports design-time (migrations)
/// • Supports runtime scenarios(TODO)
/// • Unified connection string and options configuration
/// </summary>
public class SmartCompareDbContextFactory: IDesignTimeDbContextFactory<SmartCompareDbContext>
{
    private readonly IConfiguration _configuration;
    
    /// <summary>
    /// Initializes a new instance of the <see cref="SmartCompareDbContextFactory"/> class.
    /// Used by EF Core design-time tools when discovering and executing migrations.
    /// </summary>
    /// <remarks>
    /// This parameterless constructor loads configuration from appsettings.json and 
    /// environment-specific overrides (appsettings.{Environment}.json) for the current 
    /// ASPNETCORE_ENVIRONMENT setting and User Secrets (highest priority, overrides all)
    /// </remarks>
    public SmartCompareDbContextFactory()
    {
        _configuration = BuildConfiguration();
    }
    
    /// <summary>
    /// Initializes the factory.
    /// </summary>
    /// <param name="configuration">Application configuration used to retrieve connection strings</param>
    /// <exception cref="ArgumentNullException">Thrown when configuration is null</exception>
    private SmartCompareDbContextFactory(IConfiguration configuration)
    {
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
    }
    
    /// <summary>
    /// Creates DbContext for design-time usage.
    /// 
    /// Used by EF Core migration tools and database initialization utilities.
    /// </summary>
    /// <param name="args">Command-line arguments</param>
    /// <returns>Configured DbContext instance</returns>
    public SmartCompareDbContext CreateDbContext(string[] args)
    {
        Console.WriteLine("[Factory] Creating DbContext for Design Time (EF Tools)");
        return CreateDbContextInternal();
    }
    
    /// <summary>
    /// Internal implementation: Creates and configures DbContext.
    /// 
    /// Configuration includes:
    /// • Connection string validation
    /// • SQL Server options (retry, timeout, query splitting)
    /// </summary>
    /// <returns>Configured DbContext instance</returns>
    /// <exception cref="InvalidOperationException">Thrown when connection string is not found</exception>
    private SmartCompareDbContext CreateDbContextInternal()
    {
        var optionsBuilder = new DbContextOptionsBuilder<SmartCompareDbContext>();
        var connectionString = GetConnectionString();
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException(
                "Connection string not found. Configure via: " +
                "1. 'dotnet user-secrets set \"ConnectionStrings:DefaultConnection\" \"...\"', or " +
                "2. appsettings.json 'ConnectionStrings:DefaultConnection' section");
        }
        optionsBuilder.UseSqlServer(connectionString, sqlOptions =>
        {
            sqlOptions.EnableRetryOnFailure(maxRetryCount: 3);
            sqlOptions.CommandTimeout(30);
            sqlOptions.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery);
        });
        var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
        if (string.IsNullOrEmpty(environment))
        {
            environment = "Development";
            Console.WriteLine("[Factory] WARNING: ASPNETCORE_ENVIRONMENT not set, defaulting to Development");
        }
        Console.WriteLine($"[Factory] Current Environment: {environment}");
        return new SmartCompareDbContext(optionsBuilder.Options);
    }
    
    
    /// <summary>
    /// Get connection string
    /// </summary>
    /// <returns>Connection string value, or null if not found.</returns>
    private string? GetConnectionString()
    {
        var connectionString = _configuration.GetConnectionString("DefaultConnection");
        if (!string.IsNullOrWhiteSpace(connectionString))
        {
            return connectionString;
        }
        Console.WriteLine("[Factory] WARNING: Connection string not found in any configuration source");
        return null;
    }
    
    
    /// <summary>
    /// Builds IConfiguration from appsettings.json files.
    /// 
    /// During design-time, EF Core tools don't automatically load configuration.
    /// This method explicitly loads JSON configuration files from the project root.
    /// 
    /// Configuration Sources (lowest to highest priority):
    /// 1. appsettings.json (base configuration)
    /// 2. appsettings.{Environment}.json (environment-specific overrides)
    /// 3. User Secrets (highest priority, overrides all)
    /// </summary>
    /// <returns>Configured IConfiguration instance</returns>
    private static IConfiguration BuildConfiguration()
    {
        var basePath = GetBasePath();
        Console.WriteLine($"[Factory] Loading configuration from: {basePath}");
        var configBuilder = new ConfigurationBuilder()
            .SetBasePath(basePath)
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddJsonFile(
                $"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development"}.json",
                optional: true,
                reloadOnChange: true)
            .AddUserSecrets<SmartCompareDbContextFactory>(optional: true);
        var configuration = configBuilder.Build();
        Console.WriteLine("[Factory] Configuration loaded successfully");
        return configuration;
    }
    
    /// <summary>
    /// Gets the project root directory path.
    /// 
    /// During design-time execution, the current directory is typically:
    /// bin/Debug/net{version}/
    /// 
    /// This method traverses up the directory tree to find the .csproj file
    /// and returns the project root directory.
    /// </summary>
    /// <returns>Project root directory path</returns>
    private static string GetBasePath()
    {
        var currentDir = Directory.GetCurrentDirectory();
        var dir = new DirectoryInfo(currentDir);
        Console.WriteLine($"[Factory] Current directory: {currentDir}");
        while (dir != null)
        {
            var csprojFiles = dir.GetFiles("*.csproj");
            if (csprojFiles.Length > 0)
            {
                Console.WriteLine($"[Factory] Found project at: {dir.FullName}");
                return dir.FullName;
            }
            dir = dir.Parent;
        }
        Console.WriteLine($"[Factory] Could not find .csproj, using current directory");
        return currentDir;
    }
    
}