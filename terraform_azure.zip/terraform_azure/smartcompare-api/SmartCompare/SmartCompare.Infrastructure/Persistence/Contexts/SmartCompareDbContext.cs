﻿using Microsoft.EntityFrameworkCore;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Entities.PaymentAggregate;

namespace SmartCompare.Infrastructure.Persistence.Contexts
{
    public class SmartCompareDbContext : DbContext
    {
        public SmartCompareDbContext(DbContextOptions<SmartCompareDbContext> options) : base(options)
        {
        }

        // Define DbSets for your entities here
        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Payment> Payments { get; set; } = null!;
        public DbSet<Project> Projects { get; set; } = null!;
        public DbSet<SubcontractorTypes> SubcontractorTypes { get; set; } = null!;
        public DbSet<Quote> Quotes { get; set; } = null!;
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // Apply all IEntityTypeConfiguration<T> configurations from this assembly
            // This automatically discovers and applies: any entity configuration classes
            modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);
            
        }
    }

}
