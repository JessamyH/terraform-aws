﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;

using SmartCompare.Infrastructure.Persistence.Contexts;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Infrastructure.Persistence
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IDbContextFactory<SmartCompareDbContext> _dbContextFactory;
        private SmartCompareDbContext _dbContext;
        private IDbContextTransaction? _currentTransaction;
        private bool _disposed;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="UnitOfWork"/> class.
        /// </summary>
        /// <param name="dbContextFactory">The factory used to create instances of <see cref="SmartCompareDbContext"/>.</param>
        public UnitOfWork(IDbContextFactory<SmartCompareDbContext> dbContextFactory)
        {
            _dbContextFactory = dbContextFactory ?? throw new ArgumentNullException(nameof(dbContextFactory));
        }
        
        public DbContext DbContext => GetDbContext();
        
        /// <summary>
        /// Lazy loads the <see cref="DbContext"/> instance when it is first needed.
        /// </summary>
        /// <returns>The <see cref="DbContext"/> instance.</returns>
        private DbContext GetDbContext()
        {
            CheckDisposed();
            if (_dbContext == null)
            {
                // If DbContext is not already created, create it using the factory.
                _dbContext = _dbContextFactory.CreateDbContext();
            }
            return _dbContext;
        }
        
        /// <summary>
        /// The ExecuteResilientAsync method provides transient retry capabilities for database 
        /// operations through EF Core's ExecutionStrategy.
        /// </summary>
        /// <param name="operation">This indicates the execution of an asynchronous database logic block.</param>
        /// <param name="ct"></param>
        public async Task ExecuteResilientAsync(Func<CancellationToken, Task> operation, CancellationToken ct = default)
        {
            var strategy = GetDbContext().Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(operation, ct);
        }
        
        /// <summary>
        /// It works on the same principle as ExecuteResilientAsync, but it has a return value.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="operation"></param>
        /// <param name="ct"></param>
        /// <returns>The result returned is the result of the last successful execution.</returns>
        public async Task<T> ExecuteResilientAsync<T>(Func<CancellationToken, Task<T>> operation, CancellationToken ct = default)
        {
            var strategy = GetDbContext().Database.CreateExecutionStrategy();
            return await strategy.ExecuteAsync(operation, ct);
        }
        

        
        public async Task BeginTransactionAsync()
        {
            CheckDisposed();
            if (_currentTransaction != null)
            {
                throw new InvalidOperationException("A transaction is already in progress.");
            }
            _currentTransaction = await GetDbContext().Database.BeginTransactionAsync();
        }

        public async Task CommitTransactionAsync()
        {
            CheckDisposed();
            if (_currentTransaction == null)
            {
                throw new InvalidOperationException("No active transaction to commit.");
            }
            await _currentTransaction.CommitAsync();
            await _currentTransaction.DisposeAsync();
            _currentTransaction = null;
        }

        public async Task RollbackTransactionAsync()
        {
            CheckDisposed();
            if (_currentTransaction == null)
            {
                throw new InvalidOperationException("No active transaction to rollback.");
            }
            await _currentTransaction.RollbackAsync();
            await _currentTransaction.DisposeAsync();
            _currentTransaction = null;
        }

        public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            CheckDisposed();
            return await GetDbContext().SaveChangesAsync(cancellationToken);
        }
        
        /// <summary>
        /// Disposes of the resources used by the UnitOfWork.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        
        /// <summary>
        /// Releases _dbContext and _currentTransaction resources used by the UnitOfWork.
        /// </summary>
        /// <param name="disposing">Indicates whether to release managed resources (true) or not (false).</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    if (_dbContext != null)
                    {
                        _dbContext.Dispose();
                        _dbContext = null;
                    }
                    
                    if (_currentTransaction != null)
                    {
                        _currentTransaction.Dispose();
                        _currentTransaction = null;
                    }
                }
                _disposed = true;
            }
        }
        
        /// <summary>
        /// Checks if the UnitOfWork has been disposed, throwing an exception if it has.
        /// </summary>
        private void CheckDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(
                    GetType().ShortDisplayName(),
                    $"Cannot use UnitOfWork after it has been disposed.");
            }
        }

    }
}
