using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Enums;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace SmartCompare.Infrastructure.Persistence.SeedData.Seeders;

public static class ProjectSeeder
{
    public static Project Seed(SmartCompareDbContext context, User user)
    {
        var project = Project.Create(
            userId: user.Id,
            projectName: "Residential Extension - Smith Residence",
            address: "456 Oak Avenue, Melbourne VIC 3000",
            houseType: HouseType.House,
            houseSizeSqm: 220.5m,
            bedrooms: 4,
            bathrooms: 2,
            subcontractorTypeId: 1,
            status: ProjectStatus.InProgress
        );

        context.Projects.Add(project);

        return project;
    }
}
