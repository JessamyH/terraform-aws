using Microsoft.EntityFrameworkCore;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Entities.PaymentAggregate;
using SmartCompare.Domain.Enums;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace SmartCompare.Infrastructure.Persistence.SeedData.Seeders;

public static class PaymentSeeder
{
    public static Payment Seed(SmartCompareDbContext context, Subscription subscription)
    {
        var payment = Payment.Create(
            amount: 99.00m,
            currency: "AUD",
            status: PaymentStatus.Succeeded,
            type: PaymentType.Subscription,
            subscriptionId: subscription.Id,
            stripeInvoiceId: "in_test123456789",
            stripePaymentIntentId: "pi_test123456789",
            stripeChargeId: "ch_test123456789",
            paidAt: DateTime.UtcNow,
            description: "Monthly subscription payment"
        );

        context.Payments.Add(payment);

        return payment;
    }
}
