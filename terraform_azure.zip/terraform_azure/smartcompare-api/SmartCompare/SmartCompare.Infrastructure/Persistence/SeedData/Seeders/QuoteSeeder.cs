using Microsoft.EntityFrameworkCore;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.ValueObjects;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace SmartCompare.Infrastructure.Persistence.SeedData.Seeders;

public static class QuoteSeeder
{
    public static Quote Seed(SmartCompareDbContext context, Project project)
    {
        var quote = Quote.Create(
            quoteNumber: $"Q-{DateTime.UtcNow.Year}-001",
            issuedBy: "Test Building Company Pty Ltd",
            issuedTo: "Mr. John Smith",
            projectId: project.Id,
            subTotal: 50000.00m,
            gst: 5000.00m,
            issuedDate: DateTime.UtcNow,
            validPeriod: 90,
            abn: ABN.Create("51824753556"),
            licenseNumber: "LIC-001",
            contactName: "Test Contact",
            contactEmail: "contact@testbuilding.com",
            contactPhone: "0400000000"
        );

        // Add scope of work items
        quote.AddScopeOfWork("Demolition of existing structures");
        quote.AddScopeOfWork("Foundation and concrete slab");
        quote.AddScopeOfWork("Framing and structural work");
        quote.AddScopeOfWork("Roofing installation");
        quote.AddScopeOfWork("Plumbing rough-in");
        quote.AddScopeOfWork("Electrical rough-in");
        quote.AddScopeOfWork("Insulation installation");
        quote.AddScopeOfWork("Drywall and plastering");
        quote.AddScopeOfWork("Interior finishes and painting");
        quote.AddScopeOfWork("Final fixtures and cleanup");

        // Add exclusions
        quote.AddExclusion("Electrical appliances and fixtures");
        quote.AddExclusion("Landscaping and outdoor works");
        quote.AddExclusion("Driveway and paving");
        quote.AddExclusion("Fencing");

        // Add progress payments
        quote.AddProgressPayment(0.10m, "Deposit - 10%");
        quote.AddProgressPayment(0.25m, "Foundation completion - 25%");
        quote.AddProgressPayment(0.25m, "Frame and lock-up - 25%");
        quote.AddProgressPayment(0.25m, "Fixing stage - 25%");
        quote.AddProgressPayment(0.15m, "Final completion - 15%");

        context.Quotes.Add(quote);

        return quote;
    }
}
