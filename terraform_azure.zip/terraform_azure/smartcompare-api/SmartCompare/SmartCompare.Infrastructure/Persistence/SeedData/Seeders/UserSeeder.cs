using Microsoft.EntityFrameworkCore;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Enums;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace SmartCompare.Infrastructure.Persistence.SeedData.Seeders;

public static class UserSeeder
{
    public static User Seed(SmartCompareDbContext context)
    {
        // Find the Admin role by name, admin is seeded through migration
        var adminRole = context.Set<Role>()
            .FirstOrDefault(r => r.Name == Role.RoleNames.Admin);

        var testUser = User.Create(
            auth0SubjectId: "auth0|69673ed64f6a95f8ee61fb19",
            userName: "development@distinctioncoding.com.au",
            email: "development@distinctioncoding.com.au"
        );

        testUser.AddRole(roleId: adminRole!.Id);

        testUser.AddCompanyProfile(
            companyName: "Test Building Company Pty Ltd",
            contactName: "John Smith",
            contactEmail: "john.smith@testbuilding.com.au",
            contactPhone: "+61412345678",
            postCode: 2000,
            abn: "51824753556",
            street: "123 Builder Street",
            suburb: "Sydney",
            state: "NSW",
            logoUrl: "https://example.com/logos/test-building-company.png",
            bsb: "123456",
            account: "12345678",
            licenseNumber: "NSW-BLD-123456"
        );

        testUser.AddSubscription(
            subscriptionTier: SubscriptionTier.Free,
            subscriptionDuration: SubscriptionDuration.None,
            subscriptionStatus: SubscriptionStatus.Active,
            startDate: DateTime.UtcNow,
            endDate: DateTime.UtcNow.AddMonths(1),
            stripeSubscriptionId: "sub_test123456789",
            isDeleted: false
        );

        context.Users.Add(testUser);

        return testUser;
    }
}
