using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SmartCompare.Infrastructure.Persistence.Contexts;
using SmartCompare.Infrastructure.Persistence.SeedData.Seeders;

namespace SmartCompare.Infrastructure.Persistence.SeedData;

public static class DbInitializer
{
    public static async Task SeedAsync(SmartCompareDbContext context, ILogger logger)
    {
        await context.Database.MigrateAsync();

        if (await context.Users.AsNoTracking().AnyAsync(u => u.Auth0SubjectId == "auth0|69673ed64f6a95f8ee61fb19"))
        {
            logger.LogInformation("Database already seeded. Skipping seed data");
            return;
        }

        logger.LogInformation("Starting database seeding");

        // Seed entities in dependency order
        var user = UserSeeder.Seed(context);
        await context.SaveChangesAsync(); // Save user first
        logger.LogInformation("Seeded user: {UserName} ({Email})", user.UserName, user.Email);

        var project = ProjectSeeder.Seed(context, user!);
        await context.SaveChangesAsync(); // Save project before quote
        logger.LogInformation("Seeded project: {ProjectName}", project.ProjectName);

        QuoteSeeder.Seed(context, project!);
        PaymentSeeder.Seed(context, user!.Subscription!);
        await context.SaveChangesAsync(); // Save quote and payment

        logger.LogInformation("Database seeding completed successfully");
    }
}
