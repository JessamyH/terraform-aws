using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Enums;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class SubscriptionsConfiguration : IEntityTypeConfiguration<Subscription>
{

    public void Configure(EntityTypeBuilder<Subscription> builder)
    {
        // ==================== Table ====================
        builder.ToTable("Subscriptions", schema: "dbo");

        // ==================== Primary Key ====================
        builder.Property(s => s.Id)
            .HasColumnName("Id")
            .HasColumnType("uniqueidentifier")
            .IsRequired()
            .ValueGeneratedNever()
            .HasComment("Unique identifier. Subscription ID, set by application.");

        // ==================== Properties ====================

        builder.Property(s => s.UserId)
            .HasColumnName("UserId")
            .HasColumnType("uniqueidentifier")
            .IsRequired()
            .HasComment("Foreign Key to Users. One-to-one relationship: each user has exactly one subscription. Set at subscription creation.");

        builder.HasIndex(s => s.UserId)
            .IsUnique()
            .HasDatabaseName("UX_Subscriptions_UserId");


        builder.Property(s => s.SubscriptionTier)
            .HasColumnName("SubscriptionTier")
            .HasColumnType("int")
            .HasConversion<int>()
            .HasDefaultValue(SubscriptionTier.Free)
            .HasComment("Subscription tier/plan level. Values: 0=Free, 1=Basic, 2=Pro. Stored as int for storage efficiency.");

        builder.Property(s => s.SubscriptionDuration)
            .HasColumnName("SubscriptionDuration")
            .HasColumnType("int")
            .HasConversion<int>()
            .HasDefaultValue(SubscriptionDuration.None)
            .HasComment("Subscription duration. Values: 0=None, 1=Month, 2=Year. Stored as int for storage efficiency.");

        builder.Property(s => s.SubscriptionStatus)
            .HasColumnName("SubscriptionStatus")
            .HasColumnType("int")
            .HasConversion<int>()
            .HasDefaultValue(SubscriptionStatus.Active)  // 0 = SubscriptionStatus.Active
            .HasComment("Subscription status. Values: 0=Active, 1=Cancelled, 2=Expired, 3=Trial. Stored as int for storage efficiency.");


        // ==================== Value Objects ====================
        builder.OwnsOne(s => s.DateRange, dateRange =>
        {
            dateRange.Property(dr => dr.StartDate)
                .HasColumnName("StartDate")
                .HasColumnType("datetime2")
                .HasComment("Subscription start date (UTC).");

            dateRange.Property(dr => dr.EndDate)
                .HasColumnName("EndDate")
                .HasColumnType("datetime2")
                .HasComment("Subscription end date (UTC). Optional, set when subscription ends (cancelled, expired, etc.).");
        });

        builder.Property(s => s.StripeSubscriptionId)
            .HasColumnName("StripeSubscriptionId")
            .HasColumnType("nvarchar(255)")
            .HasMaxLength(255)
            .HasComment("Stripe Subscription ID. Optional, populated when linked to Stripe subscription for recurring billing. Used to sync subscription status with Stripe. Max 255 characters.");

        builder.Property(s => s.IsDeleted)
            .HasColumnName("IsDeleted")
            .HasColumnType("bit")
            .IsRequired()
            .HasDefaultValue(false)
            .HasComment("Soft delete flag. False = active subscription, True = deleted.");



        builder.Property(u => u.CreatedAt)
            .HasColumnName("CreatedAt")
            .HasColumnType("datetime2")
            .HasComment("Subscription creation timestamp (UTC). Set once, never changed.");

        builder.Property(u => u.UpdatedAt)
            .HasColumnName("UpdatedAt")
            .HasColumnType("datetime2")
            .HasComment("Last update timestamp (UTC) for the subscription. Updated whenever subscription details are modified.");



        // ==================== Relationships ====================
        builder
            .HasMany(s => s.Payments)
            .WithOne(p => p.Subscription)
            .HasForeignKey(p => p.SubscriptionId)
            .OnDelete(DeleteBehavior.Cascade)
            .HasConstraintName("FK_Payments_Subscriptions_SubscriptionId");

    }

}