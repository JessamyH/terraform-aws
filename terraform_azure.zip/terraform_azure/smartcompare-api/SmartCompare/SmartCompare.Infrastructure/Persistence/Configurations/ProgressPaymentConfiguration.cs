using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.QuoteAggregate;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class ProgressPaymentConfiguration: IEntityTypeConfiguration<ProgressPayment>
{
    public void Configure(EntityTypeBuilder<ProgressPayment> builder)
    {
        // ==================== Table Configuration ====================
        builder.ToTable("ProgressPayments", schema: "dbo");
        
        // ==================== Primary Key ====================
        builder.HasKey(pp => pp.Id);
        
        builder.Property(pp => pp.Id)
            .HasColumnName("Id")
            .IsRequired()
            .ValueGeneratedOnAdd()
            .HasComment("Auto-incrementing unique identifier, set by the database.");
        
        // ==================== Properties ====================
        builder.Property(pp => pp.Description)
            .HasColumnName("Description")
            .HasColumnType("nvarchar(1000)")
            .HasMaxLength(1000)
            .IsRequired()
            .HasComment("Payment stage description, max 1000 characters.");
        
        builder.Property(pp => pp.Percentage)
            .HasColumnName("Percentage")
            .HasColumnType("decimal(5,2)")
            .HasComment("Payment percentage (0-100). Percentage of total quote amount due at this stage.");
        
        // ==================== Foreign Keys ====================
        builder.Property(pp => pp.QuoteId)
            .HasColumnName("QuoteId")
            .HasColumnType("int")
            .IsRequired()
            .HasComment("Foreign Key to Quotes. Progress payment stage belongs to this quote.");
        
        builder.HasIndex(pp => pp.QuoteId)
            .HasDatabaseName("IX_ProgressPayments_QuoteId");
        
        
        builder.HasIndex(pp => new { pp.QuoteId, pp.Description })
            .IsUnique()
            .HasDatabaseName("UX_ProgressPayments_QuoteId_Description");
 
    }
    
}