using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.UserAggregate;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class CompanyProfileConfiguration: IEntityTypeConfiguration<CompanyProfile>
{
    
    public void Configure(EntityTypeBuilder<CompanyProfile> builder)
    { 
        // ==================== Table Configuration ====================
        builder.ToTable("CompanyProfiles", schema: "dbo");
        
        builder.HasKey(cp => cp.Id);
            
        // ==================== Properties ====================
        builder.Property(cp => cp.Id)
            .HasColumnName("Id")
            .HasColumnType("uniqueidentifier")
            .ValueGeneratedNever()
            .HasComment("Set by application, not auto-generated.");
            
        builder.Property(cp => cp.UserId)
            .HasColumnName("UserId")
            .HasColumnType("uniqueidentifier")
            .IsRequired()
            .HasComment("Owner user ID (foreign key to User table).");
        builder.HasIndex(cp => cp.UserId)
            .HasDatabaseName("IX_CompanyProfiles_UserId");
        
        builder.Property(cp => cp.CompanyName)
            .HasColumnName("CompanyName")
            .HasColumnType("nvarchar(500)")
            .IsRequired()
            .HasMaxLength(500)
            .HasComment("Company name (1-500 characters).");
        
        builder.Property(cp => cp.ContactName)
            .HasColumnName("ContactName")
            .HasColumnType("nvarchar(100)")
            .IsRequired()
            .HasMaxLength(100)
            .HasComment("contact person name (1-100 characters).");
        
        
        builder.OwnsOne(cp => cp.ContactEmail, email =>
        {
            email.Property(e => e.Value)
                .HasColumnName("ContactEmail")
                .HasColumnType("nvarchar(254)")
                .IsRequired()
                .HasMaxLength(254)
                .HasComment("Contact email address max 254 chars.");
        });
        
        
        builder.OwnsOne(cp => cp.ContactPhone, phone =>
        {
            phone.Property(p => p.Value)
                .HasColumnName("ContactPhone")
                .HasColumnType("nvarchar(50)")
                .IsRequired()
                .HasMaxLength(50)
                .HasComment("Contact phone number (max 50 characters).");
        });
        
        
        builder.OwnsOne(cp => cp.ABN, abn =>
        {
            abn.Property(a => a.Value)
                .HasColumnName("ABN")
                .HasColumnType("nvarchar(11)")
                .HasMaxLength(11)
                .HasComment("Australian Business Number (11 digits).");
        });

        // ==================== Value Objects ====================
        builder.OwnsOne(cp => cp.Address, address =>
        {
            address.Property(a => a.Street)
                .HasColumnName("Street")
                .HasColumnType("nvarchar(255)")
                .HasComment("Street address line.");

            address.Property(a => a.Suburb)
                .HasColumnName("Suburb")
                .HasColumnType("nvarchar(100)")
                .HasMaxLength(100)
                .HasComment("Suburb or town name.");

            address.Property(a => a.State)
                .HasColumnName("State")
                .HasColumnType("nvarchar(100)")
                .HasMaxLength(100)
                .HasComment("Australian state/territory.");

            address.Property(a => a.PostCode)
                .HasColumnName("PostCode")
                .HasColumnType("int")
                .HasComment("4-digit Australian post code (1000-9999).");
        });


        builder.Property(cp => cp.LogoUrl)
            .HasColumnName("LogoUrl")
            .HasColumnType("nvarchar(max)")
            .HasComment("Company logo URL. Optional.");


        builder.OwnsOne(cp => cp.BankAccount, bankAccount =>
        {
            bankAccount.Property(b => b.BSB)
                .HasColumnName("BSB")
                .HasColumnType("nvarchar(6)")
                .HasMaxLength(6)
                .HasComment("Bank State Branch number (6 digits). Optional.");

            bankAccount.Property(b => b.AccountNumber)
                .HasColumnName("Account")
                .HasColumnType("nvarchar(20)")
                .HasMaxLength(20)
                .HasComment("Bank account number. Optional.");
        });

        builder.Property(cp => cp.LicenseNumber)
            .HasColumnName("LicenceNumber")
            .HasColumnType("nvarchar(max)")
            .HasComment("Business license/permit number. Optional.");
        
        builder.Property(u => u.CreatedAt)
            .HasColumnName("CreatedAt")
            .HasColumnType("datetime2")
            .HasComment("Company profile creation timestamp (UTC). Set once, never changed.");
        
        builder.Property(u => u.UpdatedAt)
            .HasColumnName("UpdatedAt")
            .HasColumnType("datetime2")
            .HasComment("Last update timestamp (UTC) for the company profile. Updated whenever the profile information changes.");
        
            
        // ==================== Indexes ====================
        builder.HasIndex(cp => cp.CompanyName)
            .HasDatabaseName("IX_CompanyProfiles_CompanyName");
            
    }
}