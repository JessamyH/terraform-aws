using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.UserAggregate;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class RoleConfiguration : IEntityTypeConfiguration<Role>
{
    public void Configure(EntityTypeBuilder<Role> builder)
    {
        // ==================== Table Configuration ====================
        builder.ToTable("Roles", schema: "dbo");

        // ==================== Primary Key ====================
        builder.HasKey(r => r.Id);

        builder.Property(r => r.Id)
            .HasColumnName("Id")
            .HasColumnType("uniqueidentifier")
            .IsRequired()
            .ValueGeneratedNever()
            .HasComment("Unique identifier. Set by application, not auto-generated.");

        // ==================== Properties ====================
        builder.Property(r => r.Name)
            .HasColumnName("Name")
            .HasColumnType("nvarchar(50)")
            .HasMaxLength(50)
            .IsRequired()
            .HasComment("Role name (e.g., Admin, User, Manager).");

        // ==================== Indexes ====================
        builder.HasIndex(r => r.Name)
            .IsUnique()
            .HasDatabaseName("UX_Roles_Name");

        // ==================== Relationships ====================
        builder.HasMany(r => r.UserRoles)
            .WithOne(ur => ur.Role)
            .HasForeignKey(ur => ur.RoleId)
            .OnDelete(DeleteBehavior.Cascade)
            .HasConstraintName("FK_UserRoles_Roles_RoleId");

        builder.HasData(
            new { Id = new Guid("00000000-0000-0000-0000-000000000001"), Name = Role.RoleNames.CompanyAdmin },
            new { Id = new Guid("00000000-0000-0000-0000-000000000002"), Name = Role.RoleNames.Admin }
        );
    }
}