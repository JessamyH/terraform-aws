

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.UserAggregate;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class UserRoleConfiguration: IEntityTypeConfiguration<UserRole>
{
    public void Configure(EntityTypeBuilder<UserRole> builder)
    {
        // ==================== Table Configuration ====================
        builder.ToTable("UserRoles", schema: "dbo");
            
        // ==================== Primary Key ====================
        builder.HasKey(ur => ur.Id);
        
        // ==================== Foreign Key ====================
        builder.Property(ur => ur.UserId)
            .HasColumnName("UserId")
            .HasColumnType("uniqueidentifier")
            .IsRequired();

        builder.Property(ur => ur.RoleId)
            .HasColumnName("RoleId")
            .HasColumnType("uniqueidentifier")
            .IsRequired();

        // Prevent duplicate assignment
        builder.HasIndex(ur => new { ur.UserId, ur.RoleId })
          .IsUnique()
          .HasDatabaseName("UX_UserRoles_UserId_RoleId");

        builder.HasIndex(ur => ur.UserId)
            .HasDatabaseName("IX_UserRoles_UserId");
            
        builder.HasIndex(ur => ur.RoleId)
            .HasDatabaseName("IX_UserRoles_RoleId");
    }
}