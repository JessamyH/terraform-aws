using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.QuoteAggregate;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class QuoteConfiguration: IEntityTypeConfiguration<Quote>
{

    public void Configure(EntityTypeBuilder<Quote> builder)
    {
        // ==================== Table Configuration ====================
        builder.ToTable("Quotes", schema: "dbo");
        
        // ==================== Primary Key ====================
        builder.HasKey(q => q.Id);
        
        builder.Property(q => q.Id)
            .HasColumnName("Id")
            .IsRequired()
            .ValueGeneratedOnAdd()
            .HasComment("Auto-incrementing unique identifier, set by the database.");
        
        builder.Property(q => q.PublicId)
            .HasColumnName("PublicId")
            .HasColumnType("uniqueidentifier")
            .IsRequired()
            .HasDefaultValueSql("NEWID()")
            .HasComment("Public business identifier (Guid).");
        
        builder.HasIndex(q => q.PublicId)
            .HasDatabaseName("IX_Quotes_PublicId")
            .IsUnique();
        
        // ==================== Properties ====================
        builder.Property(q => q.QuoteNumber)
            .HasColumnName("QuoteNumber")
            .HasColumnType("nvarchar(200)")
            .HasMaxLength(200)
            .IsRequired()
            .HasComment("Quote number/reference Max 200 characters.");
        
        builder.Property(q => q.IssuedDate)
            .HasColumnName("IssuedDate")
            .HasColumnType("datetime2")
            .IsRequired()
            .HasComment("Quote issuance date (UTC). Date when quote was created and sent to customer.");
        
        builder.Property(q => q.ValidDate)
            .HasColumnName("ValidDate")
            .HasColumnType("datetime2")
            .IsRequired()
            .HasComment("Quote validity date (UTC). Quote expires after this date and is no longer valid for acceptance.");
        
        builder.Property(q => q.IssuedBy)
            .HasColumnName("IssuedBy")
            .HasColumnType("nvarchar(255)")
            .HasMaxLength(255)
            .IsRequired()
            .HasComment("Issued by (person/company).");
        
        builder.Property(q => q.IssuedTo)
            .HasColumnName("IssuedTo")
            .HasColumnType("nvarchar(255)")
            .HasMaxLength(255)
            .IsRequired()
            .HasComment("Issued to (customer).Customer name or contact person who receives the quote. Max 255 characters.");
        
        builder.Property(q => q.SubTotal)
            .HasColumnName("SubTotal")
            .HasColumnType("decimal(18,2)")
            .IsRequired()
            .HasComment("Subtotal amount before tax. Work pricing without GST.");
        
        builder.Property(q => q.GST)
            .HasColumnName("GST")
            .HasColumnType("decimal(18,2)")
            .IsRequired()
            .HasComment("GST typically 10% in Australia).");
        
        builder.Property(q => q.Total)
            .HasColumnName("Total")
            .HasColumnType("decimal(18,2)")
            .IsRequired()
            .HasComment("Total amount. SubTotal + GST. Final amount customer needs to pay.");
        
        builder.Property(q => q.ValidPeriod)
            .HasColumnName("ValidPeriod")
            .HasColumnType("int")
            .IsRequired()
            .HasComment("Quote validity period in days. ValidDate is computed as IssuedDate + ValidPeriod.");

        builder.OwnsOne(q => q.ABN, abn =>
        {
            abn.Property(a => a.Value)
                .HasColumnName("ABN")
                .HasColumnType("nvarchar(20)")
                .HasMaxLength(20)
                .IsRequired()
                .HasComment("Australian Business Number (11 digits, stored without spaces).");
        });

        builder.Property(q => q.LicenseNumber)
            .HasColumnName("LicenseNumber")
            .HasColumnType("nvarchar(50)")
            .HasMaxLength(50)
            .IsRequired()
            .HasComment("Contractor license number. Max 50 characters.");

        builder.Property(q => q.ContactName)
            .HasColumnName("ContactName")
            .HasColumnType("nvarchar(200)")
            .HasMaxLength(200)
            .IsRequired()
            .HasComment("Contact person name. Max 200 characters.");

        builder.Property(q => q.ContactEmail)
            .HasColumnName("ContactEmail")
            .HasColumnType("nvarchar(255)")
            .HasMaxLength(255)
            .IsRequired()
            .HasComment("Contact person email address. Max 255 characters.");

        builder.Property(q => q.ContactPhone)
            .HasColumnName("ContactPhone")
            .HasColumnType("nvarchar(30)")
            .HasMaxLength(30)
            .IsRequired()
            .HasComment("Contact person phone number. Max 30 characters.");

        builder.Property(q => q.PDFUrl)
            .HasColumnName("PDFUrl")
            .HasColumnType("nvarchar(500)")
            .HasMaxLength(500)
            .IsRequired(false)
            .HasComment("PDF file URL (optional). URL path to stored PDF version of quote for download/preview. Max 500 characters.");
        
        builder.Property(u => u.CreatedAt)
            .HasColumnName("CreatedAt")
            .HasColumnType("datetime2")
            .HasComment("Quote creation timestamp (UTC). Set once, never changed.");
        
        builder.Property(u => u.UpdatedAt)
            .HasColumnName("UpdatedAt")
            .HasColumnType("datetime2")
            .HasComment("Last update timestamp (UTC) for the quote. Updated whenever quote details are modified.");
        
        
        // ==================== Foreign Keys ====================
        builder.Property(q => q.ProjectId)
            .HasColumnName("ProjectId")
            .IsRequired()
            .HasComment("Foreign Key to Projects. Quote belongs to this project.");
        builder.HasIndex(q => q.ProjectId)
            .HasDatabaseName("IX_Quotes_ProjectId");
        
        // ==================== Relationships ====================
        builder
            .HasMany(q => q.ScopeOfWorks)
            .WithOne(sow => sow.Quote)
            .HasForeignKey(sow => sow.QuoteId)
            .OnDelete(DeleteBehavior.Cascade)
            .IsRequired()
            .HasConstraintName("FK_ScopeOfWorks_Quotes_QuoteId");
        
        builder
            .HasMany(q => q.Exclusions)
            .WithOne(e => e.Quote)
            .HasForeignKey(e => e.QuoteId)
            .OnDelete(DeleteBehavior.Cascade)
            .IsRequired()
            .HasConstraintName("FK_Exclusions_Quotes_QuoteId");
        
        builder
            .HasMany(q => q.ProgressPayments)
            .WithOne(pp => pp.Quote)
            .HasForeignKey(pp => pp.QuoteId)
            .OnDelete(DeleteBehavior.Cascade)
            .IsRequired()
            .HasConstraintName("FK_ProgressPayments_Quotes_QuoteId");
    }
    
}