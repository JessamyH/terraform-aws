using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.QuoteAggregate;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class ExclusionConfiguration: IEntityTypeConfiguration<Exclusion>
{
    public void Configure(EntityTypeBuilder<Exclusion> builder)
    {
        // ==================== Table Configuration ====================
        builder.ToTable("Exclusions", schema: "dbo");
        
        // ==================== Primary Key ====================
        builder.HasKey(e => e.Id);
        
        builder.Property(e => e.Id)
            .HasColumnName("Id")
            .IsRequired()
            .ValueGeneratedOnAdd()
            .HasComment("Auto-incrementing unique identifier, set by the database.");
        
        // ==================== Properties ====================
        builder.Property(e => e.Description)
            .HasColumnName("Description")
            .HasColumnType("nvarchar(1000)")
            .HasMaxLength(1000)
            .IsRequired()
            .HasComment("Description of exclusion items. ");
        
        // ==================== Foreign Keys ====================
        builder.Property(e => e.QuoteId)
            .HasColumnName("QuoteId")
            .HasColumnType("int")
            .IsRequired()
            .HasComment("Foreign Key to Quotes. Exclusion item belongs to this quote.");
        builder.HasIndex(e => e.QuoteId)
            .HasDatabaseName("IX_Exclusions_QuoteId");
        
        builder.HasIndex(e => new { e.QuoteId, e.Description })
            .IsUnique()
            .HasDatabaseName("UX_Exclusions_QuoteId_Description");
        
    }
}