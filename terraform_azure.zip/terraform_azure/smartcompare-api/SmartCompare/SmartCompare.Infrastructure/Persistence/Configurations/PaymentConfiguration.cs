using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.PaymentAggregate;
using SmartCompare.Domain.Enums;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class PaymentsConfiguration : IEntityTypeConfiguration<Payment>
{

    public void Configure(EntityTypeBuilder<Payment> builder)
    {
        
        builder.ToTable("Payments", schema: "dbo");
        
        // Primary Key
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id)
            .HasColumnName("PaymentId")
            .IsRequired()
            .ValueGeneratedOnAdd()
            .HasComment("Auto-incrementing unique identifier, set by the database.");
        
        // Foreign Keys
        // builder.Property(p => p.UserId)
        //     .HasColumnName("UserId")
        //     .IsRequired()
        //     .HasComment("Foreign Key to Users. The user who made the payment.");
        // builder.HasIndex(p => p.UserId)
        //     .HasDatabaseName("IX_Payments_UserId");
        
        // Foreign Keys
        builder.Property(p => p.SubscriptionId)
            .HasColumnName("SubscriptionId")
            .IsRequired()
            .HasComment("Foreign Key to Subscriptions. The subscription this payment is associated with.");
        builder.HasIndex(p => p.SubscriptionId)
            .HasDatabaseName("IX_Payments_SubscriptionId");


        // Properties - Money Value Object
        builder.OwnsOne(p => p.PaymentAmount, money =>
        {
            money.Property(m => m.Amount)
                .HasColumnName("Amount")
                .HasColumnType("decimal(18,2)")
                .IsRequired()
                .HasComment("Payment amount. Stored with 2 decimal places (e.g., 99.99).");

            money.Property(m => m.Currency)
                .HasColumnName("Currency")
                .HasColumnType("nvarchar(3)")
                .IsRequired()
                .HasMaxLength(3)
                .HasComment("ISO 4217 currency code (3 chars, e.g., AUD, USD, CNY).");
        });

        builder.Property(p => p.Status)
            .HasColumnName("Status")
            .HasColumnType("int")
            .IsRequired()
            .HasConversion<int>()
            .HasDefaultValue(PaymentStatus.Pending)
            .HasComment("Payment status. Values: 0=Pending, 1=Succeeded, 2=Failed, 3=Refunded, 4=PartiallyRefunded. Stored as int for storage efficiency.");
        
        builder.Property(p => p.Type)
            .HasColumnName("Type")
            .HasColumnType("int")
            .IsRequired()
            .HasConversion<int>()
            .HasDefaultValue(PaymentType.Subscription)
            .HasComment("Payment type. Values: 0=Subscription, 1=OneTime, 2=Upgrade, 3=Refund. Stored as int for storage efficiency.");
        
        builder.Property(p => p.StripePaymentIntentId)
            .HasColumnName("StripePaymentIntentId")
            .HasColumnType("nvarchar(255)")
            .IsRequired(false)
            .HasMaxLength(255)
            .HasComment("Stripe PaymentIntent ID. Nullable — not available in invoice.paid webhook payload (v2026 API). One-time payments fill this.");
        builder.HasIndex(p => p.StripePaymentIntentId)
            .IsUnique()
            .HasFilter("[StripePaymentIntentId] IS NOT NULL")
            .HasDatabaseName("IX_Payments_StripePaymentIntentId");
        
        builder.Property(p => p.StripeInvoiceId)
            .HasColumnName("StripeInvoiceId")
            .HasColumnType("nvarchar(255)")
            .IsRequired(false)
            .HasMaxLength(255)
            .HasComment("Stripe Invoice ID. Nullable — subscription payments fill this, one-time payments may not.");
        builder.HasIndex(p => p.StripeInvoiceId)
            .IsUnique()
            .HasFilter("[StripeInvoiceId] IS NOT NULL")
            .HasDatabaseName("IX_Payments_StripeInvoiceId");
        
        builder.Property(p => p.StripeChargeId)
            .HasColumnName("StripeChargeId")
            .HasColumnType("nvarchar(255)")
            .IsRequired(false)
            .HasMaxLength(255)
            .HasComment("Stripe Charge ID. Optional, populated only when a charge is successfully created. Max 255 characters.");
        
        
        builder.Property(p => p.PaidAt)
            .HasColumnName("PaidAt")
            .HasColumnType("datetime2")
            .IsRequired(false)
            .HasComment("Payment confirmation timestamp (UTC). Set when payment succeeds. Null for pending/failed payments.");

        builder.Property(p => p.RefundedAt)
            .HasColumnName("RefundedAt")
            .HasColumnType("datetime2")
            .IsRequired(false)
            .HasComment("Refund timestamp (UTC). Set when payment is refunded. Null for non-refunded payments.");
        
        builder.Property(p => p.FailureReason)
            .HasColumnName("FailureReason")
            .HasColumnType("nvarchar(500)")
            .IsRequired(false)
            .HasMaxLength(500)
            .HasComment("Reason for payment failure (if failed). Examples: 'Card declined', 'Insufficient funds'. Null for successful payments. Max 500 characters.");
        
        builder.Property(p => p.Description)
            .HasColumnName("Description")
            .HasColumnType("nvarchar(500)")
            .IsRequired(false)
            .HasMaxLength(500)
            .HasComment("Payment description or memo. Examples: 'Monthly subscription renewal', 'Annual plan upgrade'. Max 500 characters.");
        
        builder.Property(p => p.CreatedAt)
            .HasColumnName("CreatedAt")
            .HasColumnType("datetime2")
            .HasComment("Payment record creation timestamp (UTC). Set once, never changed. Tracks when this payment record was created.");
        
        builder.Property(u => u.UpdatedAt)
            .HasColumnName("UpdatedAt")
            .HasColumnType("datetime2")
            .HasComment("Last update timestamp (UTC) for payment information. Updated whenever payment details are modified.");
    }
}