using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.UserAggregate;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class UserConfiguration: IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        // ==================== Table Configuration ====================
        builder.ToTable("Users", schema: "dbo");
            
        // ==================== Primary Key ====================
        builder.HasKey(u => u.Id);

        // ==================== Properties ====================
        builder.Property(u => u.Id)
            .HasColumnName("Id")
            .HasColumnType("uniqueidentifier")
            .IsRequired()
            .ValueGeneratedNever()
            .HasComment("Unique identifier. Set by application, not auto-generated.");

        builder.Property(u => u.Auth0SubjectId)
            .HasColumnName("Auth0SubjectId")
            .HasColumnType("nvarchar(256)")
            .IsRequired()
            .HasComment("Auth0 Subject ID.");
        
        builder.Property(u => u.UserName)
            .HasColumnName("UserName")
            .HasColumnType("nvarchar(100)")
            .IsRequired()
            .HasMaxLength(100)
            .HasComment("User display name (2-100 characters).");

        builder.OwnsOne(u => u.Email, email =>
        {
            email.Property(e => e.Value)
                .HasColumnName("Email")
                .HasColumnType("nvarchar(254)")
                .IsRequired()
                .HasMaxLength(254)
                .HasComment("User email max 254 chars.");

            email.HasIndex(e => e.Value)
                .IsUnique()
                .HasDatabaseName("IX_Users_Email");
        });
        
        builder.Property(u => u.CreatedAt)
            .HasColumnName("CreatedAt")
            .HasColumnType("datetime2")
            .HasComment("Account creation timestamp (UTC). Set once, never changed.");
        
        builder.Property(u => u.UpdatedAt)
            .HasColumnName("UpdatedAt")
            .HasColumnType("datetime2")
            .HasComment("Last update timestamp (UTC). Updated whenever user info changes.");
        
        builder.Property(u => u.LastLoginAt)
            .HasColumnName("LastLoginAt")
            .HasColumnType("datetime2")
            .HasComment("Last successful login timestamp (UTC), nullable. Null until first login.");

        builder.Property(u => u.StripeCustomerId)
            .HasColumnName("StripeCustomerId")
            .HasColumnType("nvarchar(255)")
            .IsRequired(false)
            .IsConcurrencyToken()
            .HasComment("Stripe Customer ID. Null until first payment. Format: cus_xxxxx");
        
        // ==================== Indexes ====================
        builder.HasIndex(u => u.Auth0SubjectId)
            .IsUnique()
            .HasDatabaseName("IX_Users_Auth0SubjectId");
        
        builder.HasIndex(u => u.StripeCustomerId)
            .IsUnique()
            .HasFilter("[StripeCustomerId] IS NOT NULL")
            .HasDatabaseName("IX_Users_StripeCustomerId");
        
        // ==================== Relationships ====================
        builder.HasMany(u => u.CompanyProfiles)
            .WithOne(cp => cp.User)
            .HasForeignKey(cp => cp.UserId)
            .OnDelete(DeleteBehavior.Cascade)
            .IsRequired(true)
            .HasConstraintName("FK_CompanyProfiles_Users_UserId");
        
        builder.HasOne(u => u.Subscription)
            .WithOne(s => s.User)
            .HasForeignKey<Subscription>(s => s.UserId)
            .OnDelete(DeleteBehavior.Cascade)
            .IsRequired(false)
            .HasConstraintName("FK_Subscriptions_Users_UserId");

        builder.HasMany(u => u.Projects)
            .WithOne(p => p.User)
            .HasForeignKey(p => p.UserId)
            .OnDelete(DeleteBehavior.Restrict)
            .HasConstraintName("FK_Projects_Users_UserId");

        builder.HasMany(u => u.UserRoles)
            .WithOne(cp => cp.User)
            .HasForeignKey(cp => cp.UserId)
            .OnDelete(DeleteBehavior.Cascade)
            .HasConstraintName("FK_UserRoles_Users_UserId");

    }
}