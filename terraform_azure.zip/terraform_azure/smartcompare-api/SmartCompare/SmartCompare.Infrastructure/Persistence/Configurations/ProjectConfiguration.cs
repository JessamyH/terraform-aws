using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Enums;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class ProjectConfiguration: IEntityTypeConfiguration<Project>
{
    public void Configure(EntityTypeBuilder<Project> builder)
    {
        // ==================== Table Configuration ====================
        builder.ToTable("Projects", schema: "dbo");
        
        // ==================== Primary Key ====================
        builder.HasKey(p => p.Id);
        
        builder.Property(e => e.Id)
            .HasColumnName("Id")
            .IsRequired()
            .ValueGeneratedOnAdd()
            .HasComment("Auto-incrementing unique identifier, set by the database.");
        
        // ==================== Properties ====================
        
        builder.Property(p => p.PublicId)
            .HasColumnName("PublicId")
            .HasColumnType("uniqueidentifier")
            .IsRequired()
            .HasDefaultValueSql("NEWID()")
            .HasComment("Public business identifier (Guid).");
        
        builder.HasIndex(p => p.PublicId)
            .HasDatabaseName("IX_Projects_PublicId")
            .IsUnique();
        
        
        builder.Property(p => p.ProjectName)
            .HasColumnName("ProjectName")
            .HasColumnType("nvarchar(255)")
            .HasMaxLength(255)
            .IsRequired()
            .HasComment("Project name, Max 255 characters.");
        
        builder.Property(p => p.Address)
            .HasColumnName("Address")
            .HasColumnType("nvarchar(500)")
            .HasMaxLength(500)
            .IsRequired()
            .HasComment("Project location/address. Max 500 characters.");

        builder.Property(p => p.HouseType)
            .HasColumnName("HouseType")
            .HasColumnType("int")
            .IsRequired()
            .HasConversion<int>()
            .HasComment("House type. Values: 0=House, 1=Apartment, 2=Townhouse, 3=Unit, 4=Other.");

        builder.Property(p => p.HouseSizeSqm)
            .HasColumnName("HouseSizeSqm")
            .HasColumnType("decimal(18,2)")
            .IsRequired()
            .HasComment("House size in square metres.");

        builder.Property(p => p.Bedrooms)
            .HasColumnName("Bedrooms")
            .HasColumnType("int")
            .IsRequired()
            .HasComment("Number of bedrooms.");

        builder.Property(p => p.Bathrooms)
            .HasColumnName("Bathrooms")
            .HasColumnType("int")
            .IsRequired()
            .HasComment("Number of bathrooms.");

        builder.Property(p => p.Status)
            .HasColumnName("Status")
            .HasColumnType("int")
            .IsRequired()
            .HasConversion<int>()
            .HasDefaultValue(ProjectStatus.Inquiry)
            .HasComment("Project status. Values: 0=Inquiry, 1=QuoteSent, 2=QuoteApproved, 3=Scheduled, 4=InProgress, 5=OnHold, 6=Completed, 7=Invoiced, 8=Paid, 9=Cancelled.");
        
        // ==================== Foreign Keys ====================
        builder.Property(cp => cp.UserId)
            .HasColumnName("UserId")
            .IsRequired()
            .HasComment("Owner user ID (foreign key to User table).");
        
        builder.HasIndex(p => p.UserId)
            .HasDatabaseName("IX_Projects_UserId");

        
        builder.Property(p => p.SubcontractorTypeId)
            .HasColumnName("SubcontractorTypeId")
            .HasColumnType("int")
            .IsRequired()
            .HasComment("Foreign Key to SubcontractorTypes.");
        
        builder.HasIndex(p => p.SubcontractorTypeId)
            .HasDatabaseName("IX_Projects_SubcontractorTypeId");
        
        builder.Property(p => p.CreatedAt)
            .HasColumnName("CreatedAt")
            .HasColumnType("datetime2")
            .IsRequired()
            .HasComment("Project creation timestamp (UTC).");
        
        builder.Property(p => p.UpdatedAt)
            .HasColumnName("UpdatedAt")
            .HasColumnType("datetime2")
            .IsRequired(false)
            .HasComment("Project last update timestamp (UTC).");

        builder.Property(p => p.DeletedAt)
            .HasColumnName("DeletedAt")
            .HasColumnType("datetime2")
            .IsRequired(false)
            .HasComment("Project deletion timestamp (UTC). Null if not deleted.");

        
        // ==================== Relationships ====================
        builder
            .HasMany(p => p.Quotes)
            .WithOne(q => q.Project)
            .HasForeignKey(q => q.ProjectId)
            .OnDelete(DeleteBehavior.Cascade)
            .IsRequired()
            .HasConstraintName("FK_Quotes_Projects_ProjectId");
        //builder.HasQueryFilter(p => !p.IsDeleted);
    }
}