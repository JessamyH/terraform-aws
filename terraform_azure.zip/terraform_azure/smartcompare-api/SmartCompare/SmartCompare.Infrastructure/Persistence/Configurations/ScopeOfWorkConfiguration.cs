using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.QuoteAggregate;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class ScopeOfWorkConfiguration: IEntityTypeConfiguration<ScopeOfWork>
{
    public void Configure(EntityTypeBuilder<ScopeOfWork> builder)
    {
        // ==================== Table Configuration ====================
        builder.ToTable("ScopeOfWorks", schema: "dbo");
        
        // ==================== Primary Key ====================
        builder.HasKey(sow => sow.Id);
        
        builder.Property(sow => sow.Id)
            .HasColumnName("Id")
            .IsRequired()
            .ValueGeneratedOnAdd()
            .HasComment("Auto-incrementing unique identifier, set by the database.");
        
        // ==================== Properties ====================
        builder.Property(sow => sow.Description)
            .HasColumnName("Description")
            .HasColumnType("nvarchar(1000)")
            .IsRequired()
            .HasMaxLength(1000)
            .HasComment("Detailed description of work scope.max 1000 characters.");
        
        // ==================== Foreign Keys ====================
        builder.Property(sow => sow.QuoteId)
            .HasColumnName("QuoteId")
            .HasColumnType("int")
            .IsRequired()
            .HasComment("Foreign Key to Quotes. Scope of work belongs to this quote.");
        builder.HasIndex(sow => sow.QuoteId)
            .HasDatabaseName("IX_ScopeOfWorks_QuoteId");
        
        
        builder.HasIndex(sow => new { sow.QuoteId, sow.Description })
            .IsUnique()
            .HasDatabaseName("UX_ScopeOfWorks_QuoteId_Description");
        
    }
}