using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SmartCompare.Domain.Entities.ProjectAggregate;

namespace SmartCompare.Infrastructure.Persistence.Configurations;

public class SubcontractorTypeConfiguration : IEntityTypeConfiguration<SubcontractorTypes>
{

    public void Configure(EntityTypeBuilder<SubcontractorTypes> builder)
    {
        // ==================== Table Configuration ====================
        builder.ToTable("SubcontractorTypes", schema: "dbo");

        // ==================== Primary Key ====================
        builder.HasKey(st => st.Id);

        builder.Property(st => st.Id)
            .HasColumnName("Id")
            .IsRequired()
            .ValueGeneratedOnAdd()
            .HasComment("Auto-incrementing unique identifier, set by the database.");

        // ==================== Properties ====================
        builder.Property(st => st.Type)
            .HasColumnName("Type")
            .HasColumnType("nvarchar(100)")
            .HasMaxLength(100)
            .IsRequired()
            .HasComment("Subcontractor type name/category.");

        // ==================== Relationships ====================
        builder
            .HasMany(st => st.Projects)
            .WithOne(p => p.SubcontractorType)
            .HasForeignKey(p => p.SubcontractorTypeId)
            .OnDelete(DeleteBehavior.Restrict)
            .IsRequired(true)
            .HasConstraintName("FK_Projects_SubcontractorTypes_SubcontractorTypeId");

        // ==================== Seed Data ====================
        builder.HasData(
            new { Id = 1, Type = "Gyprock" }
        );
    }
}