﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SmartCompare.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddStripeCustomerIdToUser : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "StripeCustomerId",
                schema: "dbo",
                table: "Users",
                type: "nvarchar(255)",
                nullable: true,
                comment: "Stripe Customer ID. Null until first payment. Format: cus_xxxxx");

            migrationBuilder.CreateIndex(
                name: "IX_Users_StripeCustomerId",
                schema: "dbo",
                table: "Users",
                column: "StripeCustomerId",
                unique: true,
                filter: "[StripeCustomerId] IS NOT NULL");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Users_StripeCustomerId",
                schema: "dbo",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "StripeCustomerId",
                schema: "dbo",
                table: "Users");
        }
    }
}
