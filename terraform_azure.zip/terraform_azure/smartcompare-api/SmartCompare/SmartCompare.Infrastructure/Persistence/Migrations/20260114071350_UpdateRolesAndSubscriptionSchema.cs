﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SmartCompare.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class UpdateRolesAndSubscriptionSchema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "SubscriptionTier",
                schema: "dbo",
                table: "Subscriptions",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "Subscription tier/plan level. Values: 0=Free, 1=Basic, 2=Pro. Stored as int for storage efficiency.",
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValue: 0,
                oldComment: "Subscription tier/plan level. Values: 0=Free, 1=Monthly, 2=Yearly. Stored as int for storage efficiency.");

            migrationBuilder.AddColumn<int>(
                name: "SubscriptionDuration",
                schema: "dbo",
                table: "Subscriptions",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "Subscription duration. Values: 0=None, 1=Month, 2=Year. Stored as int for storage efficiency.");

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Roles",
                keyColumn: "Id",
                keyValue: new Guid("00000000-0000-0000-0000-000000000001"),
                column: "Name",
                value: "CompanyAdmin");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SubscriptionDuration",
                schema: "dbo",
                table: "Subscriptions");

            migrationBuilder.AlterColumn<int>(
                name: "SubscriptionTier",
                schema: "dbo",
                table: "Subscriptions",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "Subscription tier/plan level. Values: 0=Free, 1=Monthly, 2=Yearly. Stored as int for storage efficiency.",
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValue: 0,
                oldComment: "Subscription tier/plan level. Values: 0=Free, 1=Basic, 2=Pro. Stored as int for storage efficiency.");

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Roles",
                keyColumn: "Id",
                keyValue: new Guid("00000000-0000-0000-0000-000000000001"),
                column: "Name",
                value: "User");
        }
    }
}
