﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SmartCompare.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class RenameIsActiveToIsDeleted : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsActive",
                schema: "dbo",
                table: "Subscriptions");

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                schema: "dbo",
                table: "Subscriptions",
                type: "bit",
                nullable: false,
                defaultValue: false,
                comment: "Soft delete flag. False = active subscription, True = deleted.");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsDeleted",
                schema: "dbo",
                table: "Subscriptions");

            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                schema: "dbo",
                table: "Subscriptions",
                type: "bit",
                nullable: false,
                defaultValue: true,
                comment: "True if subscription is valid and user can use it. False if subscription is paused, cancelled, or expired.");
        }
    }
}
