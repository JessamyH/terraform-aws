﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace SmartCompare.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddRoleAndUserRoleEntities : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Projects_Users_UserId",
                schema: "dbo",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "LastRefreshAt",
                schema: "dbo",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "RefreshToken",
                schema: "dbo",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "RefreshTokenExpiresAt",
                schema: "dbo",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Role",
                schema: "dbo",
                table: "Users");

            migrationBuilder.AlterColumn<int>(
                name: "SubscriptionTier",
                schema: "dbo",
                table: "Subscriptions",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "Subscription tier/plan level. Values: 0=Free, 1=Monthly, 2=Yearly. Stored as int for storage efficiency.",
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValue: 0,
                oldComment: "Subscription tier/plan level. Values: 0=Free, 1=Pro, 2=Enterprise. Stored as int for storage efficiency.");

            migrationBuilder.AlterColumn<int>(
                name: "SubscriptionStatus",
                schema: "dbo",
                table: "Subscriptions",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "Subscription status. Values: 0=Active, 1=Cancelled, 2=Expired, 3=Trial. Stored as int for storage efficiency.",
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValue: 0,
                oldComment: "Subscription status. Values: 0=Active, 1=Paused, 2=Cancelled, 3=Expired. Stored as int for storage efficiency.");

            migrationBuilder.CreateTable(
                name: "Roles",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false, comment: "Unique identifier. Set by application, not auto-generated."),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false, comment: "Role name (e.g., Admin, User, Manager).")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Roles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserRoles",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RoleId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserRoles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UserRoles_Roles_RoleId",
                        column: x => x.RoleId,
                        principalSchema: "dbo",
                        principalTable: "Roles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserRoles_Users_UserId",
                        column: x => x.UserId,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "Roles",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { new Guid("00000000-0000-0000-0000-000000000001"), "User" },
                    { new Guid("00000000-0000-0000-0000-000000000002"), "Admin" }
                });

            migrationBuilder.CreateIndex(
                name: "UX_Roles_Name",
                schema: "dbo",
                table: "Roles",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserRoles_RoleId",
                schema: "dbo",
                table: "UserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_UserRoles_UserId",
                schema: "dbo",
                table: "UserRoles",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "UX_UserRoles_UserId_RoleId",
                schema: "dbo",
                table: "UserRoles",
                columns: new[] { "UserId", "RoleId" },
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Projects_Users_UserId",
                schema: "dbo",
                table: "Projects",
                column: "UserId",
                principalSchema: "dbo",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Projects_Users_UserId",
                schema: "dbo",
                table: "Projects");

            migrationBuilder.DropTable(
                name: "UserRoles",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Roles",
                schema: "dbo");

            migrationBuilder.AddColumn<DateTime>(
                name: "LastRefreshAt",
                schema: "dbo",
                table: "Users",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                comment: "Last refresh token update timestamp (UTC), nullable.");

            migrationBuilder.AddColumn<string>(
                name: "RefreshToken",
                schema: "dbo",
                table: "Users",
                type: "nvarchar(max)",
                nullable: true,
                comment: "Current refresh token for obtaining new access tokens, nullable.");

            migrationBuilder.AddColumn<DateTime>(
                name: "RefreshTokenExpiresAt",
                schema: "dbo",
                table: "Users",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                comment: "Refresh token expiration timestamp (UTC), nullable. Token invalid after this time.");

            migrationBuilder.AddColumn<string>(
                name: "Role",
                schema: "dbo",
                table: "Users",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "",
                comment: "User role");

            migrationBuilder.AlterColumn<int>(
                name: "SubscriptionTier",
                schema: "dbo",
                table: "Subscriptions",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "Subscription tier/plan level. Values: 0=Free, 1=Pro, 2=Enterprise. Stored as int for storage efficiency.",
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValue: 0,
                oldComment: "Subscription tier/plan level. Values: 0=Free, 1=Monthly, 2=Yearly. Stored as int for storage efficiency.");

            migrationBuilder.AlterColumn<int>(
                name: "SubscriptionStatus",
                schema: "dbo",
                table: "Subscriptions",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "Subscription status. Values: 0=Active, 1=Paused, 2=Cancelled, 3=Expired. Stored as int for storage efficiency.",
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValue: 0,
                oldComment: "Subscription status. Values: 0=Active, 1=Cancelled, 2=Expired, 3=Trial. Stored as int for storage efficiency.");

            migrationBuilder.AddForeignKey(
                name: "FK_Projects_Users_UserId",
                schema: "dbo",
                table: "Projects",
                column: "UserId",
                principalSchema: "dbo",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
