﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SmartCompare.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddQuoteContactAndBusinessFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ABN",
                schema: "dbo",
                table: "Quotes",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "",
                comment: "Australian Business Number (11 digits, stored without spaces).");

            migrationBuilder.AddColumn<string>(
                name: "ContactEmail",
                schema: "dbo",
                table: "Quotes",
                type: "nvarchar(255)",
                maxLength: 255,
                nullable: false,
                defaultValue: "",
                comment: "Contact person email address. Max 255 characters.");

            migrationBuilder.AddColumn<string>(
                name: "ContactName",
                schema: "dbo",
                table: "Quotes",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: false,
                defaultValue: "",
                comment: "Contact person name. Max 200 characters.");

            migrationBuilder.AddColumn<string>(
                name: "ContactPhone",
                schema: "dbo",
                table: "Quotes",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: false,
                defaultValue: "",
                comment: "Contact person phone number. Max 30 characters.");

            migrationBuilder.AddColumn<string>(
                name: "LicenseNumber",
                schema: "dbo",
                table: "Quotes",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "",
                comment: "Contractor license number. Max 50 characters.");

            migrationBuilder.AddColumn<int>(
                name: "ValidPeriod",
                schema: "dbo",
                table: "Quotes",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "Quote validity period in days. ValidDate is computed as IssuedDate + ValidPeriod.");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ABN",
                schema: "dbo",
                table: "Quotes");

            migrationBuilder.DropColumn(
                name: "ContactEmail",
                schema: "dbo",
                table: "Quotes");

            migrationBuilder.DropColumn(
                name: "ContactName",
                schema: "dbo",
                table: "Quotes");

            migrationBuilder.DropColumn(
                name: "ContactPhone",
                schema: "dbo",
                table: "Quotes");

            migrationBuilder.DropColumn(
                name: "LicenseNumber",
                schema: "dbo",
                table: "Quotes");

            migrationBuilder.DropColumn(
                name: "ValidPeriod",
                schema: "dbo",
                table: "Quotes");
        }
    }
}
