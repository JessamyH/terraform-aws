﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SmartCompare.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class RedesignPaymentModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Payments_StripePaymentIntentId",
                schema: "dbo",
                table: "Payments");

            migrationBuilder.AlterColumn<string>(
                name: "StripePaymentIntentId",
                schema: "dbo",
                table: "Payments",
                type: "nvarchar(255)",
                maxLength: 255,
                nullable: true,
                comment: "Stripe PaymentIntent ID. Nullable — not available in invoice.paid webhook payload (v2026 API). One-time payments fill this.",
                oldClrType: typeof(string),
                oldType: "nvarchar(255)",
                oldMaxLength: 255,
                oldComment: "Stripe PaymentIntent ID. Unique identifier from Stripe API. Used for idempotency and payment tracking.");

            migrationBuilder.AlterColumn<string>(
                name: "StripeInvoiceId",
                schema: "dbo",
                table: "Payments",
                type: "nvarchar(255)",
                maxLength: 255,
                nullable: true,
                comment: "Stripe Invoice ID. Nullable — subscription payments fill this, one-time payments may not.",
                oldClrType: typeof(string),
                oldType: "nvarchar(255)",
                oldMaxLength: 255,
                oldNullable: true,
                oldComment: "Stripe Invoice ID. Optional, populated only for successful subscription payments. Max 255 characters.");

            migrationBuilder.AlterColumn<DateTime>(
                name: "RefundedAt",
                schema: "dbo",
                table: "Payments",
                type: "datetime2",
                nullable: true,
                comment: "Refund timestamp (UTC). Set when payment is refunded. Null for non-refunded payments.",
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldComment: "Refund timestamp (UTC). Set when payment is refunded. Null for non-refunded payments.");

            migrationBuilder.AlterColumn<DateTime>(
                name: "PaidAt",
                schema: "dbo",
                table: "Payments",
                type: "datetime2",
                nullable: true,
                comment: "Payment confirmation timestamp (UTC). Set when payment succeeds. Null for pending/failed payments.",
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldComment: "Payment confirmation timestamp (UTC). Set when payment succeeds. Null for pending/failed payments.");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_StripeInvoiceId",
                schema: "dbo",
                table: "Payments",
                column: "StripeInvoiceId",
                unique: true,
                filter: "[StripeInvoiceId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_StripePaymentIntentId",
                schema: "dbo",
                table: "Payments",
                column: "StripePaymentIntentId",
                unique: true,
                filter: "[StripePaymentIntentId] IS NOT NULL");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            throw new InvalidOperationException(
                "This migration cannot be reversed. Rolling back would set PaidAt/RefundedAt to NOT NULL " +
                "(corrupting NULL rows with 0001-01-01) and restore a non-filtered unique index on " +
                "StripePaymentIntentId (crashing on multiple NULL values). " +
                "Restore from a database backup if rollback is needed.");
        }
    }
}
