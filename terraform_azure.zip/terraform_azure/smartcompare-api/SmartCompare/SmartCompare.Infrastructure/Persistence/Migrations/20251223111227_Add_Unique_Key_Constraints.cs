﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SmartCompare.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class Add_Unique_Key_Constraints : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "UX_ScopeOfWorks_QuoteId_Description",
                schema: "dbo",
                table: "ScopeOfWorks",
                columns: new[] { "QuoteId", "Description" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UX_ProgressPayments_QuoteId_Description",
                schema: "dbo",
                table: "ProgressPayments",
                columns: new[] { "QuoteId", "Description" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UX_Exclusions_QuoteId_Description",
                schema: "dbo",
                table: "Exclusions",
                columns: new[] { "QuoteId", "Description" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "UX_ScopeOfWorks_QuoteId_Description",
                schema: "dbo",
                table: "ScopeOfWorks");

            migrationBuilder.DropIndex(
                name: "UX_ProgressPayments_QuoteId_Description",
                schema: "dbo",
                table: "ProgressPayments");

            migrationBuilder.DropIndex(
                name: "UX_Exclusions_QuoteId_Description",
                schema: "dbo",
                table: "Exclusions");
        }
    }
}
