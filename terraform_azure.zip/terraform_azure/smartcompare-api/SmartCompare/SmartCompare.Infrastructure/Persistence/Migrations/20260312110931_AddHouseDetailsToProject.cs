﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SmartCompare.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddHouseDetailsToProject : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Bathrooms",
                schema: "dbo",
                table: "Projects",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "Number of bathrooms.");

            migrationBuilder.AddColumn<int>(
                name: "Bedrooms",
                schema: "dbo",
                table: "Projects",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "Number of bedrooms.");

            migrationBuilder.AddColumn<decimal>(
                name: "HouseSizeSqm",
                schema: "dbo",
                table: "Projects",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m,
                comment: "House size in square metres.");

            migrationBuilder.AddColumn<int>(
                name: "HouseType",
                schema: "dbo",
                table: "Projects",
                type: "int",
                nullable: false,
                defaultValue: 0,
                comment: "House type. Values: 0=House, 1=Apartment, 2=Townhouse, 3=Unit, 4=Other.");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Bathrooms",
                schema: "dbo",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "Bedrooms",
                schema: "dbo",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "HouseSizeSqm",
                schema: "dbo",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "HouseType",
                schema: "dbo",
                table: "Projects");
        }
    }
}
