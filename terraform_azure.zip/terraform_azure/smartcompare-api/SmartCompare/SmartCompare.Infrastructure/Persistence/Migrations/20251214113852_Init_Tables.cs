﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SmartCompare.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class Init_Tables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "dbo");

            migrationBuilder.CreateTable(
                name: "SubcontractorTypes",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "Auto-incrementing unique identifier, set by the database.")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Type = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false, comment: "Subcontractor type name/category.")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SubcontractorTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false, comment: "Unique identifier. Set by application, not auto-generated."),
                    Auth0SubjectId = table.Column<string>(type: "nvarchar(256)", nullable: false, comment: "Auth0 Subject ID."),
                    UserName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false, comment: "User display name (2-100 characters)."),
                    Email = table.Column<string>(type: "nvarchar(254)", maxLength: 254, nullable: false, comment: "User email max 254 chars."),
                    Role = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false, comment: "User role"),
                    LastLoginAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Last successful login timestamp (UTC), nullable. Null until first login."),
                    LastRefreshAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Last refresh token update timestamp (UTC), nullable."),
                    RefreshToken = table.Column<string>(type: "nvarchar(max)", nullable: true, comment: "Current refresh token for obtaining new access tokens, nullable."),
                    RefreshTokenExpiresAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Refresh token expiration timestamp (UTC), nullable. Token invalid after this time."),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Account creation timestamp (UTC). Set once, never changed."),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true, comment: "Last update timestamp (UTC). Updated whenever user info changes."),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CompanyProfiles",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false, comment: "Set by application, not auto-generated."),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false, comment: "Owner user ID (foreign key to User table)."),
                    CompanyName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false, comment: "Company name (1-500 characters)."),
                    ContactName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false, comment: "contact person name (1-100 characters)."),
                    ContactEmail = table.Column<string>(type: "nvarchar(254)", maxLength: 254, nullable: false, comment: "Contact email address max 254 chars."),
                    ContactPhone = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false, comment: "Contact phone number (max 50 characters)."),
                    ABN = table.Column<string>(type: "nvarchar(11)", maxLength: 11, nullable: true, comment: "Australian Business Number (11 digits)."),
                    Street = table.Column<string>(type: "nvarchar(255)", nullable: true, comment: "Street address line."),
                    Suburb = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true, comment: "Suburb or town name."),
                    State = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true, comment: "Australian state/territory."),
                    PostCode = table.Column<int>(type: "int", nullable: true, comment: "4-digit Australian post code (1000-9999)."),
                    LogoUrl = table.Column<string>(type: "nvarchar(max)", nullable: true, comment: "Company logo URL. Optional."),
                    BSB = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: true, comment: "Bank State Branch number (6 digits). Optional."),
                    Account = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true, comment: "Bank account number. Optional."),
                    LicenceNumber = table.Column<string>(type: "nvarchar(max)", nullable: true, comment: "Business license/permit number. Optional."),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Company profile creation timestamp (UTC). Set once, never changed."),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true, comment: "Last update timestamp (UTC) for the company profile. Updated whenever the profile information changes."),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CompanyProfiles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CompanyProfiles_Users_UserId",
                        column: x => x.UserId,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Projects",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "Auto-incrementing unique identifier, set by the database.")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PublicId = table.Column<Guid>(type: "uniqueidentifier", nullable: false, defaultValueSql: "NEWID()", comment: "Public business identifier (Guid)."),
                    ProjectName = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false, comment: "Project name, Max 255 characters."),
                    Address = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false, comment: "Project location/address. Max 500 characters."),
                    Status = table.Column<int>(type: "int", nullable: false, defaultValue: 0, comment: "Project status. Values: 0=Inquiry, 1=QuoteSent, 2=QuoteApproved, 3=Scheduled, 4=InProgress, 5=OnHold, 6=Completed, 7=Invoiced, 8=Paid, 9=Cancelled."),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false, comment: "Owner user ID (foreign key to User table)."),
                    SubcontractorTypeId = table.Column<int>(type: "int", nullable: false, comment: "Foreign Key to SubcontractorTypes."),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Project creation timestamp (UTC)."),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true, comment: "Project last update timestamp (UTC)."),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true, comment: "Project deletion timestamp (UTC). Null if not deleted.")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Projects", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Projects_SubcontractorTypes_SubcontractorTypeId",
                        column: x => x.SubcontractorTypeId,
                        principalSchema: "dbo",
                        principalTable: "SubcontractorTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Projects_Users_UserId",
                        column: x => x.UserId,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Subscriptions",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false, comment: "Unique identifier. Subscription ID, set by application."),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false, comment: "Foreign Key to Users. One-to-one relationship: each user has exactly one subscription. Set at subscription creation."),
                    SubscriptionTier = table.Column<int>(type: "int", nullable: false, defaultValue: 0, comment: "Subscription tier/plan level. Values: 0=Free, 1=Pro, 2=Enterprise. Stored as int for storage efficiency."),
                    SubscriptionStatus = table.Column<int>(type: "int", nullable: false, defaultValue: 0, comment: "Subscription status. Values: 0=Active, 1=Paused, 2=Cancelled, 3=Expired. Stored as int for storage efficiency."),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Subscription start date (UTC)."),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Subscription end date (UTC). Optional, set when subscription ends (cancelled, expired, etc.)."),
                    StripeSubscriptionId = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true, comment: "Stripe Subscription ID. Optional, populated when linked to Stripe subscription for recurring billing. Used to sync subscription status with Stripe. Max 255 characters."),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true, comment: "True if subscription is valid and user can use it. False if subscription is paused, cancelled, or expired."),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Subscription creation timestamp (UTC). Set once, never changed."),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true, comment: "Last update timestamp (UTC) for the subscription. Updated whenever subscription details are modified."),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Subscriptions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Subscriptions_Users_UserId",
                        column: x => x.UserId,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Quotes",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "Auto-incrementing unique identifier, set by the database.")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PublicId = table.Column<Guid>(type: "uniqueidentifier", nullable: false, defaultValueSql: "NEWID()", comment: "Public business identifier (Guid)."),
                    QuoteNumber = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false, comment: "Quote number/reference Max 200 characters."),
                    IssuedDate = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Quote issuance date (UTC). Date when quote was created and sent to customer."),
                    ValidDate = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Quote validity date (UTC). Quote expires after this date and is no longer valid for acceptance."),
                    IssuedBy = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false, comment: "Issued by (person/company)."),
                    IssuedTo = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false, comment: "Issued to (customer).Customer name or contact person who receives the quote. Max 255 characters."),
                    Total = table.Column<decimal>(type: "decimal(18,2)", nullable: false, comment: "Total amount. SubTotal + GST. Final amount customer needs to pay."),
                    SubTotal = table.Column<decimal>(type: "decimal(18,2)", nullable: false, comment: "Subtotal amount before tax. Work pricing without GST."),
                    GST = table.Column<decimal>(type: "decimal(18,2)", nullable: false, comment: "GST typically 10% in Australia)."),
                    PDFUrl = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true, comment: "PDF file URL (optional). URL path to stored PDF version of quote for download/preview. Max 500 characters."),
                    ProjectId = table.Column<int>(type: "int", nullable: false, comment: "Foreign Key to Projects. Quote belongs to this project."),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Quote creation timestamp (UTC). Set once, never changed."),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true, comment: "Last update timestamp (UTC) for the quote. Updated whenever quote details are modified."),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Quotes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Quotes_Projects_ProjectId",
                        column: x => x.ProjectId,
                        principalSchema: "dbo",
                        principalTable: "Projects",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Payments",
                schema: "dbo",
                columns: table => new
                {
                    PaymentId = table.Column<int>(type: "int", nullable: false, comment: "Auto-incrementing unique identifier, set by the database.")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: false, comment: "Payment amount. Stored with 2 decimal places (e.g., 99.99)."),
                    Currency = table.Column<string>(type: "nvarchar(10)", maxLength: 3, nullable: false, comment: "ISO 4217 currency code (e.g., AUD, USD, CNY). Max 10 characters."),
                    Status = table.Column<int>(type: "int", nullable: false, defaultValue: 0, comment: "Payment status. Values: 0=Pending, 1=Succeeded, 2=Failed, 3=Refunded, 4=PartiallyRefunded. Stored as int for storage efficiency."),
                    Type = table.Column<int>(type: "int", nullable: false, defaultValue: 0, comment: "Payment type. Values: 0=Subscription, 1=OneTime, 2=Upgrade, 3=Refund. Stored as int for storage efficiency."),
                    StripePaymentIntentId = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false, comment: "Stripe PaymentIntent ID. Unique identifier from Stripe API. Used for idempotency and payment tracking."),
                    StripeInvoiceId = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true, comment: "Stripe Invoice ID. Optional, populated only for successful subscription payments. Max 255 characters."),
                    StripeChargeId = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true, comment: "Stripe Charge ID. Optional, populated only when a charge is successfully created. Max 255 characters."),
                    PaidAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Payment confirmation timestamp (UTC). Set when payment succeeds. Null for pending/failed payments."),
                    RefundedAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Refund timestamp (UTC). Set when payment is refunded. Null for non-refunded payments."),
                    FailureReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true, comment: "Reason for payment failure (if failed). Examples: 'Card declined', 'Insufficient funds'. Null for successful payments. Max 500 characters."),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true, comment: "Payment description or memo. Examples: 'Monthly subscription renewal', 'Annual plan upgrade'. Max 500 characters."),
                    SubscriptionId = table.Column<Guid>(type: "uniqueidentifier", nullable: false, comment: "Foreign Key to Subscriptions. The subscription this payment is associated with."),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, comment: "Payment record creation timestamp (UTC). Set once, never changed. Tracks when this payment record was created."),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true, comment: "Last update timestamp (UTC) for payment information. Updated whenever payment details are modified."),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payments", x => x.PaymentId);
                    table.ForeignKey(
                        name: "FK_Payments_Subscriptions_SubscriptionId",
                        column: x => x.SubscriptionId,
                        principalSchema: "dbo",
                        principalTable: "Subscriptions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Payments_Users_UserId",
                        column: x => x.UserId,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Exclusions",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "Auto-incrementing unique identifier, set by the database.")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false, comment: "Description of exclusion items. "),
                    QuoteId = table.Column<int>(type: "int", nullable: false, comment: "Foreign Key to Quotes. Exclusion item belongs to this quote.")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Exclusions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Exclusions_Quotes_QuoteId",
                        column: x => x.QuoteId,
                        principalSchema: "dbo",
                        principalTable: "Quotes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProgressPayments",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "Auto-incrementing unique identifier, set by the database.")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false, comment: "Payment stage description, max 1000 characters."),
                    Percentage = table.Column<decimal>(type: "decimal(5,2)", nullable: false, comment: "Payment percentage (0-100). Percentage of total quote amount due at this stage."),
                    QuoteId = table.Column<int>(type: "int", nullable: false, comment: "Foreign Key to Quotes. Progress payment stage belongs to this quote.")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProgressPayments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProgressPayments_Quotes_QuoteId",
                        column: x => x.QuoteId,
                        principalSchema: "dbo",
                        principalTable: "Quotes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ScopeOfWorks",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "Auto-incrementing unique identifier, set by the database.")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false, comment: "Detailed description of work scope.max 1000 characters."),
                    QuoteId = table.Column<int>(type: "int", nullable: false, comment: "Foreign Key to Quotes. Scope of work belongs to this quote.")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ScopeOfWorks", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ScopeOfWorks_Quotes_QuoteId",
                        column: x => x.QuoteId,
                        principalSchema: "dbo",
                        principalTable: "Quotes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "SubcontractorTypes",
                columns: new[] { "Id", "Type" },
                values: new object[] { 1, "Gyprock" });

            migrationBuilder.CreateIndex(
                name: "IX_CompanyProfiles_CompanyName",
                schema: "dbo",
                table: "CompanyProfiles",
                column: "CompanyName");

            migrationBuilder.CreateIndex(
                name: "IX_CompanyProfiles_UserId",
                schema: "dbo",
                table: "CompanyProfiles",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Exclusions_QuoteId",
                schema: "dbo",
                table: "Exclusions",
                column: "QuoteId");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_StripePaymentIntentId",
                schema: "dbo",
                table: "Payments",
                column: "StripePaymentIntentId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Payments_SubscriptionId",
                schema: "dbo",
                table: "Payments",
                column: "SubscriptionId");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_UserId",
                schema: "dbo",
                table: "Payments",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_ProgressPayments_QuoteId",
                schema: "dbo",
                table: "ProgressPayments",
                column: "QuoteId");

            migrationBuilder.CreateIndex(
                name: "IX_Projects_PublicId",
                schema: "dbo",
                table: "Projects",
                column: "PublicId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Projects_SubcontractorTypeId",
                schema: "dbo",
                table: "Projects",
                column: "SubcontractorTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Projects_UserId",
                schema: "dbo",
                table: "Projects",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Quotes_ProjectId",
                schema: "dbo",
                table: "Quotes",
                column: "ProjectId");

            migrationBuilder.CreateIndex(
                name: "IX_Quotes_PublicId",
                schema: "dbo",
                table: "Quotes",
                column: "PublicId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ScopeOfWorks_QuoteId",
                schema: "dbo",
                table: "ScopeOfWorks",
                column: "QuoteId");

            migrationBuilder.CreateIndex(
                name: "UX_Subscriptions_UserId",
                schema: "dbo",
                table: "Subscriptions",
                column: "UserId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_Auth0SubjectId",
                schema: "dbo",
                table: "Users",
                column: "Auth0SubjectId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_Email",
                schema: "dbo",
                table: "Users",
                column: "Email",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CompanyProfiles",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Exclusions",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Payments",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ProgressPayments",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ScopeOfWorks",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Subscriptions",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Quotes",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Projects",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "SubcontractorTypes",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Users",
                schema: "dbo");
        }
    }
}
