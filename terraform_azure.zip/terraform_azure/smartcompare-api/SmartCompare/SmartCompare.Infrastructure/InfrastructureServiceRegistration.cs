﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.DependencyInjection;
using SmartCompare.Domain.Interfaces;
using SmartCompare.Infrastructure.Persistence;
using SmartCompare.Infrastructure.Persistence.Contexts;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.Infrastructure.Persistence.Repositories;
using SmartCompare.Application.Interfaces;
using SmartCompare.Infrastructure.ExternalServices.Ai;
using SmartCompare.Infrastructure.ExternalServices.Stripe;
using SmartCompare.Infrastructure.Identity;
using SmartCompare.Infrastructure.Queries;
using SmartCompare.Infrastructure.Services;
using Stripe;
using QuestPDF.Infrastructure;
using SmartCompare.Application.Queries.Quotes.GetProgressPaymentsByQuoteId;
using SmartCompare.Infrastructure.PdfGeneration;


namespace SmartCompare.Infrastructure
{
    /// <summary>
    /// Provides the infrastructure layer service registrations.
    /// </summary>
    public static class InfrastructureServiceRegistration
    {

        /// <summary>
        /// Registers infrastructure services, including DbContext, repositories, and unit of work.
        /// </summary>
        /// <param name="services">The service collection to register services to.</param>
        /// <param name="configuration">The configuration containing application settings.</param>
        /// <returns>The updated <see cref="IServiceCollection"/> instance.</returns>
        public static IServiceCollection AddInfrastructure(
            this IServiceCollection services,
            IConfiguration configuration)
        {

            // Register UnitOfWork as a scoped service to manage DbContext lifecycle
            services.AddScoped<IUnitOfWork, UnitOfWork>();

            // Register ISampleEntityRepository and its implementation for dependency injection
            // This is an example of repository registration; this line can be removed or replaced later.
            services.AddScoped<ISampleEntityRepository, SampleRepository>();

            // Register IProjectRepository and its implementation for dependency injection
            services.AddScoped<IProjectRepository, ProjectRepository>();
            services.AddScoped<IQuoteRepository, QuoteRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IRoleRepository, RoleRepository>();
            services.AddScoped<IPaymentRepository, PaymentRepository>();
            //Register Queries for read operations
            services.AddScoped<IUserQueries, UserQueries>();
            services.AddScoped<IProjectQueries, ProjectQueries>();
            services.AddScoped<IQuoteQueries, QuoteQueries>();
            services.AddScoped<ISubscriptionQueries, SubscriptionQueries>();
            services.AddScoped<ISubcontractorTypeQueries, SubcontractorTypeQueries>();
            services.AddScoped<IDashboardQueries, DashboardQueries>();

            // Register HttpContextAccessor for accessing HTTP context
            services.AddHttpContextAccessor();

            // Register in-memory cache for middleware-level caching
            services.AddMemoryCache();

            // Register Infrastructure Services
            services.AddScoped<IUserContextService, UserContextService>();
            services.AddScoped<IClaimsRefreshService, ClaimsRefreshService>();

            //Stripe
            services.AddStripe(configuration);

            // AI OCR Service
            services.AddAiOcrService(configuration);

            // PDF Generation
            QuestPDF.Settings.License = LicenseType.Community;
            services.AddSingleton<IPdfGenerationService, PdfGenerationService>();

            // Logo Download (HTTP client + SSRF protection)
            services.AddHttpClient("LogoDownload", client =>
            {
                client.Timeout = TimeSpan.FromSeconds(10);
            }).ConfigurePrimaryHttpMessageHandler(() => new SocketsHttpHandler
            {
                AllowAutoRedirect = false,
            });
            services.AddScoped<ILogoDownloadService, LogoDownloadService>();

            return services;
        }

        public static IServiceCollection AddInfrastructureDatabase(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            var connectionString = GetConnectionString(configuration);
            if (string.IsNullOrWhiteSpace(connectionString))
            {
                throw new InvalidOperationException(
                    "Connection string 'DefaultConnection' not found. Configure via: " +
                    "1. 'dotnet user-secrets set \"ConnectionStrings:DefaultConnection\" \"...\"', or " +
                    "2. appsettings.json 'ConnectionStrings:DefaultConnection' section");
            }
            // Register the DbContextFactory for the SmartCompareDbContext
            services.AddDbContextFactory<SmartCompareDbContext>(options =>
                options.UseSqlServer(connectionString, sqlOptions =>
                {
                    sqlOptions.CommandTimeout(30);
                    sqlOptions.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery);
                    sqlOptions.EnableRetryOnFailure(
                    maxRetryCount: 3,
                    maxRetryDelay: TimeSpan.FromSeconds(5),
                    errorNumbersToAdd: null);
                })
            );

            // Register DbContext as a scoped service using the factory
            services.AddScoped(provider =>
            {
                var factory = provider.GetRequiredService<IDbContextFactory<SmartCompareDbContext>>();
                return factory.CreateDbContext();
            });

            return services;
        }


        /// <summary>
        /// Retrieves the connection string from configuration or environment variables.
        /// </summary>
        /// <param name="configuration">The configuration to retrieve the connection string from.</param>
        /// <returns>The connection string, or <c>null</c> if not found.</returns>
        private static string? GetConnectionString(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("DefaultConnection");
            if (!string.IsNullOrWhiteSpace(connectionString))
            {
                return connectionString;
            }
            var envConnectionString = Environment.GetEnvironmentVariable("ConnectionStrings__DefaultConnection");
            if (!string.IsNullOrWhiteSpace(envConnectionString))
            {
                return envConnectionString;
            }
            return null;
        }

        /// <summary>
        /// Registers Stripe SDK client, configuration, and payment services.
        /// </summary>
        /// <param name="services">The service collection to register services to.</param>
        /// <param name="configuration">The configuration containing Stripe settings.</param>
        /// <returns>The updated <see cref="IServiceCollection"/> instance.</returns>
        public static IServiceCollection AddAiOcrService(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            services.AddOptionsWithValidateOnStart<AiOptions>()
                .Bind(configuration.GetSection(AiOptions.SectionName))
                .Validate(o => !string.IsNullOrWhiteSpace(o.BaseUrl),
                    "AiService:BaseUrl must be configured");

            services.AddHttpClient<IAiOcrService, AiOcrService>((sp, client) =>
            {
                var opts = sp.GetRequiredService<IOptions<AiOptions>>().Value;
                client.BaseAddress = new Uri(opts.BaseUrl);
                client.Timeout = TimeSpan.FromSeconds(200); // per-file budget with headroom
            });

            return services;
        }

        public static IServiceCollection AddStripe(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            var optionsBuilder = services.AddOptionsWithValidateOnStart<StripeOptions>()
                .Bind(configuration.GetSection(StripeOptions.SectionName));

            var isDevelopment = string.Equals(
                Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"),
                "Development", StringComparison.OrdinalIgnoreCase);

            if (!isDevelopment)
            {
                optionsBuilder
                    .Validate(o => !string.IsNullOrWhiteSpace(o.SecretKey),
                        "Stripe:SecretKey must be configured — empty key disables API access")
                    .Validate(o => !string.IsNullOrWhiteSpace(o.WebhookSecret),
                        "Stripe:WebhookSecret must be configured — empty secret allows webhook signature forgery");
            }

            services.AddSingleton<IStripeClient>(sp =>
            {
                var options = sp.GetRequiredService<IOptions<StripeOptions>>().Value;
                return new StripeClient(options.SecretKey);
            });

            services.AddSingleton<IStripePriceResolver, StripePriceResolver>();
            services.AddScoped<IStripeCustomerService, StripeCustomerService>();
            services.AddScoped<ICheckoutSessionService, CheckoutSessionService>();
            services.AddScoped<IStripeWebhookService, StripeWebhookService>();

            return services;
        }
    }
}
