using System.Linq.Expressions;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.EntityFrameworkCore;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Infrastructure.Persistence.Contexts;
using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Infrastructure.Queries
{
    public class QuoteQueries : IQuoteQueries
    {
        private readonly SmartCompareDbContext _dbContext;
        private readonly IMapper _mapper;

        public QuoteQueries(SmartCompareDbContext dbContext, IMapper mapper)
        {
            _dbContext = dbContext;
            _mapper = mapper;
        }

        public async Task<PagedResult<QuoteSummaryDto>> GetByProjectIdPagedAsync(
            Guid projectPublicId,
            string auth0SubjectId,
            Pagination pagination,
            CancellationToken cancellationToken = default)
        {
            var query = _dbContext.Quotes
                .AsNoTracking()
                .Where(q => q.Project.PublicId == projectPublicId
                    && q.Project.User.Auth0SubjectId == auth0SubjectId
                    && !q.Project.IsDeleted)
                .OrderByDescending(q => q.IssuedDate);

            var totalCount = await query.CountAsync(cancellationToken);

            var quotes = await query
                .Skip(pagination.Skip)
                .Take(pagination.Take)
                .Select(q => new QuoteSummaryDto
                {
                    QuotePublicId = q.PublicId,
                    QuoteNumber = q.QuoteNumber,
                    IssuedDate = q.IssuedDate,
                    ValidDate = q.ValidDate,
                    IssuedBy = q.IssuedBy,
                    IssuedTo = q.IssuedTo,
                    Total = q.Total,
                    SubTotal = q.SubTotal,
                    GST = q.GST,
                    PDFUrl = q.PDFUrl,
                    ProjectPublicId = q.Project.PublicId,
                })
                .ToListAsync(cancellationToken);

            return new PagedResult<QuoteSummaryDto>
            {
                Items = quotes,
                TotalCount = totalCount,
                PageNumber = pagination.PageNumber,
                PageSize = pagination.PageSize
            };
        }

        public async Task<TDto?> GetByIdAsync<TDto>(Guid quotePublicId, Guid userId, CancellationToken cancellationToken = default)
            where TDto : class
        {
            return await _dbContext.Quotes
                .AsNoTracking()
                .Where(q => q.PublicId == quotePublicId && q.Project.UserId == userId)
                .ProjectTo<TDto>(_mapper.ConfigurationProvider)
                .SingleOrDefaultAsync(cancellationToken);
        }

        public async Task<PagedResult<TDto>> GetChildrenPagedAsync<TEntity, TDto>(
            Guid quotePublicId,
            Guid userId,
            Expression<Func<Quote, IEnumerable<TEntity>>> selector,
            Pagination pagination,
            CancellationToken cancellationToken = default)
            where TEntity : BaseEntity<int>
            where TDto : class
        {
            var query = _dbContext.Quotes
                .AsNoTracking()
                .Where(q => q.PublicId == quotePublicId && q.Project.UserId == userId)
                .SelectMany(selector)
                .OrderBy(e => e.Id)
                .ProjectTo<TDto>(_mapper.ConfigurationProvider);

            var totalCount = await query.CountAsync(cancellationToken);
            var results = await query
                .Skip(pagination.Skip)
                .Take(pagination.Take)
                .ToListAsync(cancellationToken);

            return new PagedResult<TDto>
            {
                Items = results,
                TotalCount = totalCount,
                PageNumber = pagination.PageNumber,
                PageSize = pagination.PageSize
            };
        }
        public async Task<string?> GetQuoteOwnerIdAsync(Guid quoteId, CancellationToken cancellationToken = default)
        {
            return await _dbContext.Quotes
                .AsNoTracking()
                .Where(q => q.PublicId == quoteId)
                .Select(q => q.Project.User.Auth0SubjectId)
                .FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<Quote?> GetQuoteWithProjectAsync(
            Guid quotePublicId,
            CancellationToken cancellationToken = default)
        {
            return await _dbContext.Quotes
                .AsNoTracking()
                .Include(q => q.Project)
                .FirstOrDefaultAsync(q => q.PublicId == quotePublicId, cancellationToken);
        }
        
    }
}

