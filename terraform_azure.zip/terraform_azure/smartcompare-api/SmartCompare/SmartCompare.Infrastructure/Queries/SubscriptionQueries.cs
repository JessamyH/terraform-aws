using Microsoft.EntityFrameworkCore;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Enums;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace SmartCompare.Infrastructure.Queries;

public class SubscriptionQueries : ISubscriptionQueries
{
    private readonly SmartCompareDbContext _dbContext;

    public SubscriptionQueries(SmartCompareDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<bool> IsSubscriptionExpiredAsync(
        string auth0SubjectId,
        DateTime utcNow,
        CancellationToken cancellationToken = default)
    {
        return await _dbContext.Users
            .AsNoTracking()
            .AnyAsync(u => u.Auth0SubjectId == auth0SubjectId
                           && u.Subscription != null
                           && !u.Subscription.IsDeleted
                           && (u.Subscription.SubscriptionStatus == SubscriptionStatus.Active
                               || u.Subscription.SubscriptionStatus == SubscriptionStatus.Trial)
                           && u.Subscription.DateRange.EndDate < utcNow,
                cancellationToken);
    }
}
