using Microsoft.EntityFrameworkCore;
using SmartCompare.Application.DTOs.Dashboard;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Enums;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace SmartCompare.Infrastructure.Queries;

public class DashboardQueries : IDashboardQueries
{
    private readonly SmartCompareDbContext _dbContext;

    private static readonly ProjectStatus[] ActiveStatuses =
    [
        ProjectStatus.QuoteSent,
        ProjectStatus.QuoteApproved,
        ProjectStatus.Scheduled,
        ProjectStatus.InProgress,
        ProjectStatus.OnHold,
        ProjectStatus.Completed,
        ProjectStatus.Invoiced
    ];

    public DashboardQueries(SmartCompareDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<DashboardStatsDto> GetDashboardStatsAsync(
        string auth0SubjectId,
        CancellationToken cancellationToken = default)
    {
        var userProjects = _dbContext.Projects
            .AsNoTracking()
            .Where(p => p.User.Auth0SubjectId == auth0SubjectId && !p.IsDeleted);

        var totalQuotes = await _dbContext.Quotes
            .AsNoTracking()
            .CountAsync(q => q.Project.User.Auth0SubjectId == auth0SubjectId
                          && !q.Project.IsDeleted, cancellationToken);

        var activeProjects = await userProjects
            .CountAsync(p => ActiveStatuses.Contains(p.Status), cancellationToken);

        var completedProjects = await userProjects
            .CountAsync(p => p.Status == ProjectStatus.Paid, cancellationToken);

        return new DashboardStatsDto
        {
            TotalQuotes = totalQuotes,
            ActiveProjects = activeProjects,
            CompletedProjects = completedProjects
        };
    }

    public async Task<List<RecentQuoteDto>> GetRecentQuotesAsync(
        string auth0SubjectId,
        int count,
        CancellationToken cancellationToken = default)
    {
        return await _dbContext.Quotes
            .AsNoTracking()
            .Where(q => q.Project.User.Auth0SubjectId == auth0SubjectId
                      && !q.Project.IsDeleted)
            .OrderByDescending(q => q.CreatedAt)
            .Take(count)
            .Select(q => new RecentQuoteDto
            {
                QuoteNumber = q.QuoteNumber,
                IssuedTo = q.IssuedTo,
                ValidDate = q.ValidDate,
                Total = q.Total,
                ProjectPublicId = q.Project.PublicId
            })
            .ToListAsync(cancellationToken);
    }
}
