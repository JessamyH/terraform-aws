﻿using Microsoft.EntityFrameworkCore;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Infrastructure.Persistence.Contexts;
using static SmartCompare.Application.DTOs.ProjectSummaryDTOs;


namespace SmartCompare.Infrastructure.Queries
{
    public class ProjectQueries : IProjectQueries
    {
        private readonly SmartCompareDbContext _dbContext;

        public ProjectQueries(SmartCompareDbContext dbcontext)
        {
            _dbContext = dbcontext;
        }

        public async Task<Project?> GetByIdAsync(
            Guid projectPublicId,
            CancellationToken cancellationToken = default)
        {
            return await _dbContext.Projects
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.PublicId == projectPublicId);
        }

        public async Task<PagedResult<ProjectSummaryDto>> GetProjectsByUserIdPagedAsync(
            string auth0SubjectId,
            Pagination pagination,
            CancellationToken cancellationToken = default)
        {
            var query = _dbContext.Projects
                .AsNoTracking()
                .Where(p => p.User.Auth0SubjectId == auth0SubjectId)
                .Where(p => !p.IsDeleted)
                .OrderByDescending(p => p.CreatedAt);

            var totalCount = await query.CountAsync(cancellationToken);

            var projects = await query
                .Skip(pagination.Skip)
                .Take(pagination.Take)
                .Select(p => new ProjectSummaryDto
                {
                    PublicId = p.PublicId,
                    ProjectName = p.ProjectName,
                    Address = p.Address,
                    HouseType = p.HouseType,
                    Bedrooms = p.Bedrooms,
                    Bathrooms = p.Bathrooms,
                    SubcontractorType = p.SubcontractorType.Type,
                    Status = p.Status.ToString(),
                    CreatedAt = p.CreatedAt,
                    UpdatedAt = p.UpdatedAt
                })
                .ToListAsync(cancellationToken);

            return new PagedResult<ProjectSummaryDto>
            {
                Items = projects,
                TotalCount = totalCount,
                PageNumber = pagination.PageNumber,
                PageSize = pagination.PageSize
            };
        }
    }
}
