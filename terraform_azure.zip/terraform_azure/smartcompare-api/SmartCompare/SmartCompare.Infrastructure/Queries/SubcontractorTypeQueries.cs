using Microsoft.EntityFrameworkCore;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.Interfaces;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace SmartCompare.Infrastructure.Queries;

public class SubcontractorTypeQueries : ISubcontractorTypeQueries
{
    private readonly SmartCompareDbContext _dbContext;

    public SubcontractorTypeQueries(SmartCompareDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<List<SubcontractorTypeDto>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _dbContext.SubcontractorTypes
            .AsNoTracking()
            .OrderBy(st => st.Type)
            .Select(st => new SubcontractorTypeDto
            {
                Id = st.Id,
                Type = st.Type
            })
            .ToListAsync(cancellationToken);
    }
}
