﻿using Microsoft.EntityFrameworkCore;
using SmartCompare.Application.DTOs.Auth.QueryDto;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace SmartCompare.Infrastructure.Queries
{
    public class UserQueries : IUserQueries
    {
        private readonly SmartCompareDbContext _dbContext;

        public UserQueries(SmartCompareDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<User?> GetByAuth0SubjectIdAsync(
            string auth0SubjectId,
            CancellationToken cancellationToken = default)
        {
            return await _dbContext.Users
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Auth0SubjectId == auth0SubjectId, cancellationToken);
        }
        
        public async Task<UserWithRoleAndSubscriptionDto?> GetUserByAuth0SubjectIdWithSubscriptionAsync(
            string auth0SubjectId,
            CancellationToken cancellationToken = default)
        {
            return await _dbContext.Users
                .AsNoTracking()
                .Include(u => u.Subscription)
                .Include(u => u.UserRoles)
                    .ThenInclude(ur => ur.Role)
                .Select(u => new UserWithRoleAndSubscriptionDto
                {
                    Id = u.Id,
                    Auth0SubjectId = u.Auth0SubjectId,
                    Roles = u.UserRoles.Select(ur => ur.Role.Name).ToArray(),
                    SubscriptionTier = u.Subscription != null 
                        ? u.Subscription.SubscriptionTier.ToString()
                        : null
                })
                .FirstOrDefaultAsync(u => u.Auth0SubjectId == auth0SubjectId, cancellationToken);
        }

        public async Task<CurrentUserDto?> GetCurrentUserByAuth0SubjectIdAsync(
            string auth0SubjectId,
            CancellationToken cancellationToken = default)
        {
            return await _dbContext.Users
                .AsNoTracking()
                .Where(u => u.Auth0SubjectId == auth0SubjectId)
                .Select(u => new CurrentUserDto(
                    u.Id,
                    u.UserName,
                    u.Email.Value,
                    u.UserRoles.Select(ur => ur.Role.Name).ToArray(),
                    u.Subscription != null
                        ? u.Subscription.SubscriptionTier.ToString()
                        : null))
                .FirstOrDefaultAsync(cancellationToken);
        }
    }
}
