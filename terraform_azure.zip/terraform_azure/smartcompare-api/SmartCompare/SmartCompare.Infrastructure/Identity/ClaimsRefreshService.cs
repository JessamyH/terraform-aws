using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SmartCompare.Application.Interfaces;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using SmartCompare.SharedKernel.Auth.Claims;


namespace SmartCompare.Infrastructure.Identity;

public class ClaimsRefreshService: IClaimsRefreshService
{
    private readonly IUserQueries _userQueries;
    private readonly ILogger<ClaimsRefreshService> _logger;

    public ClaimsRefreshService(IUserQueries userQueries, ILogger<ClaimsRefreshService> logger)
    {
        _userQueries = userQueries;
        _logger = logger;
    }
    
    
    public async Task<ClaimsPrincipal?> RefreshClaimsAndReissueCookieAsync(
        HttpContext httpContext,
        ClaimsPrincipal principal,
        string auth0SubjectId)
    {
        var refreshedPrincipal = await BuildRefreshedPrincipalAsync(principal, auth0SubjectId);
        if (refreshedPrincipal == null) return null;

        const string cookieScheme = CookieAuthenticationDefaults.AuthenticationScheme;
        
        var authResult = await httpContext.AuthenticateAsync(cookieScheme);
        var authProperties = authResult.Succeeded ? authResult.Properties : new AuthenticationProperties();
        
        await httpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            refreshedPrincipal,
            authProperties);
        
        return refreshedPrincipal;
    }
    

    public async Task<ClaimsPrincipal?> BuildRefreshedPrincipalAsync(ClaimsPrincipal principal, string auth0SubjectId)
    {
        if (string.IsNullOrWhiteSpace(auth0SubjectId))
        {
            _logger.LogWarning("Cannot build refreshed principal: Auth0SubjectId is null or empty");
            return null;
        }
        
        if (principal?.Identity is not ClaimsIdentity currentIdentity)
        {
            _logger.LogWarning("Cannot build refreshed principal: Invalid ClaimsIdentity");
            return null;
        }
        
        var userWithRoleAndTier = await _userQueries.GetUserByAuth0SubjectIdWithSubscriptionAsync(auth0SubjectId);
        if (userWithRoleAndTier == null)
        {
            _logger.LogWarning("User not found for Auth0 subject: {Auth0SubjectId}", auth0SubjectId);
            return null;
        }
        
        var identity = principal.Identity as ClaimsIdentity;
        var newIdentity = new ClaimsIdentity(identity);
        
        foreach (var c in newIdentity.Claims.Where(c => c.Type == ClaimTypes.Role).ToList())
            newIdentity.RemoveClaim(c);
        
        var roleTierClaim = new UserRoleTierClaim
        {
            Roles = userWithRoleAndTier.Roles,
            Tier = userWithRoleAndTier.SubscriptionTier
        };
        
        var roleTierJson = JsonSerializer.Serialize(roleTierClaim, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });
        
        newIdentity.AddClaim(new Claim(ClaimTypes.Role, roleTierJson));
        var newPrincipal = new ClaimsPrincipal(newIdentity);
        
        _logger.LogInformation(
            "Claims refreshed for user {UserId}. Roles: {Roles}, Tier: {Tier}",
            userWithRoleAndTier.Id,
            string.Join(", ", roleTierClaim.Roles),
            roleTierClaim.Tier ?? "Free");

        return newPrincipal;
        
    }
    

    
    
    
}