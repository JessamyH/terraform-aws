using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace SmartCompare.Infrastructure.Identity;

public interface IClaimsRefreshService
{
    
    /// <summary>
    /// Refreshes user claims from database and reissues the authentication cookie.
    /// This method can be used in any business logic that requires claim refresh and cookie reissuance.
    /// </summary>
    /// <param name="httpContext">The current HTTP context</param>
    /// <param name="principal">The current claims principal</param>
    /// <param name="auth0SubjectId">The Auth0 subject identifier</param>
    /// <returns>
    /// The new ClaimsPrincipal with updated claims, or null if refresh failed.
    /// </returns>
    /// <remarks>
    /// Usage scenarios:
    ///
    /// 1. For current request:
    /// After calling this method, assign the returned ClaimsPrincipal 
    /// to context.Principal to make updated claims available in the current request pipeline.
    /// For example: context.Principal = refreshedClaimsPrincipal
    ///
    /// 2. For subsequent requests: Simply calling this method is sufficient. 
    /// The internal httpContext.SignInAsync() will reissue the cookie, 
    /// making updated claims available in future requests automatically.
    ///
    /// </remarks>
    Task<ClaimsPrincipal?> RefreshClaimsAndReissueCookieAsync(
        HttpContext httpContext,
        ClaimsPrincipal principal,
        string auth0SubjectId);

}