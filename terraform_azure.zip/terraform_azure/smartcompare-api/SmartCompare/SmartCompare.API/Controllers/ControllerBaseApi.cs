using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
// add any other necessary common used dependencies here
public class ControllerBaseApi : ControllerBase
{
    protected readonly ILogger<ControllerBaseApi> _logger;

    public ControllerBaseApi(ILogger<ControllerBaseApi> logger)
    {
        _logger = logger;
    }

    protected string? Auth0SubjectId => User?.FindFirstValue(ClaimTypes.NameIdentifier);

    protected string GetRequiredAuth0SubjectId()
    {
        var subjectId = Auth0SubjectId;
        if (string.IsNullOrEmpty(subjectId))
        {
            _logger.LogWarning("Unauthorized access: Auth0 subject ID not found in claims.");
            throw new UnauthorizedAccessException("User is not authenticated.");
        }
        return subjectId;
    }
}