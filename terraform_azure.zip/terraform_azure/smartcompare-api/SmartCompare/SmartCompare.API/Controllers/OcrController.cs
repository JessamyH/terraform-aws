using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartCompare.API.ApiResponse;
using SmartCompare.Application.Commands.Ocr;
using SmartCompare.Application.DTOs.Ocr;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.API.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class OcrController : ControllerBaseApi
{
    private static readonly HashSet<string> _allowedMimeTypes =
        ["image/jpeg", "image/png", "image/webp"];

    private const int MaxFileCount = 5;
    private const int MaxFileSizeBytes = 10 * 1024 * 1024;
    private const int PerFileTimeoutSeconds = 180;

    private readonly IMediator _mediator;

    public OcrController(ILogger<OcrController> logger, IMediator mediator)
        : base(logger)
    {
        _mediator = mediator;
    }

    [HttpPost("analyse")]
    [RequestSizeLimit(50 * 1024 * 1024)] // 50 MB ceiling for the whole request body
    [ProducesResponseType(typeof(ApiResponse<OcrPrefillDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> AnalyseImage(
        IList<IFormFile> files,
        CancellationToken cancellationToken)
    {
        if (files.Count == 0)
            return BadRequest(ApiResponse<object>.Fail("No files provided.", "NO_FILE"));

        if (files.Count > MaxFileCount)
            return BadRequest(ApiResponse<object>.Fail(
                $"Too many files. Maximum {MaxFileCount} images per request.",
                "TOO_MANY_FILES"));

        foreach (var file in files)
        {
            var safeName = SanitizeFileName(file.FileName);

            if (file.Length == 0)
                return BadRequest(ApiResponse<object>.Fail($"File '{safeName}' is empty.", "EMPTY_FILE"));

            if (file.Length > MaxFileSizeBytes)
                return BadRequest(ApiResponse<object>.Fail(
                    $"File '{safeName}' exceeds the 10 MB limit.", "FILE_TOO_LARGE"));

            var mime = file.ContentType?.ToLowerInvariant();
            if (mime is null || !_allowedMimeTypes.Contains(mime))
                return BadRequest(ApiResponse<object>.Fail(
                    $"Unsupported file type '{mime}' in '{safeName}'. Allowed: jpeg, png, webp.",
                    "UNSUPPORTED_FILE_TYPE"));

            if (!await HasValidMagicBytesAsync(file, mime, cancellationToken))
                return BadRequest(ApiResponse<object>.Fail(
                    $"File '{safeName}' content does not match its declared type '{mime}'.",
                    "INVALID_FILE_CONTENT"));
        }

        using var totalTimeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        totalTimeoutCts.CancelAfter(TimeSpan.FromSeconds(PerFileTimeoutSeconds * files.Count));
        var ct = totalTimeoutCts.Token;

        var succeeded = new List<OcrPrefillDto>();
        var failedFiles = new List<string>();

        for (var i = 0; i < files.Count; i++)
        {
            var file = files[i];
            _logger.LogInformation("OCR processing file {Index}/{Total}: {FileName} ({Bytes} bytes)",
                i + 1, files.Count, SanitizeFileName(file.FileName), file.Length);

            using var ms = new MemoryStream((int)file.Length);
            await file.CopyToAsync(ms, ct);
            var result = await _mediator.Send(
                new AnalyseImageCommand(ms.ToArray(), file.ContentType!.ToLowerInvariant()),
                ct);

            if (!result.Succeed)
            {
                var safeName = SanitizeFileName(file.FileName);
                _logger.LogWarning("OCR failed for file {FileName}: {Error}", safeName, result.Error?.Message);
                failedFiles.Add(safeName);
                continue;
            }

            succeeded.Add(result.Value!);
        }

        if (succeeded.Count == 0)
            return BadRequest(ApiResponse<object>.Fail("All files failed to analyse.", "OCR_ALL_FAILED"));

        var merged = new OcrPrefillDto(
            succeeded.SelectMany(r => r.ScopeItems).DistinctBy(x => x.Text.Trim().ToLowerInvariant()).ToList(),
            succeeded.SelectMany(r => r.Exclusions).DistinctBy(x => x.Text.Trim().ToLowerInvariant()).ToList(),
            failedFiles);

        var message = failedFiles.Count == 0
            ? $"{succeeded.Count} image(s) analysed successfully."
            : $"{succeeded.Count} image(s) analysed successfully; {failedFiles.Count} failed.";

        return Result.Success(merged, message).ToActionResult();
    }

    private static string SanitizeFileName(string fileName)
    {
        var name = Path.GetFileName(fileName);
        name = new string(name.Where(c => !char.IsControl(c)).ToArray());
        return name.Length > 100 ? name[..100] : name;
    }

    private static async Task<bool> HasValidMagicBytesAsync(
        IFormFile file, string mimeType, CancellationToken cancellationToken)
    {
        var buffer = new byte[12];
        await using var stream = file.OpenReadStream();
        var read = await stream.ReadAsync(buffer.AsMemory(0, 12), cancellationToken);

        return mimeType switch
        {
            "image/jpeg" => read >= 3
                && buffer[0] == 0xFF && buffer[1] == 0xD8 && buffer[2] == 0xFF,
            "image/png"  => read >= 4
                && buffer[0] == 0x89 && buffer[1] == 0x50 && buffer[2] == 0x4E && buffer[3] == 0x47,
            "image/webp" => read >= 12
                && buffer[0] == 0x52 && buffer[1] == 0x49 && buffer[2] == 0x46 && buffer[3] == 0x46
                && buffer[8] == 0x57 && buffer[9] == 0x45 && buffer[10] == 0x42 && buffer[11] == 0x50,
            _ => false
        };
    }
}
