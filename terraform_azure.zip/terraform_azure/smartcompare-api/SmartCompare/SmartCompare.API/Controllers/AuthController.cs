﻿using Auth0.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using SmartCompare.API.ApiResponse;

namespace SmartCompare.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBaseApi
    {
        private readonly IConfiguration _configuration;

        public AuthController(ILogger<AuthController> logger, IConfiguration configuration) : base(logger)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Initiates the Auth0 login flow and redirects to the Auth0 login page
        /// </summary>
        /// <param name="returnUrl">The URL to redirect to after successful authentication. Defaults to root path if not provided or invalid.</param>
        /// <param name="rememberMe">Whether to remember the user for future sessions. When true, session will persist for 7 days.</param>
        /// <returns>Challenge result that redirects to Auth0 login page</returns>
        /// <response code="302">Redirects to Auth0 login page</response>
        [HttpGet("login")]
        [AllowAnonymous]
        public IActionResult Login(
            [FromQuery] string returnUrl = "/",
            [FromQuery] bool rememberMe = false)
        {
            if (!Url.IsLocalUrl(returnUrl))
            {
                var frontendBaseUrl = _configuration["Frontend:BaseUrl"];
                var isFrontendUrl = !string.IsNullOrEmpty(frontendBaseUrl) &&
                    (returnUrl.Equals(frontendBaseUrl, StringComparison.OrdinalIgnoreCase) ||
                     returnUrl.StartsWith(frontendBaseUrl + "/", StringComparison.OrdinalIgnoreCase));
                if (!isFrontendUrl)
                {
                    returnUrl = frontendBaseUrl ?? "/";
                }
            }

            var authProps = new LoginAuthenticationPropertiesBuilder()
                .WithRedirectUri(returnUrl)
                .Build();

            if (rememberMe)
            {
                authProps.IsPersistent = true;

                //TODO: Consider moving to config: Auth0:RememberMeDays 
                //var rememberMeDays = _configuration.GetValue<int>("Auth0:RememberMeDays", 7);
                authProps.ExpiresUtc = DateTimeOffset.UtcNow.AddDays(7);
            }
            else
            {
                authProps.IsPersistent = false;
                authProps.ExpiresUtc = null;
            }

            return Challenge(authProps, Auth0Constants.AuthenticationScheme);
        }

        /// <summary>
        /// Handles authentication failures and returns an error response
        /// </summary>
        /// <param name="error">The error message describing why authentication failed</param>
        /// <returns>401 Unauthorized response with error details</returns>
        [HttpGet("login-failed")]
        [AllowAnonymous]
        public IActionResult LoginFailed([FromQuery] string error = "Unknown error")
        {
            if (error.Length > 500)
            {
                error = error.Substring(0, 500);
            }

            _logger.LogError("Authentication failed: {Error}", error);

            var response = ApiResponse<object>.Fail(
                errorMessage: error,
                errorCode: ErrorMapper.UNAUTHORIZED_ERROR
            );

            return new ObjectResult(response)
            {
                StatusCode = StatusCodes.Status401Unauthorized
            };
        }

        /// <summary>
        /// Logs out the current user from both the application and Auth0
        /// </summary>
        /// <returns>Sign out result that redirects to the frontend home page</returns>
        [HttpGet("logout")]
        [HttpPost("logout")]
        [AllowAnonymous]
        public async Task<IActionResult> Logout()
        {
            var auth0SubjectId = User?.FindFirstValue("sub") ?? "Unknown";
            var email = User?.FindFirstValue("email") ?? "Unknown";

            _logger.LogInformation("User {Auth0SubjectId} ({Email}) logging out", auth0SubjectId, email);

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            var frontendBaseUrl = _configuration["Frontend:BaseUrl"] ?? "/";
            var logoutProps = new LogoutAuthenticationPropertiesBuilder()
                .WithRedirectUri(frontendBaseUrl)
                .Build();

            return SignOut(logoutProps, Auth0Constants.AuthenticationScheme);
        }
    }
}
