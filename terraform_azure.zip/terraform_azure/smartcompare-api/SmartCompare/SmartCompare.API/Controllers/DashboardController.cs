using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartCompare.API.ApiResponse;
using SmartCompare.Application.DTOs.Dashboard;
using SmartCompare.Application.Queries.Dashboard.GetDashboardStats;
using SmartCompare.Application.Queries.Dashboard.GetRecentQuotes;

namespace SmartCompare.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class DashboardController : ControllerBaseApi
{
    private readonly IMediator _mediator;

    public DashboardController(ILogger<DashboardController> logger, IMediator mediator)
        : base(logger)
    {
        _mediator = mediator;
    }

    /// <summary>
    /// Get dashboard statistics for the authenticated user.
    /// </summary>
    /// <returns>Aggregate counts: total quotes, active projects (QuoteSent–Invoiced), completed projects (Paid).</returns>
    /// <response code="200">Returns the dashboard statistics.</response>
    /// <response code="401">User is not authenticated.</response>
    [HttpGet("stats")]
    [ProducesResponseType(typeof(ApiResponse<DashboardStatsDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetDashboardStats()
    {
        var auth0SubjectId = GetRequiredAuth0SubjectId();
        var query = new GetDashboardStatsQuery(auth0SubjectId);
        var result = await _mediator.Send(query);
        return result.ToActionResult();
    }

    /// <summary>
    /// Get the most recently created quotes for the authenticated user.
    /// </summary>
    /// <param name="count">Number of quotes to return (1–10, default: 3).</param>
    /// <returns>List of recent quote summaries ordered by creation date descending.</returns>
    /// <response code="200">Returns the recent quotes.</response>
    /// <response code="400">Invalid count parameter.</response>
    /// <response code="401">User is not authenticated.</response>
    [HttpGet("recent-quotes")]
    [ProducesResponseType(typeof(ApiResponse<List<RecentQuoteDto>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetRecentQuotes([FromQuery] int count = 3)
    {
        var auth0SubjectId = GetRequiredAuth0SubjectId();
        var query = new GetRecentQuotesQuery(auth0SubjectId, count);
        var result = await _mediator.Send(query);
        return result.ToActionResult();
    }
}
