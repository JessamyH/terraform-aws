using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartCompare.API.ApiResponse;
using SmartCompare.Application.Commands.Quotes.CreateQuote;
using SmartCompare.Application.Commands.Quotes.AddExclusions;
using SmartCompare.Application.Commands.Quotes.DeleteExclusion;
using SmartCompare.Application.Commands.Quotes.DeleteQuote;
using SmartCompare.Application.Commands.Quotes.DeleteScopeOfWork;
using SmartCompare.Application.Commands.Quotes.DeleteProgressPayment;
using SmartCompare.Application.Commands.Quotes.UpdateScopeOfWork;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Queries.Quotes.GetExclusiveItemsByQuoteId;
using SmartCompare.Application.Queries.Quotes.GetQuoteById;
using SmartCompare.Application.Queries.Quotes.GetQuotesByProjectId;
using SmartCompare.Application.Queries.Quotes.GetScopeOfWorkByQuoteId;
using SmartCompare.Application.Commands.Quotes.UpdateQuote;
using SmartCompare.Application.Commands.Quotes.UpdateExclusion;
using SmartCompare.Application.Commands.Quotes.UpdateProgressPayment;
using SmartCompare.Application.Commands.Quotes.AddProgressPayments;
using SmartCompare.Application.DTOs.Quote.ResponseDto;
using SmartCompare.Application.Commands.Quotes.AddScopeOfWork;
using SmartCompare.Application.Commands.Quotes.AddBatchScopeOfWork;
using SmartCompare.Application.Queries.Quotes.GetQuoteDetailById;
using SmartCompare.Application.Queries.Quotes.GetProgressPaymentsByQuoteId;
using SmartCompare.Application.Queries.Quotes.GenerateQuotePdf;

namespace SmartCompare.API.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    [Authorize]
    public class QuotesController : ControllerBaseApi
    {
        private readonly IMediator _mediator;

        public QuotesController(
            ILogger<QuotesController> logger,
            IMediator mediator) : base(logger)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Get paginated quotes for a specific project
        /// </summary>
        /// <param name="projectPublicId">Project Public ID</param>
        /// <param name="pageNumber">Page number (default: 1)</param>
        /// <param name="pageSize">Page size (default: 10, max: 100)</param>
        /// <returns>Paginated result containing quote summaries. Returns empty list if project not found or user has no access.</returns>
        [HttpGet("/api/projects/{projectPublicId}/quotes")]
        [ProducesResponseType(typeof(ApiResponse<PagedResult<QuoteSummaryDto>>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        public async Task<IActionResult> GetQuotesByProjectId(
            [FromRoute] Guid projectPublicId,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10)
        {
            //Get Auth0 Subject Id from authenticated user claims
            var auth0SubjectId = GetRequiredAuth0SubjectId();

            var query = new GetQuotesByProjectIdQuery(
                projectPublicId,
                auth0SubjectId,
                new Pagination(pageNumber, pageSize));

            var result = await _mediator.Send(query);

            return result.ToActionResult();
        }

        /// <summary>
        /// Retrieves a quote by its unique identifier.
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <returns>The quote details if found and authorized.</returns>
        /// <response code="200">Returns the quote.</response>
        /// <response code="401">User is not authenticated or not found.</response>
        /// <response code="404">Quote not found or user does not have access.</response>
        [HttpGet("{quotePublicId}")]
        [ProducesResponseType(typeof(ApiResponse<QuoteSummaryDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetQuoteById(Guid quotePublicId)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var query = new GetQuoteByIdQuery(quotePublicId, auth0SubjectId);
            var result = await _mediator.Send(query);

            return result.ToActionResult();
        }

        /// <summary>
        /// Retrieves a quote by its unique identifier. Including all sub-entities
        /// </summary>
        /// /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <returns>The quote details if found and authorized.</returns>
        /// <response code="200">Returns the quote.</response>
        /// <response code="401">User is not authenticated or not found.</response>
        /// <response code="404">Quote not found or user does not have access.</response>
        [HttpGet("{quotePublicId}/details")]
        [ProducesResponseType(typeof(ApiResponse<QuoteDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetQuoteDetailsById(Guid quotePublicId)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var query = new GetQuoteDetailByIdQuery(quotePublicId, auth0SubjectId);
            var result = await _mediator.Send(query);

            return result.ToActionResult();
        }


        /// <summary>
        /// Retrieves paginated scope-of-work items for a specific quote
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <param name="pageNumber">Page number (default: 1)</param>
        /// <param name="pageSize">Page size (default: 10, max: 100)</param>
        /// <returns>Paginated result containing scope of work items</returns>
        /// <response code="200">Returns the paginated scope-of-work items.</response>
        /// <response code="400">Invalid pagination parameters</response>
        /// <response code="401">User is not authenticated or not found.</response>
        [HttpGet("{quotePublicId}/scopeofwork")]
        [ProducesResponseType(typeof(ApiResponse<PagedResult<ScopeOfWorkDto>>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        public async Task<IActionResult> GetScopeOfWorkItemsByQuoteId(
            [FromRoute] Guid quotePublicId,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();

            var query = new GetScopeOfWorkItemsByQuoteIdQuery(
                quotePublicId,
                auth0SubjectId,
                new Pagination(pageNumber, pageSize));

            var result = await _mediator.Send(query);

            return result.ToActionResult();
        }

        /// <summary>
        /// Get paginated exclusive items for a specific quote.
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <param name="pageNumber">Page number (default: 1)</param>
        /// <param name="pageSize">Page size (default: 10, max: 100)</param>
        /// <returns>Paginated result containing exclusive items. Returns empty list if quote not found or user has no access.</returns>
        /// <response code="200">Returns the paginated exclusive items.</response>
        /// <response code="401">User is not authenticated or not found.</response>
        /// <response code="400">Invalid request parameters.</response>
        [HttpGet("{quotePublicId}/exclusive-items")]
        [ProducesResponseType(typeof(ApiResponse<PagedResult<ExclusionDto>>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetExclusiveItemsByQuoteId(
            [FromRoute] Guid quotePublicId,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var query = new GetExclusiveItemsByQuoteIdQuery(
                quotePublicId,
                auth0SubjectId,
                new Pagination(pageNumber, pageSize));
            var result = await _mediator.Send(query);

            return result.ToActionResult();
        }

        /// <summary>
        /// Delete a quote by by its unique identifier.
        /// </summary>
        /// <param name="quotePublicId">The Public ID of the quote to delete</param>
        /// <returns>200 if successful, or error response if not found or unauthorized</returns>
        [HttpDelete("{quotePublicId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteQuoteById(Guid quotePublicId)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var command = new DeleteQuoteCommand(quotePublicId, auth0SubjectId);
            var result = await _mediator.Send(command);

            return result.ToActionResult();
        }

        /// <summary>
        /// Delete an exclusion from a quote
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote</param>
        /// <param name="exclusionId">The ID of the exclusion to delete</param>
        /// <returns>200 if successful, or error response if not found or unauthorized</returns>
        /// <response code="200">Exclusion deleted successfully.</response>
        /// <response code="400">Invalid request parameters.</response>
        /// <response code="401">User is not authenticated.</response>
        /// <response code="403">User is not authorized to delete this exclusion.</response>
        /// <response code="404">Quote or exclusion not found.</response>
        [HttpDelete("{quotePublicId}/exclusions/{exclusionId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteExclusionById(Guid quotePublicId, int exclusionId)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var command = new DeleteExclusionCommand(quotePublicId, exclusionId, auth0SubjectId);
            var result = await _mediator.Send(command);

            return result.ToActionResult();
        }

        /// <summary>
        /// Creates a new quote for a specific project
        /// </summary>
        /// <param name="projectPublicId">The project PublicID</param>
        /// <param name="createQuoteDto">The quote data</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>201 Created with the new quote</returns>
        [HttpPost("/api/projects/{projectPublicId:guid}/quotes")]
        [ProducesResponseType(typeof(ApiResponse<QuoteSummaryDto>), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreateQuote(
            [FromRoute] Guid projectPublicId,
            [FromBody] CreateQuoteDto createQuoteDto,
            CancellationToken cancellationToken)
        {
            //Get Auth0 Subject Id from authenticated user claims
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var command = new CreateQuoteCommand(
                ProjectPublicId: projectPublicId,
                Auth0SubjectId: auth0SubjectId,
                QuoteNumber: createQuoteDto.QuoteNumber,
                IssuedDate: createQuoteDto.IssuedDate,
                ValidPeriod: createQuoteDto.ValidPeriod,
                IssuedTo: createQuoteDto.IssuedTo,
                IssuedBy: createQuoteDto.IssuedBy,
                SubTotal: createQuoteDto.SubTotal,
                GST: createQuoteDto.GST,
                ABN: createQuoteDto.ABN,
                LicenseNumber: createQuoteDto.LicenseNumber,
                ContactName: createQuoteDto.ContactName,
                ContactEmail: createQuoteDto.ContactEmail,
                ContactPhone: createQuoteDto.ContactPhone,
                PDFUrl: createQuoteDto.PDFUrl
            );
            var result = await _mediator.Send(command);
            return result.ToCreatedAtAction(nameof(GetQuoteById), new { projectPublicId, quotePublicId = result.Succeed ? result.Value.QuotePublicId : Guid.Empty });
        }

        /// <summary>
        /// Updates the description of a scope of work item within a quote.
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <param name="scopeOfWorkId">The ID of the scope of work item to update.</param>
        /// <param name="updateScopeOfWorkDto">The update request containing the new description.</param>
        /// <returns>The updated scope of work details.</returns>
        /// <response code="200">Returns the updated scope of work.</response>
        /// <response code="400">Validation failed.</response>
        /// <response code="401">User is not authenticated or not found.</response>
        /// <response code="404">Quote or scope of work not found.</response>
        [HttpPut("{quotePublicId}/scope-of-work/{scopeOfWorkId}")]
        [ProducesResponseType(typeof(ApiResponse<ScopeOfWorkDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateScopeOfWork(
            [FromRoute] Guid quotePublicId,
            [FromRoute] int scopeOfWorkId,
            [FromBody] UpdateScopeOfWorkRequestDto updateScopeOfWorkDto)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var command = new UpdateScopeOfWorkCommand(quotePublicId, scopeOfWorkId, updateScopeOfWorkDto, auth0SubjectId);
            var result = await _mediator.Send(command);

            return result.ToActionResult();
        }

        /// <summary>
        /// Update a quote by its public ID
        /// </summary>
        /// <param name="quotePublicId">The public ID of the quote to update</param>
        /// <param name="quoteDto">The updated quote data</param>
        /// <returns>200 OK if successful, or error response if not found or unauthorized</returns>
        [HttpPut("{quotePublicId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<string>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<string>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<string>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<string>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateQuoteByPublicId([FromRoute] Guid quotePublicId, [FromBody] UpdateQuoteDto quoteDto)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var command = new UpdateQuoteCommand(quotePublicId, quoteDto, auth0SubjectId);
            var result = await _mediator.Send(command);
            return result.ToActionResult();
        }


        /// <summary>
        /// Update an exclusion by its identifier.
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <param name="exclusionId">The ID of the exclusion to update.</param>
        /// <param name="updateExclusionRequest">The update request containing the new description.</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>The updated exclusion details</returns>
        [HttpPut("{quotePublicId}/exclusions/{exclusionId}")]
        [ProducesResponseType(typeof(ApiResponse<ExclusionDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateExclusion(
            [FromRoute] Guid quotePublicId,
            [FromRoute] int exclusionId,
            [FromBody] UpdateExclusionRequest updateExclusionRequest,
            CancellationToken cancellationToken)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();

            var command = new UpdateExclusionCommand(
                quotePublicId,
                exclusionId,
                auth0SubjectId,
                updateExclusionRequest
            );

            var result = await _mediator.Send(command, cancellationToken);
            return result.ToActionResult();
        }

        /// <summary>
        /// Delete a scope of work item by its ID
        /// </summary>
        /// <param name="scopeofworkId">The ScopeOfWork ID to delete(int)</param>
        /// <param name="quotePublicId">The Quote's Public ID</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpDelete("{quotePublicId}/scope-of-work/{scopeofworkId}")]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteScopeOfWork(
            [FromRoute] int scopeofworkId,
            [FromRoute] Guid quotePublicId,
            CancellationToken cancellationToken)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var command = new DeleteScopeOfWorkCommand(auth0SubjectId, quotePublicId, scopeofworkId);
            var result = await _mediator.Send(command, cancellationToken);
            return result.ToActionResult();
        }


        [HttpPost("{quotePublicId:guid}/exclusions")]
        [ProducesResponseType(typeof(ApiResponse<AddExclusionsResultDto>), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status409Conflict)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> AddExclusions(
            [FromRoute] Guid quotePublicId,
            [FromBody] List<AddExclusionsDto> items,
            CancellationToken cancellationToken)
        {
            //Get Auth0 Subject Id from authenticated user claims
            var auth0SubjectId = GetRequiredAuth0SubjectId();

            var command = new AddExclusionsCommand(
                QuotePublicId: quotePublicId,
                Auth0SubjectId: auth0SubjectId,
                Items: items
            );
            var result = await _mediator.Send(command);

            return result.ToCreatedAtAction(
                createdAtAction: nameof(GetExclusiveItemsByQuoteId),
                createdAtRouteValues: new { quotePublicId = quotePublicId }
            );
        }

        /// <summary>
        ///  Batch add progress payment items to a quote.
        /// </summary>
        /// <param name="quotePublicId"></param>
        /// <param name="items"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("{quotePublicId:guid}/progress-payments")]
        [ProducesResponseType(typeof(ApiResponse<AddProgressPaymentResponseDto>), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> AddProgressPayment(
            [FromRoute] Guid quotePublicId,
            [FromBody] List<AddProgressPaymentRequestDto> items,
            CancellationToken cancellationToken)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var command = new AddProgressPaymentCommand(
                quotePublicId,
                auth0SubjectId,
                items);

            var result = await _mediator.Send(command, cancellationToken);

            return result.ToCreatedAtAction(
                createdAtAction: nameof(GetProgressPaymentsByQuoteId),
                createdAtRouteValues: new { quotePublicId }
            );
        }

        /// <summary>
        /// Update Progress Payment by its identifier.
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <param name="progressPaymentId">The ID of the progress payment to update.</param>
        /// <param name="updateProgressPaymentRequest">The update request containing the new details.</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>The updated progress payment details</returns>
        [HttpPost("{quotePublicId}/progress-payment/{progressPaymentId}")]
        [ProducesResponseType(typeof(ApiResponse<ProgressPaymentDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateProgressPayment(
            [FromRoute] Guid quotePublicId,
            [FromRoute] int progressPaymentId,
            [FromBody] UpdateProgressPaymentRequest updateProgressPaymentRequest,
            CancellationToken cancellationToken)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var command = new UpdateProgressPaymentCommand(quotePublicId, progressPaymentId, auth0SubjectId, updateProgressPaymentRequest);
            var result = await _mediator.Send(command, cancellationToken);
            return result.ToActionResult();
        }



        /// <summary>
        /// Adds a new scope-of-work item to a specific quote
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <param name="addScopeOfWorkDto">The scope of work data to add.</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>The created scope of work item</returns>
        /// <response code="201">Returns the created scope-of-work item.</response>
        /// <response code="400">Invalid request data</response>
        /// <response code="401">User is not authenticated or not found.</response>
        /// <response code="403">User does not have access to the quote.</response>
        /// <response code="404">Quote not found.</response>
        [HttpPost("{quotePublicId}/scopeofwork")]
        [ProducesResponseType(typeof(ApiResponse<ScopeOfWorkDto>), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> AddScopeOfWorkToQuote(
            [FromRoute] Guid quotePublicId,
            [FromBody] AddScopeOfWorkDto addScopeOfWorkDto,
            CancellationToken cancellationToken)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();

            var command = new AddScopeOfWorkCommand(
                QuoteId: quotePublicId,
                Auth0SubjectId: auth0SubjectId,
                Description: addScopeOfWorkDto.Description);

            var result = await _mediator.Send(command, cancellationToken);

            return result.ToCreatedAtAction(nameof(GetScopeOfWorkItemsByQuoteId), new { quotePublicId });
        }

        /// <summary>
        /// Batch add scope of work items to a quote.
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <param name="items">List of scope of work items to add.</param>
        /// <param name="cancellationToken"></param>
        /// <returns>The created scope of work items.</returns>
        /// <response code="201">Returns the created scope-of-work items.</response>
        /// <response code="400">Invalid request data</response>
        /// <response code="401">User is not authenticated or not found.</response>
        /// <response code="403">User does not have access to the quote.</response>
        /// <response code="404">Quote not found.</response>
        /// <response code="409">Duplicate scope of work items detected.</response>
        [HttpPost("{quotePublicId:guid}/scopeofwork/batch")]
        [ProducesResponseType(typeof(ApiResponse<AddBatchScopeOfWorkResultDto>), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status409Conflict)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> AddBatchScopeOfWork(
            [FromRoute] Guid quotePublicId,
            [FromBody] List<AddScopeOfWorkDto> items,
            CancellationToken cancellationToken)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();

            var command = new AddBatchScopeOfWorkCommand(
                QuotePublicId: quotePublicId,
                Auth0SubjectId: auth0SubjectId,
                Items: items);

            var result = await _mediator.Send(command, cancellationToken);

            return result.ToCreatedAtAction(nameof(GetScopeOfWorkItemsByQuoteId), new { quotePublicId });
        }

        /// <summary>
        /// Retrieves paginated progress payments for a specific quote
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <param name="pageNumber">Page number (default: 1)</param>
        /// <param name="pageSize">Page size (default: 10, max: 100)</param>
        /// <returns>Paginated result containing progress payment items</returns>
        /// <response code="200">Returns the paginated progress payment items.</response>
        /// <response code="400">Invalid pagination parameters</response>
        /// <response code="401">User is not authenticated or not found.</response>
        [HttpGet("{quotePublicId}/progresspayments")]
        [ProducesResponseType(typeof(ApiResponse<PagedResult<ProgressPaymentDto>>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        public async Task<IActionResult> GetProgressPaymentsByQuoteId(
            [FromRoute] Guid quotePublicId,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();

            var query = new GetProgressPaymentsByQuoteIdQuery(
                quotePublicId,
                auth0SubjectId,
                new Pagination(pageNumber, pageSize));

            var result = await _mediator.Send(query);

            return result.ToActionResult();
        }


        /// <summary>
        /// Delete a progress payment by its ID
        /// </summary>
        /// <param name="progressPaymentId">The ProgressPayment ID to delete (int)</param>
        /// <param name="quotePublicId">The Quote's Public ID</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpDelete("{quotePublicId}/progress-payment/{progressPaymentId}")]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> DeleteProgressPayment(
            [FromRoute] int progressPaymentId,
            [FromRoute] Guid quotePublicId,
            CancellationToken cancellationToken)
        {
            var auth0SubjectId = GetRequiredAuth0SubjectId();
            var command = new DeleteProgressPaymentCommand(auth0SubjectId, quotePublicId, progressPaymentId);
            var result = await _mediator.Send(command, cancellationToken);
            return result.ToActionResult();
        }

        /// <summary>
        /// Generate and download a PDF for a specific quote
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote</param>
        /// <returns>PDF file stream</returns>
        /// <response code="200">Returns the PDF file</response>
        /// <response code="401">User is not authenticated</response>
        /// <response code="404">Quote not found or user does not have access</response>
        [HttpGet("{quotePublicId}/pdf")]
        [ProducesResponseType(typeof(FileContentResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DownloadQuotePdf([FromRoute] Guid quotePublicId, CancellationToken cancellationToken)
        {
            var query = new GenerateQuotePdfQuery(quotePublicId, GetRequiredAuth0SubjectId());
            var result = await _mediator.Send(query, cancellationToken);

            if (!result.Succeed)
                return result.ToActionResult();

            return File(result.Value!, "application/pdf", $"Quote-{quotePublicId}.pdf");
        }
    }

}



