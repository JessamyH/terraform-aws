using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartCompare.API.ApiResponse;
using SmartCompare.Application.DTOs.Auth.QueryDto;
using SmartCompare.Application.Queries.Users.GetCurrentUser;

namespace SmartCompare.API.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class UsersController : ControllerBaseApi
{
    private readonly IMediator _mediator;

    public UsersController(ILogger<UsersController> logger, IMediator mediator)
        : base(logger)
    {
        _mediator = mediator;
    }

    [HttpGet("me")]
    [ProducesResponseType(typeof(ApiResponse<CurrentUserDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetCurrentUser(CancellationToken cancellationToken)
    {
        var auth0SubjectId = GetRequiredAuth0SubjectId();
        var query = new GetCurrentUserQuery(auth0SubjectId);
        var result = await _mediator.Send(query, cancellationToken);
        return result.ToActionResult();
    }
}
