using System.Security.Claims;
using System.Text.Json;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartCompare.API.Constants;
using SmartCompare.SharedKernel.Auth.Claims;
using SmartCompare.API.ApiResponse;
using SmartCompare.Application.DTOs.Auth.ResponseDto;

namespace SmartCompare.API.Controllers;

[ApiController]
[Authorize]
[Route("api/[controller]")]
public class ProtectedControllerSample: ControllerBaseApi
{
    private readonly IMediator _mediator;

    public ProtectedControllerSample(ILogger<ProjectsController> logger, IMediator mediator)
        : base(logger)
    {
        _mediator = mediator;
    }
    
    [Authorize(Policy = Policies.OnlyAdmin)]
    [HttpGet("admin-policy-sample")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public IActionResult AdminPolicySample()
    {
        return Ok(new { message = "success！you are admin" });
    }
    
    [Authorize(Policy = Policies.OnlyProTier)]
    [HttpGet("pro-tier-sample")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public IActionResult ProTierSample()
    {
        return Ok(new { message = "success! you are in the pro tier" });
    }
    
    
    /// <summary>
    /// Returns the current user's roles and subscription tier from claims
    /// </summary>
    /// <returns>User's roles and tier information</returns>
    /// <response code="200">Returns roles and tier</response>
    /// <response code="401">User is not authenticated</response>
    /// <response code="403">User is not authorized</response>
    [HttpGet("sync-role")]
    [ProducesResponseType(typeof(ApiResponse<UserRoleTierDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
    public IActionResult SyncRole()
    {
        var roleTierJson = User.FindFirstValue(ClaimTypes.Role);
        if (string.IsNullOrWhiteSpace(roleTierJson))
        {
            return Ok(ApiResponse<UserRoleTierDto>.Success(new UserRoleTierDto([], null)));
        }
        var claim = JsonSerializer.Deserialize<UserRoleTierClaim>(
            roleTierJson,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        var dto = new UserRoleTierDto(
            claim?.Roles ?? [],
            claim?.Tier
        );
        return Ok(ApiResponse<UserRoleTierDto>.Success(dto));
        
    }
    
}