using MediatR;
using Microsoft.AspNetCore.Mvc;
using SmartCompare.API.ApiResponse;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.Queries.SubcontractorTypes;

namespace SmartCompare.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SubcontractorTypesController : ControllerBaseApi
{
    private readonly IMediator _mediator;

    public SubcontractorTypesController(ILogger<SubcontractorTypesController> logger, IMediator mediator)
        : base(logger)
    {
        _mediator = mediator;
    }

    /// <summary>
    /// Returns all available subcontractor types
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(ApiResponse<List<SubcontractorTypeDto>>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetSubcontractorTypes(CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(new GetSubcontractorTypesQuery(), cancellationToken);
        return result.ToActionResult();
    }
}
