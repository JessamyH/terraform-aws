using MediatR;
using Microsoft.AspNetCore.Mvc;
using SmartCompare.API.ApiResponse;
using SmartCompare.Application.Commands.Projects.DeleteProject;
using SmartCompare.Application.Commands.Projects.UpdateProject;
using SmartCompare.Application.Commands.Projects.CreateProject;
using Microsoft.AspNetCore.Authorization;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.Common.Paging;
using static SmartCompare.Application.DTOs.ProjectSummaryDTOs;
using SmartCompare.Application.Queries.Projects;

namespace SmartCompare.API.Controllers;
[ApiController]
[Route("api/[controller]")]
public class ProjectsController : ControllerBaseApi
{
    private readonly IMediator _mediator;

    public ProjectsController(ILogger<ProjectsController> logger, IMediator mediator)
        : base(logger)
    {
        _mediator = mediator;
    }

    /// <summary>
    /// Creates a new project
    /// </summary>
    /// <param name="request">The project creation request data</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>The created project DTO</returns>
    [HttpPost]
    [ProducesResponseType(typeof(ApiResponse<ProjectDto>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<ProjectDto>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<ProjectDto>), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> CreateProject(
        [FromBody] CreateProjectDto request,
        CancellationToken cancellationToken)
    {
        // Validate user authentication and extract Auth0SubjectId from cookie
        var Auth0SubjectId = GetRequiredAuth0SubjectId();
        _logger.LogInformation("Received CreateProject request for Auth0SubId: {Auth0SubId}", Auth0SubjectId);

        // Create command with Auth0SubjectId from authenticated user
        var command = new CreateProjectCommand(
            Auth0SubjectId: Auth0SubjectId,
            ProjectName: request.ProjectName,
            Address: request.Address,
            HouseType: request.HouseType,
            HouseSizeSqm: request.HouseSizeSqm,
            Bedrooms: request.Bedrooms,
            Bathrooms: request.Bathrooms,
            SubcontractorTypeId: request.SubcontractorTypeId
        );

        var result = await _mediator.Send(command, cancellationToken);

        return result.ToActionResult(StatusCodes.Status201Created);
    }
    /// Get paginated projects for the authenticated user
    /// </summary>
    /// <param name="pageNumber">PageNumber (default: 1)</param>
    /// <param name="pageSize">PageSize (default: 10, max: 100)</param>
    /// <returns>Paginated list of projects</returns>
    [HttpGet]
    [ProducesResponseType(typeof(ApiResponse<PagedResult<ProjectSummaryDto>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetProjects(
        [FromQuery] int pageNumber = 1,
        [FromQuery] int pageSize = 10)
    {
        // Get Auth0 Subject Id from authenticated user claims
        var auth0SubjectId = GetRequiredAuth0SubjectId();

        var query = new GetProjectsQuery(
            auth0SubjectId,
            new Pagination(pageNumber, pageSize));

        var result = await _mediator.Send(query);

        return result.ToActionResult();
    }

    /// <summary>
    /// Update basic project information
    /// </summary>
    /// <param name="projectId">Project ID</param>
    /// <param name="updateDto">UpdateProjectDto</param>
    /// <param name="cancellationToken">Cancellation Token</param>
    /// <returns>UpdateProjectDto</returns>
    [HttpPut("/api/projects/{projectId}")]
    [Authorize]
    [ProducesResponseType(typeof(ApiResponse<UpdateProjectDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateProject(
        [FromRoute] Guid projectId,
        [FromBody] UpdateProjectDto updateDto,
        CancellationToken cancellationToken)
    {
        var auth0SubjectId = GetRequiredAuth0SubjectId();

        var command = new UpdateProjectCommand
        {
            ProjectId = projectId,
            Auth0SubjectId = auth0SubjectId,
            UpdateDto = updateDto
        };

        var result = await _mediator.Send(command, cancellationToken);

        return result.ToActionResult();
    }

    /// <summary>
    /// Delete a project by Id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    [HttpDelete("{id}")]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> DeleteProjectById(Guid id)
    {
        var auth0SubjectId = GetRequiredAuth0SubjectId();
        var command = new DeleteProjectCommand(id, auth0SubjectId);
        var result = await _mediator.Send(command);

        return result.ToActionResult();
    }

}

