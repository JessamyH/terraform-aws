﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartCompare.API.ApiResponse;
using SmartCompare.Application.Commands.Payments.CreateCheckoutSession;
using SmartCompare.Application.Commands.Payments.HandleStripeWebhookCommand;
using SmartCompare.Application.DTOs.Payment;
using SmartCompare.Application.Queries.Payments.GetCheckoutSessionStatus;

namespace SmartCompare.API.Controllers;

/// <summary>
/// Handles Stripe payment operations including checkout session creation and status retrieval.
/// All endpoints require authentication.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize]
public class PaymentsController : ControllerBaseApi
{
    private readonly IMediator _mediator;

    public PaymentsController(
        ILogger<PaymentsController> logger,
        IMediator mediator) : base(logger)
    {
        _mediator = mediator;
    }

    /// <summary>
    /// Creates a Stripe Checkout Session for a subscription payment.
    /// Returns a session URL for the client to redirect the user to Stripe's hosted checkout page.
    /// </summary>
    /// <param name="request">The subscription tier and duration to purchase.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>A Checkout Session ID and redirect URL.</returns>
    [HttpPost("checkout-session")]
    [ProducesResponseType(typeof(ApiResponse<CheckoutSessionResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> CreateCheckoutSession(
        [FromBody] CreateCheckoutSessionDto request,
        CancellationToken cancellationToken)
    {
        var auth0SubjectId = GetRequiredAuth0SubjectId();

        var command = new CreateCheckoutSessionCommand(
            Auth0SubjectId: auth0SubjectId,
            Tier: request.SubscriptionTier,
            Duration: request.SubscriptionDuration);

        var result = await _mediator.Send(command, cancellationToken);
        return result.ToActionResult();
    }

    /// <summary>
    /// Retrieves the current status of a Stripe Checkout Session.
    /// Used by the client to verify payment completion after returning from Stripe's checkout page.
    /// Validates that the session belongs to the authenticated user to prevent IDOR.
    /// </summary>
    /// <param name="sessionId">The Stripe Checkout Session ID (e.g., cs_xxxxx).</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The session status, payment status, and customer email.</returns>
    [HttpGet("checkout-session/{sessionId}/status")]
    [ProducesResponseType(typeof(ApiResponse<CheckoutSessionStatusDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetCheckoutSessionStatus(
        [FromRoute] string sessionId,
        CancellationToken cancellationToken)
    {
        var auth0SubjectId = GetRequiredAuth0SubjectId();

        var query = new GetCheckoutSessionStatusQuery(SessionId: sessionId, Auth0SubjectId: auth0SubjectId);

        var result = await _mediator.Send(query, cancellationToken);
        return result.ToActionResult();
    }


    /// <summary>
    /// Receives Stripe webhook events. Always returns 200 for successfully verified events
    /// to prevent Stripe retry storms. Returns 400 only for invalid signatures.
    /// </summary>
    [HttpPost("webhooks/stripe")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> HandleStripeWebhook(CancellationToken cancellationToken)
    {
        var json = await new StreamReader(HttpContext.Request.Body).ReadToEndAsync(cancellationToken);
        var signatureHeader = Request.Headers["Stripe-Signature"].ToString();

        var command = new HandleStripeWebhookCommand(json, signatureHeader);
        var result = await _mediator.Send(command, cancellationToken);

        return result.ToActionResult();
    }
}