﻿using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.Logging.ApplicationInsights;

namespace SmartCompare.API.Extensions
{
    public static class ApplicationInsightsExtensions
    {
        public static IServiceCollection AddApplicationInsightsTelemetry(
            this IServiceCollection services,
            IConfiguration configuration,
            IWebHostEnvironment webHostEnvironment)
        {
            var connectionString = configuration["ApplicationInsights:ConnectionString"];

            if (string.IsNullOrWhiteSpace(connectionString))
            {
                return services;
            }


            services.AddApplicationInsightsTelemetry(options =>
            {
                options.ConnectionString = connectionString;
                options.EnableAdaptiveSampling = false;
                options.EnablePerformanceCounterCollectionModule = false;
                options.EnableQuickPulseMetricStream = false;
            });

            if (webHostEnvironment.IsStaging())
            {
                services.Configure<TelemetryConfiguration>(config =>
                {
                    var maxItemsPerSecond = configuration.GetValue<int>("ApplicationInsights:MaxTelemetryItemsPerSecond", 5);
                    var telemetryBuilder = config.DefaultTelemetrySink.TelemetryProcessorChainBuilder;


                    telemetryBuilder.UseAdaptiveSampling(
                        maxTelemetryItemsPerSecond: maxItemsPerSecond,
                        excludedTypes: "Exception");

                    telemetryBuilder.Build();
                });
            }

            return services;
        }


        public static ILoggingBuilder AddApplicationInsightsLogging(
            this ILoggingBuilder builder,
            IConfiguration configuration)
        {
            var connectionString = configuration["ApplicationInsights:ConnectionString"];
            if (string.IsNullOrWhiteSpace(connectionString))
            {
                return builder;
            }
            builder.AddApplicationInsights(
                configureTelemetryConfiguration: (config) => config.ConnectionString = connectionString,
                configureApplicationInsightsLoggerOptions: (options) => { });

            // Filter logs to reduce noise and costs (only Information and above)
            var minLogLevel = configuration.GetValue<LogLevel>("ApplicationInsights:MinimumLogLevel", LogLevel.Information);
            builder.AddFilter<ApplicationInsightsLoggerProvider>(
                "",
                minLogLevel);

            return builder;
        }
    }
}
