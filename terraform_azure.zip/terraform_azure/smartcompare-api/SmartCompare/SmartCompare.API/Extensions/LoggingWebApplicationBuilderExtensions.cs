namespace SmartCompare.API.Extensions;

using Serilog;

/// <summary>
/// Extension methods for configuring Serilog logging in the WebApplicationBuilder.
/// Provides helper methods to set up structured logging with Serilog and log application startup events.
/// </summary>
/// 
public static class LoggingWebApplicationBuilderExtensions
{
    
    /// <summary>
    /// Configures and adds Serilog logging to the application.
    /// This method sets up Serilog with structured logging configuration,
    /// including reading settings from appsettings.json and enriching log entries
    /// with contextual information such as application name, version, and environment.
    /// </summary>
    /// <param name="builder">The WebApplicationBuilder instance to configure logging for.</param>
    /// <returns>The WebApplicationBuilder instance for method chaining.</returns>
    public static WebApplicationBuilder AddLogging(this WebApplicationBuilder builder)
    {
        builder.Host.UseSerilog((context, services, configuration) =>
        {
            configuration
                .ReadFrom.Configuration(context.Configuration)
                .Enrich.FromLogContext()
                .Enrich.WithProperty("Application", context.Configuration["ApplicationInfo:Name"] ?? "SmartCompare")
                .Enrich.WithProperty("Version", context.Configuration["ApplicationInfo:Version"] ?? "Unknown")
                .Enrich.WithProperty("Environment", context.Configuration["ApplicationInfo:Environment"] ?? context.HostingEnvironment.EnvironmentName);
        });
        return builder;
    }
    
    /// <summary>
    /// Logs the application startup information to indicate successful initialization.
    /// This method retrieves the logger from the dependency injection container and writes
    /// a series of informational log messages including the current environment name.
    /// </summary>
    /// <param name="app">The WebApplication instance whose startup information should be logged.</param>
    public static void LogApplicationStartup(this WebApplication app)
    {
        var logger = app.Services.GetRequiredService<ILogger<Program>>();
        logger.LogInformation("========================================");
        logger.LogInformation("Application started successfully");
        logger.LogInformation("Environment: {Environment}", app.Environment.EnvironmentName);
        logger.LogInformation("========================================");
    }
}