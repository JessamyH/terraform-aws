using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using SmartCompare.API.Constants;
using SmartCompare.SharedKernel.Auth.Claims;

namespace SmartCompare.API.Extensions;

public static class AuthorizationExtensions
{
    public static IServiceCollection AddSubscriptionTierPolicies(this IServiceCollection services)
    {
        services.AddAuthorization(options =>
        {
            options.AddPolicy(Policies.OnlyAdmin, policy =>
                policy.RequireAssertion(ctx =>
                {
                    return CheckAccess(ctx, roles: ["Admin"]);
                }));
            
            options.AddPolicy(Policies.OnlyProTier, policy =>
                policy.RequireAssertion(ctx =>
                {
                    return CheckAccess(ctx, tiers: ["Pro"]);
                }));
        });
 
        return services;
    }
    
    
    private static bool CheckAccess(
        AuthorizationHandlerContext ctx,
        string[]? roles = null,
        string[]? tiers = null)
    {
        var claim = ParseRoleTierClaim(ctx);
        if (claim is null)
            return false;
        
        if (roles is { Length: > 0 })
        {
            var hasRole = claim.Roles.Any(r =>
                roles.Any(required => string.Equals(r, required, StringComparison.OrdinalIgnoreCase)));
            
            if (hasRole)
                return true;
        }
        
        if (tiers is { Length: > 0 })
        {
            var hasTier = tiers.Any(t =>
                string.Equals(claim.Tier, t, StringComparison.OrdinalIgnoreCase));
            
            if (hasTier)
                return true;
        }
        return false;
    }

    private static UserRoleTierClaim? ParseRoleTierClaim(AuthorizationHandlerContext ctx)
    {
        var roleTierJson = ctx.User.FindFirst(ClaimTypes.Role)?.Value;
        if (string.IsNullOrWhiteSpace(roleTierJson))
            return null;
        try
        {
            return JsonSerializer.Deserialize<UserRoleTierClaim>(
                roleTierJson,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
        catch
        {
            return null;
        }
    }
    
}