using System.Reflection;
using Microsoft.OpenApi;


namespace SmartCompare.API.Extensions
{
    public static class SwaggerExtensions
    {
        public static IServiceCollection AddSwagger(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = configuration["ApplicationInfo:Name"] ?? "SmartCompare API",
                    Version = configuration["ApplicationInfo:Version"] ?? "v1",
                    Description = "SmartCompare API Documentation"
                });

                // Enable XML comments
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                if (File.Exists(xmlPath))
                {
                    options.IncludeXmlComments(xmlPath);
                }
            });

            return services;
        }

        public static IApplicationBuilder UseSwaggerUI(this IApplicationBuilder app)
        {
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "SmartCompare API v1");
                options.RoutePrefix = string.Empty;
                options.DocumentTitle = "SmartCompare API Documentation";
            });

            return app;
        }
    }
}