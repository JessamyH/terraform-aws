using Microsoft.AspNetCore.Mvc;
using SharedKernel.Errors;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.API.ApiResponse
{
    public static class ResultsMappingExtensions
    {
        public static IActionResult ToActionResult(this Result result, int successStatusCode = StatusCodes.Status200OK)
        {
            if (result.Succeed)
            {
                var response = ApiResponse<object?>.Success(null, result.Message);
                return new ObjectResult(response)
                {
                    StatusCode = successStatusCode
                };
            }
            var error = result.Error ?? new Error(ErrorType.Unexpected, "Unknown error");
            var (statusCode, errorCode) = ErrorMapper.MapError(error);
            var errorResponse = ApiResponse<object?>.Fail(
                error.Message ?? result.Message ?? "Unknown error",
                errorCode
            );
            return new ObjectResult(errorResponse)
            {
                StatusCode = statusCode
            };
        }


        public static IActionResult ToActionResult<T>(this Result<T> result,  int successStatusCode = StatusCodes.Status200OK)
        {
            if (result.Succeed)
            {
                var response = ApiResponse<T>.Success(result.Value, result.Message);
                return new ObjectResult(response)
                {
                    StatusCode = successStatusCode
                }; 
            }
            
            var error = result.Error ?? new Error(ErrorType.Unexpected, "Unknown error");
            var (statusCode, errorCode) = ErrorMapper.MapError(error);
            var errorResponse = ApiResponse<T>.Fail(
                error.Message ?? result.Message ?? "Unknown error",
                errorCode
            );
            return new ObjectResult(errorResponse)
                {
                    StatusCode = statusCode
                }; 
        }
        
        public static IActionResult ToCreatedAtAction<T>(
            this Result<T> result,
            string? createdAtAction,
            object? createdAtRouteValues,
            int createdStatusCode = StatusCodes.Status201Created)
        {
            if (result.Succeed)
            {
                var response = ApiResponse<T>.Success(result.Value, result.Message);
                return new CreatedAtActionResult(
                    actionName: createdAtAction,
                    controllerName: null,
                    routeValues: createdAtRouteValues,
                    value: response)
                {
                    StatusCode = createdStatusCode
                };
            }
            
            var error = result.Error ?? new Error(ErrorType.Unexpected, "Unknown error");
            var (statusCode, errorCode) = ErrorMapper.MapError(error);
            var errorResponse = ApiResponse<T>.Fail(
                error.Message ?? result.Message ?? "Unknown error",
                errorCode
            );
            return new ObjectResult(errorResponse)
            {
                StatusCode = statusCode
            };
        }
        
    }
}