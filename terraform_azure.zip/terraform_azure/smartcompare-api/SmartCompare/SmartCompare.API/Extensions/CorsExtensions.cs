
namespace SmartCompare.API.Extensions
{
    public static class CorsExtensions
    {
        public const string FrontendCorsPolicy = "FrontendCorsPolicy";

        public static IServiceCollection AddAppCors(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            var origins = configuration
                .GetSection("Cors:FrontendOrigins")
                .Get<string[]>() ?? [];

            services.AddCors(options =>
            {
                options.AddPolicy(FrontendCorsPolicy, builder =>
                {
                    builder.WithOrigins(origins)
                        .AllowAnyHeader()
                        .AllowAnyMethod()
                        .AllowCredentials();
                });
            });

            return services;
        }
    }
}