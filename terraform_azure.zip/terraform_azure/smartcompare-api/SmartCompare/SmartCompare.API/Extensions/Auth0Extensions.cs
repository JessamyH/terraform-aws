using System;
using System.Security.Claims;
using Auth0.AspNetCore.Authentication;
using MediatR;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using SmartCompare.API.Constants;
using SmartCompare.Infrastructure.Identity;
using SmartCompare.Application.Commands.Users.SyncUser;

namespace SmartCompare.API.Extensions;

public static class Auth0Extensions
{
    public static IServiceCollection AddAuth0Authentication(this IServiceCollection services, IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    {
        // AddAuth0WebAppAuthentication wires default cookie auth + Auth0 OIDC challenge in one call.
        // Uses Authorization Code Flow (response_type=code, SaveTokens=true, scopes openid/profile/email, issuer=Auth0).
        // WithAccessToken enables offline_access + audience-based access token; on missing refresh token it signs out then re-challenges.
        // Configure Auth0 
        services.AddAuth0WebAppAuthentication(options =>
        {
            options.Domain = configuration["Auth0:Domain"] ?? throw new InvalidOperationException("Auth0 Domain not configured");
            options.ClientId = configuration["Auth0:ClientId"] ?? throw new InvalidOperationException("Auth0 ClientId not configured");
            options.ClientSecret = configuration["Auth0:ClientSecret"] ?? throw new InvalidOperationException("Auth0 ClientSecret not configured");
            options.CallbackPath = configuration["Auth0:Callback"] ?? throw new InvalidOperationException("Auth0 Callback not configured");
            options.Scope = "openid profile email offline_access";
            
            options.OpenIdConnectEvents = new OpenIdConnectEvents
            {
                OnTokenValidated = async context =>
                {
                    var logger = context.HttpContext.RequestServices
                        .GetRequiredService<ILoggerFactory>()
                        .CreateLogger(typeof(Auth0Extensions).FullName!);

                    var principal = context.Principal;
                    // defensive check: Principal should always exist here, but check for safety.
                    if (principal == null)
                    {
                        logger.LogError("Authentication failed: Principal is null");
                        throw new InvalidOperationException("Authentication failed.");
                    }

                    var subjectId = principal.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                    var email = principal.FindFirst(ClaimTypes.Email)?.Value;
                    var userName = principal.FindFirst("nickname")?.Value;

                    if (string.IsNullOrEmpty(subjectId) || string.IsNullOrEmpty(email))
                    {
                        logger.LogError(
                            "Token validation failed: missing required claims. Auth0SubjectId={SubjectId}, Email={Email}.",
                            subjectId ?? "null", email ?? "null");
                        throw new InvalidOperationException("Authentication failed: Required user information is missing");
                    }

                    // Fallback for userName if nickname is missing
                    if (string.IsNullOrWhiteSpace(userName))
                    {
                        userName = email.Split('@')[0];
                        logger.LogInformation(
                            "Nickname claim missing, using email prefix. Auth0SubjectId={SubjectId}",
                            subjectId);
                    }

                    logger.LogInformation(
                        "Token validated for user {Auth0SubjectId} ({Email})",
                        subjectId, email);

                    try
                    {
                        var sender = context.HttpContext.RequestServices.GetRequiredService<ISender>();
                        var command = new SyncUserCommand(subjectId, userName, email);
                        var result = await sender.Send(command);

                        if (!result.Succeed)
                        {
                            logger.LogError(
                                "User sync failed: {Error}. Auth0SubjectId={SubjectId}. Login will be blocked.",
                                result.Error, subjectId);

                            // Block login if user sync fails
                            throw new InvalidOperationException("Unable to complete login. Please try again later.");
                        }

                        logger.LogInformation(
                            "User synchronized successfully: Auth0SubjectId={SubjectId}, Email={Email}",
                            subjectId, email);
                    }
                    catch (InvalidOperationException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        logger.LogError(ex,
                            "Exception during user sync. Auth0SubjectId={SubjectId}. Login will be blocked.",
                            subjectId);

                        // Block login if exception occurs during sync
                        throw new InvalidOperationException("Our service is temporarily unavailable. Please try again later.", ex);
                    }

                    var claimsRefreshService = context.HttpContext.RequestServices
                        .GetRequiredService<IClaimsRefreshService>();

                    if (!string.IsNullOrWhiteSpace(subjectId) && context.Principal is not null)
                    {
                        var refreshed = await claimsRefreshService.RefreshClaimsAndReissueCookieAsync(
                            context.HttpContext,
                            context.Principal,
                            subjectId);

                        if (refreshed is not null)
                            context.Principal = refreshed;
                    }
                },

                OnAuthenticationFailed = async context =>
                {
                    var logger = context.HttpContext.RequestServices
                        .GetRequiredService<ILoggerFactory>()
                        .CreateLogger(typeof(Auth0Extensions).FullName!);

                    logger.LogInformation("OnAuthenticationFailed triggered. Clearing all cookies and redirecting to logout.");

                    // Log cookies before deletion
                    var cookiesBefore = string.Join(", ", context.Request.Cookies.Keys);
                    logger.LogInformation("Cookies before deletion: [{Cookies}]", cookiesBefore);

                    // Clear authentication state and session cookie (if exists)
                    await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                    await context.HttpContext.SignOutAsync(Auth0Constants.AuthenticationScheme);

                    // Manually delete all cookies (including OIDC nonce/correlation cookies)
                    foreach (var cookie in context.Request.Cookies.Keys)
                    {
                        logger.LogInformation("Attempting to delete cookie: {CookieName}", cookie);
                        context.Response.Cookies.Delete(cookie);
                    }

                    logger.LogInformation("Cookie deletion completed. {Count} cookies were processed for deletion.", context.Request.Cookies.Count);

                    var error = context.Exception?.Message ?? "Authentication failed";
                    var encodedError = Uri.EscapeDataString(error);

                    // Get frontend base URL from configuration
                    var configuration = context.HttpContext.RequestServices.GetRequiredService<IConfiguration>();
                    var frontendBaseUrl = configuration["Frontend:BaseUrl"];

                    if (string.IsNullOrEmpty(frontendBaseUrl))
                    {
                        logger.LogError("Frontend:BaseUrl is not configured. Cannot redirect to frontend error page.");
                        throw new InvalidOperationException("Frontend base URL not configured.");
                    }

                    // Redirect to frontend error page instead of backend
                    // NOTE: We don't go through Auth0 logout because:
                    // 1. User authentication never completed (failed during OnTokenValidated)
                    // 2. Redirecting to Auth0 logout would lose the cookie deletion Set-Cookie headers
                    var errorPageUrl = $"{frontendBaseUrl}{AuthRoutes.Frontend.AuthError}?error={encodedError}";

                    logger.LogInformation("Redirecting to frontend error page: {ErrorPageUrl}", errorPageUrl);

                    context.HandleResponse();
                    context.Response.Redirect(errorPageUrl);
                }
            };
        })
        // Enable Access Token + Refresh Token support for calling a protected API.
        // - Audience must match an Auth0 API identifier
        // - Auth0 application must allow offline_access for refresh tokens
        // - OnMissingRefreshToken signs the user out and forces a fresh login
        .WithAccessToken(options =>
        {
            options.UseRefreshTokens = true;
            options.Audience = configuration["Auth0:Audience"] ?? throw new InvalidOperationException("Auth0 Audience not configured");
            options.Events = new Auth0WebAppWithAccessTokenEvents
            {
                OnMissingRefreshToken = async (context) =>
            {
                // Refresh token is missing/invalid: clear local session and force a fresh Auth0 login.
                await context.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

                var authenticationProperties = new LoginAuthenticationPropertiesBuilder()
                .WithRedirectUri("/")
                .WithParameter("prompt", "select_account")
                .Build();

                await context.ChallengeAsync(Auth0Constants.AuthenticationScheme, authenticationProperties);
            }
            };
        });

        // Harden auth cookie: HTTPS-only outside development to avoid leaking auth cookies over plain HTTP.
        services.PostConfigure<CookieAuthenticationOptions>(CookieAuthenticationDefaults.AuthenticationScheme, options =>
        {
            options.Cookie.SecurePolicy = webHostEnvironment.IsDevelopment() ? CookieSecurePolicy.SameAsRequest : CookieSecurePolicy.Always;
        });
        
        
        // This configuration enables refresh token support (offline_access)
        // and allows us to intercept the token response returned from the token endpoint.
        services.Configure<OpenIdConnectOptions>(Auth0Constants.AuthenticationScheme, oidc =>
        {
            
            // IMPORTANT:
            // SaveTokens controls whether the OIDC middleware stores
            // access_token / refresh_token / id_token in the authentication cookie.
            // - true  : tokens are persisted into the auth cookie
            // - false : tokens are NOT persisted
            oidc.SaveTokens = false;
            
            oidc.Events ??= new OpenIdConnectEvents();
            
            // OnTokenResponseReceived is triggered immediately after the token endpoint
            // returns the token response during authentication or token refresh.
            //
            // Purpose of this hook:
            // - Inspect the raw token response returned by Auth0
            // - Access access_token / refresh_token / expires_in values if needed
            // - Useful for logging, diagnostics, or custom token handling scenarios
            oidc.Events.OnTokenResponseReceived = ctx =>
            {
                // TODO:
                // If we need to inspect or handle tokens in the future,
                // they can be retrieved from the token endpoint response like this:
                //
                // var refreshToken = ctx.TokenEndpointResponse?.RefreshToken;
                // var accessToken  = ctx.TokenEndpointResponse?.AccessToken;
                // var expiresIn    = ctx.TokenEndpointResponse?.ExpiresIn;
                
                return Task.CompletedTask;
            };
        });
        
        return services;
    }
}
