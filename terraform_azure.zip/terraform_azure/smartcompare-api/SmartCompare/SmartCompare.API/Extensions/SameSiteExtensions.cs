using System;

namespace SmartCompare.API.Extensions;

public static class SameSiteExtensions
{
    public static IServiceCollection ConfigureSameSiteNoneCookies(this IServiceCollection services)
    {
        // Normalizes SameSite=None behavior across browsers to avoid breaking OIDC redirects.
        // This works around Chrome/Safari quirks when SameSite=None is used.
        services.Configure<CookiePolicyOptions>(options =>
        {
            options.MinimumSameSitePolicy = SameSiteMode.Unspecified;

            options.OnAppendCookie = cookieContext =>
                CheckSameSite(cookieContext.CookieOptions);

            options.OnDeleteCookie = cookieContext =>
                CheckSameSite(cookieContext.CookieOptions);
        });

        return services;
    }

    private static void CheckSameSite(CookieOptions options)
    {
        if (options.SameSite == SameSiteMode.None)
        {
            options.SameSite = SameSiteMode.Unspecified;
            options.Secure = true;
        }
    }
}
