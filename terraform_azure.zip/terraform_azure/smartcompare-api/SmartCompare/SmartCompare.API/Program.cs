using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.HttpOverrides;
using SmartCompare.API.Extensions;
using SmartCompare.API.Middleware;
using SmartCompare.Application;
using SmartCompare.Infrastructure;
using SmartCompare.Infrastructure.Persistence.Contexts;
using SmartCompare.Infrastructure.Persistence.SeedData;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseSentry(options =>
{
    options.Debug = builder.Environment.IsDevelopment();
});

// Load local configuration file for sensitive settings
builder.Configuration.AddJsonFile("appsettings.Development.local.json", optional: true, reloadOnChange: true);

// Configure Application Insights telemetry(cost-optimized for test environment)
builder.Services.AddApplicationInsightsTelemetry(builder.Configuration, builder.Environment);

// Adjust SameSite behavior for OIDC redirects (fixes Chrome/Safari SameSite=None quirks).
builder.Services.ConfigureSameSiteNoneCookies();

if (!builder.Environment.IsEnvironment("Testing"))
{
    // Configure Auth0
    builder.Services.AddAuth0Authentication(builder.Configuration, builder.Environment);
}

builder.Services.AddSubscriptionTierPolicies();

// Register custom authorization middleware result handler for 401/403 error handling
builder.Services.AddSingleton<IAuthorizationMiddlewareResultHandler, CustomAuthorizationMiddlewareResultHandler>();

// Add services to the container.
builder.Services.AddControllers();

// Configure Swagger
builder.Services.AddSwagger(builder.Configuration);

builder.Services.AddApplication();

// Configure Serilog logging
builder.AddLogging();

// Add Application Insights logging provider
builder.Logging.AddApplicationInsightsLogging(builder.Configuration);


if (!builder.Environment.IsEnvironment("Testing"))
{
    builder.Services.AddInfrastructureDatabase(builder.Configuration);
}

builder.Services.AddInfrastructure(builder.Configuration);

builder.Services.AddAppCors(builder.Configuration);

// Configure global exception handler
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddProblemDetails();

// Trust X-Forwarded-* headers from Front Door so OIDC redirect_uri, cookie
// SecurePolicy, and HttpsRedirection see the original public scheme/host
// instead of the internal Container Apps hostname.
// KnownNetworks/KnownProxies are cleared because we trust the AFD hop based on
// ip_security_restriction at the Container App ingress level.
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders =
        ForwardedHeaders.XForwardedFor |
        ForwardedHeaders.XForwardedProto |
        ForwardedHeaders.XForwardedHost;
    options.KnownNetworks.Clear();
    options.KnownProxies.Clear();
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    using var scope = app.Services.CreateScope();
    var context = scope.ServiceProvider.GetRequiredService<SmartCompareDbContext>();
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    await DbInitializer.SeedAsync(context, logger);
}

// Log application startup info
app.LogApplicationStartup();

// MUST run before any middleware that reads scheme/host (HttpsRedirection,
// auth cookie SecurePolicy, OIDC redirect_uri builder).
app.UseForwardedHeaders();

// Use global exception handler middleware
app.UseExceptionHandler();
app.UseSentryTracing();
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwaggerUI();
}
app.UseHttpsRedirection();

// Block direct access to the Container App public FQDN — only AFD passes.
// No-op locally (FrontDoor:ExpectedId unset).
app.UseMiddleware<FrontDoorRestrictionMiddleware>();

app.UseCors(CorsExtensions.FrontendCorsPolicy);

app.UseCookiePolicy();

app.UseAuthentication();

app.UseMiddleware<SelectiveClaimsRefreshMiddleware>();

app.UseMiddleware<SubscriptionExpirationMiddleware>();

app.UseAuthorization();

app.MapControllers();

app.Run();

// Make Program accessible for WebApplicationFactory in integration tests
public partial class Program { }
