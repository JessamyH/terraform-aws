using SharedKernel.Errors;


namespace SmartCompare.API.ApiResponse
{
    public static class ErrorMapper
    {
        public const string VALIDATION_ERROR = "VALIDATION_ERROR";
        public const string NOT_FOUND_ERROR = "NOT_FOUND_ERROR";
        public const string CONFLICT_ERROR = "CONFLICT_ERROR";
        public const string UNAUTHORIZED_ERROR = "UNAUTHORIZED_ERROR";
        public const string FORBIDDEN_ERROR = "FORBIDDEN_ERROR";
        public const string BUSINESS_RULE_ERROR = "BUSINESS_RULE_ERROR";
        public const string UNEXPECTED_ERROR = "UNEXPECTED_ERROR";
        public const string UNKNOWN_ERROR = "UNKNOWN_ERROR";

        public static (int statusCode, string errorCode) MapError(Error error) =>
            error.Type switch
            {
                ErrorType.Validation => (StatusCodes.Status400BadRequest, VALIDATION_ERROR),
                ErrorType.NotFound => (StatusCodes.Status404NotFound, NOT_FOUND_ERROR),
                ErrorType.Conflict => (StatusCodes.Status409Conflict, CONFLICT_ERROR),
                ErrorType.Unauthorized => (StatusCodes.Status401Unauthorized, UNAUTHORIZED_ERROR),
                ErrorType.Forbidden => (StatusCodes.Status403Forbidden, FORBIDDEN_ERROR),
                ErrorType.BusinessRule => (StatusCodes.Status422UnprocessableEntity, BUSINESS_RULE_ERROR),
                ErrorType.Unexpected => (StatusCodes.Status500InternalServerError, UNEXPECTED_ERROR),
                _ => (StatusCodes.Status500InternalServerError, UNKNOWN_ERROR),
            };


        // Added: Unify the mapping of ApiResponse error codes back to ErrorType
        // for use in logging and other scenarios.
        public static ErrorType MapErrorCodeToErrorType(string? errorCode) =>
            errorCode switch
            {
                VALIDATION_ERROR => ErrorType.Validation,
                BUSINESS_RULE_ERROR => ErrorType.BusinessRule,
                NOT_FOUND_ERROR => ErrorType.NotFound,
                CONFLICT_ERROR => ErrorType.Conflict,
                UNAUTHORIZED_ERROR => ErrorType.Unauthorized,
                FORBIDDEN_ERROR => ErrorType.Forbidden,
                UNEXPECTED_ERROR => ErrorType.Unexpected,
                UNKNOWN_ERROR => ErrorType.Unexpected,
                _ => ErrorType.Unexpected
            };
    }
}
