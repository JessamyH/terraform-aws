﻿namespace SmartCompare.API.Constants
{
    public static class AuthRoutes
    {
        // Backend API routes
        public const string Login = "/api/auth/login";
        public const string Logout = "/api/auth/logout";
        public const string LoginFailed = "/api/auth/login-failed";

        // Frontend page routes
        public static class Frontend
        {
            public const string AuthError = "/auth/error";
        }
    }
}
