namespace SmartCompare.API.Constants;

public static class Policies
{
    public const string OnlyAdmin = "Only.Admin";
    public const string OnlyProTier = "Only.ProTier";
}