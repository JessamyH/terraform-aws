using System.Security.Claims;
using Microsoft.Extensions.Caching.Memory;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.API.Middleware;

public class SubscriptionExpirationMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<SubscriptionExpirationMiddleware> _logger;
    private readonly IMemoryCache _cache;
    private static readonly TimeSpan CacheDuration = TimeSpan.FromMinutes(5);

    public SubscriptionExpirationMiddleware(
        RequestDelegate next,
        ILogger<SubscriptionExpirationMiddleware> logger,
        IMemoryCache cache)
    {
        _next = next;
        _logger = logger;
        _cache = cache;
    }

    public async Task InvokeAsync(
        HttpContext context,
        ISubscriptionQueries subscriptionQueries,
        IUserRepository userRepository,
        IUnitOfWork unitOfWork)
    {
        if (context.User.Identity?.IsAuthenticated == true)
        {
            var auth0SubjectId = context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!string.IsNullOrWhiteSpace(auth0SubjectId))
            {
                var cacheKey = $"sub_expiry_checked:{auth0SubjectId}";

                if (!_cache.TryGetValue(cacheKey, out _))
                {
                    try
                    {
                        var utcNow = DateTime.UtcNow;
                        var isExpired = await subscriptionQueries.IsSubscriptionExpiredAsync(
                            auth0SubjectId, utcNow, context.RequestAborted);

                        if (isExpired)
                        {
                            var user = await userRepository.GetBySubjectIdWithSubscriptionAsync(
                                auth0SubjectId, context.RequestAborted);

                            if (user?.Subscription is not null && user.Subscription.IsExpired(utcNow))
                            {
                                user.Subscription.Expire();
                                await unitOfWork.SaveChangesAsync(context.RequestAborted);

                                _logger.LogInformation(
                                    "Subscription expired on access for User {UserId}, downgraded to Free",
                                    user.Id);
                            }
                        }

                        _cache.Set(cacheKey, true, CacheDuration);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex,
                            "Error checking subscription expiration for {Auth0SubjectId}",
                            auth0SubjectId);
                    }
                }
            }
        }

        await _next(context);
    }
}
