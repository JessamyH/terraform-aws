﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using SmartCompare.API.ApiResponse;
using System.Security.Claims;

namespace SmartCompare.API.Middleware
{
    public class CustomAuthorizationMiddlewareResultHandler : IAuthorizationMiddlewareResultHandler
    {
        private readonly AuthorizationMiddlewareResultHandler _defaultHandler = new();
        private readonly ILogger<CustomAuthorizationMiddlewareResultHandler> _logger;

        public CustomAuthorizationMiddlewareResultHandler(ILogger<CustomAuthorizationMiddlewareResultHandler> logger)
        {
            _logger = logger;
        }

        public async Task HandleAsync(
            RequestDelegate next, 
            HttpContext httpContext, 
            AuthorizationPolicy authorizationPolicy,
            PolicyAuthorizationResult policyAuthorizationResult)
        {
            if (policyAuthorizationResult.Succeeded)
            {
                await next(httpContext);
                return;
            }

            if (policyAuthorizationResult.Challenged)
            {
                await HandleAuthenticationFailureAsync(httpContext);
                return;
            }

            if (policyAuthorizationResult.Forbidden)
            {
                await HandleAuthorizationFailureAsync(httpContext);
                return;
            }

            await _defaultHandler.HandleAsync(next, httpContext, authorizationPolicy, policyAuthorizationResult);
        }


        /// <summary>
        /// Handles 401 Unauthorized
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        private async Task HandleAuthenticationFailureAsync(HttpContext httpContext)
        {
            var endpoint = httpContext.GetEndpoint()?.DisplayName ?? "unknown endpoint";
            var path = httpContext.Request.Path;
            var method = httpContext.Request.Method;

            _logger.LogWarning("Authentication failed for {Method} {Path} at endpoint {Endpoint}", 
                method, path, endpoint);

            httpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
            httpContext.Response.ContentType = "application/json";

            var response = ApiResponse<object?>.Fail(
                errorMessage: "Authentication failed. Access is denied. Please login first",
                errorCode: ErrorMapper.UNAUTHORIZED_ERROR
            );

            await httpContext.Response.WriteAsJsonAsync(response);
        }


        /// <summary>
        /// Handles 403 Forbidden
        /// </summary>
        private async Task HandleAuthorizationFailureAsync(HttpContext httpContext)
        {
            var endpoint = httpContext.GetEndpoint()?.DisplayName ?? "unknown endpoint";
            var path = httpContext.Request.Path;
            var method = httpContext.Request.Method;
            var user = httpContext.User?.Identity?.Name ?? "unknown";
            var auth0SubjectId = httpContext.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "unknown";

            _logger.LogWarning("Authorization failed for user {User} (Auth0 Subject ID: {Auth0SubjectId}) on {Method} {Path} at endpoint {Endpoint}",
                user, auth0SubjectId, method, path, endpoint);

            httpContext.Response.StatusCode = StatusCodes.Status403Forbidden;
            httpContext.Response.ContentType = "application/json";

            var response = ApiResponse<object?>.Fail(
                errorMessage: "Authorization failed. You do not have permission to access this resource.",
                errorCode: ErrorMapper.FORBIDDEN_ERROR
            );

            await httpContext.Response.WriteAsJsonAsync(response);
        }
    }
}
