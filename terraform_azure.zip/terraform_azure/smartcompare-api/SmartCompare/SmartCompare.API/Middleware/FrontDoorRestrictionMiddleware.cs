namespace SmartCompare.API.Middleware;

// Defense-in-depth: only accept requests that came through our specific Azure
// Front Door instance. AFD injects X-Azure-FDID = profile resource_guid.
// No-op when FrontDoor:ExpectedId is empty, so local dev/tests are unaffected.
public class FrontDoorRestrictionMiddleware
{
    private const string FdidHeader = "X-Azure-FDID";

    private readonly RequestDelegate _next;
    private readonly ILogger<FrontDoorRestrictionMiddleware> _logger;
    private readonly string? _expectedId;

    public FrontDoorRestrictionMiddleware(
        RequestDelegate next,
        ILogger<FrontDoorRestrictionMiddleware> logger,
        IConfiguration configuration)
    {
        _next = next;
        _logger = logger;
        _expectedId = configuration["FrontDoor:ExpectedId"];
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (string.IsNullOrWhiteSpace(_expectedId))
        {
            await _next(context);
            return;
        }

        var actual = context.Request.Headers[FdidHeader].ToString();
        if (!string.Equals(actual, _expectedId, StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogWarning(
                "Rejected request to {Path} from {RemoteIp}: missing/invalid X-Azure-FDID",
                context.Request.Path, context.Connection.RemoteIpAddress);

            context.Response.StatusCode = StatusCodes.Status403Forbidden;
            return;
        }

        await _next(context);
    }
}
