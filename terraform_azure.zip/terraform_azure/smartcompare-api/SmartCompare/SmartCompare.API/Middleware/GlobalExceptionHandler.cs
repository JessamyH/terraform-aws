﻿using Microsoft.AspNetCore.Diagnostics;
using SmartCompare.API.ApiResponse;
using SmartCompare.Application.Exceptions;

namespace SmartCompare.API.Middleware
{
    // <summary>
    // Middleware for global exception handling
    // Catches unhandled exceptions and returns standardized error responses
    // Logs exceptions for monitoring and debugging
    // </summary>
    public class GlobalExceptionHandler : IExceptionHandler
    {
        private readonly ILogger<GlobalExceptionHandler> _logger;
        public GlobalExceptionHandler(ILogger<GlobalExceptionHandler> logger)
        {
            _logger = logger;
        }
        /// <summary>
        ///  
        /// </summary>
        /// <param name="httpContext">The current request context is used for writing the response and retrieving the TraceId.</param>
        /// <param name="exception"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
        {
            if (httpContext == null || exception == null)
            {
                return false;
            }

            switch (exception)
            {
                
                case DuplicateKeyException:
                    _logger.LogWarning(exception, "Duplicate key conflict at {Path} {Method}: {Message}", httpContext.Request.Path, httpContext.Request.Method, exception.Message);
                    await WriteResponseAsync(httpContext, StatusCodes.Status409Conflict, exception.Message, "DUPLICATE_KEY", cancellationToken);
                    break;
                
                case ArgumentException:
                    _logger.LogWarning(exception, "Invalid argument at {Path} {Method}: {Message}", httpContext.Request.Path, httpContext.Request.Method, exception.Message);
                    await WriteResponseAsync(httpContext, StatusCodes.Status400BadRequest, exception.Message, "INVALID_ARGUMENT", cancellationToken);
                    break;

                case OperationCanceledException:
                    _logger.LogInformation("Request canceled by client {Method} {Path}", httpContext.Request.Method, httpContext.Request.Path);
                    await WriteResponseAsync(httpContext, StatusCodes.Status499ClientClosedRequest, "Request canceled by client.", "REQUEST_CANCELED", cancellationToken);
                    break;

                case UnauthorizedAccessException:
                    _logger.LogWarning(exception, "Unauthorized access at {Path} {Method}", httpContext.Request.Path, httpContext.Request.Method);
                    await WriteResponseAsync(httpContext, StatusCodes.Status401Unauthorized, "Unauthorized access.", "UNAUTHORIZED_ACCESS", cancellationToken);
                    break;

                default:
                    _logger.LogError(exception,
                        "Unexpected exception {Type} at {Path} {Method}",
                        exception.GetType().Name, httpContext.Request.Path, httpContext.Request.Method);
                    await WriteResponseAsync(httpContext, StatusCodes.Status500InternalServerError, "Unexpected error.", "UNEXPECTED_ERROR", cancellationToken);
                    break;
            }

            return true;
        }

        private static Task WriteResponseAsync(HttpContext httpContext, int statusCode, string message, string errorCode, CancellationToken cancellationToken)
        {
            httpContext.Response.StatusCode = statusCode;
            httpContext.Response.ContentType = "application/json";
            var response = ApiResponse<object?>.Fail(message, errorCode);
            return httpContext.Response.WriteAsJsonAsync(response, cancellationToken);
        }

    }
}
