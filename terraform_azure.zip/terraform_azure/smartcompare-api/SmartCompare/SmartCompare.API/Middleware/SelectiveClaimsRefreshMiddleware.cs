using System.Security.Claims;
using SmartCompare.Infrastructure.Identity;

namespace SmartCompare.API.Middleware;

public class SelectiveClaimsRefreshMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<SelectiveClaimsRefreshMiddleware> _logger;
    private readonly HashSet<string> _refreshRoleClaimPaths;

    public SelectiveClaimsRefreshMiddleware(RequestDelegate next, 
        ILogger<SelectiveClaimsRefreshMiddleware> logger, 
        IConfiguration configuration)
    {
        _next = next;
        _logger = logger;
        
        var paths = configuration
            .GetSection("Authorization:RefreshRoleClaimPaths")
            .Get<List<string>>() ?? new List<string>();
        
        if (paths is null || paths.Count == 0)
            throw new InvalidOperationException("Authorization:RefreshRoleClaimPaths not configured");
        
        _refreshRoleClaimPaths = new HashSet<string>(paths, StringComparer.OrdinalIgnoreCase);
    }

    public async Task InvokeAsync(HttpContext context, IClaimsRefreshService claimsRefreshService)
    {

        if (context == null)
            throw new ArgumentNullException(nameof(context));

        if (claimsRefreshService == null)
            throw new ArgumentNullException(nameof(claimsRefreshService));
        
        var requestId = context.TraceIdentifier;
        var requestPath = context.Request.Path;
        
        if (!ShouldRefreshClaims(context))
        {
            await _next(context);
            return;
        }
        
        var auth0SubjectId = context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrWhiteSpace(auth0SubjectId))
        {
            _logger.LogWarning(
                "RequestId: {RequestId}, Path: {Path} - Skip claims refresh: Auth0SubjectId is null or whitespace",
                requestId,
                requestPath);
            await _next(context);
            return;
        }
        
        try
        {
            var refreshedPrincipal = await claimsRefreshService
                .RefreshClaimsAndReissueCookieAsync(context,
                    context.User,
                    auth0SubjectId);

            if (refreshedPrincipal is not null)
            {
                context.User = refreshedPrincipal;
                _logger.LogInformation(
                    "RequestId: {RequestId}, Path: {Path}, Auth0SubjectId: {Auth0SubjectId}, " +
                    "- Claims refreshed and cookie reissued successfully",
                    requestId,
                    requestPath,
                    auth0SubjectId);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "RequestId: {RequestId}, Path: {Path}, Auth0SubjectId: {Auth0SubjectId} - " +
                "Error refreshing claims and reissuing cookie. Continuing without refresh. Exception: {ExceptionMessage}",
                requestId,
                requestPath,
                auth0SubjectId,
                ex.Message);
        }

        await _next(context);
    }
    
    private bool ShouldRefreshClaims(HttpContext context)
    {
        if (!context.User.Identity?.IsAuthenticated ?? true)
            return false;
        return _refreshRoleClaimPaths.Contains(context.Request.Path);
    }
    
}