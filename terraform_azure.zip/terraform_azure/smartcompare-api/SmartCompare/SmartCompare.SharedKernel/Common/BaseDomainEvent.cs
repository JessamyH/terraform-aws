using SmartCompare.SharedKernel.Interfaces;
namespace SmartCompare.SharedKernel.Common;

public abstract class BaseDomainEvent: IDomainEvent
{
    public Guid EventId { get; } = Guid.NewGuid();
    public DateTime OccurredOn { get; } = DateTime.UtcNow;
}
