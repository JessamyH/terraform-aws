namespace SmartCompare.SharedKernel.Common;

public abstract class BaseEntity<T>
{
    public T Id { get; protected set; } = default!;

    protected BaseEntity() { }

    protected BaseEntity(T id)
    {
        Id = id;
    }

    //Override Equals to enforce Equality by Id
    public override bool Equals(object? obj)
    {
        if (obj is null || obj.GetType() != GetType())
            return false;

        var entity = (BaseEntity<T>)obj;

        if (EqualityComparer<T>.Default.Equals(Id, default) &&
            EqualityComparer<T>.Default.Equals(entity.Id, default))
            return false;

        return EqualityComparer<T>.Default.Equals(Id, entity.Id);
    }

    public override int GetHashCode()
    {
        return Id?.GetHashCode() ?? 0;
    }

    public static bool operator ==(BaseEntity<T>? left, BaseEntity<T>? right)
    {
        if (left is null && right is null)
            return true;

        if (left is null || right is null)
            return false;

        return left.Equals(right);
    }

    public static bool operator !=(BaseEntity<T>? left, BaseEntity<T>? right)
    {
        return !(left == right);
    }
}
