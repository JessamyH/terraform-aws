// NOTE: This file is a placeholder for the shared kernel.
// You can freely add, change, or remove members based on real application requirements.
using System;

namespace SmartCompare.SharedKernel.Common;

public abstract class ValueObject
{
    protected abstract IEnumerable<object?> GetEqualityComponents();
    public override bool Equals(object? obj)
    {
        if (obj is null || obj.GetType() != GetType())
            return false;

        return GetEqualityComponents()
          .SequenceEqual(((ValueObject)obj).GetEqualityComponents());
    }

    public override int GetHashCode()
    {
        return GetEqualityComponents()
          .Aggregate(0, (hash, obj) => HashCode.Combine(hash, obj));
    }
}
