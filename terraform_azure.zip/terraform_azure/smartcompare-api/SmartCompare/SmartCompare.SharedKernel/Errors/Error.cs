namespace SharedKernel.Errors;

public class Error
{
    public ErrorType Type { get; }
    public string? Message { get; }

    public Error(ErrorType errorType, string? message = null)
    {
        Type = errorType;           
        Message = message;
    }
}