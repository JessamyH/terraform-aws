/// <summary>
/// Error type enumeration for categorizing errors
/// add more types as needed
/// </summary>
namespace SharedKernel.Errors
{
    public enum ErrorType
    {
        None = 0,
        Validation = 1,
        NotFound = 2,
        Conflict = 3,
        Unauthorized = 4,
        Forbidden = 5,
        BusinessRule = 6,
        Unexpected = 7,
    }
}