using SharedKernel.Errors;

namespace SmartCompare.SharedKernel.Results{ 
    public class Result
    {
        public bool Succeed { get; }
        public Error? Error { get; }

        public string? Message {get; set;}

        protected Result(bool succeed, string? message = null, Error? error = null)
        {
            if (succeed && error != null)
                throw new InvalidOperationException("Success result cannot have an error");
            
            if (!succeed && error == null)
                throw new InvalidOperationException("Failure result must have an error");

            Succeed = succeed;
            Error = error;
            Message = message;
        }

        public static Result Success(string? message = null) => new(true, message);
        public static Result Failure( Error error ) => new(false, null ,error);

        public static Result<TValue> Success<TValue>( TValue value, string? message = null) => 
            new(value, true, message);
        
        public static Result<TValue> Failure<TValue>( Error error) => 
            new(default, false, null, error );
    }

    public class Result<TValue> : Result
    {
        private readonly TValue? _value;

        public TValue? Value => Succeed 
            ? _value 
            : throw new InvalidOperationException("Cannot access value of a failed result");

        protected internal Result(TValue? value, bool succeed,string? message = null, Error? error = null ) 
            : base(succeed, message, error)
        {
            _value = value;
        }
    }
}