namespace SmartCompare.SharedKernel.Auth.Claims;

public sealed class UserRoleTierClaim
{
    public string[] Roles { get; init; } = Array.Empty<string>();
    public string? Tier { get; init; }
}