// NOTE: This file is a placeholder for the shared kernel.
// You can freely add, change, or remove members based on real application requirements.
using System;

namespace SmartCompare.SharedKernel.Interfaces;

public interface IDomainEvent
{
    DateTime OccurredOn { get; }
    Guid EventId { get; }
}