// NOTE: This file is a placeholder for the shared kernel.
// You can freely add, change, or remove members based on real application requirements.
using System;
using SmartCompare.SharedKernel.Common;

namespace SmartCompare.SharedKernel.Interfaces;

public interface IRepository<T, TId> where T : AggregateRoot<TId>
{
    Task<T> GetByIdAsync(TId id, CancellationToken cancellationToken = default);

    Task<T> FirstOrDefaultAsync(Func<IQueryable<T>, IQueryable<T>> predicate, CancellationToken cancellationToken = default);

    Task AddAsync(T entity, CancellationToken cancellationToken = default);


}
