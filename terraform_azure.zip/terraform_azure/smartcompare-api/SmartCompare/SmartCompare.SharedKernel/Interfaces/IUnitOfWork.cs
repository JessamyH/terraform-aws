namespace SmartCompare.SharedKernel.Interfaces;
using Microsoft.EntityFrameworkCore;

public interface IUnitOfWork : IDisposable
{
    DbContext DbContext { get; }
    Task ExecuteResilientAsync(Func<CancellationToken, Task> operation, CancellationToken ct = default);
    Task<T> ExecuteResilientAsync<T>(Func<CancellationToken, Task<T>> operation, CancellationToken ct = default);
    Task BeginTransactionAsync();
    Task CommitTransactionAsync();
    Task RollbackTransactionAsync();
    Task<int> SaveChangesAsync(CancellationToken cancellationToken);
}


