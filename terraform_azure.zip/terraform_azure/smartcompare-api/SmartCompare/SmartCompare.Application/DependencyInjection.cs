﻿using FluentValidation;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using SmartCompare.Application.Behaviors;
using SmartCompare.Application.Services.Authorization;
using System.Reflection;


namespace SmartCompare.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            var assembly = Assembly.GetExecutingAssembly();

            //Register MediaR(13.1.0)
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(assembly));

            //Register FluentValidation
            services.AddValidatorsFromAssembly(assembly);

            //Register Pipeline Behaviors
            services.AddScoped(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
            services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
            services.AddScoped(typeof(IPipelineBehavior<,>), typeof(TransactionBehavior<,>));

            //Register Automapper
            services.AddAutoMapper(cfg => cfg.AddMaps(assembly));

            //Register Application Services
            services.AddScoped<IProjectAuthorizationService, ProjectAuthorizationService>();
            services.AddScoped<IQuoteAuthorizationService, QuoteAuthorizationService>();

            return services;
        }
    }
}
