using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.SharedKernel.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCompare.Application.Services.Authorization
{
    /// <summary>
    /// Service for handling quote-related authorization checks
    /// </summary>
    public interface IQuoteAuthorizationService
    {
        /// <summary>
        /// Validates that the authenticated user has access to the project that contains the quote.
        /// Returns detailed error information:
        /// - NotFound if the quote does not exist or project is deleted
        /// - Unauthorized if the user does not have access to the project
        /// - Forbidden if the user doesn't have access to the quote
        /// </summary>
        /// <param name="quotePublicId">The quote public ID</param>
        /// <param name="auth0SubjectId">The Auth0 subject ID of the authenticated user</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>
        /// Success with User entity if authorized
        /// Failure with appropriate error if not authorized
        /// </returns>
        Task<Result<User>> ValidateQuoteAccessAsync(
            Guid quotePublicId,
            string auth0SubjectId,
            CancellationToken cancellationToken = default);
    }
}
