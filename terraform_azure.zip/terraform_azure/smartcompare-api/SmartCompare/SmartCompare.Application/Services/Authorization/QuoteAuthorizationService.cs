﻿using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Services.Authorization
{
    public class QuoteAuthorizationService 
        : BaseAuthorizationService, IQuoteAuthorizationService
    {
        private readonly IQuoteQueries _quoteQueries;

        public QuoteAuthorizationService(
            IUserQueries userQueries,
            IQuoteQueries quoteQueries,
            ILogger<QuoteAuthorizationService> logger)
            :base(userQueries, logger)
        {
            _quoteQueries = quoteQueries;
        }

        public async Task<Result<User>> ValidateQuoteAccessAsync(
            Guid quotePublicId,
            string auth0SubjectId,
            CancellationToken cancellationToken = default)
        {
            // Get quote with project (single query)
            var quote = await _quoteQueries.GetQuoteWithProjectAsync(quotePublicId, cancellationToken);

            if (quote == null)
            {
                _logger.LogWarning("Not Found: Quote with PublicId {QuotePublicId} not found.", quotePublicId);
                return Result.Failure<User>(
                    new Error(ErrorType.NotFound, $"Quote with ID {quotePublicId} not found."));
            }

            // Check if project is deleted
            if (quote.Project.IsDeleted)
            {
                _logger.LogWarning(
                    "Not Found: Quote {QuotePublicId} belongs to a deleted project {ProjectId}",
                    quotePublicId,
                    quote.Project.Id);
                return Result.Failure<User>(
                    new Error(ErrorType.NotFound, "Quote not found."));
            }

            // Get user
            var userResult = await GetValidatedUserAsync(auth0SubjectId, cancellationToken);
            if (!userResult.Succeed)
                return userResult;

            var user = userResult.Value!;

            // Check if user owns the project
            if (quote.Project.UserId != user.Id)
            {
                _logger.LogWarning(
                    "Authorization failed: User {UserId} does not have access to quote {QuotePublicId}",
                    user.Id,
                    quotePublicId);
                return Result.Failure<User>(
                    new Error(ErrorType.Forbidden, $"You don't have access to quote with ID {quotePublicId}"));
            }

            return Result.Success(user);
        }
    }
}
