﻿using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Services.Authorization
{
    public class ProjectAuthorizationService
        : BaseAuthorizationService, IProjectAuthorizationService
    {
        private readonly IProjectQueries _projectQueries;

        public ProjectAuthorizationService(
            IUserQueries userQueries,
            IProjectQueries projectQueries,
            ILogger<ProjectAuthorizationService> logger)
            : base(userQueries, logger)
        {
            _projectQueries = projectQueries;
        }

        public async Task<Result<User>> ValidateProjectOwnershipAsync(
            Guid projectPublicId,
            string auth0SubjectId,
            CancellationToken cancellationToken = default)
        {
            var project = await _projectQueries.GetByIdAsync(projectPublicId, cancellationToken);
            if (project == null)
            {
                _logger.LogWarning("Not Found: Project with ID {ProjectId} not found.", projectPublicId);

                return Result.Failure<User>(
                    new Error(ErrorType.NotFound, $"Project with ID {projectPublicId} not found."));
            }

            if (project.IsDeleted)
            {
                _logger.LogWarning("Not Found: Project with ID {ProjectId} is deleted.", projectPublicId);
                return Result.Failure<User>(
                    new Error(ErrorType.NotFound, $"Project with ID {projectPublicId} is deleted."));
            }

            var userResult = await GetValidatedUserAsync(auth0SubjectId, cancellationToken);
            if (!userResult.Succeed)
                return userResult;

            var user = userResult.Value!;

            if (project.UserId != user.Id)
            {
                _logger.LogWarning(
                    "Authorization failed: User {UserId} ({Auth0SubjectId}) does not own project {ProjectId}. Project owner is {OwnerId}",
                    user.Id,
                    auth0SubjectId,
                    project.Id,
                    project.UserId);

                return Result.Failure<User>(
                    new Error(ErrorType.Forbidden, $"User does not have access to project with ID {projectPublicId}."));
            }

            return Result.Success(user);
        }
    }
}
