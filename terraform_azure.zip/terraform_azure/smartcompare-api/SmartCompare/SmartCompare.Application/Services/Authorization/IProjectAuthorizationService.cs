using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Services.Authorization
{
    /// <summary>
    /// Service for handling project-related authorization checks
    /// </summary>
    public interface IProjectAuthorizationService
    {
        /// <summary>
        /// Validates that the authenticated user has access to the specified project.
        /// Checks if the project exists, user exists, and user owns the project.
        /// </summary>
        /// <param name="projectPublicId">The project public ID to validate access for</param>
        /// <param name="auth0SubjectId">The Auth0 subject ID of the authenticated user</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>
        /// Success with User entity if authorized,
        /// Failure with NotFound if project/user not found,
        /// Failure with Forbidden if user doesn't own the project
        /// </returns>
        Task<Result<User>> ValidateProjectOwnershipAsync(
            Guid projectPublicId,
            string auth0SubjectId,
            CancellationToken cancellationToken = default);

        // Add more project-related authorization methods as needed in the future
    }
}
