﻿using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Services.Authorization
{
    public abstract class BaseAuthorizationService
    {
        protected readonly IUserQueries _userQueries;
        protected readonly ILogger _logger;

        protected BaseAuthorizationService(
            IUserQueries userQueries,
            ILogger logger)
        {
            _userQueries = userQueries;
            _logger = logger;
        }

        protected async Task<Result<User>> GetValidatedUserAsync(
            string auth0SubjectId,
            CancellationToken cancellationToken = default)
        {
            var user = await _userQueries.GetByAuth0SubjectIdAsync(auth0SubjectId, cancellationToken);
            if (user == null)
            {
                _logger.LogWarning("Authorization failed: User with Auth0SubjectId {Auth0SubjectId} not found.", auth0SubjectId);
                return Result.Failure<User>(
                    new Error(ErrorType.Unauthorized, $"User with Auth0SubjectId {auth0SubjectId} not found."));
            }

            return Result.Success(user);
        }
    }
}
