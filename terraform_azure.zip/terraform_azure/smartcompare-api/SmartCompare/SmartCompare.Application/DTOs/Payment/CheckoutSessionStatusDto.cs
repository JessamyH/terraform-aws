﻿namespace SmartCompare.Application.DTOs.Payment;

public record CheckoutSessionStatusDto(
    string SessionId,
    string Status,
    string? PaymentStatus,
    string? CustomerEmail
);