﻿using SmartCompare.Domain.Enums;

namespace SmartCompare.Application.DTOs.Payment;

public class CreateCheckoutSessionDto
{
    public required SubscriptionTier SubscriptionTier { get; init; }
    public required SubscriptionDuration SubscriptionDuration { get; init; }
}