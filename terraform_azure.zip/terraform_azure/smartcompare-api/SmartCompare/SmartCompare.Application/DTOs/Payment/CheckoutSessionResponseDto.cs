﻿namespace SmartCompare.Application.DTOs.Payment;

public record CheckoutSessionResponseDto(
    string SessionId,
    string SessionUrl
);