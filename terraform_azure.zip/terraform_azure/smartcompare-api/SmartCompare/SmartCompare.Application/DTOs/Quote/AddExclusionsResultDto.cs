namespace SmartCompare.Application.DTOs.Quote;

public class AddExclusionsResultDto
{
    public int Count { get; set; }
    public List<ExclusionViewDto> Exclusions { get; set; } = new();
}