namespace SmartCompare.Application.DTOs;

public class CreateQuoteDto
{
    public required string QuoteNumber { get; init; }
    public required DateTime IssuedDate { get; init; }
    public required int ValidPeriod { get; init; }
    public required string IssuedTo { get; init; }
    public required string IssuedBy { get; init; }
    public required decimal SubTotal { get; init; }
    public required decimal GST { get; init; }
    public required string ABN { get; init; }
    public required string LicenseNumber { get; init; }
    public required string ContactName { get; init; }
    public required string ContactEmail { get; init; }
    public required string ContactPhone { get; init; }
    public string? PDFUrl { get; init; }
}