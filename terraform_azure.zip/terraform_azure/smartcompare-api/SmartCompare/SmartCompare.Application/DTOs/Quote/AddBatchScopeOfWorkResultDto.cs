namespace SmartCompare.Application.DTOs.Quote;

public class AddBatchScopeOfWorkResultDto
{
    public int Count { get; set; }
    public List<ScopeOfWorkViewDto> ScopeOfWorks { get; set; } = new();
}
