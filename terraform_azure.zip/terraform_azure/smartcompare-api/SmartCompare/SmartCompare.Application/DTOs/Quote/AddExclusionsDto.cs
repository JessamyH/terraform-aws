namespace SmartCompare.Application.DTOs.Quote;

public class AddExclusionsDto
{
    public required string Description { get; init; }
}