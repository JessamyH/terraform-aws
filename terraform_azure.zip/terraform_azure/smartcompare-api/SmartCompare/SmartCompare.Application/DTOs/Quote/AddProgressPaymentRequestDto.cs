﻿namespace SmartCompare.Application.DTOs.Quote
{
    public class AddProgressPaymentRequestDto
    {
        public required string Description { get; init; }
        public required decimal Percentage { get; init; }
    }
}
