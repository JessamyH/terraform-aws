using SmartCompare.Application.Interfaces;

namespace SmartCompare.Application.DTOs.Quote;

public record class QuoteDto
{
    public Guid PublicId { get; init; }
    public string QuoteNumber { get; init; } = null!;
    public DateTime IssuedDate { get; init; }
    public DateTime ValidDate { get; init; }
    public int ValidPeriod { get; init; }
    public string IssuedBy { get; init; } = null!;
    public string IssuedTo { get; init; } = null!;
    public decimal Total { get; init; }
    public decimal SubTotal { get; init; }
    public decimal GST { get; init; }
    public string ABN { get; init; } = null!;
    public string LicenseNumber { get; init; } = null!;
    public string ContactName { get; init; } = null!;
    public string ContactEmail { get; init; } = null!;
    public string ContactPhone { get; init; } = null!;
    public string ProjectName { get; init; } = null!;
    public string? PDFUrl { get; init; }
    public IReadOnlyCollection<ScopeOfWorkDto> ScopeOfWorks { get; init; } = null!;
    public IReadOnlyCollection<ExclusionDto> Exclusions { get; init; } = null!;
    public IReadOnlyCollection<ProgressPaymentDto> ProgressPayments { get; init; } = null!;
}
