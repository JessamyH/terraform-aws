using SmartCompare.Application.Interfaces;

namespace SmartCompare.Application.DTOs.Quote;

public record class ScopeOfWorkDto
{
    public int Id { get; init; }
    public string Description { get; init; } = null!;
}
