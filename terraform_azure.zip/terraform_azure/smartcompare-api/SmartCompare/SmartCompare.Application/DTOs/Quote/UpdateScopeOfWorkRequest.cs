namespace SmartCompare.Application.DTOs.Quote;

public record UpdateScopeOfWorkRequestDto
{
    public string Description { get; init; } = null!;
}
