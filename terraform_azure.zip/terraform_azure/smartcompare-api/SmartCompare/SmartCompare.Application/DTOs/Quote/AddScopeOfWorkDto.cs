namespace SmartCompare.Application.DTOs.Quote;

public class AddScopeOfWorkDto
{
    public string Description { get; init; } = null!;
}
