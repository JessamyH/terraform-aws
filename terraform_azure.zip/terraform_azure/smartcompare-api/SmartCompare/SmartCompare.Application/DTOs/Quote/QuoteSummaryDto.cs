﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartCompare.Application.Interfaces;

namespace SmartCompare.Application.DTOs.Quote
{
    /// <summary>
    /// Summary DTO for quote list views (e.g., GetQuotesByProjectId)
    /// </summary>
    public record QuoteSummaryDto
    {
        public Guid QuotePublicId { get; init; }
        public string QuoteNumber { get; init; } = string.Empty;
        public DateTime IssuedDate { get; init; }
        public DateTime ValidDate { get; init; }
        public int ValidPeriod { get; init; }
        public string IssuedBy { get; init; } = string.Empty;
        public string IssuedTo { get; init; } = string.Empty;
        public decimal Total { get; init; }
        public decimal SubTotal { get; init; }
        public decimal GST { get; init; }
        public string ABN { get; init; } = string.Empty;
        public string LicenseNumber { get; init; } = string.Empty;
        public string ContactName { get; init; } = string.Empty;
        public string ContactEmail { get; init; } = string.Empty;
        public string ContactPhone { get; init; } = string.Empty;
        public string? PDFUrl { get; init; }
        public Guid ProjectPublicId { get; init; }
    }
}
