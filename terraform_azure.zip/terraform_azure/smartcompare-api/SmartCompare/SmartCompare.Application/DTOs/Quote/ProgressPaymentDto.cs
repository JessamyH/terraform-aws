using SmartCompare.Application.Interfaces;

namespace SmartCompare.Application.DTOs.Quote;

public record class ProgressPaymentDto
{
    public int Id { get; init; }
    public string Description { get; init; } = null!;
    public decimal Percentage { get; init; }
}
