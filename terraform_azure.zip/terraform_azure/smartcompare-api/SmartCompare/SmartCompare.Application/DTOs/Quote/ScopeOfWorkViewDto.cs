namespace SmartCompare.Application.DTOs.Quote;

public class ScopeOfWorkViewDto
{
    public string Description { get; set; } = null!;
}
