﻿namespace SmartCompare.Application.DTOs.Quote.ResponseDto
{
    public class AddProgressPaymentResponseDto
    {
        public int Count => ProgressPayments.Count;
        public List<ProgressPaymentViewDto> ProgressPayments { get; set; } = new();
    }
}
