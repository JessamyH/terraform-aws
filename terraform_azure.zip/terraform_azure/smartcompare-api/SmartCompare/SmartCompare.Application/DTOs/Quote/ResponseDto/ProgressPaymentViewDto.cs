﻿namespace SmartCompare.Application.DTOs.Quote.ResponseDto
{
    public class ProgressPaymentViewDto
    {
        public string Description { get; set; } = null!;
        public decimal Percentage { get; set; }
    }
}
