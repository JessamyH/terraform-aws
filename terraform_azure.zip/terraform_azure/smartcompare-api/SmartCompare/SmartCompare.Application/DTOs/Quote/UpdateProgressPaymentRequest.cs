namespace SmartCompare.Application.DTOs.Quote;

public class UpdateProgressPaymentRequest
{
    public decimal Percentage { get; set; }
    public string Description { get; set; } = null!;
}
