namespace SmartCompare.Application.DTOs.Quote
{
    /// <summary>
    ///  DTO for single quote update
    /// </summary>
    public record UpdateQuoteDto
    {
        public string QuoteNumber { get; init; }
        public DateTime IssuedDate { get; init; }
        public int ValidPeriod { get; init; }
        public string IssuedBy { get; init; }
        public string IssuedTo { get; init; }
        public decimal SubTotal { get; init; }
        public decimal GST { get; init; }
        public string ABN { get; init; }
        public string LicenseNumber { get; init; }
        public string ContactName { get; init; }
        public string ContactEmail { get; init; }
        public string ContactPhone { get; init; }
        public string? PDFUrl { get; init; }
    }
}