﻿
namespace SmartCompare.Application.DTOs.Quote
{
    public record UpdateExclusionRequest
    {
        public string Description { get; init; } = null!;
    }
}
