namespace SmartCompare.Application.DTOs.Quote;

public class ExclusionViewDto
{
    public string Description { get; set; }
}