namespace SmartCompare.Application.DTOs.Dashboard;

public record DashboardStatsDto
{
    public int TotalQuotes { get; init; }
    public int ActiveProjects { get; init; }
    public int CompletedProjects { get; init; }
}
