namespace SmartCompare.Application.DTOs.Dashboard;

public record RecentQuoteDto
{
    public string QuoteNumber { get; init; } = string.Empty;
    public string IssuedTo { get; init; } = string.Empty;
    public DateTime ValidDate { get; init; }
    public decimal Total { get; init; }
    public Guid ProjectPublicId { get; init; }
}
