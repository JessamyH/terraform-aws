namespace SmartCompare.Application.DTOs;

public class SubcontractorTypeDto
{
    public int Id { get; set; }
    public string Type { get; set; } = null!;
}
