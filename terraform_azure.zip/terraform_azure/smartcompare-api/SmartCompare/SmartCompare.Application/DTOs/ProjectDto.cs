using SmartCompare.Domain.Enums;

namespace SmartCompare.Application.DTOs;

public record ProjectDto
{
    public Guid PublicId { get; init; }
    public string ProjectName { get; init; } = null!;
    public string Address { get; init; } = null!;
    public HouseType HouseType { get; init; }
    public decimal HouseSizeSqm { get; init; }
    public int Bedrooms { get; init; }
    public int Bathrooms { get; init; }
    public int SubcontractorTypeId { get; init; }
    public ProjectStatus Status { get; init; }
    public DateTime CreatedAt { get; init; }
    public DateTime? UpdatedAt { get; init; }
}
