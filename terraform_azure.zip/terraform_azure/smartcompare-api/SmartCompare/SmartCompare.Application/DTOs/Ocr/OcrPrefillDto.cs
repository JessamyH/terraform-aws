namespace SmartCompare.Application.DTOs.Ocr;

public record OcrPrefillDto(
    List<OcrScopeItemDto> ScopeItems,
    List<OcrExclusionDto> Exclusions,
    List<string> FailedFiles
);

public record OcrScopeItemDto(string Id, string Text);
public record OcrExclusionDto(string Id, string Text);
