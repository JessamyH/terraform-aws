using SmartCompare.Domain.Enums;

namespace SmartCompare.Application.DTOs;

public class ProjectSummaryDTOs
{

    /// <summary>
    /// Summary DTO for project list views (e.g., GetProjects)
    /// </summary>
    public record ProjectSummaryDto
    {
        public Guid PublicId { get; init; }
        public string ProjectName { get; init; } = string.Empty;
        public string Address { get; init; } = string.Empty;
        public HouseType HouseType { get; init; }
        public int Bedrooms { get; init; }
        public int Bathrooms { get; init; }
        public string SubcontractorType { get; init; } = string.Empty;
        public string Status { get; init; } = string.Empty;
        public DateTime CreatedAt { get; init; }
        public DateTime? UpdatedAt { get; init; }
    }
}
