using SmartCompare.Domain.Enums;

namespace SmartCompare.Application.DTOs;

public record UpdateProjectDto
{
    public string ProjectName { get; init; }
    public string Address { get; init; }
    public HouseType HouseType { get; init; }
    public decimal HouseSizeSqm { get; init; }
    public int Bedrooms { get; init; }
    public int Bathrooms { get; init; }
    public ProjectStatus Status { get; init; }
    public int SubcontractorTypeId { get; init; }
}
