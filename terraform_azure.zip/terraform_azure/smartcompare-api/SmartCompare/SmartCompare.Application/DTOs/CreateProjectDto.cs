using SmartCompare.Domain.Enums;

namespace SmartCompare.Application.DTOs;

/// <summary>
/// Request model for creating a new project
/// </summary>
public class CreateProjectDto
{
    /// <summary>
    /// The name of the project
    /// </summary>
    public string ProjectName { get; set; }

    /// <summary>
    /// The project address
    /// </summary>
    public string Address { get; set; }

    /// <summary>
    /// The type of house
    /// </summary>
    public HouseType HouseType { get; set; }

    /// <summary>
    /// The house size in square metres
    /// </summary>
    public decimal HouseSizeSqm { get; set; }

    /// <summary>
    /// The number of bedrooms
    /// </summary>
    public int Bedrooms { get; set; }

    /// <summary>
    /// The number of bathrooms
    /// </summary>
    public int Bathrooms { get; set; }

    /// <summary>
    /// The subcontractor type ID
    /// </summary>
    public int SubcontractorTypeId { get; set; }
}
