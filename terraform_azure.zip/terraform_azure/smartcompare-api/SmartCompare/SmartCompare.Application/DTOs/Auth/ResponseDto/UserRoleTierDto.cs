namespace SmartCompare.Application.DTOs.Auth.ResponseDto;

public record UserRoleTierDto(
        string[] Roles,
        string? Tier
);