namespace SmartCompare.Application.DTOs.Auth.QueryDto;

public sealed record CurrentUserDto(
    Guid Id,
    string UserName,
    string Email,
    string[] Roles,
    string? SubscriptionTier);
