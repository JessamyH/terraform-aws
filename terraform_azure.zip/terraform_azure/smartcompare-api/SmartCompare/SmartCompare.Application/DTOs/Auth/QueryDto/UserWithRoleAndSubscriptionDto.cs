namespace SmartCompare.Application.DTOs.Auth.QueryDto;

public class UserWithRoleAndSubscriptionDto
{
    public Guid Id { get; init; }
    public string Auth0SubjectId { get; init; } = string.Empty;
    public string[] Roles { get; init; } = [];
    public string? SubscriptionTier { get; init; }
}