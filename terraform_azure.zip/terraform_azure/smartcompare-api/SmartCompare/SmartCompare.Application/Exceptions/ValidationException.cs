﻿namespace SmartCompare.Application.Exceptions
{
    public class ValidationException : Exception
    {
        public IDictionary<string, string[]> Errors { get; }


        /// <summary>
        /// Parameterless constructor-manual validation exception
        /// </summary>
        public ValidationException() : base("One or more validation errors occurred.")
        {
            Errors = new Dictionary<string, string[]>();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="errors"></param>
        public ValidationException(IDictionary<string, string[]> errors) : base("One or more validation errors occurred.")
        {
            Errors = errors;
        }


        /// <summary>
        /// Only a single field Exception is needed
        /// </summary>
        /// <param name="propertyName"></param>
        /// <param name="errorMessage"></param>
        public ValidationException(string propertyName, string errorMessage) : base("One or more validation errors occurred.")
        {
            Errors = new Dictionary<string, string[]>
            {
                { propertyName, new[] { errorMessage } }
            };
        }
    }
}
