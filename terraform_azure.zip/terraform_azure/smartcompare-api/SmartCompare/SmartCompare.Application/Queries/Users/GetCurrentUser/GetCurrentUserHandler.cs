using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Auth.QueryDto;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Users.GetCurrentUser;

public sealed class GetCurrentUserHandler
    : IRequestHandler<GetCurrentUserQuery, Result<CurrentUserDto>>
{
    private readonly ILogger<GetCurrentUserHandler> _logger;
    private readonly IUserQueries _userQueries;

    public GetCurrentUserHandler(
        ILogger<GetCurrentUserHandler> logger,
        IUserQueries userQueries)
    {
        _logger = logger;
        _userQueries = userQueries;
    }

    public async Task<Result<CurrentUserDto>> Handle(
        GetCurrentUserQuery request, CancellationToken cancellationToken)
    {
        var user = await _userQueries.GetCurrentUserByAuth0SubjectIdAsync(
            request.Auth0SubjectId, cancellationToken);

        if (user is null)
        {
            _logger.LogWarning(
                "User not found for Auth0SubjectId: {Auth0SubjectId}",
                request.Auth0SubjectId);
            return Result.Failure<CurrentUserDto>(
                new Error(ErrorType.NotFound, "User not found."));
        }

        return Result.Success(user, "Successfully retrieved current user.");
    }
}
