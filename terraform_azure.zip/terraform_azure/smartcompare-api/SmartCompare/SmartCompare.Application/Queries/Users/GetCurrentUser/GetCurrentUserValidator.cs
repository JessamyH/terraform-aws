using FluentValidation;

namespace SmartCompare.Application.Queries.Users.GetCurrentUser;

public class GetCurrentUserValidator : AbstractValidator<GetCurrentUserQuery>
{
    public GetCurrentUserValidator()
    {
        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty()
            .WithMessage("Auth0SubjectId must be provided.");
    }
}
