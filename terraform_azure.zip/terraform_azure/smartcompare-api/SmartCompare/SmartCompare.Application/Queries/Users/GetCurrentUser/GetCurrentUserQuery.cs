using SmartCompare.Application.DTOs.Auth.QueryDto;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Users.GetCurrentUser;

public sealed record GetCurrentUserQuery(string Auth0SubjectId)
    : IQuery<Result<CurrentUserDto>>;
