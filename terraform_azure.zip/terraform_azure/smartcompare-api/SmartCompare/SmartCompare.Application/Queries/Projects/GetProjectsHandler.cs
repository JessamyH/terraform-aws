using MediatR;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;
using static SmartCompare.Application.DTOs.ProjectSummaryDTOs;

namespace SmartCompare.Application.Queries.Projects
{
    public class GetProjectsHandler : IRequestHandler<GetProjectsQuery, Result<PagedResult<ProjectSummaryDto>>>
    {
        private readonly IProjectQueries _projectQueries;

        public GetProjectsHandler(IProjectQueries projectQueries)
        {
            _projectQueries = projectQueries;
        }

        public async Task<Result<PagedResult<ProjectSummaryDto>>> Handle(
            GetProjectsQuery request,
            CancellationToken cancellationToken)
        {
            var pagedResult = await _projectQueries.GetProjectsByUserIdPagedAsync(
                request.Auth0SubjectId,
                request.Pagination,
                cancellationToken);

            return Result.Success(pagedResult);
        }
    }
}