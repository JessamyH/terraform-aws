
using FluentValidation;
using SmartCompare.Application.Common.Paging;

namespace SmartCompare.Application.Queries.Projects;

public class GetProjectsValidator : AbstractValidator<GetProjectsQuery>
{
    private static readonly PaginationValidator _paginationValidator = new();
    public GetProjectsValidator()
    {
        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty()
            .WithMessage("Auth0SubjectId cannot be empty.");

        RuleFor(x => x.Pagination)
            .SetValidator(_paginationValidator);
    }

}
