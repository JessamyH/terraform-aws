using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;
using static SmartCompare.Application.DTOs.ProjectSummaryDTOs;

namespace SmartCompare.Application.Queries.Projects
{
    public record GetProjectsQuery(
        string Auth0SubjectId,
        Pagination Pagination
        ) : IQuery<Result<PagedResult<ProjectSummaryDto>>>;
}