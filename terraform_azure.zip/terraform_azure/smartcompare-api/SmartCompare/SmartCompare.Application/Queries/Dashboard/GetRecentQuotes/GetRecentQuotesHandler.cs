using MediatR;
using SmartCompare.Application.DTOs.Dashboard;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Dashboard.GetRecentQuotes;

public sealed class GetRecentQuotesHandler : IRequestHandler<GetRecentQuotesQuery, Result<List<RecentQuoteDto>>>
{
    private readonly IDashboardQueries _dashboardQueries;

    public GetRecentQuotesHandler(IDashboardQueries dashboardQueries)
    {
        _dashboardQueries = dashboardQueries;
    }

    public async Task<Result<List<RecentQuoteDto>>> Handle(
        GetRecentQuotesQuery request,
        CancellationToken cancellationToken)
    {
        var quotes = await _dashboardQueries.GetRecentQuotesAsync(
            request.Auth0SubjectId, request.Count, cancellationToken);

        return Result.Success(quotes);
    }
}
