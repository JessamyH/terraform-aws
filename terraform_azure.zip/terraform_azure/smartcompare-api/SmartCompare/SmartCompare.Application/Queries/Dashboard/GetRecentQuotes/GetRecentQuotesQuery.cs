using SmartCompare.Application.DTOs.Dashboard;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Dashboard.GetRecentQuotes;

public sealed record GetRecentQuotesQuery(
    string Auth0SubjectId,
    int Count
) : IQuery<Result<List<RecentQuoteDto>>>;
