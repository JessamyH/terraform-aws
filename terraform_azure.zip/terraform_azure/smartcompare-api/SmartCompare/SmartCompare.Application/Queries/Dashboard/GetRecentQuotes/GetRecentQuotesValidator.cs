using FluentValidation;

namespace SmartCompare.Application.Queries.Dashboard.GetRecentQuotes;

public class GetRecentQuotesValidator : AbstractValidator<GetRecentQuotesQuery>
{
    public GetRecentQuotesValidator()
    {
        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty()
            .WithMessage("Auth0SubjectId must be provided.");

        RuleFor(x => x.Count)
            .InclusiveBetween(1, 10)
            .WithMessage("Count must be between 1 and 10.");
    }
}
