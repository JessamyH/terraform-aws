using SmartCompare.Application.DTOs.Dashboard;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Dashboard.GetDashboardStats;

public sealed record GetDashboardStatsQuery(
    string Auth0SubjectId
) : IQuery<Result<DashboardStatsDto>>;
