using MediatR;
using SmartCompare.Application.DTOs.Dashboard;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Dashboard.GetDashboardStats;

public sealed class GetDashboardStatsHandler : IRequestHandler<GetDashboardStatsQuery, Result<DashboardStatsDto>>
{
    private readonly IDashboardQueries _dashboardQueries;

    public GetDashboardStatsHandler(IDashboardQueries dashboardQueries)
    {
        _dashboardQueries = dashboardQueries;
    }

    public async Task<Result<DashboardStatsDto>> Handle(
        GetDashboardStatsQuery request,
        CancellationToken cancellationToken)
    {
        var stats = await _dashboardQueries.GetDashboardStatsAsync(
            request.Auth0SubjectId, cancellationToken);

        return Result.Success(stats);
    }
}
