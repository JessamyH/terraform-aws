using FluentValidation;

namespace SmartCompare.Application.Queries.Dashboard.GetDashboardStats;

public class GetDashboardStatsValidator : AbstractValidator<GetDashboardStatsQuery>
{
    public GetDashboardStatsValidator()
    {
        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty()
            .WithMessage("Auth0SubjectId must be provided.");
    }
}
