﻿using SmartCompare.Application.DTOs.Payment;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Payments.GetCheckoutSessionStatus;

public record GetCheckoutSessionStatusQuery(string SessionId, string Auth0SubjectId)
    :IQuery<Result<CheckoutSessionStatusDto>>;