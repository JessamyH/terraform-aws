﻿using MediatR;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Payment;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Payments.GetCheckoutSessionStatus;

public sealed class GetCheckoutSessionStatusQueryHandler
    : IRequestHandler<GetCheckoutSessionStatusQuery,
    Result<CheckoutSessionStatusDto>>
{
    private readonly ICheckoutSessionService _checkoutSessionService;
    private readonly IUserQueries _userQueries;

    public GetCheckoutSessionStatusQueryHandler(
        ICheckoutSessionService checkoutSessionService,
        IUserQueries userQueries)
    {
        _checkoutSessionService = checkoutSessionService;
        _userQueries = userQueries;
    }

    public async Task<Result<CheckoutSessionStatusDto>> Handle(
        GetCheckoutSessionStatusQuery request,
        CancellationToken cancellationToken)
    {
        var user = await _userQueries.GetByAuth0SubjectIdAsync(
            request.Auth0SubjectId,
            cancellationToken);
        
        if (user is null)
            return Result.Failure<CheckoutSessionStatusDto>(
                new Error(ErrorType.Unauthorized, "User not found."));
        
        if (string.IsNullOrEmpty(user.StripeCustomerId))
            return Result.Failure<CheckoutSessionStatusDto>(
                new Error(ErrorType.Forbidden, "User has no Stripe Customer record."));
        
        return await _checkoutSessionService.GetSessionStatusAsync(
            request.SessionId,
            user.StripeCustomerId,
            cancellationToken);
    }
}