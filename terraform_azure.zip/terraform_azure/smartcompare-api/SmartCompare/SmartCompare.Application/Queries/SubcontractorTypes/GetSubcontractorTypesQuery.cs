using SmartCompare.Application.DTOs;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.SubcontractorTypes;

public record GetSubcontractorTypesQuery : IQuery<Result<List<SubcontractorTypeDto>>>;
