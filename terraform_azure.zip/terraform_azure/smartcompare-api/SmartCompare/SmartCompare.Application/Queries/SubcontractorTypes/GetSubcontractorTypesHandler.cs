using MediatR;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.SubcontractorTypes;

public class GetSubcontractorTypesHandler : IRequestHandler<GetSubcontractorTypesQuery, Result<List<SubcontractorTypeDto>>>
{
    private readonly ISubcontractorTypeQueries _subcontractorTypeQueries;

    public GetSubcontractorTypesHandler(ISubcontractorTypeQueries subcontractorTypeQueries)
    {
        _subcontractorTypeQueries = subcontractorTypeQueries;
    }

    public async Task<Result<List<SubcontractorTypeDto>>> Handle(
        GetSubcontractorTypesQuery request,
        CancellationToken cancellationToken)
    {
        var types = await _subcontractorTypeQueries.GetAllAsync(cancellationToken);
        return Result.Success(types);
    }
}
