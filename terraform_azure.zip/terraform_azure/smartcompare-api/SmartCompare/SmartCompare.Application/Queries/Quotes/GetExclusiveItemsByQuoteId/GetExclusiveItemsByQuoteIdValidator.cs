using System;
using FluentValidation;
using SmartCompare.Application.Common.Paging;

namespace SmartCompare.Application.Queries.Quotes.GetExclusiveItemsByQuoteId;

public class GetExclusiveItemsByQuoteIdValidator : AbstractValidator<GetExclusiveItemsByQuoteIdQuery>
{
    private static readonly PaginationValidator _paginationValidator = new();
    public GetExclusiveItemsByQuoteIdValidator()
    {
        RuleFor(x => x.QuotePublicId)
            .NotEmpty()
            .WithMessage("QuotePublicId must be provided.");

        RuleFor(x => x.Pagination)
            .SetValidator(_paginationValidator);
    }
}
