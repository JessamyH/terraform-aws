using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Quotes.GetExclusiveItemsByQuoteId;

public sealed class GetExclusiveItemsByQuoteIdHandler : IRequestHandler<GetExclusiveItemsByQuoteIdQuery, Result<PagedResult<ExclusionDto>>>
{
    private readonly ILogger<GetExclusiveItemsByQuoteIdHandler> _logger;
    private readonly IQuoteQueries _quoteQueries;
    private readonly IUserQueries _userQueries;

    public GetExclusiveItemsByQuoteIdHandler(ILogger<GetExclusiveItemsByQuoteIdHandler> logger, IQuoteQueries quoteQueries, IUserQueries userQueries)
    {
        _logger = logger;
        _quoteQueries = quoteQueries;
        _userQueries = userQueries;
    }
    public async Task<Result<PagedResult<ExclusionDto>>> Handle(GetExclusiveItemsByQuoteIdQuery request, CancellationToken cancellationToken)
    {
        var user = await _userQueries.GetByAuth0SubjectIdAsync(request.Auth0SubjectId);
        if (user == null)
        {
            _logger.LogWarning("User not found: Auth0SubjectId {Auth0SubjectId}", request.Auth0SubjectId);
            return Result.Failure<PagedResult<ExclusionDto>>(new Error(ErrorType.Unauthorized, "User not found."));
        }

        var pagedExclusiveItems = await _quoteQueries.GetChildrenPagedAsync<Exclusion, ExclusionDto>(
            request.QuotePublicId,
            user.Id,
            q => q.Exclusions,
            request.Pagination,
            cancellationToken);

        return Result.Success(pagedExclusiveItems, $"Successfully retrieved Exclusive Items for Quote Id {request.QuotePublicId}");
    }
}
