using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Quotes.GenerateQuotePdf;

public sealed record GenerateQuotePdfQuery(
    Guid QuotePublicId,
    string Auth0SubjectId
) : IQuery<Result<byte[]>>;
