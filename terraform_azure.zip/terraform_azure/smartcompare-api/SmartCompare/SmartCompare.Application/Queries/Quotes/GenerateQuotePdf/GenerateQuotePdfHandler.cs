using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Quotes.GenerateQuotePdf;

public sealed class GenerateQuotePdfHandler : IRequestHandler<GenerateQuotePdfQuery, Result<byte[]>>
{
    private readonly IQuoteQueries _quoteQueries;
    private readonly IQuoteAuthorizationService _quoteAuthorizationService;
    private readonly IPdfGenerationService _pdfGenerationService;
    private readonly ILogoDownloadService _logoDownloadService;
    private readonly ILogger<GenerateQuotePdfHandler> _logger;

    public GenerateQuotePdfHandler(
        IQuoteQueries quoteQueries,
        IQuoteAuthorizationService quoteAuthorizationService,
        IPdfGenerationService pdfGenerationService,
        ILogoDownloadService logoDownloadService,
        ILogger<GenerateQuotePdfHandler> logger)
    {
        _quoteQueries = quoteQueries;
        _quoteAuthorizationService = quoteAuthorizationService;
        _pdfGenerationService = pdfGenerationService;
        _logoDownloadService = logoDownloadService;
        _logger = logger;
    }

    public async Task<Result<byte[]>> Handle(GenerateQuotePdfQuery request, CancellationToken cancellationToken)
    {
        // Explicit ownership check (command-style auth) — PDF returns binary stream,
        // WHERE-clause filtering (query-style) cannot be used for binary responses.
        var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
            request.QuotePublicId, request.Auth0SubjectId, cancellationToken);

        if (!authResult.Succeed)
            return Result.Failure<byte[]>(authResult.Error!);

        var user = authResult.Value!;

        var quote = await _quoteQueries.GetByIdAsync<QuoteDto>(
            request.QuotePublicId, user.Id, cancellationToken);

        if (quote == null)
        {
            _logger.LogWarning("Quote {QuotePublicId} not found for PDF generation", request.QuotePublicId);
            return Result.Failure<byte[]>(new Error(ErrorType.NotFound, "Quote not found."));
        }

        var logoUrl = user.CompanyProfiles.Select(cp => cp.LogoUrl).FirstOrDefault();
        var logoBytes = await _logoDownloadService.DownloadLogoAsync(logoUrl, cancellationToken);

        try
        {
            var pdfBytes = _pdfGenerationService.GenerateQuotePdf(quote, logoBytes);
            return Result.Success(pdfBytes);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "PDF generation failed for quote {QuotePublicId}", request.QuotePublicId);
            return Result.Failure<byte[]>(new Error(ErrorType.Unexpected, "PDF generation failed."));
        }
    }
}
