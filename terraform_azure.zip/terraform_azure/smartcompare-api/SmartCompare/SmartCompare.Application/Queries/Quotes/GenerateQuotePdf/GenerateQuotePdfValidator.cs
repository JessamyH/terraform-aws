using FluentValidation;

namespace SmartCompare.Application.Queries.Quotes.GenerateQuotePdf;

public class GenerateQuotePdfValidator : AbstractValidator<GenerateQuotePdfQuery>
{
    public GenerateQuotePdfValidator()
    {
        RuleFor(x => x.QuotePublicId)
            .NotEmpty()
            .WithMessage("QuotePublicId must be provided.");

        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty()
            .WithMessage("Auth0SubjectId must be provided.");
    }
}
