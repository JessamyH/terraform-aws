using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Quotes.GetProgressPaymentsByQuoteId;

public sealed class GetProgressPaymentsByQuoteIdHandler : IRequestHandler<GetProgressPaymentsByQuoteIdQuery, Result<PagedResult<ProgressPaymentDto>>>
{
    private readonly ILogger<GetProgressPaymentsByQuoteIdHandler> _logger;
    private readonly IUserQueries _userQueries;
    private readonly IQuoteQueries _quoteQueries;

    public GetProgressPaymentsByQuoteIdHandler(
        ILogger<GetProgressPaymentsByQuoteIdHandler> logger,
        IUserQueries userQueries,
        IQuoteQueries quoteQueries)
    {
        _logger = logger;
        _userQueries = userQueries;
        _quoteQueries = quoteQueries;
    }

    public async Task<Result<PagedResult<ProgressPaymentDto>>> Handle(
        GetProgressPaymentsByQuoteIdQuery request,
        CancellationToken cancellationToken)
    {
        var user = await _userQueries.GetByAuth0SubjectIdAsync(request.Auth0SubjectId);
        if (user == null)
        {
            _logger.LogWarning("User not found: Auth0SubjectId {Auth0SubjectId}", request.Auth0SubjectId);
            return Result.Failure<PagedResult<ProgressPaymentDto>>
                (new Error(ErrorType.Unauthorized, "User not found."));
        }

        // Note: Quote validation is redundant in the Handler as GetChildrenPagedAsync handles it internally
        //var quote = await _quoteQueries.GetByIdAsync<QuoteDto>(request.QuotePublicId, user.Id, cancellationToken);
        //if (quote == null)
        //{
        //    _logger.LogWarning("Quote {QuotePublicId} not found", request.QuotePublicId);
        //    return Result.Failure<PagedResult<ProgressPaymentDto>>
        //        (new Error(ErrorType.NotFound, "Quote not found."));
        //}

        var pagedProgressPayments = await _quoteQueries.GetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
            request.QuotePublicId,
            user.Id,
            q => q.ProgressPayments,
            request.Pagination,
            cancellationToken);

        return Result.Success(
            pagedProgressPayments,
            $"Successfully retrieved ProgressPayments for Quote Id {request.QuotePublicId}");
    }
}