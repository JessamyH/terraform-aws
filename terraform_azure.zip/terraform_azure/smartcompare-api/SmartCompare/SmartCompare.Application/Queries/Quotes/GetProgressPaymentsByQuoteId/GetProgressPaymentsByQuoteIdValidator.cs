using FluentValidation;
using SmartCompare.Application.Common.Paging;

namespace SmartCompare.Application.Queries.Quotes.GetProgressPaymentsByQuoteId;

public class GetProgressPaymentsByQuoteIdValidator : AbstractValidator<GetProgressPaymentsByQuoteIdQuery>
{
    private static readonly PaginationValidator _paginationValidator = new();
    public GetProgressPaymentsByQuoteIdValidator()
    {
        RuleFor(x => x.QuotePublicId)
            .NotEmpty()
            .WithMessage("QuotePublicId must be provided.");

        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty()
            .WithMessage("Auth0SubjectId cannot be empty.");

        RuleFor(x => x.Pagination)
            .SetValidator(_paginationValidator);
    }
}