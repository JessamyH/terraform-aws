﻿using MediatR;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Quotes.GetQuotesByProjectId
{
    public sealed class GetQuotesByProjectIdHandler : IRequestHandler<GetQuotesByProjectIdQuery, Result<PagedResult<QuoteSummaryDto>>>
    {
        private readonly IQuoteQueries _quoteQueries;

        public GetQuotesByProjectIdHandler(IQuoteQueries quoteQueries)
        {
            _quoteQueries = quoteQueries;
        }

        public async Task<Result<PagedResult<QuoteSummaryDto>>> Handle(
            GetQuotesByProjectIdQuery request,
            CancellationToken cancellationToken)
        {
            var pagedResult = await _quoteQueries.GetByProjectIdPagedAsync(
                request.projectPublicId,
                request.Auth0SubjectId,
                request.Pagination,
                cancellationToken);

            return Result.Success(pagedResult);
        }
    }
}
