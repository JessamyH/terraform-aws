﻿using FluentValidation;
using SmartCompare.Application.Common.Paging;

namespace SmartCompare.Application.Queries.Quotes.GetQuotesByProjectId;

public class GetQuotesByProjectIdValidator : AbstractValidator<GetQuotesByProjectIdQuery>
{
    private static readonly PaginationValidator _paginationValidator = new();
    public GetQuotesByProjectIdValidator()
    {
        RuleFor(x => x.projectPublicId)
            .NotEmpty()
            .WithMessage("ProjectPublicId must be provided.");

        RuleFor(x => x.Pagination)
            .SetValidator(_paginationValidator);
    }
}
