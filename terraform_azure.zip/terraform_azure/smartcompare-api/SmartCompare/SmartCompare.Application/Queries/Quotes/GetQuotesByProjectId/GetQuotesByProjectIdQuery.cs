﻿using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Quotes.GetQuotesByProjectId
{
    public sealed record GetQuotesByProjectIdQuery(
        Guid projectPublicId,
        string Auth0SubjectId,
        Pagination Pagination
        ) : IQuery<Result<PagedResult<QuoteSummaryDto>>>;
}
