using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Quotes.GetQuoteDetailById;

public sealed class GetQuoteDetailByIdHandler : IRequestHandler<GetQuoteDetailByIdQuery, Result<QuoteDto>>
{
    private readonly ILogger<GetQuoteDetailByIdHandler> _logger;
    private readonly IQuoteQueries _quoteQueries;
    private readonly IQuoteAuthorizationService _quoteAuthorizationService;

    public GetQuoteDetailByIdHandler(
        ILogger<GetQuoteDetailByIdHandler> logger,
        IQuoteQueries quoteQueries,
        IQuoteAuthorizationService quoteAuthorizationService)
    {
        _logger = logger;
        _quoteQueries = quoteQueries;
        _quoteAuthorizationService = quoteAuthorizationService;
    }

    public async Task<Result<QuoteDto>> Handle(GetQuoteDetailByIdQuery request, CancellationToken cancellationToken)
    {
        // Validate user has access to the quote
        var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
            request.QuotePublicId,
            request.Auth0SubjectId,
            cancellationToken);

        if (!authResult.Succeed)
        {
            return Result.Failure<QuoteDto>(authResult.Error!);
        }

        var user = authResult.Value!;

        var quote = await _quoteQueries.GetByIdAsync<QuoteDto>(request.QuotePublicId, user.Id, cancellationToken);

        if (quote == null)
        {
            _logger.LogWarning("Quote {QuotePublicId} not found", request.QuotePublicId);
            return Result.Failure<QuoteDto>(new Error(ErrorType.NotFound, "Quote not found."));
        }

        return Result.Success(quote, $"Successfully retrieved Quote with Id {request.QuotePublicId}");
    }
}