using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;
namespace SmartCompare.Application.Queries.Quotes.GetQuoteDetailById;
public sealed record GetQuoteDetailByIdQuery(Guid QuotePublicId, string Auth0SubjectId) : IQuery<Result<QuoteDto>>;