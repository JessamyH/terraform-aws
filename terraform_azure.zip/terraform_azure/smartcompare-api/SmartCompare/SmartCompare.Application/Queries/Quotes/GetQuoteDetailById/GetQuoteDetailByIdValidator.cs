using FluentValidation;

namespace SmartCompare.Application.Queries.Quotes.GetQuoteDetailById;

public class GetQuoteDetailByIdValidator : AbstractValidator<GetQuoteDetailByIdQuery>
{
    public GetQuoteDetailByIdValidator()
    {
        RuleFor(x => x.QuotePublicId)
            .NotEmpty()
            .WithMessage("QuotePublicId must be provided.");

        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty()
            .WithMessage("Auth0SubjectId must be provided.");
    }
}
