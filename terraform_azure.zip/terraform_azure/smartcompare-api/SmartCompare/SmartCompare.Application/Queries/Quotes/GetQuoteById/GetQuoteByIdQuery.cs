using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Quotes.GetQuoteById;

public sealed record GetQuoteByIdQuery(Guid QuotePublicId, string Auth0SubjectId) : IQuery<Result<QuoteSummaryDto>>;
