using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Quotes.GetQuoteById;

public sealed class GetQuoteByIdHandler : IRequestHandler<GetQuoteByIdQuery, Result<QuoteSummaryDto>>
{
    private readonly ILogger<GetQuoteByIdHandler> _logger;
    private readonly IQuoteQueries _quoteQueries;
    private readonly IUserQueries _userQueries;

    public GetQuoteByIdHandler(
        ILogger<GetQuoteByIdHandler> logger,
        IQuoteQueries quoteQueries,
        IUserQueries userQueries)
    {
        _logger = logger;
        _quoteQueries = quoteQueries;
        _userQueries = userQueries;
    }

    public async Task<Result<QuoteSummaryDto>> Handle(GetQuoteByIdQuery request, CancellationToken cancellationToken)
    {
        var user = await _userQueries.GetByAuth0SubjectIdAsync(request.Auth0SubjectId, cancellationToken);
        if (user == null)
        {
            _logger.LogWarning("User not found: Auth0SubjectId {Auth0SubjectId}", request.Auth0SubjectId);
            return Result.Failure<QuoteSummaryDto>(new Error(ErrorType.Unauthorized, "User not found."));
        }

        var quote = await _quoteQueries.GetByIdAsync<QuoteSummaryDto>(request.QuotePublicId, user.Id, cancellationToken);

        if (quote == null)
        {
            _logger.LogWarning("Quote {QuotePublicId} not found", request.QuotePublicId);
            return Result.Failure<QuoteSummaryDto>(new Error(ErrorType.NotFound, "Quote not found."));
        }

        return Result.Success(quote, $"Successfully retrieved Quote with Id {request.QuotePublicId}");
    }
}
