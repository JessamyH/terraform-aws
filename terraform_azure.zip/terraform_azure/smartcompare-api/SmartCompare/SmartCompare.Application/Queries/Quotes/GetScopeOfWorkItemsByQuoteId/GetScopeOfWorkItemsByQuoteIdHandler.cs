﻿using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Queries.Quotes.GetScopeOfWorkByQuoteId
{
    public sealed class GetScopeOfWorkItemsByQuoteIdHandler : IRequestHandler<GetScopeOfWorkItemsByQuoteIdQuery, Result<PagedResult<ScopeOfWorkDto>>>
    {
        private readonly ILogger<GetScopeOfWorkItemsByQuoteIdHandler> _logger;
        private readonly IUserQueries _userQueries;
        private readonly IQuoteQueries _quoteQueries;

        public GetScopeOfWorkItemsByQuoteIdHandler(
            ILogger<GetScopeOfWorkItemsByQuoteIdHandler> logger,
            IUserQueries userQueries,
            IQuoteQueries quoteQueries)
        {
            _logger = logger;
            _userQueries = userQueries;
            _quoteQueries = quoteQueries;
        }

        public async Task<Result<PagedResult<ScopeOfWorkDto>>> Handle(
            GetScopeOfWorkItemsByQuoteIdQuery request, 
            CancellationToken cancellationToken)
        {
            var user = await _userQueries.GetByAuth0SubjectIdAsync(request.Auth0SubjectId);
            if (user == null)
            {
                _logger.LogWarning("User not found: Auth0SubjectId {Auth0SubjectId}", request.Auth0SubjectId);
                return Result.Failure<PagedResult<ScopeOfWorkDto>>
                    (new Error(ErrorType.Unauthorized, "User not found."));
            }

            var pagedScopeOfWorkItems = await _quoteQueries.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                request.QuotePublicId,
                user.Id,
                q => q.ScopeOfWorks,
                request.Pagination,
                cancellationToken);

            return Result.Success(
                pagedScopeOfWorkItems, 
                $"Successfully retrieved ScopeOfWork items for Quote Id {request.QuotePublicId}");
        }
    }
}
