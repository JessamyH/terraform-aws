﻿using FluentValidation;
using SmartCompare.Application.Common.Paging;

namespace SmartCompare.Application.Queries.Quotes.GetScopeOfWorkByQuoteId
{
    public class GetScopeOfWorkitemsByQuoteIdValidator : AbstractValidator<GetScopeOfWorkItemsByQuoteIdQuery>
    {
        private readonly static PaginationValidator _paginationValidator = new();
        public GetScopeOfWorkitemsByQuoteIdValidator() {
            RuleFor(x => x.QuotePublicId)
                .NotEmpty()
                .WithMessage("QuotePublicId must be provided.");

            RuleFor(x => x.Pagination)
                .SetValidator(_paginationValidator);
        }
    }
}
