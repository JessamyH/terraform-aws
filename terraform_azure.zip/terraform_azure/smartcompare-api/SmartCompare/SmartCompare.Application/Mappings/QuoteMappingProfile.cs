using AutoMapper;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Entities.QuoteAggregate;

namespace SmartCompare.Application.Mappings;

public class QuoteMappingProfile : Profile
{
    public QuoteMappingProfile()
    {
        // Quote entity mappings
        CreateMap<Quote, QuoteDto>()
            .ForMember(dest => dest.ABN, opt => opt.MapFrom(src => src.ABN.Value))
            .ForMember(dest => dest.ProjectName, opt => opt.MapFrom(src => src.Project.ProjectName));
        CreateMap<Quote, QuoteSummaryDto>()
            .ForMember(dest => dest.ABN, opt => opt.MapFrom(src => src.ABN.Value));
        CreateMap<ProgressPayment, ProgressPaymentDto>();
        CreateMap<ScopeOfWork, ScopeOfWorkDto>();
        CreateMap<Exclusion, ExclusionDto>();
        CreateMap<(Quote quote, Project project), QuoteSummaryDto>()
            .ForMember(dest => dest.QuotePublicId, opt => opt.MapFrom(src => src.quote.PublicId))
            .ForMember(dest => dest.ProjectPublicId, opt => opt.MapFrom(src => src.project.PublicId))
            .ForMember(dest => dest.IssuedDate, opt => opt.MapFrom(src => src.quote.IssuedDate))
            .ForMember(dest => dest.ValidDate, opt => opt.MapFrom(src => src.quote.ValidDate))
            .ForMember(dest => dest.ValidPeriod, opt => opt.MapFrom(src => src.quote.ValidPeriod))
            .ForMember(dest => dest.QuoteNumber, opt => opt.MapFrom(src => src.quote.QuoteNumber))
            .ForMember(dest => dest.IssuedBy, opt => opt.MapFrom(src => src.quote.IssuedBy))
            .ForMember(dest => dest.IssuedTo, opt => opt.MapFrom(src => src.quote.IssuedTo))
            .ForMember(dest => dest.Total, opt => opt.MapFrom(src => src.quote.Total))
            .ForMember(dest => dest.SubTotal, opt => opt.MapFrom(src => src.quote.SubTotal))
            .ForMember(dest => dest.GST, opt => opt.MapFrom(src => src.quote.GST))
            .ForMember(dest => dest.ABN, opt => opt.MapFrom(src => src.quote.ABN.Value))
            .ForMember(dest => dest.LicenseNumber, opt => opt.MapFrom(src => src.quote.LicenseNumber))
            .ForMember(dest => dest.ContactName, opt => opt.MapFrom(src => src.quote.ContactName))
            .ForMember(dest => dest.ContactEmail, opt => opt.MapFrom(src => src.quote.ContactEmail))
            .ForMember(dest => dest.ContactPhone, opt => opt.MapFrom(src => src.quote.ContactPhone))
            .ForMember(dest => dest.PDFUrl, opt => opt.MapFrom(src => src.quote.PDFUrl));


    }
}
