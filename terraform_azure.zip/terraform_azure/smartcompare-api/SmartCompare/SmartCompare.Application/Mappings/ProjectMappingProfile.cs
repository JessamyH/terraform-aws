using AutoMapper;
using SmartCompare.Application.DTOs;
using SmartCompare.Domain.Entities.ProjectAggregate;
using static SmartCompare.Application.DTOs.ProjectSummaryDTOs;

namespace SmartCompare.Application.Mappings
{
    /// <summary>
    /// AutoMapper configuration profile for Project aggregate mappings
    /// </summary>
    public class ProjectMappingProfile : Profile
    {
        public ProjectMappingProfile()
        {
            // Project entity mappings
            CreateMap<Project, ProjectSummaryDto>()
                .ForMember(dest => dest.SubcontractorType,
                          opt => opt.MapFrom(src => src.SubcontractorType.Type))
                .ForMember(dest => dest.Status,
                          opt => opt.MapFrom(src => src.Status.ToString()));
            
            CreateMap<Project, ProjectDto>();
        }
    }
}