﻿using MediatR;
using Microsoft.Extensions.Logging;
using System.Diagnostics;



namespace SmartCompare.Application.Behaviors
{
    public class LoggingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    {
        private readonly ILogger<LoggingBehavior<TRequest, TResponse>> _logger;
        public LoggingBehavior(ILogger<LoggingBehavior<TRequest, TResponse>> logger)
        {
            _logger = logger;
        }


        /// <summary>
        /// Handles the specified request by invoking the next delegate in the pipeline and logging the execution details.
        /// </summary>
        /// <remarks>This method logs the start and end of the request handling process, including the
        /// elapsed time.  If an exception occurs during processing, it logs the error along with the elapsed time
        /// before rethrowing the exception.</remarks>
        /// <param name="request">The request object to be processed.</param>
        /// <param name="next">Call the "pointer" to the next Pipeline or the final Handler.</param>
        /// <param name="cancellationToken">A token to monitor for cancellation requests.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the response from the next
        /// handler in the pipeline.</returns>
        public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
        {
            var requestName = typeof(TRequest).Name;
            var stopwatch = Stopwatch.StartNew();

            _logger.LogInformation("Handling {RequestName}", requestName);

            try
            {
                var response = await next();
                stopwatch.Stop();
                _logger.LogInformation("Handled {RequestName} in {ElapsedMilliseconds}ms", requestName, stopwatch.ElapsedMilliseconds);

                return response;
            }
            catch(Exception ex)
            {
                stopwatch.Stop();
                _logger.LogError(ex, "Error handling {RequestName} after {ElapsedMilliseconds}ms", requestName, stopwatch.ElapsedMilliseconds);
                throw;
            }
        }
    }
}
