# 1. CreateProductCommand.cs
`using SmartCompare.Application.Interfaces;

namespace SmartCompare.Application.Commands
{
    public record CreateProductCommand(
        string Name, 
        decimal Price, 
        string? Description
    ) : ICommand<int>; // Inheriting from ICommand<int>
}`

ICommand<int> inherit from IRequest<int> - MediatR will automatically recognize and apply all Pipeline Behaviors.

# 2. CreateProductCommandValidator.cs
`   /// <summary>
    /// Validator for CreateProductCommand
    /// </summary>
    public class CreateProductCommandValidator : AbstractValidator<CreateProductCommand>
    {
        public CreateProductCommandValidator()
        {
            RuleFor(x => x.Name)
                .NotEmpty()
                .WithMessage("not empty")
                .MaximumLength(100);

            RuleFor(x => x.Price)
                .GreaterThan(0)
                .WithMessage("larger than 0");

            RuleFor(x => x.Description)
                .MaximumLength(500)
                .WithMessage("no more than 500")
                .When(x => !string.IsNullOrEmpty(x.Description)); // only valid when it has value
        }
    }`

Inheriting from AbstractValidator<CreateProductCommand> - ValidationBehavior will automatically discover and execute it.
If valid failed will throw FluentValidation.ValidationException
No need to manually call the verification logic
FluentValidation integration need to register in DependencyInjection.cs

1. The ValidationBehavior detected the registration of IValidator<CreateProductCommand>.
2. Automatically execute all verification rules.
3. If it fails: Throw a ValidationException to prevent the Handler from executing.
4. If successful: Continue executing the Handler.

#  3. CreateProductCommandHandler.cs
`    public class CreateProductCommandHandler : IRequestHandler<CreateProductCommand, int>
    {
        private readonly SmartCompareDbContext _context;

        public CreateProductCommandHandler(SmartCompareDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Handles the CreateProductCommand to create a new product
        /// </summary>
        /// <param name="request">The command containing product details</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>The ID of the created product</returns>
        public async Task<int> Handle(CreateProductCommand request, CancellationToken cancellationToken)
        {
            var product = new Product
            {
                Name = request.Name,
                Price = request.Price,
                Description = request.Description,
                CreatedAt = DateTime.UtcNow
            };

            _context.Products.Add(product);
            
            await _context.SaveChangesAsync(cancellationToken);

            return product.Id;
        }
    }`

Implementing IRequestHandler<CreateProductCommand, int> - MediatR automatic recognition
•	No need to manually call _unitOfWork.BeginTransactionAsync(), _logger.LogInformation() and validator

# TransactionBehavior Automated Workflow:
1. The TransactionBehavior automatically calls _unitOfWork.BeginTransactionAsync().
2. Execute Handler business logic
3. Success: TransactionBehavior automatically called _unitOfWork.CommitTransactionAsync()
4. Failure: TransactionBehavior automatically calls _unitOfWork.RollbackTransactionAsync()

# LoggingBehavior Automated Workflow:
1. LoggingBehavior record: "Handling CreateProductCommand"
2. Execute ValidationBehavior → TransactionBehavior → Handler
3. LoggingBehavior record: "Handled CreateProductCommand in 125ms"

# Using (.Send)
`using MediatR;
using Microsoft.AspNetCore.Mvc;
using SmartCompare.Application.Commands;

namespace SmartCompare.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ProductsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Create a new product
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> CreateProduct([FromBody] CreateProductCommand command)
        {
            // call .Send, and all Behaviors will execute automatically.
            var productId = await _mediator.Send(command);
            
            return CreatedAtAction(
                nameof(GetProduct), 
                new { id = productId }, 
                new { id = productId });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct(int id)
        {
            return Ok();
        }
    }
}`

The MediatR called by Send(command) finds the corresponding Handler.
Pipeline Behaviors execute automatically in the order of registration. （LoggerBehavior，ValidatorBehavior，TransactionBehavior）
The rollback mechanism depends entirely on whether the Handle throws an exception.
There is no need to manually handle transaction rollback, logging, and validation in the controller.


# For example, the database save failed.
1. LoggingBehavior: "Handling CreateProductCommand"
2. ValidationBehavior: Pass
3. TransactionBehavior: Start business
4. Handler: A DbUpdateException is thrown when SaveChangesAsync() is executed.
3. TransactionBehavior: 
    1.catch exception
    2.call _unitOfWork.RollbackTransactionAsync() 
    3.re-throw exception
1. LoggingBehavior: "Error handling CreateProductCommand after 85ms"


# Query

The Query does not execute TransactionBehavior; the rest of the execution logic is the same.

`using SmartCompare.Application.Interfaces;

namespace SmartCompare.Application.Queries
{
    public record GetProductQuery(int Id) 
        : IQuery<ProductDto>; // inheriting IQuery，Do not execute rollback
}`