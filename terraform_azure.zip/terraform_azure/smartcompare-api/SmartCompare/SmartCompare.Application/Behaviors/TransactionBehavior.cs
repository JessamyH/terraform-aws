﻿using MediatR;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.SharedKernel.Results;


namespace SmartCompare.Application.Behaviors
{
    public class TransactionBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
        where TRequest : ICommand<TResponse>
    {
        private readonly IUnitOfWork _unitOfWork;
        public TransactionBehavior(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// Handles the execution of a request within a transactional context.
        /// </summary>
        /// <param name="request">The request to be processed.</param>
        /// <param name="next"> next() calls the actual Handler
        /// If any exception is thrown inside the Handler, the try block will be interrupted.
        /// The `catch` block executes `_unitOfWork.RollbackTransactionAsync()` to perform a database rollback.
        /// The exception is then re-thrown to the upper layer (Controller or caller).
        /// </param>
        /// <param name="cancellationToken">A token to monitor for cancellation requests.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the response returned by the
        /// next handler in the pipeline.</returns>
        public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
        {
            if (request is not ICommand<TResponse> || request is IManagesOwnTransaction)
            {
                return await next();
            }

            return await _unitOfWork.ExecuteResilientAsync<TResponse>(async innerCt =>
            {
                await _unitOfWork.BeginTransactionAsync();
                try
                {
                    var response = await next();

                    if (response is not Result r)
                    {
                        await _unitOfWork.RollbackTransactionAsync();
                        throw new InvalidOperationException(
                            $"Handler must return Result/Result<T>. Found: {typeof(TResponse).FullName} for {typeof(TRequest).Name}");
                    }

                    if (r.Succeed)
                    {
                        await _unitOfWork.SaveChangesAsync(innerCt);
                        await _unitOfWork.CommitTransactionAsync();
                    }
                    else
                    {
                        await _unitOfWork.RollbackTransactionAsync();
                    }

                    return response;
                }
                catch
                {
                    await _unitOfWork.RollbackTransactionAsync();
                    throw;
                }
            }, cancellationToken);
        }
    }
}
