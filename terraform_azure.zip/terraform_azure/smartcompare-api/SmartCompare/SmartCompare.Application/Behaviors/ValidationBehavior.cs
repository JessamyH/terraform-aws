﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using SharedKernel.Errors;
using SmartCompare.SharedKernel.Results;
using SmartCompare.Application.Interfaces;

namespace SmartCompare.Application.Behaviors
{
    public class ValidationBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse> where TRequest : notnull
    {
        private readonly IEnumerable<IValidator<TRequest>> _validators;
        public ValidationBehavior(IEnumerable<IValidator<TRequest>> validators)
        {
            _validators = validators;
        }

        /// <summary>
        /// Processes the specified request by validating it using the configured validators and then invoking the next
        /// handler in the pipeline.
        /// </summary>
        /// <remarks>If any validators are configured, the request is validated before invoking the next
        /// handler. If validation fails, a <see cref="FluentValidation.ValidationException"/> is thrown containing the validation
        /// errors.</remarks>
        /// <param name="request">The request to be processed.</param>
        /// <param name="next">Call the "pointer" to the next Pipeline or the final Handler.</param>
        /// <param name="cancellationToken">A token to monitor for cancellation requests.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the response produced by the
        /// next handler in the pipeline.</returns>
        /// <exception cref="FluentValidation.ValidationException">Thrown if one or more validation failures occur when processing the request.</exception>
        public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
        {
            bool isCommand = request is ICommand || request is ICommand<TResponse>;
            bool isQuery = request is IQuery<TResponse>;

            if (!_validators.Any() || (!isCommand && !isQuery))
            {
                return await next();
            }

            var context = new ValidationContext<TRequest>(request);
            var failures = new List<ValidationFailure>();

            foreach (var validator in _validators)
            {
                var result = await validator.ValidateAsync(context, cancellationToken);
                if (!result.IsValid)
                {
                    failures.AddRange(result.Errors);
                }
            }

            if (failures.Count == 0)
            {
                return await next();
            }

            var message = string.Join(" | ",
                failures.GroupBy(e => e.PropertyName)
                        .Select(g => $"{g.Key}: {string.Join(", ", g.Select(x => x.ErrorMessage))}"));

            var error = new Error(ErrorType.Validation, message);

            if (typeof(TResponse) == typeof(Result))
            {
                object boxed = Result.Failure(error);
                return (TResponse)boxed;
            }

            if (typeof(TResponse).IsGenericType && typeof(TResponse).GetGenericTypeDefinition() == typeof(Result<>))
            {
                var method = typeof(Result).GetMethod(nameof(Result.Failure), 1, new[] { typeof(Error) })!;
                var generic = method.MakeGenericMethod(typeof(TResponse).GetGenericArguments()[0]);
                object boxed = generic.Invoke(null, new object[] { error })!;
                return (TResponse)boxed;
            }

            throw new InvalidOperationException(
                $"ValidationBehavior requires TResponse to be Result or Result<T>. Found: {typeof(TResponse).FullName}.");
        }
    }
}
