using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Payments.HandleStripeWebhookCommand;

public sealed record HandleStripeWebhookCommand(
    string Json,
    string SignatureHeader) : ICommand<Result>, IManagesOwnTransaction;
