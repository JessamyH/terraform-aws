using MediatR;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Payments.HandleStripeWebhookCommand;

public sealed class HandleStripeWebhookHandler
    : IRequestHandler<HandleStripeWebhookCommand, Result>
{
    private readonly IStripeWebhookService _stripeWebhookService;

    public HandleStripeWebhookHandler(IStripeWebhookService stripeWebhookService)
    {
        _stripeWebhookService = stripeWebhookService;
    }

    public async Task<Result> Handle(HandleStripeWebhookCommand request, CancellationToken cancellationToken)
    {
        return await _stripeWebhookService.HandleWebhookAsync(
            request.Json,
            request.SignatureHeader,
            cancellationToken);
    }
}
