﻿using MediatR;
using SmartCompare.Application.DTOs.Payment;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Payments.CreateCheckoutSession;

public sealed class CreateCheckoutSessionCommandHandler
    : IRequestHandler<CreateCheckoutSessionCommand,
    Result<CheckoutSessionResponseDto>>
{
    private readonly ICheckoutSessionService _checkoutSessionService;

    public CreateCheckoutSessionCommandHandler(ICheckoutSessionService checkoutSessionService)
    {
        _checkoutSessionService = checkoutSessionService;
    }
    
    public async Task<Result<CheckoutSessionResponseDto>> Handle(
        CreateCheckoutSessionCommand request,
        CancellationToken cancellationToken)
    {
        return await _checkoutSessionService.CreateCheckoutSessionAsync(
            request.Auth0SubjectId,
            request.Tier,
            request.Duration,
            cancellationToken);
    }
}