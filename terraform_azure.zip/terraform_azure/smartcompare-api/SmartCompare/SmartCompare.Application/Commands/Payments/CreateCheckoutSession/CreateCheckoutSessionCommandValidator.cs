﻿using FluentValidation;
using SmartCompare.Domain.Enums;

namespace SmartCompare.Application.Commands.Payments.CreateCheckoutSession;

public class CreateCheckoutSessionCommandValidator
    : AbstractValidator<CreateCheckoutSessionCommand>
{
    public CreateCheckoutSessionCommandValidator()
    {
        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty()
            .WithMessage("Auth0 Subject ID is required.");

        RuleFor(x => x.Tier)
            .Must(tier => tier != SubscriptionTier.Free)
            .WithMessage("Free tier does not require payment.");
        
        RuleFor(x => x.Duration)
            .Must(duration => duration != SubscriptionDuration.None)
            .WithMessage("Subscription Duration is required.");
    }
}