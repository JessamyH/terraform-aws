﻿using SmartCompare.Application.DTOs.Payment;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Enums;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Payments.CreateCheckoutSession;

/// <summary>
/// Command to create a Stripe Checkout Session for a subscription payment.
/// </summary>
public record CreateCheckoutSessionCommand(
    string Auth0SubjectId,
    SubscriptionTier Tier,
    SubscriptionDuration Duration) : ICommand<Result<CheckoutSessionResponseDto>>;