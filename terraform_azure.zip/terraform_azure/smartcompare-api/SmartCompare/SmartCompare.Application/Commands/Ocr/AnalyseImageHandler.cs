using MediatR;
using Microsoft.Extensions.Logging;
using SmartCompare.Application.DTOs.Ocr;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Ocr;

public sealed class AnalyseImageHandler : IRequestHandler<AnalyseImageCommand, Result<OcrPrefillDto>>
{
    private readonly IAiOcrService _aiOcrService;
    private readonly ILogger<AnalyseImageHandler> _logger;

    public AnalyseImageHandler(IAiOcrService aiOcrService, ILogger<AnalyseImageHandler> logger)
    {
        _aiOcrService = aiOcrService;
        _logger = logger;
    }

    public async Task<Result<OcrPrefillDto>> Handle(
        AnalyseImageCommand request,
        CancellationToken cancellationToken)
    {
        _logger.LogInformation("Forwarding image ({MimeType}, {Bytes} bytes) to AI service",
            request.MimeType, request.ImageBytes.Length);

        return await _aiOcrService.AnalyseImageAsync(
            request.ImageBytes,
            request.MimeType,
            cancellationToken);
    }
}
