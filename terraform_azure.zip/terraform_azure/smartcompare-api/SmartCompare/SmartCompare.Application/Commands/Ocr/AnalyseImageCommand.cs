using MediatR;
using SmartCompare.Application.DTOs.Ocr;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Ocr;

public record AnalyseImageCommand(byte[] ImageBytes, string MimeType)
    : IRequest<Result<OcrPrefillDto>>;
