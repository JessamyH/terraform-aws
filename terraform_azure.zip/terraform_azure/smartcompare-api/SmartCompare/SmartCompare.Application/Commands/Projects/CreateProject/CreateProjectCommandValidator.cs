using FluentValidation;
namespace SmartCompare.Application.Commands.Projects.CreateProject;

public class CreateProjectCommandValidator : AbstractValidator<CreateProjectCommand>
{
    public CreateProjectCommandValidator()
    {
        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty()
            .WithMessage("Auth0 subject ID is required.")
            .MaximumLength(255)
            .WithMessage("Auth0 subject ID must be between 1 and 255 characters.");

        RuleFor(x => x.ProjectName)
            .NotEmpty()
            .WithMessage("Project name is required.")
            .MaximumLength(200)
            .WithMessage("Project name must be between 1 and 200 characters.");

        RuleFor(x => x.Address)
            .NotEmpty()
            .WithMessage("Address is required.")
            .MaximumLength(500)
            .WithMessage("Address must be between 1 and 500 characters.");

        RuleFor(x => x.HouseType)
            .IsInEnum()
            .WithMessage("House type must be a valid HouseType value.");

        RuleFor(x => x.HouseSizeSqm)
            .GreaterThan(0)
            .WithMessage("House size must be greater than 0.");

        RuleFor(x => x.Bedrooms)
            .GreaterThanOrEqualTo(0)
            .WithMessage("Bedrooms must be 0 or greater.");

        RuleFor(x => x.Bathrooms)
            .GreaterThanOrEqualTo(0)
            .WithMessage("Bathrooms must be 0 or greater.");

        RuleFor(x => x.SubcontractorTypeId)
            .GreaterThan(0)
            .WithMessage("Subcontractor type ID must be a positive integer.");
    }
}
