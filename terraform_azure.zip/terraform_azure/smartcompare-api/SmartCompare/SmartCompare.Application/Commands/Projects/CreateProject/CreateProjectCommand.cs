using SmartCompare.Application.DTOs;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Enums;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Projects.CreateProject;

public record CreateProjectCommand(
    string Auth0SubjectId,
    string ProjectName,
    string Address,
    HouseType HouseType,
    decimal HouseSizeSqm,
    int Bedrooms,
    int Bathrooms,
    int SubcontractorTypeId
) : ICommand<Result<ProjectDto>>;
