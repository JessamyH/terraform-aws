using AutoMapper;
using MediatR;
using SmartCompare.Application.DTOs;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Enums;
using SmartCompare.Domain.Interfaces;
using SmartCompare.Domain.Exceptions;
using SmartCompare.SharedKernel.Results;
using SmartCompare.Application.Interfaces;
using SharedKernel.Errors;

namespace SmartCompare.Application.Commands.Projects.CreateProject;

public class CreateProjectCommandHandler : IRequestHandler<CreateProjectCommand, Result<ProjectDto>>
{
    private readonly IProjectRepository _projectRepository;
    private readonly IUserQueries _userQueries;
    private readonly IMapper _mapper;

    public CreateProjectCommandHandler(
        IProjectRepository projectRepository,
        IUserQueries userQueries,
        IMapper mapper)
    {
        _projectRepository = projectRepository;
        _userQueries = userQueries;
        _mapper = mapper;
    }
        
    public async Task<Result<ProjectDto>> Handle(CreateProjectCommand request, CancellationToken cancellationToken)
    {
        // Resolve userId from Auth0SubjectId
        var user = await _userQueries.GetByAuth0SubjectIdAsync(request.Auth0SubjectId, cancellationToken);

        if (user is null)
        {
            return Result.Failure<ProjectDto>(new Error(ErrorType.Unauthorized,  $"No user found with Auth0SubjectId '{request.Auth0SubjectId}'"));
        }
        
        var project = Project.Create(
            userId: user.Id,
            projectName: request.ProjectName,
            address: request.Address,
            houseType: request.HouseType,
            houseSizeSqm: request.HouseSizeSqm,
            bedrooms: request.Bedrooms,
            bathrooms: request.Bathrooms,
            subcontractorTypeId: request.SubcontractorTypeId,
            status: ProjectStatus.InProgress);
         
        await _projectRepository.AddAsync(project, cancellationToken);

        var projectDto = _mapper.Map<ProjectDto>(project);

        return Result.Success(projectDto);
    }
}