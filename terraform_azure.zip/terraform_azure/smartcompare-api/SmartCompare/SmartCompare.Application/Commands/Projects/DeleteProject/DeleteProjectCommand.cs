﻿using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Projects.DeleteProject;
public sealed record DeleteProjectCommand(Guid ProjectId, string Auth0SubjectId) : ICommand<Result>;