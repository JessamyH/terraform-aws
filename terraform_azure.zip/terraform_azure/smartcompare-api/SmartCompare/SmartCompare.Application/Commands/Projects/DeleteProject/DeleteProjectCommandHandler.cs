﻿using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Projects.DeleteProject
{
    public sealed class DeleteProjectCommandHandler : IRequestHandler<DeleteProjectCommand, Result>
    {
        private readonly IProjectRepository _projectRepository;
        private readonly ILogger<DeleteProjectCommandHandler> _logger;
        private readonly IProjectAuthorizationService _projectAuthorizationService;

        public DeleteProjectCommandHandler(
            IProjectRepository projectRepository,
            ILogger<DeleteProjectCommandHandler> logger,
            IProjectAuthorizationService projectAuthorizationService)
        {
            _projectRepository = projectRepository;
            _logger = logger;
            _projectAuthorizationService = projectAuthorizationService;
        }

        /// <summary>
        /// Handle the DeleteProjectCommand to soft delete a project after validating ownership.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<Result> Handle(DeleteProjectCommand request, CancellationToken cancellationToken)
        {
            var authorizationResult = await _projectAuthorizationService.ValidateProjectOwnershipAsync(
                request.ProjectId,
                request.Auth0SubjectId,
                cancellationToken);

            if (!authorizationResult.Succeed)
            {
                return Result.Failure(authorizationResult.Error!);
            }

            var project = await _projectRepository.GetProjectByPublicIdAsync(request.ProjectId, cancellationToken);

            if (project == null)
            {
                _logger.LogWarning(
                    "Project {ProjectId} not found after authorization check - possible race condition",
                    request.ProjectId);

                return Result.Failure(new Error(
                    ErrorType.NotFound,
                    $"Project with ID {request.ProjectId} not found."));
            }

            var isSoftDeletedSuccessful = project.SoftDelete();
            if (!isSoftDeletedSuccessful)
            {
                _logger.LogError(
                    "Failed to soft delete Project {ProjectId}",
                    request.ProjectId);
                return Result.Failure(new Error(
                    ErrorType.Unexpected,
                    $"Failed to delete Project with ID {request.ProjectId}."));
            }

            return Result.Success($"Project with Id {request.ProjectId} deleted successfully.");
        }

    }
}
