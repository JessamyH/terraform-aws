using SmartCompare.Application.DTOs;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Projects.UpdateProject;

public record UpdateProjectCommand : ICommand<Result<ProjectDto>>
{
    public Guid ProjectId { get; init; }
    public required string Auth0SubjectId { get; init; }
    public required UpdateProjectDto UpdateDto { get; init; }
}
