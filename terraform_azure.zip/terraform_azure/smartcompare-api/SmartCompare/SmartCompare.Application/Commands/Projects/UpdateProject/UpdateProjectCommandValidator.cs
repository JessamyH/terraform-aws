using System.Data;
using FluentValidation;

namespace SmartCompare.Application.Commands.Projects.UpdateProject;

public class UpdateProjectCommandValidator : AbstractValidator<UpdateProjectCommand>
{
    public UpdateProjectCommandValidator()
    {
        RuleFor(x => x.ProjectId)
            .NotEqual(Guid.Empty)
            .WithMessage("ProjectId must be a valid GUID.");

        RuleFor(x => x.UpdateDto)
            .NotNull()
            .WithMessage("UpdateDto is required.");

        When(x => x.UpdateDto != null, () =>
        {
            RuleFor(x => x.UpdateDto.ProjectName)
                .NotEmpty()
                .WithMessage("ProjectName is required.")
                .MaximumLength(200)
                .WithMessage("ProjectName must not exceed 200 characters.");

            RuleFor(x => x.UpdateDto.Address)
                .NotEmpty()
                .WithMessage("Address is required.")
                .MaximumLength(500)
                .WithMessage("Address must not exceed 500 characters.");

            RuleFor(x => x.UpdateDto.HouseType)
                .IsInEnum()
                .WithMessage("House type must be a valid HouseType value.");

            RuleFor(x => x.UpdateDto.HouseSizeSqm)
                .GreaterThan(0)
                .WithMessage("House size must be greater than 0.");

            RuleFor(x => x.UpdateDto.Bedrooms)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Bedrooms must be 0 or greater.");

            RuleFor(x => x.UpdateDto.Bathrooms)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Bathrooms must be 0 or greater.");

            RuleFor(x => x.UpdateDto.SubcontractorTypeId)
                .GreaterThan(0)
                .WithMessage("SubcontractorTypeId must be greater than 0.");

            RuleFor(x => x.UpdateDto.Status)
                .IsInEnum()
                .WithMessage("Status must be a valid ProjectStatus enum value.");
        });
    }
}
