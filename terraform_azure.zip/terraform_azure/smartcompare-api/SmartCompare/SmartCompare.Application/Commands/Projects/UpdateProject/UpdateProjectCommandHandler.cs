using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Projects.UpdateProject;

public sealed class UpdateProjectCommandHandler : IRequestHandler<UpdateProjectCommand, Result<ProjectDto>>
{
    private readonly IProjectAuthorizationService _authorizationService;
    private readonly IProjectRepository _projectRepository;
    private readonly IMapper _mapper;

    public UpdateProjectCommandHandler(
        IProjectAuthorizationService authorizationService,
        IProjectRepository projectRepository,
        IMapper mapper)
    {
        _authorizationService = authorizationService;
        _projectRepository = projectRepository;
        _mapper = mapper;
    }

    public async Task<Result<ProjectDto>> Handle(UpdateProjectCommand request, CancellationToken cancellationToken)
    {
        // Get the tracked entity for update
        var project = await _projectRepository.GetProjectByPublicIdAsync(request.ProjectId, cancellationToken);

        // Check if ProjectId exists
        if (project == null)
        {
            return Result.Failure<ProjectDto>(
                new Error(ErrorType.NotFound, $"Project with ID {request.ProjectId} was not found."));
        }

        // Verify Auth0SubjectId matches project owner
        var authResult = await _authorizationService.ValidateProjectOwnershipAsync(
            project.PublicId,
            request.Auth0SubjectId,
            cancellationToken);

        if (!authResult.Succeed)
        {
            return Result.Failure<ProjectDto>(authResult.Error!);
        }

        // Update changes to database
        project.Update(
            request.UpdateDto.ProjectName,
            request.UpdateDto.Address,
            request.UpdateDto.HouseType,
            request.UpdateDto.HouseSizeSqm,
            request.UpdateDto.Bedrooms,
            request.UpdateDto.Bathrooms,
            request.UpdateDto.SubcontractorTypeId,
            request.UpdateDto.Status
            );

        // Map to DTO and return
        var projectDto = _mapper.Map<ProjectDto>(project);
        return Result.Success(projectDto);
    }
}
