﻿using FluentValidation;

namespace SmartCompare.Application.Commands.Users.SyncUser
{
    public class SyncUserCommandValidator : AbstractValidator<SyncUserCommand>
    {
        public SyncUserCommandValidator()
        {
            RuleFor(x => x.Auth0SubjectId)
                .NotEmpty()
                .WithMessage("Auth0SubjectId is required.");

            RuleFor(x => x.UserName)
                .NotEmpty()
                .WithMessage("UserName is required.");

            RuleFor(x => x.Email)
                .NotEmpty()
                .WithMessage("Email is required.")
                .EmailAddress()
                .WithMessage("Must be a valid email address.");
        }
    }
}
