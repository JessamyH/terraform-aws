﻿using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Users.SyncUser
{
    /// <summary>
    /// Command to synchronize user from Auth0 to local database.
    /// Creates new user with free subscription if not exists, otherwise update LastLoginAt
    /// Note: Implements IManagesOwnTransaction to bypass TransactionBehavior due to:
    /// - Race condition handling requires rollback + retry logic
    /// - Partial failure scenario (last login update) should not rollback user creation
    /// </summary>
    public record SyncUserCommand(
        string Auth0SubjectId,
        string UserName,
        string Email): ICommand<Result>, IManagesOwnTransaction;
}
