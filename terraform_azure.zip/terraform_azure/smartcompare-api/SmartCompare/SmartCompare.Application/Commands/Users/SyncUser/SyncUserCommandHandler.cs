﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Exceptions;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Users.SyncUser
{
    public sealed class SyncUserCommandHandler : IRequestHandler<SyncUserCommand, Result>
    {
        private readonly IUserRepository _userRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<SyncUserCommandHandler> _logger;

        public SyncUserCommandHandler(
            IUserRepository userRepository,
            IRoleRepository roleRepository,
            IUnitOfWork unitOfWork,
            ILogger<SyncUserCommandHandler> logger)
        {
            _userRepository = userRepository;
            _roleRepository = roleRepository;
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public async Task<Result> Handle(SyncUserCommand request, CancellationToken cancellationToken)
        {
            var existingUser = await _userRepository.GetBySubjectIdAsync(
                request.Auth0SubjectId,
                cancellationToken);

            if (existingUser == null)
            {
                return await CreateNewUserAsync(request, cancellationToken);
            }

            var updated = await TryUpdateUserLastLoginAsync(existingUser, cancellationToken);

            if (!updated)
            {
                _logger.LogWarning("User logged in successfully but last login timestamp could not be updated. Auth0SubjectId: {Auth0SubjectId}",
                    existingUser.Auth0SubjectId);
            }

            return Result.Success();
        }

        private async Task<Result> CreateNewUserAsync(
            SyncUserCommand request,
            CancellationToken cancellationToken)
        {
            var userRole = await GetUserRoleAsync(cancellationToken);
            if (userRole is null)
            {
                return RoleNotFoundError();
            }

            try
            {
                return await _unitOfWork.ExecuteResilientAsync(async innerCt =>
                {
                    await _unitOfWork.BeginTransactionAsync();
                    try
                    {
                        var newUser = CreateUserWithDefaults(request);
                        await SaveNewUserAsync(newUser, request, innerCt);

                        await _unitOfWork.CommitTransactionAsync();
                        return Result.Success($"User with Auth0SubjectId {request.Auth0SubjectId} created.");
                    }
                    catch
                    {
                        await _unitOfWork.RollbackTransactionAsync();
                        throw;
                    }
                }, cancellationToken);
            }
            catch (DbUpdateException ex) when (IsUniqueConstraintViolation(ex))
            {
                return await HandleConcurrencyConflictAsync(request, ex, cancellationToken);
            }
            catch (Exception ex)
            {
                return HandleUserSyncError(request, ex);
            }
        }

        private async Task<Role?> GetUserRoleAsync(CancellationToken cancellationToken)
        {
            //TODO: Cache roles to avoid DB hit on every user creation
            return await _roleRepository.GetByIdAsync(Role.RoleIds.CompanyAdmin, cancellationToken);
        }

        private User CreateUserWithDefaults(SyncUserCommand request)
        {
            var newUser = User.Create(
                auth0SubjectId: request.Auth0SubjectId,
                userName: request.UserName,
                email: request.Email);

            newUser.AddRole(Role.RoleIds.CompanyAdmin);
            newUser.AddFreeSubscription();

            return newUser;
        }

        private async Task SaveNewUserAsync(
            User newUser,
            SyncUserCommand request,
            CancellationToken cancellationToken)
        {
            await _userRepository.AddAsync(newUser, cancellationToken);
            await _unitOfWork.SaveChangesAsync(cancellationToken);

            _logger.LogInformation(
                "New user created with free subscription. Auth0SubjectId: {Auth0SubjectId}, UserId: {UserId}, Email: {Email}",
                request.Auth0SubjectId,
                newUser.Id,
                request.Email);
        }

        private async Task<Result> HandleConcurrencyConflictAsync(
            SyncUserCommand request,
            DbUpdateException ex,
            CancellationToken cancellationToken)
        {
            // Race condition: Another concurrent request already created this user
            _logger.LogWarning(ex,
                "User creation failed due to uniqueness constraint violation (likely race condition). " +
                "Attempting to retrieve the existing user. Auth0SubjectId={Auth0SubjectId}",
                request.Auth0SubjectId);

            // Clear the change tracker to ensure we query fresh data from the database
            _unitOfWork.DbContext.ChangeTracker.Clear();

            // Retry: Fetch the user that was created by the concurrent request
            var concurrentlyCreatedUser = await _userRepository.GetBySubjectIdAsync(
                request.Auth0SubjectId,
                cancellationToken);

            // Unexpected: User still doesn't exist after uniqueness violation
            if (concurrentlyCreatedUser is null)
            {
                _logger.LogError(ex,
                    "Uniqueness constraint violation occurred but user still not found. Auth0SubjectId={SubjectId}",
                    request.Auth0SubjectId);

                return Result.Failure(new Error(
                    ErrorType.Conflict,
                    "User account creation failed: Concurrency error. Please try logging in again."));
            }

            // Update last login for the user that was created concurrently
            var updated = await TryUpdateUserLastLoginAsync(concurrentlyCreatedUser, cancellationToken);
            if (!updated)
            {
                _logger.LogWarning(
                    "User logged in successfully but last login timestamp could not be updated after concurrency conflict. Auth0SubjectId: {Auth0SubjectId}",
                    concurrentlyCreatedUser.Auth0SubjectId);
            }

            _logger.LogInformation(
                "Retrieved concurrently created user and updated login timestamp. Auth0SubjectId={SubjectId}, UserId={UserId}",
                request.Auth0SubjectId,
                concurrentlyCreatedUser.Id);

            return Result.Success($"User with Auth0SubjectId {request.Auth0SubjectId} synchronized.");
        }

        /// <summary>
        /// Attempts to update the user's last login timestamp.
        /// Returns false if the update fails, but does NOT throw exception.
        /// Login should succeed even if this operation fails
        /// </summary>
        /// <param name="user"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        private async Task<bool> TryUpdateUserLastLoginAsync(
            User user,
            CancellationToken cancellationToken)
        {
            try
            {
                user.UpdateLastLoginAt();
                await _unitOfWork.SaveChangesAsync(cancellationToken);

                _logger.LogInformation(
                    "User login timestamp updated. Auth0SubjectId: {Auth0SubjectId}, LastLoginAt:{LastLoginAt}.",
                    user.Auth0SubjectId,
                    user.LastLoginAt);

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex,
                    "Failed to update last login timestamp. Auth0SubjectId={SubjectId}",
                    user.Auth0SubjectId);

                return false;
                // Continue execution - login timestamp update failure should not block user login
            }
        }

        private Result RoleNotFoundError()
        {
            _logger.LogError(
                "Cannot create user: Role '{RoleId}' does not exist in database. Database may not be properly seeded.",
                Role.RoleIds.CompanyAdmin);

            return Result.Failure(new Error(
                ErrorType.Unexpected,
                "User account creation failed: System configuration error. Please contact support."));
        }

        private Result HandleUserSyncError(SyncUserCommand request, Exception ex)
        {
            _logger.LogError(ex,
                "Unexpected error occurred during user synchronization. Auth0SubjectId={SubjectId}",
                request.Auth0SubjectId);

            return Result.Failure(new Error(ErrorType.Unexpected,
                "User account synchronization failed due to an unexpected error. Please try again later."));
        }

        /// <summary>
        /// Checks if the DbUpdateException is caused by a unique constraint violation.
        /// Supports SQL Server.
        /// </summary>
        private static bool IsUniqueConstraintViolation(DbUpdateException ex)
        {
            var exceptionMessage = ex.InnerException?.Message ?? ex.Message;

            // SQL Server unique constraint violation error formats:
            // Error 2601: "Cannot insert duplicate key row in object..."
            // Error 2627: "Violation of UNIQUE KEY constraint..."
            if (exceptionMessage.Contains("UNIQUE KEY constraint", StringComparison.OrdinalIgnoreCase) ||
                exceptionMessage.Contains("duplicate key", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            return false;
        }
    }
}
