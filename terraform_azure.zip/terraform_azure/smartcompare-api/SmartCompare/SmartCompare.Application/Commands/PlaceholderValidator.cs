// Placeholder validator; replace ICommand with the concrete command type when it exists.
// Prefer SmartCompare.Application.Interfaces.ICommand over System.Windows.Input when wiring real rules.
using System;
using System.Windows.Input;
using FluentValidation;

namespace SmartCompare.Application.Validators;

public sealed class PlaceholderCommandValidator : AbstractValidator<ICommand>
{
    public PlaceholderCommandValidator()
    {
        // your rules
        // RuleFor(x => x.Name)
        //       .NotEmpty().WithMessage("Name is required.")
        //       .MaximumLength(100).WithMessage("Name cannot exceed 100 characters.");
    }
}
