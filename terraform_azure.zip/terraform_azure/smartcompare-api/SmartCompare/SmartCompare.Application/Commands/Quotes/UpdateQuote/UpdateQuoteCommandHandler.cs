using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.Domain.ValueObjects;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.UpdateQuote;

public sealed class UpdateQuoteCommandHandler : IRequestHandler<UpdateQuoteCommand, Result>
{
    private readonly ILogger<UpdateQuoteCommandHandler> _logger;
    private readonly IQuoteRepository _quoteRepository;
    private readonly IQuoteAuthorizationService _quoteAuthorizationService;
    private readonly IMapper _mapper;

    public UpdateQuoteCommandHandler(ILogger<UpdateQuoteCommandHandler> logger, IQuoteRepository quoteRepository, IQuoteAuthorizationService quoteAuthorizationService, IMapper mapper)
    {
        _logger = logger;
        _quoteRepository = quoteRepository;
        _mapper = mapper;
        _quoteAuthorizationService = quoteAuthorizationService;
    }

    public async Task<Result> Handle(UpdateQuoteCommand request, CancellationToken cancellationToken)
    {
        var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
            request.QuotePublicId,
            request.Auth0SubjectId,
            cancellationToken);

        if (!authResult.Succeed)
        {
            return Result.Failure<QuoteSummaryDto>(authResult.Error!);
        }
        var quote = await _quoteRepository.GetQuoteByIdAsync(request.QuotePublicId, cancellationToken);

        if (quote == null)
        {
            _logger.LogWarning("Quote {QuotePublicId} not found", request.QuotePublicId);
            return Result.Failure<UpdateQuoteDto>(new Error(ErrorType.NotFound, "Quote not found."));
        }

        ABN abn;
        try
        {
            abn = ABN.Create(request.UpdateQuoteDto.ABN);
        }
        catch (ArgumentException ex)
        {
            return Result.Failure(new Error(ErrorType.Validation, ex.Message));
        }

        quote.Update(
            request.UpdateQuoteDto.QuoteNumber,
            request.UpdateQuoteDto.IssuedBy,
            request.UpdateQuoteDto.IssuedTo,
            request.UpdateQuoteDto.SubTotal,
            request.UpdateQuoteDto.GST,
            request.UpdateQuoteDto.IssuedDate,
            request.UpdateQuoteDto.ValidPeriod,
            abn,
            request.UpdateQuoteDto.LicenseNumber,
            request.UpdateQuoteDto.ContactName,
            request.UpdateQuoteDto.ContactEmail,
            request.UpdateQuoteDto.ContactPhone,
            request.UpdateQuoteDto.PDFUrl
            );

        _logger.LogInformation(
            "Update Quote successfully. QuoteNumber: {QuoteNumber}",
            quote.QuoteNumber
           );

        var quoteSummaryDto = _mapper.Map<QuoteSummaryDto>(quote);
        return Result.Success(quoteSummaryDto);


    }
}