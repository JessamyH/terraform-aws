using FluentValidation;

namespace SmartCompare.Application.Commands.Quotes.UpdateQuote
{
    public class UpdateQuoteValidator : AbstractValidator<UpdateQuoteCommand>
    {
        public UpdateQuoteValidator()
        {
            RuleFor(x => x.QuotePublicId)
                .NotEqual(Guid.Empty)
                .WithMessage("PublicId must be a valid GUID.");

            RuleFor(x => x.UpdateQuoteDto)
                .NotNull()
                .WithMessage("UpdateQuoteDto is required.");

            When(x => x.UpdateQuoteDto != null, () =>
            {
                // ========== QuoteNumber ==========
                RuleFor(x => x.UpdateQuoteDto.QuoteNumber)
                    .NotEmpty()
                    .WithMessage("Quote number is required")
                    .WithErrorCode("QUOTE_NUMBER_REQUIRED")

                    .MaximumLength(200)
                    .WithMessage("Quote number cannot exceed 200 characters")
                    .WithErrorCode("QUOTE_NUMBER_TOO_LONG")

                    .Matches(@"^[a-zA-Z0-9\-_/.]+$")
                    .WithMessage("Quote number can only contain letters, numbers, and special characters (-, _, /, .)")
                    .WithErrorCode("QUOTE_NUMBER_INVALID_FORMAT");

                // ========== IssuedBy ==========
                RuleFor(x => x.UpdateQuoteDto.IssuedBy)
                    .NotEmpty()
                    .WithMessage("Issued by is required")
                    .WithErrorCode("ISSUED_BY_REQUIRED")

                    .MaximumLength(255)
                    .WithMessage("Issued by cannot exceed 255 characters")
                    .WithErrorCode("ISSUED_BY_TOO_LONG")

                    .MinimumLength(2)
                    .WithMessage("Issued by must be at least 2 characters")
                    .WithErrorCode("ISSUED_BY_TOO_SHORT");

                // ========== IssuedTo ==========
                RuleFor(x => x.UpdateQuoteDto.IssuedTo)
                    .NotEmpty()
                    .WithMessage("Issued to is required")
                    .WithErrorCode("ISSUED_TO_REQUIRED")

                    .MaximumLength(255)
                    .WithMessage("Issued to cannot exceed 255 characters")
                    .WithErrorCode("ISSUED_TO_TOO_LONG")

                    .MinimumLength(2)
                    .WithMessage("Issued to must be at least 2 characters")
                    .WithErrorCode("ISSUED_TO_TOO_SHORT");

                // ========== IssuedDate ==========
                RuleFor(x => x.UpdateQuoteDto.IssuedDate)
                    .NotEmpty()
                    .WithMessage("Issued date is required")
                    .WithErrorCode("ISSUED_DATE_REQUIRED")

                    .GreaterThanOrEqualTo(DateTime.UtcNow.AddYears(-10))
                    .WithMessage("Issued date cannot be more than 10 years in the past")
                    .WithErrorCode("ISSUED_DATE_TOO_OLD");

                // ========== ValidPeriod ==========
                RuleFor(x => x.UpdateQuoteDto.ValidPeriod)
                    .GreaterThan(0)
                    .WithMessage("Must be at least 1 day")
                    .WithErrorCode("VALID_PERIOD_TOO_SMALL")

                    .LessThanOrEqualTo(365)
                    .WithMessage("Must be at most 365 days")
                    .WithErrorCode("VALID_PERIOD_TOO_LARGE");

                // ========== SubTotal ==========
                RuleFor(x => x.UpdateQuoteDto.SubTotal)
                    .NotEmpty()
                    .WithMessage("Subtotal is required")
                    .WithErrorCode("SUBTOTAL_REQUIRED")

                    .GreaterThan(0)
                    .WithMessage("Subtotal must be greater than 0")
                    .WithErrorCode("SUBTOTAL_INVALID")

                    .LessThanOrEqualTo(decimal.MaxValue)
                    .WithMessage("Subtotal exceeds maximum allowed value")
                    .WithErrorCode("SUBTOTAL_TOO_LARGE")

                    .Must(x => x % 0.01m == 0)
                    .WithMessage("Subtotal can only have up to 2 decimal places")
                    .WithErrorCode("SUBTOTAL_DECIMAL_PLACES_INVALID");

                // ========== GST ==========
                RuleFor(x => x.UpdateQuoteDto.GST)
                    .GreaterThanOrEqualTo(0)
                    .WithMessage("GST cannot be negative")
                    .WithErrorCode("GST_NEGATIVE")

                    .LessThanOrEqualTo(decimal.MaxValue)
                    .WithMessage("GST exceeds maximum allowed value")
                    .WithErrorCode("GST_TOO_LARGE")

                    .Must(x => x % 0.01m == 0)
                    .WithMessage("GST can only have up to 2 decimal places")
                    .WithErrorCode("GST_DECIMAL_PLACES_INVALID");

                // ========== ABN ==========
                RuleFor(x => x.UpdateQuoteDto.ABN)
                    .NotEmpty()
                    .WithMessage("ABN is required")
                    .WithErrorCode("ABN_REQUIRED")

                    .Must(abn => new string(abn.Where(char.IsDigit).ToArray()).Length == 11)
                    .WithMessage("ABN must be exactly 11 digits")
                    .WithErrorCode("ABN_INVALID_LENGTH")
                    .When(x => !string.IsNullOrEmpty(x.UpdateQuoteDto.ABN));

                // ========== LicenseNumber ==========
                RuleFor(x => x.UpdateQuoteDto.LicenseNumber)
                    .NotEmpty()
                    .WithMessage("License number is required")
                    .WithErrorCode("LICENSE_NUMBER_REQUIRED")

                    .MaximumLength(50)
                    .WithMessage("License number cannot exceed 50 characters")
                    .WithErrorCode("LICENSE_NUMBER_TOO_LONG");

                // ========== ContactName ==========
                RuleFor(x => x.UpdateQuoteDto.ContactName)
                    .NotEmpty()
                    .WithMessage("Contact name is required")
                    .WithErrorCode("CONTACT_NAME_REQUIRED")

                    .MinimumLength(2)
                    .WithMessage("Contact name must be at least 2 characters")
                    .WithErrorCode("CONTACT_NAME_TOO_SHORT")

                    .MaximumLength(200)
                    .WithMessage("Contact name cannot exceed 200 characters")
                    .WithErrorCode("CONTACT_NAME_TOO_LONG");

                // ========== ContactEmail ==========
                RuleFor(x => x.UpdateQuoteDto.ContactEmail)
                    .NotEmpty()
                    .WithMessage("Contact email is required")
                    .WithErrorCode("CONTACT_EMAIL_REQUIRED")

                    .EmailAddress()
                    .WithMessage("Invalid email format")
                    .WithErrorCode("CONTACT_EMAIL_INVALID");

                // ========== ContactPhone ==========
                RuleFor(x => x.UpdateQuoteDto.ContactPhone)
                    .NotEmpty()
                    .WithMessage("Contact phone is required")
                    .WithErrorCode("CONTACT_PHONE_REQUIRED")

                    .MaximumLength(30)
                    .WithMessage("Contact phone cannot exceed 30 characters")
                    .WithErrorCode("CONTACT_PHONE_TOO_LONG");

                // ========== PDFUrl ==========
                When(x => !string.IsNullOrWhiteSpace(x.UpdateQuoteDto.PDFUrl), () =>
                {
                    RuleFor(x => x.UpdateQuoteDto.PDFUrl)
                        .MaximumLength(500)
                        .WithMessage("PDF URL cannot exceed 500 characters")
                        .WithErrorCode("PDF_URL_TOO_LONG")
                        .Must(url => Uri.TryCreate(url, UriKind.Absolute, out var uriResult)
                            && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps))
                        .WithMessage("PDF URL must be a valid URL")
                        .WithErrorCode("PDF_URL_INVALID");
                });

                // ========== cross validation ==========
                // validate SubTotal + GST consistency
                RuleFor(x => x.UpdateQuoteDto)
                    .Custom((dto, context) =>
                    {
                        if (dto.SubTotal == 0 && dto.GST == 0)
                        {
                            context.AddFailure(new FluentValidation.Results.ValidationFailure(
                                propertyName: "SubTotal",
                                errorMessage: "SubTotal and GST cannot both be zero",
                                attemptedValue: dto.SubTotal)
                            {
                                ErrorCode = "SUBTOTAL_AND_GST_BOTH_ZERO"
                            });
                        }
                    });
            });
        }
    }
}
