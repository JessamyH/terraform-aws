using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.UpdateQuote;

public record UpdateQuoteCommand : ICommand<Result>
{
    public Guid QuotePublicId { get; init; }

    public string Auth0SubjectId { get; init; }
    public UpdateQuoteDto UpdateQuoteDto { get; init; }

    public UpdateQuoteCommand(Guid quotePublicId, UpdateQuoteDto updateQuoteDto, string auth0SubjectId)
    {
        QuotePublicId = quotePublicId;
        UpdateQuoteDto = updateQuoteDto;
        Auth0SubjectId = auth0SubjectId;
    }

};