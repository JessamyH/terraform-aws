using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.UpdateProgressPayment
{
    public record UpdateProgressPaymentCommand(
        Guid QuotePublicId,
        int ProgressPaymentId,
        string Auth0SubjectId,
        UpdateProgressPaymentRequest UpdateProgressPaymentRequest
        ): ICommand<Result<ProgressPaymentDto>>;
}
