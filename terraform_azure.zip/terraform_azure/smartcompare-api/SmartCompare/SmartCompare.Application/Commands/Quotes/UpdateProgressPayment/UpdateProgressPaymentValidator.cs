using FluentValidation;
using SmartCompare.Application.Commands.Quotes.UpdateProgressPayment;

namespace SmartCompare.Application.Commands.Quotes.UpdateExclusion
{
    public sealed class UpdateProgressPaymentValidator : AbstractValidator<UpdateProgressPaymentCommand>
    {
        public UpdateProgressPaymentValidator()
        {
            RuleFor(x => x.QuotePublicId)
                .NotEmpty()
                .WithMessage("Quote Id must be provided.");

            RuleFor(x => x.ProgressPaymentId)
                .GreaterThan(0).WithMessage("Progress Payment Id must be greater than zero.");

            RuleFor(x => x.UpdateProgressPaymentRequest)
                .NotNull().WithMessage("Update data is required.");

            RuleFor(x => x.UpdateProgressPaymentRequest.Description)
                .NotEmpty()
                .WithMessage("Description must be provided.")
                .MaximumLength(1000)
                .WithMessage("Description must not exceed 1000 characters.");
            
            RuleFor(x => x.UpdateProgressPaymentRequest.Percentage)
                .GreaterThanOrEqualTo(0)
                .WithMessage("Percentage must be greater than or equal to zero.");
        }
    }
}