using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.UpdateProgressPayment
{
    public sealed class UpdateProgressPaymentCommandHandler : IRequestHandler<UpdateProgressPaymentCommand, Result<ProgressPaymentDto>>
    {
        private readonly ILogger<UpdateProgressPaymentCommandHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IQuoteRepository _quoteRepository;
        private readonly IQuoteAuthorizationService _quoteAuthorizationService;

        public UpdateProgressPaymentCommandHandler(
            ILogger<UpdateProgressPaymentCommandHandler> logger,
            IMapper mapper,
            IQuoteRepository quoteRepository,
            IQuoteAuthorizationService quoteAuthorizationService)
        {
            _logger = logger;
            _mapper = mapper;
            _quoteRepository = quoteRepository;
            _quoteAuthorizationService = quoteAuthorizationService;
        }
        public async Task<Result<ProgressPaymentDto>> Handle(UpdateProgressPaymentCommand request, CancellationToken cancellationToken)
        {
            var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
                request.QuotePublicId,
                request.Auth0SubjectId,
                cancellationToken);

            if (!authResult.Succeed)
            {
                return Result.Failure<ProgressPaymentDto>(authResult.Error!);
            }
            var quote = await _quoteRepository.GetQuoteWithProgressPaymentsAsync(request.QuotePublicId, cancellationToken);

            if(quote == null)
            {
                _logger.LogError("Unexpected: Quote {QuotePublicId} not found after successful authorization. Possible race condition.", 
                    request.QuotePublicId);
                return Result.Failure<ProgressPaymentDto>(
                    new Error(ErrorType.NotFound, $"Quote with ID {request.QuotePublicId} not found."));
            }
            var amount = request.UpdateProgressPaymentRequest.Percentage;
            var description = request.UpdateProgressPaymentRequest.Description;
            bool isUpdated = quote.UpdateProgressPayment(request.ProgressPaymentId, amount, description, out var progressPayment);
            if (!isUpdated)
            {
                _logger.LogWarning("Not Found: Progress Payment {ProgressPaymentId} not found in Quote {QuotePublicId}.",
                    request.ProgressPaymentId,
                    request.QuotePublicId);
                return Result.Failure<ProgressPaymentDto>(
                    new Error(ErrorType.NotFound, $"Progress Payment with ID {request.ProgressPaymentId} not found."));
            }
            _logger.LogInformation("Successfully updated progress payment {ProgressPaymentId} in quote {QuotePublicId} by user {Auth0SubjectId}",
                request.ProgressPaymentId, request.QuotePublicId, request.Auth0SubjectId);
                
            return Result.Success(_mapper.Map<ProgressPaymentDto>(progressPayment));
        }
    }
}