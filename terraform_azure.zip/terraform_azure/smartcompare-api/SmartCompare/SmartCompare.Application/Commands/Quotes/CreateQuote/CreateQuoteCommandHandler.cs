using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.Domain.ValueObjects;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.CreateQuote;

public class CreateQuoteCommandHandler : IRequestHandler<CreateQuoteCommand, Result<QuoteSummaryDto>>
{
    private readonly IProjectAuthorizationService _authorizationService;
    private readonly IProjectQueries _projectQueries;
    private readonly IQuoteRepository _quoteRepository;
    private readonly ILogger<CreateQuoteCommandHandler> _logger;
    private readonly IMapper _mapper;

    public CreateQuoteCommandHandler(
        IProjectAuthorizationService authorizationService,
        IProjectQueries projectQueries,
        IQuoteRepository quoteRepository,
        ILogger<CreateQuoteCommandHandler> logger,
        IMapper mapper)
    {
        _authorizationService = authorizationService;
        _projectQueries = projectQueries;
        _quoteRepository = quoteRepository;
        _logger = logger;
        _mapper = mapper;
    }

    public async Task<Result<QuoteSummaryDto>> Handle(CreateQuoteCommand request, CancellationToken cancellationToken)
    {

        // Verify Auth0SubjectId matches project owner
        var authResult = await _authorizationService.ValidateProjectOwnershipAsync(
            request.ProjectPublicId,
            request.Auth0SubjectId,
            cancellationToken);

        if (!authResult.Succeed)
        {
            _logger.LogWarning(
                "User doesn't have project authority. ProjectPublicId: {ProjectPublicId}, Auth0SubjectId: {Auth0SubjectId}",
                request.ProjectPublicId,
                request.Auth0SubjectId);

            return Result.Failure<QuoteSummaryDto>(
                new Error(ErrorType.Forbidden, $"User doesn't have project authority"));
        }

        var project = await _projectQueries.GetByIdAsync(
            request.ProjectPublicId,
            cancellationToken);

        if (project == null)
        {
            _logger.LogWarning("Project was not found. ProjectPublicId: {ProjectPublicId}",
                request.ProjectPublicId);
            return Result.Failure<QuoteSummaryDto>(
                new Error(ErrorType.NotFound, $"Project was not found"));
        }

        ABN abn;
        try
        {
            abn = ABN.Create(request.ABN);
        }
        catch (ArgumentException ex)
        {
            return Result.Failure<QuoteSummaryDto>(new Error(ErrorType.Validation, ex.Message));
        }

        var quote = Quote.Create(
            quoteNumber: request.QuoteNumber,
            issuedBy: request.IssuedBy,
            issuedTo: request.IssuedTo,
            projectId: project.Id,
            subTotal: request.SubTotal,
            gst: request.GST,
            issuedDate: request.IssuedDate,
            validPeriod: request.ValidPeriod,
            abn: abn,
            licenseNumber: request.LicenseNumber,
            contactName: request.ContactName,
            contactEmail: request.ContactEmail,
            contactPhone: request.ContactPhone,
            pdfUrl: request.PDFUrl);

        await _quoteRepository.AddAsync(quote, cancellationToken);
        var quoteSummaryDto = _mapper.Map<QuoteSummaryDto>((quote, project));

        _logger.LogInformation(
            "Create Quote successfully. QuoteNumber: {QuoteNumber}, ProjectPublicId: {ProjectPublicId}",
            quote.QuoteNumber,
            project.PublicId);

        return Result.Success(quoteSummaryDto);

    }
}

