using MediatR;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.CreateQuote;

public record CreateQuoteCommand(
    Guid ProjectPublicId,
    string Auth0SubjectId,
    string QuoteNumber,
    DateTime IssuedDate,
    int ValidPeriod,
    string IssuedTo,
    string IssuedBy,
    decimal SubTotal,
    decimal GST,
    string ABN,
    string LicenseNumber,
    string ContactName,
    string ContactEmail,
    string ContactPhone,
    string? PDFUrl): ICommand<Result<QuoteSummaryDto>>;