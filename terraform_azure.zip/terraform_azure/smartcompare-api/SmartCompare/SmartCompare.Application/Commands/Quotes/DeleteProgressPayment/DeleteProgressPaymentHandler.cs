﻿using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.DeleteProgressPayment
{
    public class DeleteProgressPaymentHandler : IRequestHandler<DeleteProgressPaymentCommand, Result>
    {
        private readonly IQuoteRepository _quoteRepository;
        private readonly IQuoteAuthorizationService _quoteAuthorizationService;
        private readonly ILogger<DeleteProgressPaymentHandler> _logger;
        
        public DeleteProgressPaymentHandler(
            IQuoteRepository quoteRepository,
            IQuoteAuthorizationService quoteAuthorizationService,
            ILogger<DeleteProgressPaymentHandler> logger)
        {
            _quoteRepository = quoteRepository;
            _quoteAuthorizationService = quoteAuthorizationService;
            _logger = logger;
        }

        public async Task<Result> Handle(DeleteProgressPaymentCommand request, CancellationToken cancellationToken)
        {
            
            var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
                request.QuotePublicId,
                request.Auth0SubjectId,
                cancellationToken);
            
            if (!authResult.Succeed)
            {
                return Result.Failure(authResult.Error);
            }
            
            var quote = await _quoteRepository.GetQuoteWithProgressPaymentsAsync(
                request.QuotePublicId,
                cancellationToken);
            if (quote == null)
            {
                _logger.LogWarning(
                    "Quote not found. QuotePublicId: {QuotePublicId}",
                    request.QuotePublicId);

                return Result.Failure(new Error(ErrorType.NotFound, $"Quote with ID {request.QuotePublicId} not found"));
            }
            
            var isDeletedSuccessful = quote.DeleteProgressPayment(request.ProgressPaymentId);

            if (!isDeletedSuccessful)
            {
                _logger.LogWarning(
                    "Progress Payment with ID {PaymentProgressId} not found in Quote {QuotePublicId} when attempting deletion",
                    request.ProgressPaymentId,
                    request.QuotePublicId);
                return Result.Failure(new Error(ErrorType.NotFound, $"Progress Payment with ID {request.ProgressPaymentId} not found in Quote {request.QuotePublicId}."));
            }

            return Result.Success($"Progress Payment with ID {request.ProgressPaymentId} deleted successfully from Quote {request.QuotePublicId}.");

        }
    }
}
