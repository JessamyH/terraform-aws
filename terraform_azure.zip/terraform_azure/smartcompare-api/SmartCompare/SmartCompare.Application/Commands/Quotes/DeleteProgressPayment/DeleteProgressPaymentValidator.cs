﻿using FluentValidation;

namespace SmartCompare.Application.Commands.Quotes.DeleteProgressPayment
{
    public class DeleteProgressPaymentValidator : AbstractValidator<DeleteProgressPaymentCommand>
    {
        public DeleteProgressPaymentValidator()
        {
            RuleFor(x => x.ProgressPaymentId)
                .NotEmpty().WithMessage("Progress Payment ID must not be empty.")
                .GreaterThan(0).WithMessage("Progress Payment ID must be greater than zero.");
            RuleFor(x => x.QuotePublicId)
                .NotEmpty().WithMessage("Quote Public ID must not be empty.");
            RuleFor(x => x.Auth0SubjectId)
                .NotEmpty().WithMessage("Auth0 Subject ID must not be empty.");
        }
    }
}
