﻿using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.DeleteProgressPayment
{
    public sealed record DeleteProgressPaymentCommand(string Auth0SubjectId, Guid QuotePublicId, int ProgressPaymentId) 
        : ICommand<Result>;

}
