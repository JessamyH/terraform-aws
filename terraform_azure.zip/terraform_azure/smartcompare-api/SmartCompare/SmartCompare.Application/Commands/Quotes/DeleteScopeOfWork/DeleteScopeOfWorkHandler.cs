﻿using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.DeleteScopeOfWork
{
    public class DeleteScopeOfWorkHandler : IRequestHandler<DeleteScopeOfWorkCommand, Result>
    {
        private readonly IQuoteRepository _quoteRepository;
        private readonly IQuoteAuthorizationService _quoteAuthorizationService;
        private readonly ILogger<DeleteScopeOfWorkHandler> _logger;
        public DeleteScopeOfWorkHandler(
            IQuoteRepository quoteRepository,
            IQuoteAuthorizationService quoteAuthorizationService,
            ILogger<DeleteScopeOfWorkHandler> logger)
        {
            _quoteRepository = quoteRepository;
            _quoteAuthorizationService = quoteAuthorizationService;
            _logger = logger;
        }

        public async Task<Result> Handle(DeleteScopeOfWorkCommand request, CancellationToken cancellationToken)
        {
            var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
                request.QuotePublicId,
                request.Auth0SubjectId,
                cancellationToken);
            if (!authResult.Succeed)
            {
                return Result.Failure(authResult.Error);
            }

            var quote = await _quoteRepository.GetQuoteWithScopeOfWorkAsync(
                request.QuotePublicId,
                cancellationToken);

            if (quote is null)
            {
                return Result.Failure(new Error(ErrorType.NotFound, $"Quote with ID {request.QuotePublicId} not found."));
            }

            var isDeletedSuccessful = quote.DeleteScopeOfWork(request.ScopeOfWorkId);

            if (!isDeletedSuccessful)
            {
                _logger.LogWarning(
                    "Scope of Work with ID {ScopeOfWorkId} not found in Quote {QuotePublicId} when attempting deletion",
                    request.ScopeOfWorkId,
                    request.QuotePublicId);
                return Result.Failure(new Error(ErrorType.NotFound, $"Scope of Work with ID {request.ScopeOfWorkId} not found in Quote {request.QuotePublicId}."));
            }

            return Result.Success($"Scope of Work with ID {request.ScopeOfWorkId} deleted successfully from Quote {request.QuotePublicId}.");


        }
    }
}
