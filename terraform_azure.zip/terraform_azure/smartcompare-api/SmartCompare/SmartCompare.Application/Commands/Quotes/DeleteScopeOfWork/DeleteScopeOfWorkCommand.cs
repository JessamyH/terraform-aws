﻿using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.DeleteScopeOfWork
{
    public sealed record DeleteScopeOfWorkCommand(string Auth0SubjectId, Guid QuotePublicId, int ScopeOfWorkId) 
        : ICommand<Result>;

}
