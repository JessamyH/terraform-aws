﻿using FluentValidation;

namespace SmartCompare.Application.Commands.Quotes.DeleteScopeOfWork
{
    public class DeleteScopeOfWorkValidator : AbstractValidator<DeleteScopeOfWorkCommand>
    {
        public DeleteScopeOfWorkValidator()
        {
            RuleFor(x => x.ScopeOfWorkId)
                .NotEmpty().WithMessage("Scope of Work ID must not be empty.")
                .GreaterThan(0).WithMessage("Scope of Work ID must be greater than zero.");
            RuleFor(x => x.QuotePublicId)
                .NotEmpty().WithMessage("Quote Public ID must not be empty.");
            RuleFor(x => x.Auth0SubjectId)
                .NotEmpty().WithMessage("Auth0 Subject ID must not be empty.");
        }
    }
}
