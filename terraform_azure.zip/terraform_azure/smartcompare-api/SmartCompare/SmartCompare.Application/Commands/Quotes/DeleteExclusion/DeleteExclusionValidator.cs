using FluentValidation;

namespace SmartCompare.Application.Commands.Quotes.DeleteExclusion;

public class DeleteExclusionValidator : AbstractValidator<DeleteExclusionCommand>
{
    public DeleteExclusionValidator()
    {
        RuleFor(x => x.QuotePublicId)
            .NotEmpty().WithMessage("Quote ID is required.");

        RuleFor(x => x.ExclusionId)
            .NotEmpty().WithMessage("Exclusion ID is required.")
            .GreaterThan(0).WithMessage("Exclusion ID must be greater than 0.");

        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty().WithMessage("Auth0 Subject ID is required.");
    }
}