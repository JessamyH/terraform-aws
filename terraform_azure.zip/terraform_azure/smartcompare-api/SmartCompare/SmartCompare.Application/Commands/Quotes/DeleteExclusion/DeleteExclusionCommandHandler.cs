using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.DeleteExclusion;
public sealed class DeletedExclusionCommandHandler : IRequestHandler<DeleteExclusionCommand, Result>
{
    private readonly IQuoteRepository _quoteRepository;
    private readonly IQuoteAuthorizationService _quoteAuthorizationService;
    private readonly ILogger<DeletedExclusionCommandHandler> _logger;

    public DeletedExclusionCommandHandler(
        IQuoteRepository quoteRepository,
        IQuoteAuthorizationService quoteAuthorizationService,
        ILogger<DeletedExclusionCommandHandler> logger)
    {
        _quoteRepository = quoteRepository;
        _quoteAuthorizationService = quoteAuthorizationService;
        _logger = logger;
    }

    public async Task<Result> Handle(DeleteExclusionCommand request, CancellationToken cancellationToken)
    {
        var authorizationResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
            request.QuotePublicId,
            request.Auth0SubjectId,
            cancellationToken);

        if (!authorizationResult.Succeed)
        {
            _logger.LogWarning(
                "Authorization failed for deleting exclusion. QuotePublicId: {QuotePublicId}, Auth0SubjectId: {Auth0SubjectId}",
                request.QuotePublicId,
                request.Auth0SubjectId);

            return Result.Failure(authorizationResult.Error!);
        }

        var quote = await _quoteRepository.GetQuoteWithExclusionsAsync(request.QuotePublicId, cancellationToken);
        if (quote == null)
        {
            _logger.LogWarning(
                "Quote not found. QuotePublicId: {QuotePublicId}",
                request.QuotePublicId);

            return Result.Failure(new Error(ErrorType.NotFound, $"Quote with ID {request.QuotePublicId} not found"));
        }

        var exclusion = quote.Exclusions.FirstOrDefault(e => e.Id == request.ExclusionId);
        if (exclusion == null)
        {
            _logger.LogWarning(
                "Exclusion not found in quote. QuotePublicId: {QuotePublicId}, ExclusionId: {ExclusionId}",
                request.QuotePublicId,
                request.ExclusionId);

            return Result.Failure(new Error(ErrorType.NotFound, $"Exclusion with ID {request.ExclusionId} not found in this quote"));
        }

        bool isDeleted = quote.DeleteExclusion(exclusion);
        if (!isDeleted)
        {
            _logger.LogWarning(
                "Failed to delete exclusion - possible race condition. QuotePublicId: {QuotePublicId}, ExclusionId: {ExclusionId}",
                request.QuotePublicId,
                request.ExclusionId);

            return Result.Failure(new Error(ErrorType.Conflict, "Exclusion was already deleted or modified by another operation"));
        }

        _logger.LogInformation(
            "Exclusion deleted successfully. QuotePublicId: {QuotePublicId}, ExclusionId: {ExclusionId}",
            request.QuotePublicId,
            request.ExclusionId);

        return Result.Success("Exclusion deleted successfully");
    }
}
