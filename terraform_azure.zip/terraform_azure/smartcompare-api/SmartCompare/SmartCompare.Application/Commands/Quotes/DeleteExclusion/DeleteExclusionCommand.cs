using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.DeleteExclusion;
public sealed record DeleteExclusionCommand(Guid QuotePublicId, int ExclusionId, string Auth0SubjectId) : ICommand<Result>;