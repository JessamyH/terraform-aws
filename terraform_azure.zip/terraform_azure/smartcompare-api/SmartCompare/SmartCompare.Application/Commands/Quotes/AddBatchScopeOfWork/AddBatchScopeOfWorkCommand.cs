using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.AddBatchScopeOfWork;

public sealed record AddBatchScopeOfWorkCommand(
    Guid QuotePublicId,
    string Auth0SubjectId,
    List<AddScopeOfWorkDto> Items
) : ICommand<Result<AddBatchScopeOfWorkResultDto>>;
