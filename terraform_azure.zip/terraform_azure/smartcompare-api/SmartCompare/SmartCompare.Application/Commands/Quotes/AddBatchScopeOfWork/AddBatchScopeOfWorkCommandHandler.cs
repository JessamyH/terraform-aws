using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.AddBatchScopeOfWork;

public sealed class AddBatchScopeOfWorkCommandHandler : IRequestHandler<AddBatchScopeOfWorkCommand, Result<AddBatchScopeOfWorkResultDto>>
{
    private readonly IQuoteAuthorizationService _quoteAuthorizationService;
    private readonly IQuoteRepository _quoteRepository;
    private readonly ILogger<AddBatchScopeOfWorkCommandHandler> _logger;

    public AddBatchScopeOfWorkCommandHandler(
        IQuoteAuthorizationService quoteAuthorizationService,
        IQuoteRepository quoteRepository,
        ILogger<AddBatchScopeOfWorkCommandHandler> logger)
    {
        _quoteAuthorizationService = quoteAuthorizationService;
        _quoteRepository = quoteRepository;
        _logger = logger;
    }

    public async Task<Result<AddBatchScopeOfWorkResultDto>> Handle(AddBatchScopeOfWorkCommand request, CancellationToken cancellationToken)
    {
        var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
            request.QuotePublicId,
            request.Auth0SubjectId,
            cancellationToken);

        if (!authResult.Succeed)
        {
            _logger.LogWarning(
                "User doesn't have quote authority. QuotePublicId: {QuotePublicId}, Auth0SubjectId: {Auth0SubjectId}",
                request.QuotePublicId,
                request.Auth0SubjectId);
            return Result.Failure<AddBatchScopeOfWorkResultDto>(
                new Error(ErrorType.Forbidden, "User doesn't have quote authority"));
        }

        var quote = await _quoteRepository.GetQuoteWithScopeOfWorkAsync(
            request.QuotePublicId,
            cancellationToken);

        if (quote == null)
        {
            _logger.LogWarning("Quote was not found. QuotePublicId: {QuotePublicId}",
                request.QuotePublicId);
            return Result.Failure<AddBatchScopeOfWorkResultDto>(
                new Error(ErrorType.NotFound, "Quote was not found"));
        }

        var scopeOfWorksAdded = new List<ScopeOfWork>();
        foreach (var itemDto in request.Items)
        {
            var item = ScopeOfWork.Create(quote.Id, itemDto.Description);
            scopeOfWorksAdded.Add(item);
        }

        quote.AddScopeOfWorks(scopeOfWorksAdded);

        var resultDto = new AddBatchScopeOfWorkResultDto
        {
            Count = scopeOfWorksAdded.Count,
            ScopeOfWorks = scopeOfWorksAdded
                .Select(s => new ScopeOfWorkViewDto
                {
                    Description = s.Description
                })
                .ToList()
        };

        return Result.Success(resultDto, $"Successfully added {resultDto.Count} scope of work items");
    }
}
