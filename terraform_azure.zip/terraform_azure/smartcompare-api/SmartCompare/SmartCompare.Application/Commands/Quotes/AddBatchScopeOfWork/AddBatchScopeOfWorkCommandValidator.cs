using FluentValidation;
using SmartCompare.Application.DTOs.Quote;

namespace SmartCompare.Application.Commands.Quotes.AddBatchScopeOfWork;

public class AddBatchScopeOfWorkCommandValidator : AbstractValidator<AddBatchScopeOfWorkCommand>
{
    public AddBatchScopeOfWorkCommandValidator()
    {
        RuleFor(x => x.Items)
            .NotEmpty()
            .WithMessage("At least one item is required")
            .WithErrorCode("ITEMS_REQUIRED");

        RuleFor(x => x.Items)
            .Must(items => items.Count <= 100)
            .WithMessage("Maximum 100 items can be added at once")
            .WithErrorCode("ITEMS_MAX_COUNT")
            .When(x => x.Items != null && x.Items.Count > 0);

        RuleForEach(x => x.Items)
            .SetValidator(new AddScopeOfWorkDtoValidator());
    }

    private sealed class AddScopeOfWorkDtoValidator : AbstractValidator<AddScopeOfWorkDto>
    {
        public AddScopeOfWorkDtoValidator()
        {
            RuleFor(x => x.Description)
                .NotEmpty()
                .WithMessage("Description is required")
                .WithErrorCode("DESCRIPTION_REQUIRED")
                .MaximumLength(1000)
                .WithMessage("Description must not exceed 1000 characters")
                .WithErrorCode("DESCRIPTION_MAX_LENGTH");
        }
    }
}
