using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.AddExclusions;

public record AddExclusionsCommand(
    Guid QuotePublicId,
    string Auth0SubjectId,
    List<AddExclusionsDto> Items
    ): ICommand<Result<AddExclusionsResultDto>>;