using FluentValidation;
using SmartCompare.Application.DTOs.Quote;

namespace SmartCompare.Application.Commands.Quotes.AddExclusions;

public class AddExclusionsCommandValidator: AbstractValidator<AddExclusionsCommand>
{
    
    public AddExclusionsCommandValidator()
    {
        // Items cannot be empty
        RuleFor(x => x.Items)
            .NotEmpty()
            .WithMessage("At least one item is required")
            .WithErrorCode("ITEMS_REQUIRED");

        // Items max count
        RuleFor(x => x.Items)
            .Must(items => items.Count <= 100)
            .WithMessage("Maximum 100 items can be added at once")
            .WithErrorCode("ITEMS_MAX_COUNT")
            .When(x => x.Items != null && x.Items.Count > 0);

        // validate each item
        RuleForEach(x => x.Items)
            .SetValidator(new AddExclusionsDtoValidator());
    }
    
    private sealed class AddExclusionsDtoValidator : AbstractValidator<AddExclusionsDto>
    {
        public AddExclusionsDtoValidator()
        {
            RuleFor(x => x.Description)
                .NotEmpty()
                .WithMessage("Description is required")
                .WithErrorCode("DESCRIPTION_REQUIRED")
                .MaximumLength(1000)
                .WithMessage("Description must not exceed 1000 characters")
                .WithErrorCode("DESCRIPTION_MAX_LENGTH");
        }
    }
}
