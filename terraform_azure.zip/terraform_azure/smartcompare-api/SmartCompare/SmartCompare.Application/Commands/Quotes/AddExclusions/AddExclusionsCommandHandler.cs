using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;
using SmartCompare.Domain.Entities.QuoteAggregate;

namespace SmartCompare.Application.Commands.Quotes.AddExclusions;

public class AddExclusionsCommandHandler : IRequestHandler<AddExclusionsCommand, Result<AddExclusionsResultDto>>
{
    private readonly IQuoteAuthorizationService _quoteAuthorizationService;
    private readonly IQuoteRepository _quoteRepository;
    private readonly ILogger<AddExclusionsCommandHandler> _logger;

    public AddExclusionsCommandHandler(
        IQuoteAuthorizationService quoteAuthorizationService,
        IQuoteRepository quoteRepository,
        ILogger<AddExclusionsCommandHandler> logger)
    {
        _quoteAuthorizationService = quoteAuthorizationService;
        _quoteRepository = quoteRepository;
        _logger = logger;
    }
    
    public async Task<Result<AddExclusionsResultDto>> Handle(AddExclusionsCommand request, CancellationToken cancellationToken)
    {
        // Verify Auth0SubjectId matches quote owner
        var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
            request.QuotePublicId,
            request.Auth0SubjectId,
            cancellationToken);
        
        if (!authResult.Succeed)
        {
            _logger.LogWarning(
                "User doesn't have quote authority. QuotePublicId: {QuotePublicId}, Auth0SubjectId: {Auth0SubjectId}",
                request.QuotePublicId,
                request.Auth0SubjectId);
            return Result.Failure<AddExclusionsResultDto>(
                new Error(ErrorType.Forbidden, $"User doesn't have quote authority"));
        }
        
        
        var quote = await _quoteRepository.GetQuoteWithExclusionsAsync(
            request.QuotePublicId,
            cancellationToken);
        if (quote == null)
        {
            _logger.LogWarning("Quote was not found. QuotePublicId: {ProjectPublicId}",
                request.QuotePublicId);
            return Result.Failure<AddExclusionsResultDto>(
                new Error(ErrorType.NotFound, $"Quote was not found"));
        }
        
        var exclusionsAdded = new List<Exclusion>();
        foreach (var itemDto in request.Items)
        {
            var item = Exclusion.Create(quote.Id, itemDto.Description);
            exclusionsAdded.Add(item);
        }
        quote.AddExclusions(exclusionsAdded);
        
        var resultDto = new AddExclusionsResultDto
        {
            Count = exclusionsAdded.Count,
            Exclusions = exclusionsAdded
                .Select(e => new ExclusionViewDto
                {
                    Description = e.Description
                })
                .ToList()
        };
        
        return Result.Success(resultDto, $"Successfully added {resultDto.Count} exclusions");
    }
}

