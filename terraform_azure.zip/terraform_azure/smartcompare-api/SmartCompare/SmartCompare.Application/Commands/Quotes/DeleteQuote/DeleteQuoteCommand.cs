using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.DeleteQuote;
public sealed record DeleteQuoteCommand(Guid QuoteId, string Auth0SubjectId) : ICommand<Result>;