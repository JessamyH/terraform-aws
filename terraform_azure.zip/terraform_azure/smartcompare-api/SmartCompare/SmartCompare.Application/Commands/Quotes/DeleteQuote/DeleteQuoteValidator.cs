using FluentValidation;

namespace SmartCompare.Application.Commands.Quotes.DeleteQuote
{
    public class DeleteQuoteValidator : AbstractValidator<DeleteQuoteCommand>
    {
        public DeleteQuoteValidator()
        {
            RuleFor(x => x.QuoteId)
            .NotEmpty().WithMessage("QuoteId is required.");
        }
    }
}