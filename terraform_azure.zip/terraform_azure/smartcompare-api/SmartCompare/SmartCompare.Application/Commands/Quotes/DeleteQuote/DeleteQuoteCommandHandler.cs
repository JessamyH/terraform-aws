using MediatR;
using SharedKernel.Errors;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.DeleteQuote;

public sealed class DeleteQuoteCommandHandler : IRequestHandler<DeleteQuoteCommand, Result>
{
    private readonly IQuoteRepository _quoteRepository;
    private readonly IQuoteQueries _quoteQueries;
    private readonly IUnitOfWork _unitOfWork;
    public DeleteQuoteCommandHandler(
        IQuoteRepository quoteRepository,
        IQuoteQueries quoteQueries,
        IUnitOfWork unitOfWork)
    {
        _quoteRepository = quoteRepository;
        _quoteQueries = quoteQueries;
        _unitOfWork = unitOfWork;
    }
    /// <summary>
    /// Handle the DeleteQuoteCommand, hard delete a quote after validating ownership.
    /// Uses two query optimization: first validates ownership with minimal data transfer,
    /// then fetches and delete the quote entity.
    /// </summary>
    /// <param name="request">The command containing the quote ID and user's Auth0 subject ID</param>
    /// <param name="cancellationToken">Cancellation token for the async operation</param>
    /// <returns>Success result if deleted, or failure result if not found or unauthorized</returns>
    public async Task<Result> Handle(DeleteQuoteCommand request, CancellationToken cancellationToken)
    {
        var ownerAuth0SubjectId = await _quoteQueries.GetQuoteOwnerIdAsync(request.QuoteId, cancellationToken);

        if (ownerAuth0SubjectId == null)
        {
            return Result.Failure(new Error(ErrorType.NotFound, $"Quote with {request.QuoteId} not found"));
        }

        if (ownerAuth0SubjectId != request.Auth0SubjectId)
        {
            return Result.Failure(new Error(ErrorType.Forbidden, "You are not authorized to delete this quote"));
        }

        var quote = await _quoteRepository.GetQuoteByIdAsync(request.QuoteId, cancellationToken);

        if (quote == null)
        {
            return Result.Failure(new Error(ErrorType.NotFound, $"Quote with {request.QuoteId} not found"));
        }

        await _quoteRepository.Delete(quote);

        return Result.Success();
    }
}