﻿using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.DTOs.Quote.ResponseDto;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;


namespace SmartCompare.Application.Commands.Quotes.AddProgressPayments
{
    public sealed record AddProgressPaymentCommand(
        Guid QuotePublicId,
        string Auth0SubjectId,
        List<AddProgressPaymentRequestDto> Items): ICommand<Result<AddProgressPaymentResponseDto>>;
}
