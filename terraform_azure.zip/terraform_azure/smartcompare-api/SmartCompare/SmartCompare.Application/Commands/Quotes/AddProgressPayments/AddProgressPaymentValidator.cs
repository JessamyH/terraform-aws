﻿
using FluentValidation;
using SmartCompare.Application.DTOs.Quote;

namespace SmartCompare.Application.Commands.Quotes.AddProgressPayments
{
    public class AddProgressPaymentValidator : AbstractValidator<AddProgressPaymentCommand>
    {
        public AddProgressPaymentValidator()
        {
            RuleFor(x => x.Items)
                .NotEmpty()
                .WithMessage("At least one item is required")
                .WithErrorCode("ITEMS_REQUIRED");

            RuleFor(x => x.Items)
                .Must(items => items.Count <= 100)
                .WithMessage("Maximum 100 items can be added at once")
                .WithErrorCode("ITEMS_MAX_COUNT")
                .When(x => x.Items != null && x.Items.Count > 0);

            RuleForEach(x => x.Items)
                .SetValidator(new AddProgressPaymentDtoValidator());
        }

        private sealed class AddProgressPaymentDtoValidator : AbstractValidator<AddProgressPaymentRequestDto>
        {
            public AddProgressPaymentDtoValidator()
            {
                RuleFor(x => x.Description)
                    .NotEmpty()
                    .WithMessage("Description is required")
                    .WithErrorCode("DESCRIPTION_REQUIRED")
                    .MaximumLength(1000)
                    .WithMessage("Description must not exceed 1000 characters")
                    .WithErrorCode("DESCRIPTION_MAX_LENGTH");

                RuleFor(x => x.Percentage)
                    .NotEmpty()
                    .WithMessage("Percentage is required")
                    .WithErrorCode("PERCENTAGE_REQUIRED");
            }
        }
    }
}
