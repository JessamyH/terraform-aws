﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote.ResponseDto;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.AddProgressPayments
{
    public class AddProgressPaymentHandler: IRequestHandler<AddProgressPaymentCommand, Result<AddProgressPaymentResponseDto>>
    {
        private readonly ILogger<AddProgressPaymentHandler> _logger;
        private readonly IQuoteRepository _quoteRepository;
        private readonly IQuoteAuthorizationService _quoteAuthorizationService;

        public AddProgressPaymentHandler(
            ILogger<AddProgressPaymentHandler> logger,
            IQuoteRepository quoteRepository,
            IQuoteAuthorizationService quoteAuthorizationService)
        {
            _logger = logger;
            _quoteRepository = quoteRepository;
            _quoteAuthorizationService = quoteAuthorizationService;
        }

        public async Task<Result<AddProgressPaymentResponseDto>> Handle(AddProgressPaymentCommand request, CancellationToken cancellationToken)
        {
            var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
                request.QuotePublicId,
                request.Auth0SubjectId,
                cancellationToken);

            if(!authResult.Succeed)
            {
                _logger.LogWarning(
                    "User doesn't have quote authority. QuotePublicId: {QuotePublicId}, Auth0SubjectId: {Auth0SubjectId}",
                    request.QuotePublicId,
                    request.Auth0SubjectId);
                return Result.Failure<AddProgressPaymentResponseDto>(authResult.Error!);
            }

            var quote = await _quoteRepository.GetQuoteWithProgressPaymentsAsync(
                request.QuotePublicId,
                cancellationToken);

            if (quote == null)
            {
                _logger.LogWarning("Quote was not found. QuotePublicId: {QuotePublicId}",
                    request.QuotePublicId);
                return Result.Failure<AddProgressPaymentResponseDto>(
                    new Error(ErrorType.NotFound, "Quote was not found."));
            }

            var addedProgressPayment = new List<ProgressPayment>();

            foreach (var itemDto in request.Items)
            {
                var item = ProgressPayment.Create(
                    quote.Id,
                    itemDto.Percentage,
                    itemDto.Description);

                addedProgressPayment.Add(item);
            }

            quote.AddProgressPayment(addedProgressPayment);

            var progressPaymentsResponseDto = new AddProgressPaymentResponseDto
            {
                ProgressPayments = addedProgressPayment
                .Select(pp => new ProgressPaymentViewDto
                {
                    Description = pp.Description,
                    Percentage = pp.Percentage
                })
                .ToList()
            };

            return Result.Success(progressPaymentsResponseDto, $"Successfully add {progressPaymentsResponseDto.Count} progress payments");
        }

    }
}
