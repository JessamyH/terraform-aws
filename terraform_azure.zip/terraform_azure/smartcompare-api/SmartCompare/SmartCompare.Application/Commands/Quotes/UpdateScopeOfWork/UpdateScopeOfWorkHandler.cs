using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.UpdateScopeOfWork;

public sealed class UpdateScopeOfWorkHandler : IRequestHandler<UpdateScopeOfWorkCommand, Result<ScopeOfWorkDto>>
{
    private readonly ILogger<UpdateScopeOfWorkHandler> _logger;
    private readonly IMapper _mapper;
    private readonly IQuoteRepository _quoteRepository;
    private readonly IQuoteAuthorizationService _quoteAuthorizationService;

    public UpdateScopeOfWorkHandler(ILogger<UpdateScopeOfWorkHandler> logger,
        IMapper mapper,
        IQuoteRepository quoteRepository,
        IQuoteAuthorizationService quoteAuthorizationService)
    {
        _logger = logger;
        _mapper = mapper;
        _quoteRepository = quoteRepository;
        _quoteAuthorizationService = quoteAuthorizationService;
    }

    public async Task<Result<ScopeOfWorkDto>> Handle(UpdateScopeOfWorkCommand request, CancellationToken cancellationToken)
    {
        // TODO: replace ownership check method when pipeline behavior is ready
        var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(request.QuotePublicId,
            request.Auth0SubjectId,
            cancellationToken);

        if (!authResult.Succeed)
        {
            return Result.Failure<ScopeOfWorkDto>(authResult.Error!);
        }

        var quote = await _quoteRepository.GetQuoteWithScopeOfWorkAsync(request.QuotePublicId, cancellationToken);
        if (quote == null)
        {
            _logger.LogWarning("Not Found: Quote with PublicId {QuotePublicId} not found.", request.QuotePublicId);
            return Result.Failure<ScopeOfWorkDto>(
                new Error(ErrorType.NotFound, $"Quote with ID {request.QuotePublicId} not found."));
        }

        var description = request.ScopeOfWorkRequestDto.Description;
        bool updated = quote.UpdateScopeOfWork(request.ScopeOfWorkId, description, out var scopeOfWork);

        if (!updated)
        {
            _logger.LogWarning("ScopeOfWork not found: Id {ScopeOfWorkId}", request.ScopeOfWorkId);
            return Result.Failure<ScopeOfWorkDto>(new Error(ErrorType.NotFound, "Scope of work not found."));
        }

        var scopeOfWorkDto = _mapper.Map<ScopeOfWorkDto>(scopeOfWork);
        return Result.Success<ScopeOfWorkDto>(scopeOfWorkDto);
    }
}
