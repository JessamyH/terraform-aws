using FluentValidation;

namespace SmartCompare.Application.Commands.Quotes.UpdateScopeOfWork;

public sealed class UpdateScopeOfWorkValidator : AbstractValidator<UpdateScopeOfWorkCommand>
{
    public UpdateScopeOfWorkValidator()
    {
        RuleFor(x => x.QuotePublicId)
            .NotEmpty()
            .WithMessage("Quote Id must be provided.");

        RuleFor(x => x.ScopeOfWorkId)
            .GreaterThan(0)
            .WithMessage("Scope of work Id must be provided.");

        RuleFor(x => x.ScopeOfWorkRequestDto)
            .NotNull()
            .WithMessage("Scope of work data must be provided.");

        RuleFor(x => x.ScopeOfWorkRequestDto.Description)
            .NotEmpty()
            .WithMessage("Description must be provided.")
            .MaximumLength(1000)
            .WithMessage("Description must not exceed 1000 characters.");
    }
}
