using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.UpdateScopeOfWork;

public sealed record class UpdateScopeOfWorkCommand(
    Guid QuotePublicId,
    int ScopeOfWorkId,
    UpdateScopeOfWorkRequestDto ScopeOfWorkRequestDto,
    string Auth0SubjectId) : ICommand<Result<ScopeOfWorkDto>>
{
}
