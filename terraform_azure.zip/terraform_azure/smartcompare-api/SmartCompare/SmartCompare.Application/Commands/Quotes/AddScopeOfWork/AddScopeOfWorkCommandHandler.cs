using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.AddScopeOfWork;

public class AddScopeOfWorkCommandHandler : IRequestHandler<AddScopeOfWorkCommand, Result<ScopeOfWorkDto>>
{
    private readonly IQuoteAuthorizationService _quoteAuthorizationService;
    private readonly IQuoteQueries _quoteQueries;
    private readonly ILogger<AddScopeOfWorkCommandHandler> _logger;
    private readonly IMapper _mapper;

    public AddScopeOfWorkCommandHandler(
        IQuoteAuthorizationService quoteAuthorizationService,
        IQuoteQueries quoteQueries,
        ILogger<AddScopeOfWorkCommandHandler> logger,
        IMapper mapper)
    {
        _quoteAuthorizationService = quoteAuthorizationService;
        _quoteQueries = quoteQueries;
        _logger = logger;
        _mapper = mapper;
    }

    public async Task<Result<ScopeOfWorkDto>> Handle(AddScopeOfWorkCommand request, CancellationToken cancellationToken)
    {
        var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
            request.QuoteId,
            request.Auth0SubjectId,
            cancellationToken);

        if (!authResult.Succeed)
        {
            _logger.LogWarning(
                "User doesn't have quote access. QuoteId: {QuoteId}, Auth0SubjectId: {Auth0SubjectId}",
                request.QuoteId,
                request.Auth0SubjectId);

            return Result.Failure<ScopeOfWorkDto>(authResult.Error!);
        }

        var quote = await _quoteQueries.GetQuoteWithProjectAsync(request.QuoteId, cancellationToken);
        if (quote == null)
        {
            _logger.LogError("Quote not found after authorization check. QuoteId: {QuoteId}", request.QuoteId);
            return Result.Failure<ScopeOfWorkDto>(
                new Error(ErrorType.NotFound, $"Quote with ID {request.QuoteId} not found."));
        }

        var scopeOfWork = ScopeOfWork.Create(quote.Id, request.Description);

        quote.ScopeOfWorks.Add(scopeOfWork);

        var scopeOfWorkDto = _mapper.Map<ScopeOfWorkDto>(scopeOfWork);

        _logger.LogInformation(
            "ScopeOfWork added successfully. QuoteId: {QuoteId}, ScopeOfWorkId: {ScopeOfWorkId}",
            request.QuoteId,
            scopeOfWork.Id);

        return Result.Success(scopeOfWorkDto);
    }
}