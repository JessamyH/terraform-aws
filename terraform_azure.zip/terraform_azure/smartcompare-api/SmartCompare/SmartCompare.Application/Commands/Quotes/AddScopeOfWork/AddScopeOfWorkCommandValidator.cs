using FluentValidation;

namespace SmartCompare.Application.Commands.Quotes.AddScopeOfWork;

public class AddScopeOfWorkCommandValidator : AbstractValidator<AddScopeOfWorkCommand>
{
    public AddScopeOfWorkCommandValidator()
    {
        // ========== QuoteId ==========
        RuleFor(x => x.QuoteId)
            .NotEmpty()
            .WithMessage("Quote ID is required")
            .WithErrorCode("QUOTE_ID_REQUIRED");

        // ========== Auth0SubjectId ==========
        RuleFor(x => x.Auth0SubjectId)
            .NotEmpty()
            .WithMessage("Auth0 Subject ID is required")
            .WithErrorCode("AUTH0_SUBJECT_ID_REQUIRED")

            .MinimumLength(5)
            .WithMessage("Auth0 Subject ID must be at least 5 characters")
            .WithErrorCode("AUTH0_SUBJECT_ID_TOO_SHORT");

        // ========== Description ==========
        RuleFor(x => x.Description)
            .NotEmpty()
            .WithMessage("Description is required")
            .WithErrorCode("DESCRIPTION_REQUIRED")

            .MaximumLength(1000)
            .WithMessage("Description cannot exceed 1000 characters")
            .WithErrorCode("DESCRIPTION_TOO_LONG");
    }
}