using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.AddScopeOfWork;

public record class AddScopeOfWorkCommand(
    Guid QuoteId,
    string Auth0SubjectId,
    string Description) : ICommand<Result<ScopeOfWorkDto>>;