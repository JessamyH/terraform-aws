﻿using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.UpdateExclusion
{
    public record UpdateExclusionCommand(
        Guid QuotePublicId,
        int ExclusionId,
        string Auth0SubjectId,
        UpdateExclusionRequest UpdateExclusionRequest
        ): ICommand<Result<ExclusionDto>>;
}
