﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Commands.Quotes.UpdateExclusion
{
    public sealed class UpdateExclusionCommandHandler
        : IRequestHandler<UpdateExclusionCommand, Result<ExclusionDto>>
    {
        private readonly ILogger<UpdateExclusionCommandHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IQuoteRepository _quoteRepository;
        private readonly IQuoteAuthorizationService _quoteAuthorizationService;

        public UpdateExclusionCommandHandler(
            ILogger<UpdateExclusionCommandHandler> logger,
            IMapper mapper,
            IQuoteRepository quoteRepository,
            IQuoteAuthorizationService quoteAuthorizationService)
        {
            _logger = logger;
            _mapper = mapper;
            _quoteRepository = quoteRepository;
            _quoteAuthorizationService = quoteAuthorizationService;
        }

        public async Task<Result<ExclusionDto>> Handle(
            UpdateExclusionCommand request,
            CancellationToken cancellationToken)
        {
            var authResult = await _quoteAuthorizationService.ValidateQuoteAccessAsync(
                request.QuotePublicId,
                request.Auth0SubjectId,
                cancellationToken);

            if (!authResult.Succeed)
            {
                return Result.Failure<ExclusionDto>(authResult.Error!);
            }

            var quote = await _quoteRepository.GetQuoteWithExclusionsAsync(request.QuotePublicId, cancellationToken);

            if(quote == null)
            {
                _logger.LogError("Unexpected: Quote {QuotePublicId} not found after successful authorization. Possible race condition.", 
                    request.QuotePublicId);
                return Result.Failure<ExclusionDto>(
                    new Error(ErrorType.NotFound, $"Quote with ID {request.QuotePublicId} not found."));
            }

            var description = request.UpdateExclusionRequest.Description;
            bool isUpdated = quote.UpdateExclusion(request.ExclusionId, description, out var exclusion);

            if (!isUpdated)
            {
                _logger.LogWarning("Exclusion not found: ExclusionId {ExclusionId} in Quote {QuotePublicId}",
                    request.ExclusionId, request.QuotePublicId);
                return Result.Failure<ExclusionDto>(
                    new Error(ErrorType.NotFound, $"Exclusion with ID {request.ExclusionId} not found in quote {request.QuotePublicId}."));
            }

            _logger.LogInformation("Successfully updated exclusion {ExclusionId} in quote {QuotePublicId} by user {Auth0SubjectId}",
                request.ExclusionId, request.QuotePublicId, request.Auth0SubjectId);

            var exclusionDto = _mapper.Map<ExclusionDto>(exclusion);
            return Result.Success(exclusionDto, "Exclusion updated successfully.");
        }
    }
}
