﻿using FluentValidation;

namespace SmartCompare.Application.Commands.Quotes.UpdateExclusion
{
    public sealed class UpdateExclusionValidator : AbstractValidator<UpdateExclusionCommand>
    {
        public UpdateExclusionValidator()
        {
            RuleFor(x => x.QuotePublicId)
                .NotEmpty()
                .WithMessage("Quote Id must be provided.");

            RuleFor(x => x.ExclusionId)
                .GreaterThan(0).WithMessage("Exclusion Id must be greater than zero.");

            RuleFor(x => x.UpdateExclusionRequest)
                .NotNull().WithMessage("Update data is required.");

            RuleFor(x => x.UpdateExclusionRequest.Description)
                .NotEmpty()
                .WithMessage("Description must be provided.")
                .MaximumLength(1000)
                .WithMessage("Description must not exceed 1000 characters.");
        }
    }
}
