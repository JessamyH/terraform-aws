namespace SmartCompare.Application.Interfaces;

public interface ILogoDownloadService
{
    Task<byte[]?> DownloadLogoAsync(string? logoUrl, CancellationToken cancellationToken = default);
}
