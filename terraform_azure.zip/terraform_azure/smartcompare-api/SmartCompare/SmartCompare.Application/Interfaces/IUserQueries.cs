﻿using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Application.DTOs.Auth.QueryDto;

namespace SmartCompare.Application.Interfaces
{
    public interface IUserQueries
    {
        /// <summary>
        /// Gets a User by Auth0 Subject ID
        /// </summary>
        /// <param name="auth0SubjectId">Aut0 Subject ID</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>The User if found, otherwise null</returns>
        Task<User?> GetByAuth0SubjectIdAsync(string auth0SubjectId, CancellationToken cancellationToken = default);


        Task<UserWithRoleAndSubscriptionDto?> GetUserByAuth0SubjectIdWithSubscriptionAsync(string auth0SubjectId, CancellationToken cancellationToken = default);

        Task<CurrentUserDto?> GetCurrentUserByAuth0SubjectIdAsync(string auth0SubjectId, CancellationToken cancellationToken = default);
    }
}
