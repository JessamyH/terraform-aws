﻿using MediatR;


namespace SmartCompare.Application.Interfaces
{
    /// <summary>
    /// Marker interface for commands (write operations that require transaction)
    /// </summary>
    /// <typeparam name="TResponse">The response type</typeparam>
    public interface ICommand<out TResponse> : IRequest<TResponse>
    {
    }

    /// <summary>
    /// Marker interface for commands without response (void commands)
    /// </summary>
    public interface ICommand : IRequest
    {
    }
}
