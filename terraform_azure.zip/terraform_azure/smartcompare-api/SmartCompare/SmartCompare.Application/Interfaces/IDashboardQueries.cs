using SmartCompare.Application.DTOs.Dashboard;

namespace SmartCompare.Application.Interfaces;

public interface IDashboardQueries
{
    Task<DashboardStatsDto> GetDashboardStatsAsync(
        string auth0SubjectId,
        CancellationToken cancellationToken = default);

    Task<List<RecentQuoteDto>> GetRecentQuotesAsync(
        string auth0SubjectId,
        int count,
        CancellationToken cancellationToken = default);
}
