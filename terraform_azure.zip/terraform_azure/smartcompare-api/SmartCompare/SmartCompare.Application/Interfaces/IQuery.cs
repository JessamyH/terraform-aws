﻿using MediatR;


namespace SmartCompare.Application.Interfaces
{
    /// <summary>
    /// Marker interface for queries (read-only operations, no transaction needed)
    /// </summary>
    /// <typeparam name="TResponse">The response type</typeparam>
    public interface IQuery<out TResponse> : IRequest<TResponse>
    {
    }
}
