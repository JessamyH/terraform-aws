﻿using SmartCompare.Application.DTOs.Payment;
using SmartCompare.Domain.Enums;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Interfaces;

/// <summary>
/// Manages Stripe Checkout Sessions for subscription payments.
/// </summary>
public interface ICheckoutSessionService
{
    /// <summary>
    /// Creates a Stripe Checkout Session for a subscription plan.
    /// Ensures the user has a Stripe Customer before creating the session.
    /// </summary>
    /// <param name="auth0SubjectId">The Auth0 Subject ID of the authenticated user.</param>
    /// <param name="tier">The subscription tier (Basic or Pro). Free tier is not supported.</param>
    /// <param name="duration">The subscription duration (Month or Year).</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>A Result containing the Checkout Session ID and redirect URL. Returns Validation error for unsupported tier/duration combinations.</returns>
    Task<Result<CheckoutSessionResponseDto>> CreateCheckoutSessionAsync(
        string auth0SubjectId,
        SubscriptionTier tier,
        SubscriptionDuration duration,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Retrieves the current status of a Stripe Checkout Session.
    /// Validates that the session belongs to the specified Stripe Customer to prevent IDOR.
    /// </summary>
    /// <param name="sessionId">The Stripe Checkout Session ID (e.g., cs_xxxxx).</param>
    /// <param name="stripeCustomerId">The Stripe Customer ID of the current user, used for ownership validation.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>A Result containing the session status, payment status, and customer email. Returns Forbidden if the session does not belong to the user.</returns>
    Task<Result<CheckoutSessionStatusDto>> GetSessionStatusAsync(
        string sessionId,
        string stripeCustomerId,
        CancellationToken cancellationToken = default);
}