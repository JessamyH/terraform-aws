﻿
namespace SmartCompare.Application.Interfaces
{
    public interface IUserContextService
    {
        /// <summary>
        /// Checks if the current request has an authenticated user.
        /// </summary>
        bool IsAuthenticated();

        /// <summary>
        /// Gets the Auth0 Subject ID (sub claim) of the current user
        /// </summary>
        /// <exception cref="UnauthorizedAccessException">Thrown if not authenticated</exception>
        string GetRequiredAuth0SubjectId();

        /// <summary>
        /// Gets the email claim (nullable - may not be in token)
        /// </summary>
        string? GetEmail();

        /// <summary>
        /// Gets the name claim (nullable - may not be in token)
        /// </summary>
        string? GetName();

        /// <summary>
        /// Gets the picture claim (nullable - may not be in token)
        /// </summary>
        string? GetPicture();
    }
}
