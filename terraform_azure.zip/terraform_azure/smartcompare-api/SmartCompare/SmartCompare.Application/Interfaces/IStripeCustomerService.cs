﻿using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Interfaces;

/// <summary>
/// Manages Stripe Customer lifecycle, ensuring each user has a corresponding Stripe Customer.
/// </summary>
public interface IStripeCustomerService
{
    /// <summary>
    /// Gets the existing Stripe Customer ID for the user, or creates a new Stripe Customer if none exists.
    /// </summary>
    /// <param name="auth0SubjectId">The Auth0 Subject ID of the authenticated user.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>A Result containing the Stripe Customer ID (e.g., cus_xxxxx).</returns>
    Task<Result<string>> GetOrCreateCustomerAsync(
        string auth0SubjectId,
        CancellationToken cancellationToken = default);
}
