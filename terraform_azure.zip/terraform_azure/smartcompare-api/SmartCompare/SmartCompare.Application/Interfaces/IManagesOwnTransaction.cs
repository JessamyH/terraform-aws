namespace SmartCompare.Application.Interfaces
{
    /// <summary>
    /// Marker interface for commands that manage their own transactions.
    /// Commands implementing this interface will bypass the TransactionBehavior pipeline.
    /// Use when command requires fine-grained transaction control (e.g., race condition handling, partial failure scenarios).
    /// </summary>
    public interface IManagesOwnTransaction
    {
    }
}
