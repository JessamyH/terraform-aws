﻿using SmartCompare.Application.Common.Paging;
using SmartCompare.Domain.Entities.ProjectAggregate;
using static SmartCompare.Application.DTOs.ProjectSummaryDTOs;

namespace SmartCompare.Application.Interfaces
{
    public interface IProjectQueries
    {
        Task<Project?> GetByIdAsync(
            Guid projectPublicId,
            CancellationToken cancellationToken = default);

        Task<PagedResult<ProjectSummaryDto>> GetProjectsByUserIdPagedAsync(
            string auth0SubjectId,
            Pagination pagination,
            CancellationToken cancellationToken = default);
    }

}
