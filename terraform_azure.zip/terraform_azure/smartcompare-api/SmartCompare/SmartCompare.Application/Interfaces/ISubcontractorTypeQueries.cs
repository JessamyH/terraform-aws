using SmartCompare.Application.DTOs;

namespace SmartCompare.Application.Interfaces;

public interface ISubcontractorTypeQueries
{
    Task<List<SubcontractorTypeDto>> GetAllAsync(CancellationToken cancellationToken = default);
}
