namespace SmartCompare.Application.Interfaces;

public interface ISubscriptionQueries
{
    Task<bool> IsSubscriptionExpiredAsync(string auth0SubjectId, DateTime utcNow, CancellationToken cancellationToken = default);
}
