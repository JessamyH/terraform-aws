using SmartCompare.Application.DTOs.Quote;

namespace SmartCompare.Application.Interfaces;

public interface IPdfGenerationService
{
    byte[] GenerateQuotePdf(QuoteDto data, byte[]? logoBytes = null);
}
