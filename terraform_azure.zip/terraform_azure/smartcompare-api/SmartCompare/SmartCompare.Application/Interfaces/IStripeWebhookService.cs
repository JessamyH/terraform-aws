using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Interfaces;

/// <summary>
/// Processes incoming Stripe webhook events.
/// Implementations must be idempotent — Stripe may deliver the same event more than once.
/// </summary>
public interface IStripeWebhookService
{
    /// <summary>
    /// Verifies the webhook signature and dispatches the event to the appropriate handler.
    /// </summary>
    /// <param name="json">Raw JSON request body from Stripe.</param>
    /// <param name="signatureHeader">Value of the <c>Stripe-Signature</c> header.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>
    /// <see cref="Result.Success()"/> for all acknowledged events (including unhandled types).
    /// <see cref="Result.Failure"/> only for signature verification failures.
    /// Permanent processing errors (e.g. user not found) still return success to prevent Stripe retry storms.
    /// </returns>
    Task<Result> HandleWebhookAsync(string json, string signatureHeader, CancellationToken cancellationToken = default);
}
