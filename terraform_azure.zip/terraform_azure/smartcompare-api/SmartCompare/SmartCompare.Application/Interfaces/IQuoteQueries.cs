﻿using System.Linq.Expressions;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.SharedKernel.Common;


namespace SmartCompare.Application.Interfaces
{
    public interface IQuoteQueries
    {
        /// <summary>
        /// Get paged quotes by project Id
        /// </summary>
        /// <param name="projectPublicId">Project public ID</param>
        /// <param name="Auth0SubjectId">Auth0 Subject ID</param>
        /// <param name="pagination">Pagination parameters</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Paginated result containing quote summaries</returns>
        Task<PagedResult<QuoteSummaryDto>> GetByProjectIdPagedAsync(
            Guid projectPublicId,
            string Auth0SubjectId,
            Pagination pagination,
            CancellationToken cancellationToken);

        /// <summary>
        /// Retrieves a quote by its ID and user ID, projected to the specified DTO type.
        /// </summary>
        /// <typeparam name="TDto">The DTO type to project to, must implement IDto.</typeparam>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <param name="userId">The user ID for authorization check.</param>
        /// <param name="cancellationToken">Cancellation token for the operation.</param>
        /// <returns>The projected DTO or null if not found.</returns>
        Task<TDto?> GetByIdAsync<TDto>(Guid quotePublicId, Guid userId, CancellationToken cancellationToken = default) where TDto : class;

        /// <summary>
        /// Gets the owner's Auth0SubjectId for a quote for authorization checks.
        /// </summary>
        /// <param name="quoteId">The quote's public ID.</param>
        /// <param name="cancellationToken">Cancellation token for the operation.</param>
        /// <returns>The owner's Auth0SubjectId or null if quote not found.</returns>
        Task<string?> GetQuoteOwnerIdAsync(Guid quoteId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Retrieves paginated child entities for a specific quote.
        /// </summary>
        /// <typeparam name="TEntity">The entity type to select from quote.</typeparam>
        /// <typeparam name="TDto">The DTO type to project to.</typeparam>
        /// <param name="quotePublicId">The unique identifier of the quote.</param>
        /// <param name="userId">The user ID for authorization check.</param>
        /// <param name="selector">Expression to select the child collection (e.g., q => q.Exclusions).</param>
        /// <param name="pagination">Pagination parameters.</param>
        /// <param name="cancellationToken">Cancellation token for the operation.</param>
        /// <returns>Paginated result containing the projected DTOs.</returns>
        Task<PagedResult<TDto>> GetChildrenPagedAsync<TEntity, TDto>(
            Guid quotePublicId,
            Guid userId,
            Expression<Func<Quote, IEnumerable<TEntity>>> selector,
            Pagination pagination,
            CancellationToken cancellationToken = default)
            where TEntity : BaseEntity<int>
            where TDto : class;

        /// <summary>
        /// Get quote entity by public ID (for authorization checks)
        /// Includes Project navigation property
        /// </summary>
        /// <param name="quotePublicId">The unique identifier of the quote</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Quote entity with Project, or null if not found</returns>
        Task<Quote?> GetQuoteWithProjectAsync(
            Guid quotePublicId,
            CancellationToken cancellationToken = default);
        
        
    }
}
