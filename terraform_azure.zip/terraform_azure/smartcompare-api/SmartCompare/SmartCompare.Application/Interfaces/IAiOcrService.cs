using SmartCompare.Application.DTOs.Ocr;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.Application.Interfaces;

public interface IAiOcrService
{
    Task<Result<OcrPrefillDto>> AnalyseImageAsync(
        byte[] imageBytes,
        string mimeType,
        CancellationToken cancellationToken = default);
}
