using SmartCompare.Domain.Enums;

namespace SmartCompare.Application.Interfaces;

/// <summary>
/// Bidirectional mapping between Stripe Price IDs and subscription tier/duration.
/// Used by Checkout (tier→price) and Webhook (price→tier).
/// </summary>
public interface IStripePriceResolver
{
    /// <summary>
    /// Maps a subscription tier and duration to the configured Stripe Price ID.
    /// </summary>
    /// <returns>The Stripe Price ID, or null for unsupported combinations (e.g., Free tier).</returns>
    string? GetPriceId(SubscriptionTier tier, SubscriptionDuration duration);

    /// <summary>
    /// Resolves a Stripe Price ID to the corresponding subscription tier and duration.
    /// </summary>
    /// <returns>The tier/duration tuple, or null if the price ID is unknown.</returns>
    (SubscriptionTier Tier, SubscriptionDuration Duration)? Resolve(string priceId);
}
