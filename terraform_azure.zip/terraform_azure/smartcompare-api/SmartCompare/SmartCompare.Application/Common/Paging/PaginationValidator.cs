using FluentValidation;

namespace SmartCompare.Application.Common.Paging;

public class PaginationValidator : AbstractValidator<Pagination>
{
    public PaginationValidator()
    {
        RuleFor(x => x.PageNumber)
            .GreaterThan(0)
            .WithMessage("PageNumber must be greater than 0.");

        RuleFor(x => x.PageSize)
            .Must((pagination, pageSize) =>
                pageSize >= 1 && pageSize <= (pagination.MaxPageSize ?? Pagination.DefaultMaxPageSize))
            .WithMessage(x => $"PageSize must be between 1 and {(x.MaxPageSize ?? Pagination.DefaultMaxPageSize)}.");
    }
}
