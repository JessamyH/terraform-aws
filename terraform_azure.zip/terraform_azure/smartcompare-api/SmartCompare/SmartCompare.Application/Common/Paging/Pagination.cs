namespace SmartCompare.Application.Common.Paging;

/// <summary>
/// Represents pagination parameters for query requests
/// </summary>
/// <param name="PageNumber">Page number (1-based)</param>
/// <param name="PageSize">Number of items per page (1-100)</param>
public sealed record Pagination(int PageNumber = 1, int PageSize = 10, int? MaxPageSize = null)
{
    public const int DefaultMaxPageSize = 100;

    public int Skip => (PageNumber - 1) * PageSize;
    public int Take => PageSize;
}
