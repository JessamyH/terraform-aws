using IntegrationTests.Authentication;
using Microsoft.EntityFrameworkCore;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Enums;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace IntegrationTests.Helpers;

/// <summary>
/// Helper class for seeding test data into the database.
/// </summary>
public static class TestDataSeeder
{
    /// <summary>
    /// Seeds a test user into the database if they don't already exist.
    /// </summary>
    public static async Task<User> SeedUserAsync(SmartCompareDbContext context, TestUser testUser)
    {
        var existingUser = await context.Users
            .FirstOrDefaultAsync(u => u.Auth0SubjectId == testUser.Auth0SubjectId);

        if (existingUser != null)
            return existingUser;

        var user = User.Create(
            testUser.Auth0SubjectId,
            testUser.UserName,
            testUser.Email);

        // Add subscription based on tier
        var tier = ParseTier(testUser.Tier);
        if (tier == SubscriptionTier.Free)
        {
            user.AddFreeSubscription();
        }
        else
        {
            user.AddSubscription(
                subscriptionTier: tier,
                subscriptionDuration: SubscriptionDuration.Month,
                subscriptionStatus: SubscriptionStatus.Active,
                startDate: DateTime.UtcNow,
                endDate: DateTime.UtcNow.AddMonths(1));
        }

        context.Users.Add(user);
        await context.SaveChangesAsync();
        return user;
    }
    
    private static SubscriptionTier ParseTier(string? tier)
    {
        return tier?.ToLowerInvariant() switch
        {
            "pro" => SubscriptionTier.Pro,
            "basic" => SubscriptionTier.Basic,
            _ => SubscriptionTier.Free
        };
    }
}