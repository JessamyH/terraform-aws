using Microsoft.EntityFrameworkCore;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace IntegrationTests.Helpers;

/// <summary>
/// Helper class for database cleanup and utility operations.
/// </summary>
public static class DatabaseHelper
{
    /// <summary>
    /// Cleans up all test data from the database.
    /// Order matters due to foreign key constraints.
    /// </summary>
    public static async Task CleanupTestDataAsync(SmartCompareDbContext context)
    {
        // Delete in order of dependencies (children first, parents last)
        // Quotes depend on Projects
        await context.Quotes.ExecuteDeleteAsync();

        // Projects depend on Users
        await context.Projects.ExecuteDeleteAsync();

        // Payments depend on Users
        await context.Payments.ExecuteDeleteAsync();

        // Finally delete Users (this will cascade delete related entities if configured)
        await context.Users.ExecuteDeleteAsync();
    }
    
}