using System.Net.Http.Json;
using System.Text.Json;
using SmartCompare.API.ApiResponse;

namespace IntegrationTests.Helpers;

/// <summary>
/// Extension methods for HttpClient to work with typed API responses.
/// </summary>
public static class HttpClientExtensions
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    /// <summary>
    /// Sends a GET request and deserializes the response to ApiResponse{T}.
    /// </summary>
    public static async Task<ApiResponse<T>?> GetApiResponseAsync<T>(
        this HttpClient client,
        string requestUri,
        CancellationToken cancellationToken = default)
    {
        var response = await client.GetAsync(requestUri, cancellationToken);
        return await DeserializeResponseAsync<T>(response, cancellationToken);
    }

    /// <summary>
    /// Sends a POST request with JSON content and deserializes the response to ApiResponse{T}.
    /// </summary>
    public static async Task<(HttpResponseMessage Response, ApiResponse<T>? ApiResponse)> PostApiResponseAsync<T>(
        this HttpClient client,
        string requestUri,
        object? content = null,
        CancellationToken cancellationToken = default)
    {
        var response = await client.PostAsJsonAsync(requestUri, content, JsonOptions, cancellationToken);
        var apiResponse = await DeserializeResponseAsync<T>(response, cancellationToken);
        return (response, apiResponse);
    }

    /// <summary>
    /// Sends a PUT request with JSON content and deserializes the response to ApiResponse{T}.
    /// </summary>
    public static async Task<(HttpResponseMessage Response, ApiResponse<T>? ApiResponse)> PutApiResponseAsync<T>(
        this HttpClient client,
        string requestUri,
        object? content = null,
        CancellationToken cancellationToken = default)
    {
        var response = await client.PutAsJsonAsync(requestUri, content, JsonOptions, cancellationToken);
        var apiResponse = await DeserializeResponseAsync<T>(response, cancellationToken);
        return (response, apiResponse);
    }

    /// <summary>
    /// Sends a DELETE request and deserializes the response to ApiResponse{T}.
    /// </summary>
    public static async Task<(HttpResponseMessage Response, ApiResponse<T>? ApiResponse)> DeleteApiResponseAsync<T>(
        this HttpClient client,
        string requestUri,
        CancellationToken cancellationToken = default)
    {
        var response = await client.DeleteAsync(requestUri, cancellationToken);
        var apiResponse = await DeserializeResponseAsync<T>(response, cancellationToken);
        return (response, apiResponse);
    }

    /// <summary>
    /// Sends a GET request and returns the raw HttpResponseMessage.
    /// </summary>
    public static Task<HttpResponseMessage> GetRawAsync(
        this HttpClient client,
        string requestUri,
        CancellationToken cancellationToken = default)
    {
        return client.GetAsync(requestUri, cancellationToken);
    }

    
    private static async Task<ApiResponse<T>?> DeserializeResponseAsync<T>(
        HttpResponseMessage response,
        CancellationToken cancellationToken)
    {
        var content = await response.Content.ReadAsStringAsync(cancellationToken);

        if (string.IsNullOrEmpty(content))
            return null;

        try
        {
            return JsonSerializer.Deserialize<ApiResponse<T>>(content, JsonOptions);
        }
        catch (JsonException)
        {
            return null;
        }
    }
}