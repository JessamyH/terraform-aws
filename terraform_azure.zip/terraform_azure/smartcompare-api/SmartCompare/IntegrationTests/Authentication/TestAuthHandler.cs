using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace IntegrationTests.Authentication;

/// <summary>
/// Custom authentication handler for integration tests.
/// Bypasses Auth0 and reads identity from HTTP headers.
/// </summary>
public class TestAuthHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    public const string SchemeName = "TestScheme";

    // Header names for passing test user identity
    public const string UserIdHeader = "X-Test-User-Id";
    public const string UserEmailHeader = "X-Test-User-Email";
    public const string RoleTierHeader = "X-Test-User-RoleTier";

    public TestAuthHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder)
        : base(options, logger, encoder)
    {
    }

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        // Check if test user headers are present
        if (!Request.Headers.TryGetValue(UserIdHeader, out var userId) ||
            string.IsNullOrEmpty(userId))
        {
            return Task.FromResult(AuthenticateResult.NoResult());
        }

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, userId!)
        };

        // Add email claim if present
        if (Request.Headers.TryGetValue(UserEmailHeader, out var email) &&
            !string.IsNullOrEmpty(email))
        {
            claims.Add(new Claim(ClaimTypes.Email, email!));
        }

        // Add role/tier claim as JSON (matching production UserRoleTierClaim format)
        if (Request.Headers.TryGetValue(RoleTierHeader, out var roleTierJson) &&
            !string.IsNullOrEmpty(roleTierJson))
        {
            claims.Add(new Claim(ClaimTypes.Role, roleTierJson!));
        }

        var identity = new ClaimsIdentity(claims, SchemeName);
        var principal = new ClaimsPrincipal(identity);
        var ticket = new AuthenticationTicket(principal, SchemeName);

        return Task.FromResult(AuthenticateResult.Success(ticket));
    }
}