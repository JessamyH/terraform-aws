namespace IntegrationTests.Authentication;

/// <summary>
/// Represents a test user for integration tests.
/// </summary>
public record TestUser(
    string Auth0SubjectId,
    string UserName,
    string Email,
    string[] Roles,
    string? Tier);

/// <summary>
/// Predefined test users for different scenarios.
/// </summary>
public static class TestUsers
{
    /// <summary>
    /// Default test user with Free tier.
    /// </summary>
    public static TestUser Default => new(
        Auth0SubjectId: "auth0|test-user-default",
        UserName: "testuser",
        Email: "testuser@example.com",
        Roles: ["User"],
        Tier: "Free");

    /// <summary>
    /// Admin test user with Admin role.
    /// </summary>
    public static TestUser Admin => new(
        Auth0SubjectId: "auth0|test-user-admin",
        UserName: "adminuser",
        Email: "admin@example.com",
        Roles: ["Admin", "User"],
        Tier: "Pro");

    /// <summary>
    /// Pro tier test user.
    /// </summary>
    public static TestUser Pro => new(
        Auth0SubjectId: "auth0|test-user-pro",
        UserName: "prouser",
        Email: "prouser@example.com",
        Roles: ["User"],
        Tier: "Pro");

    /// <summary>
    /// Creates a unique test user for isolated test scenarios.
    /// </summary>
    public static TestUser CreateUnique(string? prefix = null)
    {
        var uniqueId = Guid.NewGuid().ToString("N")[..8];
        var userName = string.IsNullOrEmpty(prefix) ? $"user_{uniqueId}" : $"{prefix}_{uniqueId}";

        return new TestUser(
            Auth0SubjectId: $"auth0|test-{uniqueId}",
            UserName: userName,
            Email: $"{userName}@example.com",
            Roles: ["User"],
            Tier: "Free");
    }
}