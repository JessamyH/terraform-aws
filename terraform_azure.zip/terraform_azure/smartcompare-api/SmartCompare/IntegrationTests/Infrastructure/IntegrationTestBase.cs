using System.Text.Json;
using IntegrationTests.Authentication;
using IntegrationTests.Helpers;
using Microsoft.Extensions.DependencyInjection;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace IntegrationTests.Infrastructure;

/// <summary>
/// Base class for all integration tests.
/// Provides common functionality for database access, user switching, and cleanup.
/// </summary>
[Collection(IntegrationTestCollection.Name)]
public abstract class IntegrationTestBase : IAsyncLifetime
{
    
    
    private readonly SqlServerContainerFixture _containerFixture;
    protected CustomWebApplicationFactory Factory { get; private set; } = null!;
    protected HttpClient Client { get; private set; } = null!;
    protected TestUser CurrentTestUser { get; private set; } = TestUsers.Default;

    
    protected IntegrationTestBase(SqlServerContainerFixture containerFixture)
    {
        _containerFixture = containerFixture;
    }

    public virtual async Task InitializeAsync()
    {
        Factory = new CustomWebApplicationFactory(_containerFixture.ConnectionString);
        await Factory.EnsureMigratedAsync();
        Client = Factory.CreateClientForUser(CurrentTestUser);
    }

    public virtual async Task DisposeAsync()
    {
        Client.Dispose();
        await Factory.DisposeAsync();
    }

    /// <summary>
    /// Switches the current test user and updates the HTTP client accordingly.
    /// </summary>
    protected void SwitchToUser(TestUser user)
    {
        CurrentTestUser = user;
        Client.Dispose();
        Client = Factory.CreateClientForUser(user);
    }

    /// <summary>
    /// Switches to anonymous (unauthenticated) client.
    /// </summary>
    protected void SwitchToAnonymous()
    {
        Client.Dispose();
        Client = Factory.CreateAnonymousClient();
    }

    /// <summary>
    /// Executes an action against the database context directly.
    /// </summary>
    protected async Task ExecuteDbContextAsync(Func<SmartCompareDbContext, Task> action)
    {
        using var scope = Factory.Services.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<SmartCompareDbContext>();
        await action(context);
    }

    /// <summary>
    /// Executes a function against the database context and returns a result.
    /// </summary>
    protected async Task<T> ExecuteDbContextAsync<T>(Func<SmartCompareDbContext, Task<T>> func)
    {
        using var scope = Factory.Services.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<SmartCompareDbContext>();
        return await func(context);
    }
    

    /// <summary>
    /// Cleans up test data created during the test.
    /// Override this method for custom cleanup logic.
    /// </summary>
    protected virtual async Task CleanupTestDataAsync()
    {
        await ExecuteDbContextAsync(async context =>
        {
            await DatabaseHelper.CleanupTestDataAsync(context);
        });
    }

    /// <summary>
    /// Seeds the test user into the database.
    /// </summary>
    protected async Task SeedTestUserAsync(TestUser user)
    {
        await ExecuteDbContextAsync(async context =>
        {
            await TestDataSeeder.SeedUserAsync(context, user);
        });
    }

    /// <summary>
    /// Seeds the current test user into the database.
    /// </summary>
    protected async Task SeedCurrentTestUserAsync()
    {
        await SeedTestUserAsync(CurrentTestUser);
    }
}