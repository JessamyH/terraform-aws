using System.Runtime.InteropServices;
using DotNet.Testcontainers.Builders;
using Testcontainers.MsSql;

namespace IntegrationTests.Infrastructure;

/// <summary>
/// xUnit fixture that manages the SQL Server container lifecycle.
/// Shared across all tests via xUnit collection fixture.
/// </summary>
public class SqlServerContainerFixture : IAsyncLifetime
{
    private readonly MsSqlContainer _container;
    private const string Password = "Strong_Password_123!";
    private const int Port = 1433;

    public SqlServerContainerFixture()
    {
        
        var image = IsArm64() 
            ? "mcr.microsoft.com/azure-sql-edge:latest" 
            : "mcr.microsoft.com/mssql/server:2022-latest";
        
        
        _container = new MsSqlBuilder()
            .WithImage(image)
            .WithPassword("Strong_Password_123!")
            // Required environment variables
            .WithEnvironment("ACCEPT_EULA", "Y")
            .WithEnvironment("MSSQL_PID", "Developer")
            // Use custom wait strategy to avoid the exec issue
            .WithWaitStrategy(Wait.ForUnixContainer()
                .UntilPortIsAvailable(1433))
            .Build();
    }

    public string ConnectionString => BuildConnectionString();

    public async Task InitializeAsync()
    {
        try
        {
            // Start container
            await _container.StartAsync();
        }
        catch (Exception ex)
        {
            var logs = await GetContainerLogsAsync();
            throw new InvalidOperationException(
                $"Failed to start SQL Server container. Image: {(IsArm64() ? "Azure SQL Edge" : "SQL Server")}. Logs: {logs}", ex);
        }
    }
    
    private string BuildConnectionString()
    {
        var host = _container.Hostname;
        var port = _container.GetMappedPublicPort(Port);
        return $"Server={host},{port};Database=master;User Id=sa;Password={Password};TrustServerCertificate=True;";
    }

    private async Task<string> GetContainerLogsAsync()
    {
        try
        {
            var (stdout, stderr) = await _container.GetLogsAsync();
            return $"STDOUT: {stdout}\nSTDERR: {stderr}";
        }
        catch
        {
            return "Unable to retrieve container logs";
        }
    }
    
    /// <summary>
    /// Detect if running on ARM64 architecture (Mac M1/M2)
    /// </summary>
    private static bool IsArm64()
    {
        return RuntimeInformation.ProcessArchitecture == Architecture.Arm64;
    }
    
    public async Task DisposeAsync()
    {
        await _container.DisposeAsync();
    }
}