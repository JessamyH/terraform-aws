using System.Text.Json;
using IntegrationTests.Authentication;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using SmartCompare.Infrastructure.Persistence.Contexts;
using SmartCompare.SharedKernel.Auth.Claims;

namespace IntegrationTests.Infrastructure;

/// <summary>
/// Custom WebApplicationFactory that configures the test server with:
/// - Test database using Testcontainers SQL Server
/// - Custom authentication handler that bypasses Auth0
/// - Applies migrations once per factory instance
/// </summary>
public class CustomWebApplicationFactory : WebApplicationFactory<Program>
{
    private readonly string _connectionString;
    private bool _migrated;

    public CustomWebApplicationFactory(string connectionString)
    {
        _connectionString = connectionString;
    }

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        // Load test configuration BEFORE services are registered
        // This ensures Auth0 config values are available during Program.cs execution
        builder.ConfigureAppConfiguration((context, config) =>
        {
            // // Clear existing configuration sources to avoid conflicts
            // config.Sources.Clear();

            // Add test configuration with dummy Auth0 values
            config.AddJsonFile("appsettings.Testing.json", optional: false);

            // Override connection string with test container
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["ConnectionStrings:DefaultConnection"] = _connectionString
            });
        });

        builder.ConfigureTestServices(services =>
        {
            // Remove existing DbContext registrations
            services.RemoveAll<DbContextOptions<SmartCompareDbContext>>();
            services.RemoveAll<SmartCompareDbContext>();
            services.RemoveAll<IDbContextFactory<SmartCompareDbContext>>();

            // Register DbContext with test container connection string
            services.AddDbContextFactory<SmartCompareDbContext>(options =>
                options.UseSqlServer(_connectionString, sqlOptions =>
                {
                    sqlOptions.CommandTimeout(60);
                    sqlOptions.EnableRetryOnFailure(
                        maxRetryCount: 3,
                        maxRetryDelay: TimeSpan.FromSeconds(5),
                        errorNumbersToAdd: null);
                }));

            // Register DbContext as scoped service using the factory
            services.AddScoped(provider =>
            {
                var factory = provider.GetRequiredService<IDbContextFactory<SmartCompareDbContext>>();
                return factory.CreateDbContext();
            });

            // Replace authentication with test authentication handler
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = TestAuthHandler.SchemeName;
                options.DefaultChallengeScheme = TestAuthHandler.SchemeName;
            })
            .AddScheme<AuthenticationSchemeOptions, TestAuthHandler>(
                TestAuthHandler.SchemeName,
                options => { });
        });
        
        builder.ConfigureServices(services =>
        {
            services.AddProblemDetails();
        });
    }

    /// <summary>
    /// Ensures the database is migrated. Called once per test run.
    /// </summary>
    public async Task EnsureMigratedAsync()
    {
        if (_migrated)
            return;

        using var scope = Services.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<SmartCompareDbContext>();
        await context.Database.MigrateAsync();
        _migrated = true;
    }

    /// <summary>
    /// Creates an HTTP client configured for a specific test user.
    /// </summary>
    public HttpClient CreateClientForUser(TestUser user)
    {
        var client = CreateClient();

        client.DefaultRequestHeaders.Add(TestAuthHandler.UserIdHeader, user.Auth0SubjectId);
        client.DefaultRequestHeaders.Add(TestAuthHandler.UserEmailHeader, user.Email);

        var roleTierClaim = new UserRoleTierClaim
        {
            Roles = user.Roles,
            Tier = user.Tier
        };
        var roleTierJson = JsonSerializer.Serialize(roleTierClaim);
        client.DefaultRequestHeaders.Add(TestAuthHandler.RoleTierHeader, roleTierJson);

        return client;
    }

    /// <summary>
    /// Creates an HTTP client without authentication headers (anonymous user).
    /// </summary>
    public HttpClient CreateAnonymousClient()
    {
        return CreateClient();
    }
}