using System.Net;
using FluentAssertions;
using IntegrationTests.Authentication;
using IntegrationTests.Helpers;
using IntegrationTests.Infrastructure;

namespace IntegrationTests.Tests;

/// <summary>
/// Integration tests for authorization policies (Admin, Pro tier).
/// </summary>
public class AuthorizationTests : IntegrationTestBase
{
    private const string AdminEndpoint = "/api/ProtectedControllerSample/admin-policy-sample";
    private const string ProTierEndpoint = "/api/ProtectedControllerSample/pro-tier-sample";
    private const string SyncRoleEndpoint = "/api/ProtectedControllerSample/sync-role";

    public AuthorizationTests(SqlServerContainerFixture containerFixture)
        : base(containerFixture)
    {
    }

    #region Admin Policy Tests

    [Fact]
    public async Task AdminEndpoint_WithAdminUser_ShouldReturn200Ok()
    {
        // Arrange
        SwitchToUser(TestUsers.Admin);

        // Act
        var response = await Client.GetRawAsync(AdminEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    [Fact]
    public async Task AdminEndpoint_WithDefaultUser_ShouldReturn403Forbidden()
    {
        // Arrange
        SwitchToUser(TestUsers.Default);

        // Act
        var response = await Client.GetRawAsync(AdminEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
    }

    [Fact]
    public async Task AdminEndpoint_WithProUser_ShouldReturn403Forbidden()
    {
        // Arrange
        SwitchToUser(TestUsers.Pro);

        // Act
        var response = await Client.GetRawAsync(AdminEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
    }

    [Fact]
    public async Task AdminEndpoint_WithAnonymousUser_ShouldReturn401Unauthorized()
    {
        // Arrange
        SwitchToAnonymous();

        // Act
        var response = await Client.GetRawAsync(AdminEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }

    #endregion

    #region Pro Tier Policy Tests

    [Fact]
    public async Task ProTierEndpoint_WithProUser_ShouldReturn200Ok()
    {
        // Arrange
        SwitchToUser(TestUsers.Pro);

        // Act
        var response = await Client.GetRawAsync(ProTierEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    [Fact]
    public async Task ProTierEndpoint_WithAdminUser_ShouldReturn200Ok()
    {
        // Arrange - Admin user also has Pro tier
        SwitchToUser(TestUsers.Admin);

        // Act
        var response = await Client.GetRawAsync(ProTierEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    [Fact]
    public async Task ProTierEndpoint_WithDefaultUser_ShouldReturn403Forbidden()
    {
        // Arrange - Default user has Free tier
        SwitchToUser(TestUsers.Default);

        // Act
        var response = await Client.GetRawAsync(ProTierEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
    }

    [Fact]
    public async Task ProTierEndpoint_WithAnonymousUser_ShouldReturn401Unauthorized()
    {
        // Arrange
        SwitchToAnonymous();

        // Act
        var response = await Client.GetRawAsync(ProTierEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }

    #endregion

    #region SyncRole Tests

    [Fact]
    public async Task SyncRole_WithAuthenticatedUser_ShouldReturn200Ok()
    {
        // Arrange
        SwitchToUser(TestUsers.Default);

        // Act
        var response = await Client.GetRawAsync(SyncRoleEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    [Fact]
    public async Task SyncRole_WithAnonymousUser_ShouldReturn401Unauthorized()
    {
        // Arrange
        SwitchToAnonymous();

        // Act
        var response = await Client.GetRawAsync(SyncRoleEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }

    #endregion

    #region Custom User Tests

    [Fact]
    public async Task AdminEndpoint_WithCustomAdminUser_ShouldReturn200Ok()
    {
        // Arrange
        var customAdmin = new TestUser(
            Auth0SubjectId: "auth0|custom-admin",
            UserName: "customadmin",
            Email: "customadmin@example.com",
            Roles: ["Admin"],
            Tier: "Free");

        SwitchToUser(customAdmin);

        // Act
        var response = await Client.GetRawAsync(AdminEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    [Fact]
    public async Task ProTierEndpoint_WithCustomProUser_ShouldReturn200Ok()
    {
        // Arrange
        var customProUser = new TestUser(
            Auth0SubjectId: "auth0|custom-pro",
            UserName: "custompro",
            Email: "custompro@example.com",
            Roles: ["User"],
            Tier: "Pro");

        SwitchToUser(customProUser);

        // Act
        var response = await Client.GetRawAsync(ProTierEndpoint);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    #endregion
}