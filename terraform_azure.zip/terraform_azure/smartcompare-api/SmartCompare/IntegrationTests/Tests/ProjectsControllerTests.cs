using System.Net;
using FluentAssertions;
using IntegrationTests.Helpers;
using IntegrationTests.Infrastructure;
using SmartCompare.Application.DTOs;

namespace IntegrationTests.Tests;

/// <summary>
/// Integration tests for ProjectsController CRUD operations.
/// </summary>
public class ProjectsControllerTests : IntegrationTestBase
{
    private const string BaseUrl = "/api/projects";

    public ProjectsControllerTests(SqlServerContainerFixture containerFixture)
        : base(containerFixture)
    {
    }

    public override async Task InitializeAsync()
    {
        await base.InitializeAsync();
        await SeedCurrentTestUserAsync();
    }

    public override async Task DisposeAsync()
    {
        await CleanupTestDataAsync();
        await base.DisposeAsync();
    }
    

    [Fact]
    public async Task CreateProject_WithValidData_ShouldReturn201Created()
    {
        // Arrange
        var createDto = new CreateProjectDto
        {
            ProjectName = "Test Project",
            Address = "123 Test Street",
            SubcontractorTypeId = 1
        };

        // Act
        var (response, apiResponse) = await Client.PostApiResponseAsync<ProjectDto>(BaseUrl, createDto);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Created);
        apiResponse.Should().NotBeNull();
        apiResponse!.Succeed.Should().BeTrue();
        apiResponse.Data.Should().NotBeNull();
        apiResponse.Data!.ProjectName.Should().Be(createDto.ProjectName);
        apiResponse.Data.Address.Should().Be(createDto.Address);
    }

    [Fact]
    public async Task CreateProject_WithoutAuthentication_ShouldReturn401Unauthorized()
    {
        // Arrange
        SwitchToAnonymous();
        var createDto = new CreateProjectDto
        {
            ProjectName = "Unauthorized Project",
            Address = "456 Unauthorized Street",
            SubcontractorTypeId = 1
        };

        // Act
        var (response, _) = await Client.PostApiResponseAsync<ProjectDto>(BaseUrl, createDto);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }

    [Fact]
    public async Task GetProjects_WithAuthentication_ShouldReturn200Ok()
    {
        // Arrange - Create a project first
        var createDto = new CreateProjectDto
        {
            ProjectName = "Project to Get",
            Address = "789 Get Street",
            SubcontractorTypeId = 1
        };
        await Client.PostApiResponseAsync<ProjectDto>(BaseUrl, createDto);

        // Act
        var response = await Client.GetRawAsync(BaseUrl);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    [Fact]
    public async Task GetProjects_WithoutAuthentication_ShouldReturn401Unauthorized()
    {
        // Arrange
        SwitchToAnonymous();

        // Act
        var response = await Client.GetRawAsync(BaseUrl);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }

    [Fact]
    public async Task DeleteProject_ExistingProject_ShouldReturn200Ok()
    {
        // Arrange - Create a project first
        var createDto = new CreateProjectDto
        {
            ProjectName = "Project to Delete",
            Address = "Delete Street",
            SubcontractorTypeId = 1
        };
        var (_, createResponse) = await Client.PostApiResponseAsync<ProjectDto>(BaseUrl, createDto);
        var projectId = createResponse!.Data!.PublicId;

        // Act
        var (response, _) = await Client.DeleteApiResponseAsync<object>($"{BaseUrl}/{projectId}");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
    
    
    
}