using SmartCompare.Domain.Entities;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Domain.Interfaces;

public interface ISampleEntityRepository : IRepository<SampleAggregate, Guid>
{
    
}
