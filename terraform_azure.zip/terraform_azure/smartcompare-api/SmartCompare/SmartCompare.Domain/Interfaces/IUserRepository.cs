using System;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Domain.Interfaces;

public interface IUserRepository : IRepository<User, Guid>
{
    Task<User?> GetBySubjectIdAsync(string auth0SubjectId, CancellationToken cancellationToken = default);
    Task<User?> GetBySubjectIdWithSubscriptionAsync(string auth0SubjectId, CancellationToken cancellationToken = default);
    Task<User?> GetByStripeCustomerIdWithSubscriptionAsync(string stripeCustomerId, CancellationToken cancellationToken = default);
}
