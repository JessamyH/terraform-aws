using System;
using SmartCompare.Domain.Entities.PaymentAggregate;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Domain.Interfaces;

public interface IPaymentRepository : IRepository<Payment, int>
{
    Task<Payment?> GetByStripeInvoiceIdAsync(string stripeInvoiceId, CancellationToken cancellationToken = default);
}
