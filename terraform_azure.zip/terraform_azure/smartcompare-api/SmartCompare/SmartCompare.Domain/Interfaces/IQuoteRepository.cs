using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Domain.Interfaces;

/// <summary>
/// Repository interface for Quote aggregate root operations.
/// </summary>
public interface IQuoteRepository : IRepository<Quote, int>
{
    /// <summary>
    /// Deletes a quote from the repository.
    /// </summary>
    /// <param name="quote">The quote entity to delete.</param>
    Task Delete(Quote quote);

    /// <summary>
    /// Retrieves a quote by its public identifier.
    /// </summary>
    /// <param name="quoteId">The public GUID of the quote.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The quote if found; otherwise null.</returns>
    Task<Quote?> GetQuoteByIdAsync(Guid quoteId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Retrieves a quote with its scope of work items included.
    /// </summary>
    /// <param name="quoteId">The public GUID of the quote.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The quote with scope of work items if found; otherwise null.</returns>
    Task<Quote?> GetQuoteWithScopeOfWorkAsync(Guid quoteId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Retrieves a quote with its exclusion items included.
    /// </summary>
    /// <param name="quoteId">The public GUID of the quote.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The quote with exclusion items if found; otherwise null.</returns>
    Task<Quote?> GetQuoteWithExclusionsAsync(Guid quoteId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Retrieves a quote with its associated progress payments
    /// </summary>
    /// <param name="quoteId">The unique identifier of the quote to retrieve.</param>
    /// <param name="cancellationToken"></param>
    /// <returns>The quote with Progress Payment items if found; otherwise null.</returns>
    Task<Quote?> GetQuoteWithProgressPaymentsAsync(Guid quoteId, CancellationToken cancellationToken = default);

}