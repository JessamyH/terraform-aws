﻿using SmartCompare.Domain.Entities;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Domain.Interfaces;

public interface IProjectRepository : IRepository<Project, int>
{
    // Add custom methods if needed
    Task<Project?> GetProjectByPublicIdAsync(Guid projectId, CancellationToken cancellationToken = default);
}