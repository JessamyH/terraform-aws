using SmartCompare.Domain.Entities.UserAggregate;

namespace SmartCompare.Domain.Interfaces
{

    public interface IRoleRepository
    {
        Task<Role?> GetByIdAsync(Guid roleId, CancellationToken cancellationToken = default);
    }
}

