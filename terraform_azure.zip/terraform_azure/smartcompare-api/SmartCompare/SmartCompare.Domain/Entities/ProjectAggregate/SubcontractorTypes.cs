using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Domain.Entities.ProjectAggregate;
public class SubcontractorTypes : BaseEntity<int>
{
    
    public string Type { get; private set; } = null!;
    
    public virtual ICollection<Project> Projects { get; private set; } = new List<Project>();
    
    protected SubcontractorTypes(){}

    private SubcontractorTypes(
        string type
    ) {
        Type = type;
    }

    public static SubcontractorTypes Create(
        string type)
    {
        return new SubcontractorTypes(type);
    }
}