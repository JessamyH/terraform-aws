using SmartCompare.Domain.Enums;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.SharedKernel.Common;
namespace SmartCompare.Domain.Entities.ProjectAggregate;
public class Project : AggregateRoot<int>
{

    public Guid PublicId { get; private set; }
    public string ProjectName { get; private set; } = null!;
    public string Address { get; private set; } = null!;
    public HouseType HouseType { get; private set; }
    public decimal HouseSizeSqm { get; private set; }
    public int Bedrooms { get; private set; }
    public int Bathrooms { get; private set; }
    public ProjectStatus Status { get; private set; }
    public Guid UserId { get; private set; }
    public int SubcontractorTypeId { get; private set; }

    public bool IsDeleted { get; private set; } = false;

    public virtual ICollection<Quote> Quotes { get; private set; } = new List<Quote>();
    public virtual SubcontractorTypes SubcontractorType { get; private set; } = null!;

    public virtual User User { get; private set; } = null!;

    protected Project() {} // EF Core

    private Project(
        Guid userId,
        string projectName,
        string address,
        HouseType houseType,
        decimal houseSizeSqm,
        int bedrooms,
        int bathrooms,
        int subcontractorTypeId,
        ProjectStatus status = ProjectStatus.InProgress)
    {
        PublicId = Guid.NewGuid();
        UserId = userId;
        ProjectName = projectName ?? throw new ArgumentNullException(nameof(projectName));
        Address = address ?? throw new ArgumentNullException(nameof(address));
        HouseType = houseType;
        HouseSizeSqm = houseSizeSqm;
        Bedrooms = bedrooms;
        Bathrooms = bathrooms;
        SubcontractorTypeId = subcontractorTypeId;
        Status = status;
    }

    public static Project Create(
        Guid userId,
        string projectName,
        string address,
        HouseType houseType,
        decimal houseSizeSqm,
        int bedrooms,
        int bathrooms,
        int subcontractorTypeId,
        ProjectStatus status = ProjectStatus.InProgress)
    {
        return new Project(
            userId,
            projectName,
            address,
            houseType,
            houseSizeSqm,
            bedrooms,
            bathrooms,
            subcontractorTypeId,
            status);
    }

    public void Update(
        string projectName,
        string address,
        HouseType houseType,
        decimal houseSizeSqm,
        int bedrooms,
        int bathrooms,
        int subcontractorTypeId,
        ProjectStatus status)
    {
        ProjectName = projectName;
        Address = address;
        HouseType = houseType;
        HouseSizeSqm = houseSizeSqm;
        Bedrooms = bedrooms;
        Bathrooms = bathrooms;
        SubcontractorTypeId = subcontractorTypeId;
        Status = status;
    }

    //Soft delete a project
    public bool SoftDelete()
    {
        if (IsDeleted)
        {
            return false;
        }
        IsDeleted = true;
        DeletedAt = DateTime.UtcNow;

        return true;
    }
}
