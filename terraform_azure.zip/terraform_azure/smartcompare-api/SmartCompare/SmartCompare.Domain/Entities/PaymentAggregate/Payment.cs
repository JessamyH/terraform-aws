using SmartCompare.Domain.Enums;
using SmartCompare.SharedKernel.Common;
using SmartCompare.Domain.Entities.UserAggregate;

namespace SmartCompare.Domain.Entities.PaymentAggregate;

public class Payment : AggregateRoot<int>
{
    public Money PaymentAmount { get; private set; } = null!;
    public PaymentStatus Status { get; private set; }
    public PaymentType Type { get; private set; }
    public string? StripeInvoiceId { get; private set; }
    public string? StripePaymentIntentId { get; private set; }
    public string? StripeChargeId { get; private set; }
    public DateTime? PaidAt { get; private set; }
    public DateTime? RefundedAt { get; private set; }
    public string? FailureReason { get; private set; }
    public string? Description { get; private set; }
    public Guid SubscriptionId { get; private set; }

    public virtual Subscription Subscription { get; private set; } = null!;

    protected Payment() { }

    private Payment(
        decimal amount,
        string currency,
        PaymentStatus status,
        PaymentType type,
        Guid subscriptionId,
        string? stripeInvoiceId,
        string? stripePaymentIntentId,
        string? stripeChargeId,
        DateTime? paidAt,
        string? description)
    {
        if (stripeInvoiceId is null && stripePaymentIntentId is null)
            throw new ArgumentException("At least one of stripeInvoiceId or stripePaymentIntentId must be provided.");

        PaymentAmount = Money.Create(amount, currency);
        Status = status;
        Type = type;
        SubscriptionId = subscriptionId;
        StripeInvoiceId = stripeInvoiceId;
        StripePaymentIntentId = stripePaymentIntentId;
        StripeChargeId = stripeChargeId;
        PaidAt = paidAt;
        Description = description;
    }

    public static Payment Create(
        decimal amount,
        string currency,
        PaymentStatus status,
        PaymentType type,
        Guid subscriptionId,
        string? stripeInvoiceId = null,
        string? stripePaymentIntentId = null,
        string? stripeChargeId = null,
        DateTime? paidAt = null,
        string? description = null)
    {
        return new Payment(
            amount, currency, status, type,
            subscriptionId, stripeInvoiceId,
            stripePaymentIntentId, stripeChargeId,
            paidAt, description);
    }

    public void MarkAsSucceeded()
    {
        if (Status == PaymentStatus.Succeeded) return;
        Status = PaymentStatus.Succeeded;
        PaidAt = DateTime.UtcNow;
        UpdatedAt = DateTime.UtcNow;
    }

    public void MarkAsFailed(string? failureReason = null)
    {
        if (Status == PaymentStatus.Succeeded) return;
        Status = PaymentStatus.Failed;
        FailureReason = failureReason;
        UpdatedAt = DateTime.UtcNow;
    }
}
