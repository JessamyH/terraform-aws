using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Domain.Entities;

public class SampleAggregate : AggregateRoot<Guid>
{
    
}