using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Application.Exceptions;
using SmartCompare.Domain.Enums;
using SmartCompare.Domain.ValueObjects;
using SmartCompare.SharedKernel.Common;
using SmartCompare.Domain.Entities.PaymentAggregate;

namespace SmartCompare.Domain.Entities.UserAggregate;

public class User : AggregateRoot<Guid>
{
    public string Auth0SubjectId { get; private set; } = null!;
    public string UserName { get; private set; } = null!;
    public EmailAddress Email { get; private set; } = null!;
    public DateTime LastLoginAt { get; private set; }
    public virtual ICollection<CompanyProfile> CompanyProfiles { get; private set; } = new List<CompanyProfile>();
    public virtual ICollection<Project> Projects { get; private set; } = new List<Project>();
    public ICollection<UserRole> UserRoles { get; private set; } = new List<UserRole>();
    public virtual Subscription? Subscription { get; private set; }
    public virtual ICollection<Payment> Payments { get; private set; } = new List<Payment>();
    public string? StripeCustomerId { get; private set; }
    protected User() { }
    private User(
        string auth0SubjectId,
        string userName,
        string email)
    {
        Id = Guid.NewGuid();
        Auth0SubjectId = auth0SubjectId ?? throw new ArgumentNullException(nameof(auth0SubjectId));
        UserName = userName ?? throw new ArgumentNullException(nameof(userName));
        Email = EmailAddress.Create(email);
        LastLoginAt = DateTime.UtcNow;
    }

    public static User Create(
        string auth0SubjectId,
        string userName,
        string email)
    {
        var user = new User(
            auth0SubjectId,
            userName,
            email);
        return user;
    }

    public bool AddRole(Guid roleId)
    {
        if (UserRoles.Any(r => r.RoleId == roleId))
        {
            return false; // Role already assigned
        }

        var userRole = UserRole.Create(Id, roleId);
        UserRoles.Add(userRole);
        return true; // Role added successfully
    }

    public void AddCompanyProfile(
        string companyName,
        string contactName,
        string contactEmail,
        string contactPhone,
        int? postCode = null,
        string? abn = null,
        string? street = null,
        string? suburb = null,
        string? state = null,
        string? logoUrl = null,
        string? bsb = null,
        string? account = null,
        string? licenseNumber = null)
    {
        var companyProfile = CompanyProfile.Create(
            userId: Id,
            companyName: companyName,
            contactName: contactName,
            contactEmail: contactEmail,
            contactPhone: contactPhone,
            postCode: postCode,
            abn: abn,
            street: street,
            suburb: suburb,
            state: state,
            logoUrl: logoUrl,
            bsb: bsb,
            account: account,
            licenseNumber: licenseNumber);

        CompanyProfiles.Add(companyProfile);
    }

    public void UpdateLastLoginAt()
    {
        LastLoginAt = DateTime.UtcNow;
    }

    public void SetStripeCustomerId(string stripeCustomerId)
    {
        if (string.IsNullOrEmpty(stripeCustomerId))
            throw new ArgumentException("Stripe customer Id cannot be empty",
                nameof(stripeCustomerId));

        StripeCustomerId = stripeCustomerId;
    }

    public void AddSubscription(
        SubscriptionTier subscriptionTier,
        SubscriptionDuration subscriptionDuration,
        SubscriptionStatus subscriptionStatus,
        DateTime startDate,
        DateTime endDate,
        string? stripeSubscriptionId = null,
        bool isDeleted = false)
    {
        if (Subscription != null)
        {
            Subscription.Update(
                subscriptionTier: subscriptionTier,
                subscriptionDuration: subscriptionDuration,
                subscriptionStatus: subscriptionStatus,
                startDate: startDate,
                endDate: endDate,
                stripeSubscriptionId: stripeSubscriptionId);
            return;
        }

        var subscription = Subscription.Create(
            userId: Id,
            subscriptionTier: subscriptionTier,
            subscriptionDuration: subscriptionDuration,
            subscriptionStatus: subscriptionStatus,
            startDate: startDate,
            endDate: endDate,
            stripeSubscriptionId: stripeSubscriptionId,
            isDeleted: isDeleted);
        Subscription = subscription;
    }

    public void AddFreeSubscription()
    {
        AddSubscription(
            subscriptionTier: SubscriptionTier.Free,
            subscriptionDuration: SubscriptionDuration.None,
            subscriptionStatus: SubscriptionStatus.Trial,
            startDate: DateTime.UtcNow,
            endDate: new DateTime(2099, 12, 31, 23, 59, 59, DateTimeKind.Utc)
        );
    }
}