using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Domain.Entities.UserAggregate;
public class UserRole : BaseEntity<int>
{
    public Guid UserId { get; private set; }
    public Guid RoleId { get; private set; }

    public virtual User User { get; private set; } = null!;
    public virtual Role Role { get; private set; } = null!;

    protected UserRole() {} // EF Core

    private UserRole(Guid userId, Guid roleId)
    {
        UserId = userId;
        RoleId = roleId;
    }

    public static UserRole Create(Guid userId, Guid roleId)
    {
        if (roleId == Guid.Empty)
            throw new ArgumentException("Invalid role ID", nameof(roleId));

        return new UserRole(userId, roleId);
    }
}