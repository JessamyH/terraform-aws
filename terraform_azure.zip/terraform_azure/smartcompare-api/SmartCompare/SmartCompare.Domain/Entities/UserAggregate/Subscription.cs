using SmartCompare.Domain.Enums;
using SmartCompare.SharedKernel.Common;
using SmartCompare.Domain.Entities.PaymentAggregate;
namespace SmartCompare.Domain.Entities.UserAggregate;

public class Subscription : BaseAuditableEntity<Guid>
{
    public Guid UserId { get; private set; }
    public SubscriptionTier SubscriptionTier { get; private set; }
    public SubscriptionDuration SubscriptionDuration { get; private set; }
    public SubscriptionStatus SubscriptionStatus { get; private set; }
    public DateRange DateRange { get; private set; } = null!;
    public string? StripeSubscriptionId { get; private set; }
    public bool IsDeleted { get; private set; } = false;

    public virtual ICollection<Payment> Payments { get; private set; } = new List<Payment>();
    public virtual User User { get; private set; } = null!;

    protected Subscription() { }

    private Subscription(
        Guid userId,
        SubscriptionTier subscriptionTier,
        SubscriptionDuration subscriptionDuration,
        SubscriptionStatus subscriptionStatus,
        DateTime startDate,
        DateTime endDate,
        string? stripeSubscriptionId,
        bool isDeleted)
    {
        Id = Guid.NewGuid();
        UserId = userId;
        SubscriptionTier = subscriptionTier;
        SubscriptionDuration = subscriptionDuration;
        SubscriptionStatus = subscriptionStatus;
        DateRange = DateRange.Create(startDate, endDate);
        StripeSubscriptionId = stripeSubscriptionId;
        IsDeleted = isDeleted;
    }

    public static Subscription Create(
        Guid userId,
        SubscriptionTier subscriptionTier,
        SubscriptionDuration subscriptionDuration,
        SubscriptionStatus subscriptionStatus,
        DateTime startDate,
        DateTime endDate,
        string? stripeSubscriptionId,
        bool isDeleted)
    {
        return new Subscription(
            userId,
            subscriptionTier,
            subscriptionDuration,
            subscriptionStatus,
            startDate,
            endDate,
            stripeSubscriptionId,
            isDeleted);
    }

    public void Renew(DateTime newStartDate, DateTime newEndDate)
    {
        DateRange = DateRange.Create(newStartDate, newEndDate);
        SubscriptionStatus = SubscriptionStatus.Active;
        UpdatedAt = DateTime.UtcNow;
    }

    public void Cancel()
    {
        SubscriptionTier = SubscriptionTier.Free;
        SubscriptionDuration = SubscriptionDuration.None;
        SubscriptionStatus = SubscriptionStatus.Cancelled;
        StripeSubscriptionId = null;
        UpdatedAt = DateTime.UtcNow;
    }

    public void Expire()
    {
        SubscriptionTier = SubscriptionTier.Free;
        SubscriptionDuration = SubscriptionDuration.None;
        SubscriptionStatus = SubscriptionStatus.Expired;
        StripeSubscriptionId = null;
        UpdatedAt = DateTime.UtcNow;
    }

    public bool IsExpired(DateTime utcNow)
    {
        return (SubscriptionStatus == SubscriptionStatus.Active ||
                SubscriptionStatus == SubscriptionStatus.Trial) &&
               DateRange.EndDate < utcNow;
    }

    public void Update(
        SubscriptionTier subscriptionTier,
        SubscriptionDuration subscriptionDuration,
        SubscriptionStatus subscriptionStatus,
        DateTime startDate,
        DateTime endDate,
        string? stripeSubscriptionId)
    {
        SubscriptionTier = subscriptionTier;
        SubscriptionDuration = subscriptionDuration;
        SubscriptionStatus = subscriptionStatus;
        DateRange = DateRange.Create(startDate, endDate);
        StripeSubscriptionId = stripeSubscriptionId;
        UpdatedAt = DateTime.UtcNow;
    }
}