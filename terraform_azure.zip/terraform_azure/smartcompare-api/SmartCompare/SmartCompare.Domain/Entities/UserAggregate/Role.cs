using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Domain.Entities.UserAggregate;

public class Role : BaseEntity<Guid>
{
    public string Name { get; private set; } = null!;
    public ICollection<UserRole> UserRoles { get; private set; } = new List<UserRole>();
    public static class RoleNames
    {
        public const string Admin = "Admin";
        public const string CompanyAdmin = "CompanyAdmin";
    }

    /// <summary>
    /// Predefined role IDs (must match RoleConfiguration seed data)
    /// </summary>
    public static class RoleIds
    {
        public static readonly Guid CompanyAdmin = new Guid("00000000-0000-0000-0000-000000000001");
        public static readonly Guid Admin = new Guid("00000000-0000-0000-0000-000000000002");
    }

    protected Role() { } // EF Core

    private Role(string name)
    {
        Id = Guid.NewGuid();
        Name = name;
    }

    public static Role Create(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Role name cannot be empty", nameof(name));

        return new Role(name.Trim());
    }
}