using SmartCompare.Domain.ValueObjects;
using SmartCompare.SharedKernel.Common;
namespace SmartCompare.Domain.Entities.UserAggregate;
public class CompanyProfile : BaseAuditableEntity<Guid>
{
    public Guid UserId { get; private set; }
    public string CompanyName { get; private set; } = null!;
    public string ContactName { get; private set; } = null!;
    public EmailAddress ContactEmail { get; private set; } = null!;
    public PhoneNumber ContactPhone { get; private set; } = null!;
    public ABN? ABN { get; private set; }
    public Address? Address { get; private set; } 
    public string? LogoUrl { get; private set; }
    public BankAccount? BankAccount { get; private set; }
    public string? LicenseNumber { get; private set; }
    
    public virtual User User { get; private set; } = null!;
    
    protected CompanyProfile() {} // EF Core

    private CompanyProfile(
        Guid userId,
        string companyName,
        string contactName,
        string contactEmail,
        string contactPhone,
        int? postCode = null,
        string? abn = null,
        string? street = null,
        string? suburb = null,
        string? state = null,
        string? logoUrl = null,
        string? bsb = null,
        string? account = null,
        string? licenseNumber = null)
    {
        Id = Guid.NewGuid();
        UserId = userId;
        CompanyName = companyName ?? throw new ArgumentNullException(nameof(companyName));
        ContactName = contactName ?? throw new ArgumentNullException(nameof(contactName));
        ContactEmail = EmailAddress.Create(contactEmail);
        ContactPhone = PhoneNumber.Create(contactPhone);
        Address = Address.Create(street, suburb, state, postCode);
        ABN = abn != null ? ABN.Create(abn) : null;
        LogoUrl = logoUrl;
        BankAccount = (bsb != null && account != null) ? BankAccount.Create(bsb, account) : null;
        LicenseNumber = licenseNumber;
    }
    public static CompanyProfile Create(
        Guid userId,
        string companyName,
        string contactName,
        string contactEmail,
        string contactPhone,
        int? postCode = null,
        string? abn = null,
        string? street = null,
        string? suburb = null,
        string? state = null,
        string? logoUrl = null,
        string? bsb = null,
        string? account = null,
        string? licenseNumber = null
    )
    {
        return new CompanyProfile(
            userId,
            companyName,
            contactName,
            contactEmail,
            contactPhone,
            postCode,
            abn,
            street,
            suburb,
            state,
            logoUrl,
            bsb,
            account,
            licenseNumber);
    }
}