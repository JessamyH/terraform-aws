using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Domain.Entities.QuoteAggregate;

public class ProgressPayment : BaseEntity<int>
{

    public string Description { get; private set; } = null!;
    public decimal Percentage { get; private set; }
    public int QuoteId { get; private set; }

    public virtual Quote? Quote { get; private set; } = null!;


    protected ProgressPayment() { } // EF Core

    private ProgressPayment(
        int quoteId,
        decimal percentage,
        string description)
    {
        QuoteId = quoteId;
        Percentage = percentage;
        Description = description ?? throw new ArgumentNullException(nameof(description));
    }

    public static ProgressPayment Create(
        int quoteId,
        decimal percentage,
        string description)
    {
        return new ProgressPayment(quoteId, percentage, NormalizeDescription(description));
    }

    internal void UpdateDetails(decimal percentage, string description)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(description);
        ArgumentOutOfRangeException.ThrowIfNegative(percentage);
        Percentage = percentage;
        Description = NormalizeDescription(description);
    }

    private static string NormalizeDescription(string description)
    {
        if (string.IsNullOrWhiteSpace(description))
            throw new ArgumentNullException(nameof(description));

        var trimmed = description.Trim();
        return trimmed;
    }


}