using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Domain.Entities.QuoteAggregate;

public class ScopeOfWork : BaseEntity<int>
{
    public string Description { get; private set; } = null!;
    public int QuoteId { get; private set; }

    public virtual Quote? Quote { get; private set; } = null!;

    protected ScopeOfWork() { } // EF Core

    private ScopeOfWork(
        int quoteId,
        string description)
    {
        QuoteId = quoteId;
        Description = description ?? throw new ArgumentNullException(nameof(description));
    }

    public static ScopeOfWork Create(
        int quoteId,
        string description)
    {
        return new ScopeOfWork(quoteId, NormalizeDescription(description));
    }

    internal void UpdateDescription(string description)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(description);
        Description = NormalizeDescription(description);
    }

    private static string NormalizeDescription(string description)
    {
        if (string.IsNullOrWhiteSpace(description))
            throw new ArgumentNullException(nameof(description));

        return description.Trim();
    }
}