using SmartCompare.Application.Exceptions;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.ValueObjects;
using SmartCompare.SharedKernel.Common;
using SmartCompare.SharedKernel.Results;
namespace SmartCompare.Domain.Entities.QuoteAggregate;

public class Quote : AggregateRoot<int>
{
    public Guid PublicId { get; private set; }
    public string QuoteNumber { get; private set; } = null!;
    public DateTime IssuedDate { get; private set; }
    public DateTime ValidDate { get; private set; }
    public string IssuedBy { get; private set; } = null!;
    public string IssuedTo { get; private set; } = null!;
    public decimal Total { get; private set; }
    public decimal SubTotal { get; private set; }
    public decimal GST { get; private set; }
    public string? PDFUrl { get; private set; }
    public int ProjectId { get; private set; }
    public int ValidPeriod { get; private set; }
    public ABN ABN { get; private set; } = null!;
    public string LicenseNumber { get; private set; } = null!;
    public string ContactName { get; private set; } = null!;
    public string ContactEmail { get; private set; } = null!;
    public string ContactPhone { get; private set; } = null!;

    public virtual Project Project { get; private set; } = null!;

    public virtual ICollection<ScopeOfWork> ScopeOfWorks { get; private set; } = new List<ScopeOfWork>();
    public virtual ICollection<Exclusion> Exclusions { get; private set; } = new List<Exclusion>();
    public virtual ICollection<ProgressPayment> ProgressPayments { get; private set; } = new List<ProgressPayment>();

    protected Quote() { } // EF Core

    private Quote(
        string quoteNumber,
        string issuedBy,
        string issuedTo,
        int projectId,
        decimal subTotal,
        decimal gst,
        DateTime issuedDate,
        int validPeriod,
        ABN abn,
        string licenseNumber,
        string contactName,
        string contactEmail,
        string contactPhone,
        string? pdfUrl = null)
    {
        PublicId = Guid.NewGuid();
        QuoteNumber = quoteNumber ?? throw new ArgumentNullException(nameof(quoteNumber));
        IssuedBy = issuedBy ?? throw new ArgumentNullException(nameof(issuedBy));
        IssuedTo = issuedTo ?? throw new ArgumentNullException(nameof(issuedTo));
        ProjectId = projectId;
        SubTotal = subTotal;
        GST = gst;
        Total = subTotal + gst;
        IssuedDate = issuedDate;
        ValidPeriod = validPeriod;
        ValidDate = issuedDate.AddDays(validPeriod);
        ABN = abn ?? throw new ArgumentNullException(nameof(abn));
        LicenseNumber = licenseNumber ?? throw new ArgumentNullException(nameof(licenseNumber));
        ContactName = contactName ?? throw new ArgumentNullException(nameof(contactName));
        ContactEmail = contactEmail ?? throw new ArgumentNullException(nameof(contactEmail));
        ContactPhone = contactPhone ?? throw new ArgumentNullException(nameof(contactPhone));
        PDFUrl = pdfUrl;
    }

    public static Quote Create(
        string quoteNumber,
        string issuedBy,
        string issuedTo,
        int projectId,
        decimal subTotal,
        decimal gst,
        DateTime issuedDate,
        int validPeriod,
        ABN abn,
        string licenseNumber,
        string contactName,
        string contactEmail,
        string contactPhone,
        string? pdfUrl = null)
    {
        return new Quote(
            quoteNumber,
            issuedBy,
            issuedTo,
            projectId,
            subTotal,
            gst,
            issuedDate,
            validPeriod,
            abn,
            licenseNumber,
            contactName,
            contactEmail,
            contactPhone,
            pdfUrl);
    }

    public void AddScopeOfWork(string description)
    {
        var scopeOfWork = ScopeOfWork.Create(
            quoteId: Id,
            description: description);

        ValidateDuplicates(
            items: [scopeOfWork.Description],
            keySelector: d => d,
            existingKeys: ScopeOfWorks.Select(s => s.Description),
            itemTypeName: "scopeOfWorks");

        ScopeOfWorks.Add(scopeOfWork);
    }

    public void AddExclusion(string description)
    {
        var exclusion = Exclusion.Create(
            quoteId: Id,
            description: description);

        Exclusions.Add(exclusion);
    }

    public void AddProgressPayment(decimal percentage, string description)
    {
        var progressPayment = ProgressPayment.Create(
            quoteId: Id,
            percentage: percentage,
            description: description);

        ProgressPayments.Add(progressPayment);
    }

    public void Update(
        string quoteNumber,
        string issuedBy,
        string issuedTo,
        decimal subTotal,
        decimal gst,
        DateTime issuedDate,
        int validPeriod,
        ABN abn,
        string licenseNumber,
        string contactName,
        string contactEmail,
        string contactPhone,
        string? pdfUrl = null)
    {
        QuoteNumber = quoteNumber;
        IssuedBy = issuedBy;
        IssuedTo = issuedTo;
        SubTotal = subTotal;
        GST = gst;
        Total = subTotal + gst;
        IssuedDate = issuedDate;
        ValidPeriod = validPeriod;
        ValidDate = issuedDate.AddDays(validPeriod);
        ABN = abn ?? throw new ArgumentNullException(nameof(abn));
        LicenseNumber = licenseNumber ?? throw new ArgumentNullException(nameof(licenseNumber));
        ContactName = contactName ?? throw new ArgumentNullException(nameof(contactName));
        ContactEmail = contactEmail ?? throw new ArgumentNullException(nameof(contactEmail));
        ContactPhone = contactPhone ?? throw new ArgumentNullException(nameof(contactPhone));
        PDFUrl = pdfUrl;
        UpdatedAt = DateTime.UtcNow;
    }
    public bool DeleteExclusion(Exclusion exclusion)
    {
        //var exclusion = Exclusions.FirstOrDefault(e => e.Id == exclusionId);
        //if (exclusion == null) return false;
        return Exclusions.Remove(exclusion);
    }

    public bool UpdateScopeOfWork(int scopeOfWorkId, string description, out ScopeOfWork? scopeOfWork)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(description);

        scopeOfWork = ScopeOfWorks.FirstOrDefault(sow => sow.Id == scopeOfWorkId);

        if (scopeOfWork == null)
        {
            return false;
        }

        ValidateDuplicates(
            items: [description.Trim()],
            keySelector: d => d,
            existingKeys: ScopeOfWorks.Where(s => s.Id != scopeOfWorkId).Select(s => s.Description),
            itemTypeName: "scopeOfWorks");

        scopeOfWork.UpdateDescription(description);

        return true;
    }

    public bool UpdateExclusion(int exclusionId, string description, out Exclusion? exclusion)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(description);

        exclusion = Exclusions.FirstOrDefault(e => e.Id == exclusionId);

        if (exclusion == null)
        {
            return false;
        }

        ValidateDuplicates(
            items: [description.Trim()],
            keySelector: d => d,
            existingKeys: Exclusions.Where(e => e.Id != exclusionId).Select(e => e.Description),
            itemTypeName: "exclusions");

        exclusion.UpdateDescription(description);

        return true;
    }

    public bool UpdateProgressPayment(int progressPaymentId, decimal amount, string description, out ProgressPayment? progressPayment)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(description);

        progressPayment = ProgressPayments.FirstOrDefault(pp => pp.Id == progressPaymentId);

        if (progressPayment == null)
        {
            return false;
        }

        ValidateDuplicates(
            items: [description.Trim()],
            keySelector: d => d,
            existingKeys: ProgressPayments.Where(pp => pp.Id != progressPaymentId).Select(pp => pp.Description),
            itemTypeName: "progressPayment");

        progressPayment.UpdateDetails(amount, description);
        return true;
    }

    public bool DeleteScopeOfWork(int scopeOfWorkId)
    {
        var scopeOfWork = ScopeOfWorks.FirstOrDefault(s => s.Id == scopeOfWorkId);
        if (scopeOfWork == null)
        {
            return false;
        }
        ScopeOfWorks.Remove(scopeOfWork);
        return true;
    }


    public bool DeleteProgressPayment(int progressPaymentId)
    {
        var progressPayment = ProgressPayments.FirstOrDefault(pp => pp.Id == progressPaymentId);
        if (progressPayment == null)
        {
            return false;
        }
        ProgressPayments.Remove(progressPayment);
        return true;
    }

    public void AddScopeOfWorks(IEnumerable<ScopeOfWork> scopeOfWorks)
    {
        ArgumentNullException.ThrowIfNull(scopeOfWorks);

        var items = scopeOfWorks.ToList();
        if (items.Count == 0)
            throw new ArgumentException("ScopeOfWork list cannot be empty.", nameof(scopeOfWorks));

        var wrongQuoteScopeOfWork = items.FirstOrDefault(s => s.QuoteId != Id);
        if (wrongQuoteScopeOfWork is not null)
            throw new InvalidOperationException($"ScopeOfWork Description = {wrongQuoteScopeOfWork.Description} belongs to QuoteId={wrongQuoteScopeOfWork.QuoteId}, expected QuoteId={Id}.");

        ValidateDuplicates(
            items: items,
            keySelector: s => s.Description,
            existingKeys: ScopeOfWorks.Select(s => s.Description),
            itemTypeName: "scopeOfWorks");

        foreach (var item in items)
            ScopeOfWorks.Add(item);
    }

    public void AddExclusions(IEnumerable<Exclusion> exclusions)
    {
        ArgumentNullException.ThrowIfNull(exclusions);
        // materialize once
        var items = exclusions.ToList();
        if (items.Count == 0)
            throw new ArgumentException("Exclusions list cannot be empty.", nameof(exclusions));

        // validate quote id first (fail fast)
        var wrongQuoteExclusion = items.FirstOrDefault(e => e.QuoteId != Id);
        if (wrongQuoteExclusion is not null)
            throw new InvalidOperationException($"Exclusion Description = {wrongQuoteExclusion.Description} belongs to QuoteId={wrongQuoteExclusion.QuoteId}, expected QuoteId={Id}.");

        ValidateDuplicates(
            items: items,
            keySelector: e => e.Description,
            existingKeys: Exclusions.Select(e => e.Description),
            itemTypeName: "exclusions");

        foreach (var exclusion in items)
            Exclusions.Add(exclusion);
    }

    public void AddProgressPayment(IEnumerable<ProgressPayment> progressPayments)
    {
        ArgumentNullException.ThrowIfNull(progressPayments);

        var items = progressPayments.ToList();
        if (items.Count == 0)
        {
            throw new ArgumentException("ProgressPayment list cannot be empty", nameof(progressPayments));
        }

        var wrongQuotePayment = items.FirstOrDefault(item => item.QuoteId != Id);
        if (wrongQuotePayment != null)
        {
            throw new InvalidOperationException($"ProgressPayment Description = {wrongQuotePayment.Description} belongs to QuoteId={wrongQuotePayment.QuoteId}, expected QuoteId={Id}.");
        }

        ValidateDuplicates(
            items: items,
            keySelector: pp => pp.Description,
            existingKeys: ProgressPayments.Select(pp => pp.Description),
            itemTypeName: "progressPayment");

        foreach (var item in items)
            ProgressPayments.Add(item);
    }


    private static void ValidateDuplicates<T>(
        IEnumerable<T> items,
        Func<T, string> keySelector,
        IEnumerable<string>? existingKeys = null,
        string? itemTypeName = null)
    {
        ArgumentNullException.ThrowIfNull(items);

        if (keySelector == null)
            throw new InvalidOperationException(
                "descriptionSelector parameter is null.");

        var itemsList = items.ToList();
        if (itemsList.Count == 0)
            throw new ArgumentException($"{itemTypeName ?? "Items"} list cannot be empty.", nameof(items));

        var comparer = StringComparer.Ordinal;

        // request-internal duplicates
        var requestDescriptions = itemsList
            .Select(keySelector)
            .ToList();

        var duplicateWithinRequest = requestDescriptions
            .GroupBy(d => d, comparer)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();

        if (duplicateWithinRequest.Count > 0)
        {
            var itemType = itemTypeName ?? "items";
            throw new DuplicateKeyException(
                $"Duplicate {itemType} in the request: {string.Join(", ", duplicateWithinRequest)}",
                duplicateWithinRequest);
        }

        // duplicates vs existing
        if (existingKeys != null)
        {
            var existingSet = existingKeys
                .ToHashSet(comparer);

            var duplicateWithExisting = requestDescriptions
                .Where(existingSet.Contains)
                .Distinct(comparer)
                .ToList();

            if (duplicateWithExisting.Count > 0)
            {
                var itemType = itemTypeName ?? "items";
                throw new DuplicateKeyException(
                    $"The following {itemType} already exist in database: {string.Join(", ", duplicateWithExisting)}",
                    duplicateWithExisting);
            }
        }
    }

}