using System.Text.RegularExpressions;
using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Domain.Entities.QuoteAggregate;

public class Exclusion : BaseEntity<int>
{
    public string Description { get; private set; } = null!;
    public int QuoteId { get; private set; }

    public virtual Quote? Quote { get; private set; } = null!;

    protected Exclusion() { } // EF Core

    private Exclusion(
        int quoteId,
        string description)
    {
        QuoteId = quoteId;
        Description = description ?? throw new ArgumentNullException(nameof(description));
    }

    public static Exclusion Create(
        int quoteId,
        string description)
    {
        return new Exclusion(quoteId, NormalizeDescription(description));
    }

    internal void UpdateDescription(string description)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(description);
        Description = NormalizeDescription(description);
    }

    private static string NormalizeDescription(string description)
    {
        if (string.IsNullOrWhiteSpace(description))
            throw new ArgumentNullException(nameof(description));

        var trimmed = description.Trim();
        return trimmed;
    }

}