using System;
using SmartCompare.SharedKernel.Interfaces;

namespace SmartCompare.Domain.DomainEvents;

public sealed class ProjectCreatedEvent : IDomainEvent
{
    public int ProjectId { get; }
    public string ProjectName { get; }
    public Guid UserId { get; }

    public DateTime OccurredOn { get; }

    public Guid EventId { get; }

    public ProjectCreatedEvent(int projectId, string projectName, Guid userId)
    {
        ProjectId = projectId;
        ProjectName = projectName;
        UserId = userId;
        OccurredOn = DateTime.UtcNow;
        EventId = Guid.NewGuid();
    }
}