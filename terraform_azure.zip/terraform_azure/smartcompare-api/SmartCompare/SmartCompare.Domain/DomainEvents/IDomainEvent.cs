using System;

namespace SmartCompare.Domain.DomainEvents;

public interface IDomainEvent
{

}
