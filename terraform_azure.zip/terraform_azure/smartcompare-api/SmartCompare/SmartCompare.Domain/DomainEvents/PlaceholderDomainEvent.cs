using System;

namespace SmartCompare.Domain.DomainEvents;

public sealed class PlaceholderDomainEvent : IDomainEvent
{
    public DateTime OccurredOn { get; }
    public PlaceholderDomainEvent()
    {
        OccurredOn = DateTime.UtcNow;
    }
}