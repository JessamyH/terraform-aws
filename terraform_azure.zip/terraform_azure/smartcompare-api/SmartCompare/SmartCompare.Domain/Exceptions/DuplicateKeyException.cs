using SmartCompare.Domain.Exceptions;

namespace SmartCompare.Application.Exceptions;

public class DuplicateKeyException: DomainException
{
    public IReadOnlyList<string> DuplicateDescriptions { get; }
    
    public DuplicateKeyException(string message) : base(message)
    {
    }
    
    public DuplicateKeyException(string message, List<string> duplicateDescriptions) : base(message)
    {
        DuplicateDescriptions = duplicateDescriptions.AsReadOnly();
    }
    
}