using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Domain.ValueObjects;

public class PlaceholderValueObject : ValueObject
{
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        throw new NotImplementedException();
    }
}