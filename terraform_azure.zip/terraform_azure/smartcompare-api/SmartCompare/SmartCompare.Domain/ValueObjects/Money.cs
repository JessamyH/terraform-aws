using SmartCompare.SharedKernel.Common;

public sealed class Money : ValueObject
{
    public decimal Amount { get; }
    public string Currency { get; } = null!;
    private Money () {} // EF ctor, maps it as owned
    private Money (decimal amount, string currency)
    {
        Amount = amount;
        Currency = currency;
    }
    public static Money Create(decimal amount, string currency)
    {
        return new Money(amount, currency);
    }
    public Money ApplyOperation(Money other, MoneyOperation operation)
    {   
        if (other is null)
            throw new ArgumentNullException(nameof(other));

        if (other.Currency != Currency)
            throw new InvalidOperationException($"Cannot apply money operation between different currencies: {Currency} vs {other.Currency}");
        
        return ApplyOperation(other.Amount, operation);
    }
    public Money ApplyOperation(decimal value, MoneyOperation operation)
    {
        switch (operation)
        {
            case MoneyOperation.Divide:
                if (value <= 0)
                    throw new DivideByZeroException("Cannot divide money by zero or negative values.");
                break;

            case MoneyOperation.Multiply:
                if (value < 0)
                    throw new InvalidOperationException("Cannot multiply money by a negative value.");
                break;

            case MoneyOperation.Subtract:
                if (Amount - value < 0)
                    throw new InvalidOperationException("Resultant amount cannot be negative.");
                break;
        }

        return operation switch
        {
            MoneyOperation.Add      => Create(Amount + value, Currency),
            MoneyOperation.Subtract => Create(Amount - value, Currency),
            MoneyOperation.Multiply => Create(Amount * value, Currency),
            MoneyOperation.Divide   => Create(Amount / value, Currency),
            _ => throw new ArgumentOutOfRangeException(nameof(operation),
                    "Unsupported money operation.")
        };
    }
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Amount;
        yield return Currency;
    }
}