using SmartCompare.SharedKernel.Common;
using System.Text.RegularExpressions;
namespace SmartCompare.Domain.ValueObjects;
public sealed class EmailAddress : ValueObject
{
    public string Value { get; } = null!;
    private EmailAddress() { } // EF ctor, maps it as owned
    private EmailAddress(string emailString) => Value = emailString;
    public static EmailAddress Create(string emailString)
    {
        if (string.IsNullOrWhiteSpace(emailString))
            throw new ArgumentNullException("Email cannot be blank.", nameof(emailString));
        
        string EmailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
        if (!Regex.IsMatch(emailString, EmailPattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant))
        {
            throw new ArgumentException("Invalid email address.", nameof(emailString));
        }

        return new EmailAddress(emailString.Trim().ToLowerInvariant());
    }
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Value;
    }
}