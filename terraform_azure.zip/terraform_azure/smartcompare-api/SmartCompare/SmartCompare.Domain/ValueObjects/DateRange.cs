using SmartCompare.SharedKernel.Common;

public sealed class DateRange : ValueObject
{
    public DateTime StartDate { get; }
    public DateTime EndDate { get; }
    private DateRange() { }
    private DateRange(DateTime startDate, DateTime endDate)
    {
        StartDate = startDate;
        EndDate = endDate;
    }
    public static DateRange Create(DateTime startDate, DateTime endDate)
    {
        if (endDate < startDate)
            throw new ArgumentException("End date must be greater than or equal to start date.", nameof(endDate));
        return new DateRange(startDate, endDate);
    }

  protected override IEnumerable<object?> GetEqualityComponents()
  {
      yield return StartDate;
      yield return EndDate;
  }
}