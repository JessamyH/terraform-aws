using SmartCompare.SharedKernel.Common;

public sealed class Address : ValueObject
{
    public string? Street { get; }
    public string? Suburb { get; }
    public string? State { get; }
    public int? PostCode { get; }
    private Address() { } // EF ctor, maps it as owned
    private Address(string? street, string? suburb, string? state, int? postCode)
    {
        Street = street;
        Suburb = suburb;
        State = state;
        PostCode = postCode;
    }
    public static Address Create(string? street, string? suburb, string? state, int? postCode)
    {
        return new Address(street, suburb, state, postCode);
    }
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Street;
        yield return Suburb;
        yield return State;
        yield return PostCode;
    }
}