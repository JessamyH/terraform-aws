using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Domain.ValueObjects;

public class BankAccount : ValueObject
{
    public string BSB { get; private set; } = null!;
    public string AccountNumber { get; private set; } = null!;

    private BankAccount() { } // EF Core constructor

    private BankAccount(string bsb, string accountNumber)
    {
        BSB = bsb;
        AccountNumber = accountNumber;
    }

    public static BankAccount Create(string bsb, string accountNumber)
    {
        if (string.IsNullOrWhiteSpace(bsb))
            throw new ArgumentException("BSB cannot be empty", nameof(bsb));

        if (string.IsNullOrWhiteSpace(accountNumber))
            throw new ArgumentException("Account number cannot be empty", nameof(accountNumber));

        var cleanedBsb = bsb.Replace(" ", "").Replace("-", "");
        if (cleanedBsb.Length != 6 || !cleanedBsb.All(char.IsDigit))
            throw new ArgumentException("BSB must be 6 digits", nameof(bsb));

        var cleanedAccount = accountNumber.Replace(" ", "").Replace("-", "");
        if (!cleanedAccount.All(char.IsDigit))
            throw new ArgumentException("Account number must contain only digits", nameof(accountNumber));

        return new BankAccount(cleanedBsb, cleanedAccount);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return BSB;
        yield return AccountNumber;
    }
}
