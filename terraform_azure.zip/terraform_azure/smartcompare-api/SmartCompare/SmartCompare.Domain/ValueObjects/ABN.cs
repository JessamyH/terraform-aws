using SmartCompare.SharedKernel.Common;

namespace SmartCompare.Domain.ValueObjects;

public class ABN : ValueObject
{
    public string Value { get; private set; } = null!;
    private ABN () {} // EF ctor, maps it as owned
    private ABN(string value)
    {
        Value = value;
    }

    public static ABN Create(string abn)
    {
        if (string.IsNullOrWhiteSpace(abn))
            throw new ArgumentException("ABN is required", nameof(abn));

        var digits = new string(abn.Where(char.IsDigit).ToArray());
        if (digits.Length != 11)
            throw new ArgumentException("ABN must be exactly 11 digits", nameof(abn));

        if (!IsValidAbnChecksum(digits))
            throw new ArgumentException("Invalid ABN checksum", nameof(abn));

        return new ABN(digits);
    }

    private static bool IsValidAbnChecksum(string abn)
    {
        // ABN checksum validation
        // Subtract 1 from the first digit, multiply each digit by its weight, sum the results
        // Valid if sum is divisible by 89
        int[] weights = { 10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19 };

        int sum = 0;
        for (int i = 0; i < 11; i++)
        {
            int digit = abn[i] - '0';
            if (i == 0)
                digit -= 1;

            sum += digit * weights[i];
        }

        return sum % 89 == 0;
    }
    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Value;
    }
}
