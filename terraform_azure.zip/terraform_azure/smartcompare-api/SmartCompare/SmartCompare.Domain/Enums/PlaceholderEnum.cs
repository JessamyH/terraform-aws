namespace SmartCompare.Domain.Enums;
public enum PlaceholderEnum
{
    None = 0,
    Option1 = 1,
    Option2 = 2
}

