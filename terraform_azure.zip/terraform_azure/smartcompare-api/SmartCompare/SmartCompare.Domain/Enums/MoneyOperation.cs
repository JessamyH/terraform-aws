public enum MoneyOperation
{
    Add,
    Subtract,
    Multiply,
    Divide
}