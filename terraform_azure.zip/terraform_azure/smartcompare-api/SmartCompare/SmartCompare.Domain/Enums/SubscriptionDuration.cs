namespace SmartCompare.Domain.Enums;

public enum SubscriptionDuration
{
    None = 0,
    Month = 1,
    Year = 2
}
