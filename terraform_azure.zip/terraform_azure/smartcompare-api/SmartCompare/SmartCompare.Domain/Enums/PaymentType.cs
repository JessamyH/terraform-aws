namespace SmartCompare.Domain.Enums;

public enum PaymentType
{
    Subscription = 0,
    OneTime = 1,
    Upgrade = 2,
    Refund = 3
}