namespace SmartCompare.Domain.Enums;

public enum HouseType
{
    House = 0,
    Apartment = 1,
    Townhouse = 2,
    Unit = 3,
    Other = 4
}
