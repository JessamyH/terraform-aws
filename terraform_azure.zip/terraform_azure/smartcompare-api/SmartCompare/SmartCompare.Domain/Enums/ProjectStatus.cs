namespace SmartCompare.Domain.Enums;
public enum ProjectStatus
{
    Inquiry = 0,
    QuoteSent = 1,
    QuoteApproved = 2,
    Scheduled = 3,
    InProgress = 4,
    OnHold = 5,
    Completed = 6,
    Invoiced = 7,
    Paid = 8,
    Cancelled = 9
}