using System.Security.Claims;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.API.Middleware;
using SmartCompare.Infrastructure.Identity;

namespace SmartCompare.UnitTests.Middleware;

public class SelectiveClaimsRefreshMiddlewareTests
{
    private readonly Mock<IClaimsRefreshService> _mockClaimsRefresh;
    private readonly Mock<ILogger<SelectiveClaimsRefreshMiddleware>> _mockLogger;
    private bool _nextCalled;

    private const string RefreshPath = "/api/ProtectedControllerSample/sync-role";
    private const string Auth0SubjectId = "auth0|test123";

    public SelectiveClaimsRefreshMiddlewareTests()
    {
        _mockClaimsRefresh = new Mock<IClaimsRefreshService>();
        _mockLogger = new Mock<ILogger<SelectiveClaimsRefreshMiddleware>>();
    }

    private SelectiveClaimsRefreshMiddleware CreateMiddleware()
    {
        _nextCalled = false;
        RequestDelegate next = _ => { _nextCalled = true; return Task.CompletedTask; };

        var config = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                { "Authorization:RefreshRoleClaimPaths:0", RefreshPath }
            })
            .Build();

        return new SelectiveClaimsRefreshMiddleware(next, _mockLogger.Object, config);
    }

    private static DefaultHttpContext CreateAuthenticatedContext(string path, string? subjectId = Auth0SubjectId)
    {
        var context = new DefaultHttpContext();
        context.Request.Path = path;

        var claims = new List<Claim>();
        if (subjectId is not null)
            claims.Add(new Claim(ClaimTypes.NameIdentifier, subjectId));

        var identity = new ClaimsIdentity(claims, "TestAuth");
        context.User = new ClaimsPrincipal(identity);
        return context;
    }

    private static DefaultHttpContext CreateAnonymousContext(string path)
    {
        var context = new DefaultHttpContext();
        context.Request.Path = path;
        return context;
    }

    [Fact]
    public async Task InvokeAsync_WhenPathNotInRefreshList_ShouldCallNextWithoutRefresh()
    {
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext("/api/quotes");

        await middleware.InvokeAsync(context, _mockClaimsRefresh.Object);

        _nextCalled.Should().BeTrue();
        _mockClaimsRefresh.Verify(
            x => x.RefreshClaimsAndReissueCookieAsync(It.IsAny<HttpContext>(), It.IsAny<ClaimsPrincipal>(), It.IsAny<string>()),
            Times.Never);
    }

    [Fact]
    public async Task InvokeAsync_WhenNotAuthenticated_ShouldCallNextWithoutRefresh()
    {
        var middleware = CreateMiddleware();
        var context = CreateAnonymousContext(RefreshPath);

        await middleware.InvokeAsync(context, _mockClaimsRefresh.Object);

        _nextCalled.Should().BeTrue();
        _mockClaimsRefresh.Verify(
            x => x.RefreshClaimsAndReissueCookieAsync(It.IsAny<HttpContext>(), It.IsAny<ClaimsPrincipal>(), It.IsAny<string>()),
            Times.Never);
    }

    [Fact]
    public async Task InvokeAsync_WhenAuthenticatedOnRefreshPath_ShouldRefreshClaims()
    {
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext(RefreshPath);
        var refreshedPrincipal = new ClaimsPrincipal(
            new ClaimsIdentity(new[] { new Claim(ClaimTypes.NameIdentifier, Auth0SubjectId), new Claim(ClaimTypes.Role, "Admin") }, "TestAuth"));

        _mockClaimsRefresh
            .Setup(x => x.RefreshClaimsAndReissueCookieAsync(context, It.IsAny<ClaimsPrincipal>(), Auth0SubjectId))
            .ReturnsAsync(refreshedPrincipal);

        await middleware.InvokeAsync(context, _mockClaimsRefresh.Object);

        _nextCalled.Should().BeTrue();
        context.User.Should().BeSameAs(refreshedPrincipal);
    }

    [Fact]
    public async Task InvokeAsync_WhenRefreshReturnsNull_ShouldKeepOriginalPrincipal()
    {
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext(RefreshPath);
        var originalUser = context.User;

        _mockClaimsRefresh
            .Setup(x => x.RefreshClaimsAndReissueCookieAsync(context, It.IsAny<ClaimsPrincipal>(), Auth0SubjectId))
            .ReturnsAsync((ClaimsPrincipal?)null);

        await middleware.InvokeAsync(context, _mockClaimsRefresh.Object);

        _nextCalled.Should().BeTrue();
        context.User.Should().BeSameAs(originalUser);
    }

    [Fact]
    public async Task InvokeAsync_WhenRefreshThrows_ShouldContinueWithoutRefresh()
    {
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext(RefreshPath);
        var originalUser = context.User;

        _mockClaimsRefresh
            .Setup(x => x.RefreshClaimsAndReissueCookieAsync(context, It.IsAny<ClaimsPrincipal>(), Auth0SubjectId))
            .ThrowsAsync(new InvalidOperationException("DB connection failed"));

        await middleware.InvokeAsync(context, _mockClaimsRefresh.Object);

        _nextCalled.Should().BeTrue();
        context.User.Should().BeSameAs(originalUser);
    }

    [Fact]
    public async Task InvokeAsync_WhenSubjectIdMissing_ShouldSkipRefreshAndCallNext()
    {
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext(RefreshPath, subjectId: null);

        await middleware.InvokeAsync(context, _mockClaimsRefresh.Object);

        _nextCalled.Should().BeTrue();
        _mockClaimsRefresh.Verify(
            x => x.RefreshClaimsAndReissueCookieAsync(It.IsAny<HttpContext>(), It.IsAny<ClaimsPrincipal>(), It.IsAny<string>()),
            Times.Never);
    }

    [Fact]
    public void Constructor_WhenRefreshPathsNotConfigured_ShouldThrow()
    {
        var config = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>())
            .Build();

        var act = () => new SelectiveClaimsRefreshMiddleware(
            _ => Task.CompletedTask, _mockLogger.Object, config);

        act.Should().Throw<InvalidOperationException>()
            .WithMessage("*RefreshRoleClaimPaths*");
    }

    [Fact]
    public async Task InvokeAsync_WhenPathMatchesCaseInsensitive_ShouldRefreshClaims()
    {
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext(RefreshPath.ToUpperInvariant());

        _mockClaimsRefresh
            .Setup(x => x.RefreshClaimsAndReissueCookieAsync(context, It.IsAny<ClaimsPrincipal>(), Auth0SubjectId))
            .ReturnsAsync(context.User);

        await middleware.InvokeAsync(context, _mockClaimsRefresh.Object);

        _mockClaimsRefresh.Verify(
            x => x.RefreshClaimsAndReissueCookieAsync(It.IsAny<HttpContext>(), It.IsAny<ClaimsPrincipal>(), Auth0SubjectId),
            Times.Once);
    }
}
