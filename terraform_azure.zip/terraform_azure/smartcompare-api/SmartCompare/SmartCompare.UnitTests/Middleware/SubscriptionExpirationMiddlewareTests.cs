using System.Security.Claims;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.API.Middleware;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Enums;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.UnitTests.Factories;
using User = SmartCompare.Domain.Entities.UserAggregate.User;

namespace SmartCompare.UnitTests.Middleware;

public class SubscriptionExpirationMiddlewareTests
{
    private readonly Mock<ISubscriptionQueries> _mockSubscriptionQueries;
    private readonly Mock<IUserRepository> _mockUserRepository;
    private readonly Mock<IUnitOfWork> _mockUnitOfWork;
    private readonly IMemoryCache _cache;
    private readonly Mock<ILogger<SubscriptionExpirationMiddleware>> _mockLogger;
    private bool _nextCalled;

    private const string DefaultAuth0SubjectId = "auth0|test123";

    public SubscriptionExpirationMiddlewareTests()
    {
        _mockSubscriptionQueries = new Mock<ISubscriptionQueries>();
        _mockUserRepository = new Mock<IUserRepository>();
        _mockUnitOfWork = new Mock<IUnitOfWork>();
        _cache = new MemoryCache(new MemoryCacheOptions());
        _mockLogger = new Mock<ILogger<SubscriptionExpirationMiddleware>>();
        _nextCalled = false;
    }

    private SubscriptionExpirationMiddleware CreateMiddleware()
    {
        return new SubscriptionExpirationMiddleware(
            next: _ => { _nextCalled = true; return Task.CompletedTask; },
            logger: _mockLogger.Object,
            cache: _cache);
    }

    private async Task InvokeMiddleware(SubscriptionExpirationMiddleware middleware, HttpContext context)
    {
        await middleware.InvokeAsync(
            context,
            _mockSubscriptionQueries.Object,
            _mockUserRepository.Object,
            _mockUnitOfWork.Object);
    }

    private static HttpContext CreateAuthenticatedContext(string auth0SubjectId = DefaultAuth0SubjectId)
    {
        var context = new DefaultHttpContext();
        var claims = new[] { new Claim(ClaimTypes.NameIdentifier, auth0SubjectId) };
        var identity = new ClaimsIdentity(claims, "TestAuth");
        context.User = new ClaimsPrincipal(identity);
        return context;
    }

    #region Unauthenticated / Skip Scenarios

    [Fact]
    public async Task InvokeAsync_WhenUnauthenticated_ShouldCallNextWithoutDbCheck()
    {
        // Arrange
        var middleware = CreateMiddleware();
        var context = new DefaultHttpContext();

        // Act
        await InvokeMiddleware(middleware, context);

        // Assert
        _nextCalled.Should().BeTrue();
        _mockSubscriptionQueries.Verify(
            x => x.IsSubscriptionExpiredAsync(
                It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task InvokeAsync_WhenCacheHit_ShouldSkipDbCheck()
    {
        // Arrange
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext();
        _cache.Set($"sub_expiry_checked:{DefaultAuth0SubjectId}", true, TimeSpan.FromMinutes(5));

        // Act
        await InvokeMiddleware(middleware, context);

        // Assert
        _nextCalled.Should().BeTrue();
        _mockSubscriptionQueries.Verify(
            x => x.IsSubscriptionExpiredAsync(
                It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    #endregion

    #region Subscription Not Expired

    [Fact]
    public async Task InvokeAsync_WhenSubscriptionNotExpired_ShouldNotLoadEntityOrSave()
    {
        // Arrange
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext();

        _mockSubscriptionQueries
            .Setup(x => x.IsSubscriptionExpiredAsync(
                DefaultAuth0SubjectId, It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);

        // Act
        await InvokeMiddleware(middleware, context);

        // Assert
        _nextCalled.Should().BeTrue();
        _mockUserRepository.Verify(
            x => x.GetBySubjectIdWithSubscriptionAsync(
                It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
        _mockUnitOfWork.Verify(
            x => x.SaveChangesAsync(It.IsAny<CancellationToken>()),
            Times.Never);
    }

    #endregion

    #region Subscription Expired — Mutation

    [Fact]
    public async Task InvokeAsync_WhenSubscriptionExpired_ShouldExpireAndSave()
    {
        // Arrange
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext();

        _mockSubscriptionQueries
            .Setup(x => x.IsSubscriptionExpiredAsync(
                DefaultAuth0SubjectId, It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        var user = TestEntityFactory.CreateUserWithExpiredSubscription();
        _mockUserRepository
            .Setup(x => x.GetBySubjectIdWithSubscriptionAsync(
                DefaultAuth0SubjectId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);

        // Act
        await InvokeMiddleware(middleware, context);

        // Assert
        _nextCalled.Should().BeTrue();
        user.Subscription!.SubscriptionStatus.Should().Be(SubscriptionStatus.Expired);
        user.Subscription.SubscriptionTier.Should().Be(SubscriptionTier.Free);
        user.Subscription.SubscriptionDuration.Should().Be(SubscriptionDuration.None);
        user.Subscription.StripeSubscriptionId.Should().BeNull();
        _mockUnitOfWork.Verify(
            x => x.SaveChangesAsync(It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task InvokeAsync_WhenExpiredQueryTrueButUserNull_ShouldNotSave()
    {
        // Arrange
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext();

        _mockSubscriptionQueries
            .Setup(x => x.IsSubscriptionExpiredAsync(
                DefaultAuth0SubjectId, It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        _mockUserRepository
            .Setup(x => x.GetBySubjectIdWithSubscriptionAsync(
                DefaultAuth0SubjectId, It.IsAny<CancellationToken>()))
            .ReturnsAsync((User?)null);

        // Act
        await InvokeMiddleware(middleware, context);

        // Assert
        _nextCalled.Should().BeTrue();
        _mockUnitOfWork.Verify(
            x => x.SaveChangesAsync(It.IsAny<CancellationToken>()),
            Times.Never);
    }

    #endregion

    #region Error Handling

    [Fact]
    public async Task InvokeAsync_WhenExceptionThrown_ShouldLogErrorAndCallNext()
    {
        // Arrange
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext();

        _mockSubscriptionQueries
            .Setup(x => x.IsSubscriptionExpiredAsync(
                DefaultAuth0SubjectId, It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new InvalidOperationException("DB connection failed"));

        // Act
        await InvokeMiddleware(middleware, context);

        // Assert
        _nextCalled.Should().BeTrue();
        _mockUnitOfWork.Verify(
            x => x.SaveChangesAsync(It.IsAny<CancellationToken>()),
            Times.Never);
    }

    #endregion

    #region Caching Behavior

    [Fact]
    public async Task InvokeAsync_AfterSuccessfulCheck_ShouldCacheAndSkipSecondCall()
    {
        // Arrange
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext();

        _mockSubscriptionQueries
            .Setup(x => x.IsSubscriptionExpiredAsync(
                DefaultAuth0SubjectId, It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);

        // Act — first call triggers DB check
        await InvokeMiddleware(middleware, context);

        // Reset tracking
        _mockSubscriptionQueries.Invocations.Clear();
        _nextCalled = false;

        // Act — second call should hit cache
        await InvokeMiddleware(middleware, context);

        // Assert
        _nextCalled.Should().BeTrue();
        _mockSubscriptionQueries.Verify(
            x => x.IsSubscriptionExpiredAsync(
                It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task InvokeAsync_WhenExceptionThrown_ShouldNotCacheAndRetryNextRequest()
    {
        // Arrange
        var middleware = CreateMiddleware();
        var context = CreateAuthenticatedContext();

        _mockSubscriptionQueries
            .Setup(x => x.IsSubscriptionExpiredAsync(
                DefaultAuth0SubjectId, It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new InvalidOperationException("DB down"));

        // Act — first call fails
        await InvokeMiddleware(middleware, context);
        _mockSubscriptionQueries.Invocations.Clear();

        // Fix DB — second call should retry (not cached)
        _mockSubscriptionQueries
            .Setup(x => x.IsSubscriptionExpiredAsync(
                DefaultAuth0SubjectId, It.IsAny<DateTime>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);

        _nextCalled = false;
        await InvokeMiddleware(middleware, context);

        // Assert — DB was queried again on second call
        _nextCalled.Should().BeTrue();
        _mockSubscriptionQueries.Verify(
            x => x.IsSubscriptionExpiredAsync(
                DefaultAuth0SubjectId, It.IsAny<DateTime>(), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    #endregion
}
