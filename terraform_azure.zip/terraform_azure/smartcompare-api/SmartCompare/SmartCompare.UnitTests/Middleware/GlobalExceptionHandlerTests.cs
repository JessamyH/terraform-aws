using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.API.Middleware;
using SmartCompare.Application.Exceptions;

namespace SmartCompare.UnitTests.Middleware;

public class GlobalExceptionHandlerTests
{
    private readonly GlobalExceptionHandler _handler;
    private readonly Mock<ILogger<GlobalExceptionHandler>> _mockLogger;

    public GlobalExceptionHandlerTests()
    {
        _mockLogger = new Mock<ILogger<GlobalExceptionHandler>>();
        _handler = new GlobalExceptionHandler(_mockLogger.Object);
    }

    private static DefaultHttpContext CreateHttpContext()
    {
        var context = new DefaultHttpContext();
        context.Response.Body = new MemoryStream();
        context.Request.Path = "/api/test";
        context.Request.Method = "POST";
        return context;
    }

    [Fact]
    public async Task TryHandleAsync_DuplicateKeyException_Returns409()
    {
        var context = CreateHttpContext();
        var exception = new DuplicateKeyException("Duplicate found", ["key1"]);

        var handled = await _handler.TryHandleAsync(context, exception, CancellationToken.None);

        handled.Should().BeTrue();
        context.Response.StatusCode.Should().Be(StatusCodes.Status409Conflict);
    }

    [Fact]
    public async Task TryHandleAsync_ArgumentException_Returns400()
    {
        var context = CreateHttpContext();
        var exception = new ArgumentException("Invalid input");

        var handled = await _handler.TryHandleAsync(context, exception, CancellationToken.None);

        handled.Should().BeTrue();
        context.Response.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
    }

    [Fact]
    public async Task TryHandleAsync_OperationCanceledException_Returns499()
    {
        var context = CreateHttpContext();
        var exception = new OperationCanceledException();

        var handled = await _handler.TryHandleAsync(context, exception, CancellationToken.None);

        handled.Should().BeTrue();
        context.Response.StatusCode.Should().Be(StatusCodes.Status499ClientClosedRequest);
    }

    [Fact]
    public async Task TryHandleAsync_UnauthorizedAccessException_Returns401()
    {
        var context = CreateHttpContext();
        var exception = new UnauthorizedAccessException("No access");

        var handled = await _handler.TryHandleAsync(context, exception, CancellationToken.None);

        handled.Should().BeTrue();
        context.Response.StatusCode.Should().Be(StatusCodes.Status401Unauthorized);
    }

    [Fact]
    public async Task TryHandleAsync_UnexpectedException_Returns500()
    {
        var context = CreateHttpContext();
        var exception = new InvalidOperationException("Something went wrong");

        var handled = await _handler.TryHandleAsync(context, exception, CancellationToken.None);

        handled.Should().BeTrue();
        context.Response.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
    }

    [Fact]
    public async Task TryHandleAsync_NullHttpContext_ReturnsFalse()
    {
        var handled = await _handler.TryHandleAsync(null!, new Exception(), CancellationToken.None);

        handled.Should().BeFalse();
    }

    [Fact]
    public async Task TryHandleAsync_NullException_ReturnsFalse()
    {
        var context = CreateHttpContext();

        var handled = await _handler.TryHandleAsync(context, null!, CancellationToken.None);

        handled.Should().BeFalse();
    }

    [Fact]
    public async Task TryHandleAsync_SetsContentTypeToJson()
    {
        var context = CreateHttpContext();
        var exception = new ArgumentException("test");

        await _handler.TryHandleAsync(context, exception, CancellationToken.None);

        context.Response.ContentType.Should().StartWith("application/json");
    }
}
