using FluentAssertions;
using SmartCompare.Application.Queries.Dashboard.GetRecentQuotes;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.Validators.Dashboard;

public class GetRecentQuotesValidatorTests
{
    private readonly GetRecentQuotesValidator _validator = new();

    [Fact]
    public void Validate_WhenAuth0SubjectIdEmpty_ShouldFail()
    {
        var query = new GetRecentQuotesQuery(string.Empty, 3);
        var result = _validator.Validate(query);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e =>
            e.PropertyName == "Auth0SubjectId");
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void Validate_WhenCountBelowMinimum_ShouldFail(int count)
    {
        var query = new GetRecentQuotesQuery(
            TestConstants.Auth0.DefaultSubjectId, count);
        var result = _validator.Validate(query);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e =>
            e.PropertyName == "Count");
    }

    [Theory]
    [InlineData(11)]
    [InlineData(100)]
    public void Validate_WhenCountAboveMaximum_ShouldFail(int count)
    {
        var query = new GetRecentQuotesQuery(
            TestConstants.Auth0.DefaultSubjectId, count);
        var result = _validator.Validate(query);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e =>
            e.PropertyName == "Count");
    }

    [Theory]
    [InlineData(1)]
    [InlineData(5)]
    [InlineData(10)]
    public void Validate_WhenCountWithinRange_ShouldPass(int count)
    {
        var query = new GetRecentQuotesQuery(
            TestConstants.Auth0.DefaultSubjectId, count);
        var result = _validator.Validate(query);

        result.IsValid.Should().BeTrue();
    }
}
