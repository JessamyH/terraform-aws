using FluentValidation.TestHelper;
using SmartCompare.Application.Commands.Quotes.AddProgressPayments;
using SmartCompare.Application.DTOs.Quote;

namespace SmartCompare.UnitTests.Validators.Quotes;

/// <summary>
/// Tests custom business rules: collection max count (Must <= 100),
/// nested validator wiring (SetValidator). Framework rules not tested.
/// </summary>
public class AddProgressPaymentValidatorTests
{
    private readonly AddProgressPaymentValidator _validator = new();

    private static AddProgressPaymentCommand ValidCommand() => new(
        QuotePublicId: Guid.NewGuid(),
        Auth0SubjectId: "auth0|12345",
        Items: [new AddProgressPaymentRequestDto { Description = "Progress payment", Percentage = 25m }]
    );

    // ========== Collection max count (custom Must rule) ==========

    [Fact]
    public void Items_Exactly100_NoError()
    {
        var items = Enumerable.Range(1, 100)
            .Select(i => new AddProgressPaymentRequestDto { Description = $"Payment {i}", Percentage = 1m })
            .ToList();
        var command = ValidCommand() with { Items = items };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.Items);
    }

    [Fact]
    public void Items_Over100_HasError()
    {
        var items = Enumerable.Range(1, 101)
            .Select(i => new AddProgressPaymentRequestDto { Description = $"Payment {i}", Percentage = 1m })
            .ToList();
        var command = ValidCommand() with { Items = items };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.Items)
            .WithErrorCode("ITEMS_MAX_COUNT");
    }

    // ========== Nested validator wiring (SetValidator) ==========

    [Fact]
    public void Items_EmptyDescription_HasNestedError()
    {
        var command = ValidCommand() with
        {
            Items = [new AddProgressPaymentRequestDto { Description = "", Percentage = 25m }]
        };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor("Items[0].Description")
            .WithErrorCode("DESCRIPTION_REQUIRED");
    }

    [Fact]
    public void Items_DescriptionTooLong_HasNestedError()
    {
        var command = ValidCommand() with
        {
            Items = [new AddProgressPaymentRequestDto { Description = new string('A', 1001), Percentage = 25m }]
        };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor("Items[0].Description")
            .WithErrorCode("DESCRIPTION_MAX_LENGTH");
    }
}
