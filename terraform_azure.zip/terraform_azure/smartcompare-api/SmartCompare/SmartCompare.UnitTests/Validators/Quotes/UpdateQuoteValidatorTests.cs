using FluentAssertions;
using FluentValidation.TestHelper;
using SmartCompare.Application.Commands.Quotes.UpdateQuote;
using SmartCompare.Application.DTOs.Quote;

namespace SmartCompare.UnitTests.Validators.Quotes;

/// <summary>
/// Tests custom business rules: When(dto != null) guard, ValidDate > IssuedDate,
/// conditional URL validation. Framework rules not tested.
/// </summary>
public class UpdateQuoteValidatorTests
{
    private readonly UpdateQuoteValidator _validator = new();

    private static UpdateQuoteCommand ValidCommand() => new(
        quotePublicId: Guid.NewGuid(),
        auth0SubjectId: "auth0|12345",
        updateQuoteDto: new UpdateQuoteDto
        {
            QuoteNumber = "QUO-001",
            IssuedDate = DateTime.UtcNow.AddDays(-7),
            ValidPeriod = 30,
            IssuedBy = "Builder Co",
            IssuedTo = "Client Ltd",
            SubTotal = 1000m,
            GST = 100m,
            ABN = "51824753556",
            LicenseNumber = "LIC-001",
            ContactName = "Test Contact",
            ContactEmail = "contact@test.com",
            ContactPhone = "0400000000",
            PDFUrl = null
        }
    );

    // ========== When(dto != null) guard ==========

    [Fact]
    public void UpdateQuoteDto_Null_HasError()
    {
        var command = ValidCommand() with { UpdateQuoteDto = null! };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.UpdateQuoteDto);
    }

    [Fact]
    public void UpdateQuoteDto_Null_DoesNotThrowNRE()
    {
        // Unlike the Update sub-entity validators, this one has When() guard
        var command = ValidCommand() with { UpdateQuoteDto = null! };

        var act = () => _validator.TestValidate(command);

        act.Should().NotThrow<NullReferenceException>();
    }

    // ========== ValidPeriod ==========

    [Fact]
    public void ValidPeriod_One_NoError()
    {
        var command = ValidCommand() with
        {
            UpdateQuoteDto = ValidCommand().UpdateQuoteDto with { ValidPeriod = 1 }
        };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.UpdateQuoteDto.ValidPeriod);
    }

    [Fact]
    public void ValidPeriod_Zero_HasError()
    {
        var command = ValidCommand() with
        {
            UpdateQuoteDto = ValidCommand().UpdateQuoteDto with { ValidPeriod = 0 }
        };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.UpdateQuoteDto.ValidPeriod);
    }

    [Fact]
    public void ValidPeriod_365_NoError()
    {
        var command = ValidCommand() with
        {
            UpdateQuoteDto = ValidCommand().UpdateQuoteDto with { ValidPeriod = 365 }
        };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.UpdateQuoteDto.ValidPeriod);
    }

    [Fact]
    public void ValidPeriod_366_HasError()
    {
        var command = ValidCommand() with
        {
            UpdateQuoteDto = ValidCommand().UpdateQuoteDto with { ValidPeriod = 366 }
        };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.UpdateQuoteDto.ValidPeriod);
    }

    // ========== Conditional PDFUrl (When + Must) ==========

    [Fact]
    public void PDFUrl_Null_NoError()
    {
        var command = ValidCommand() with
        {
            UpdateQuoteDto = ValidCommand().UpdateQuoteDto with { PDFUrl = null }
        };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.UpdateQuoteDto.PDFUrl);
    }

    [Fact]
    public void PDFUrl_ValidUrl_NoError()
    {
        var command = ValidCommand() with
        {
            UpdateQuoteDto = ValidCommand().UpdateQuoteDto with { PDFUrl = "https://example.com/q.pdf" }
        };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.UpdateQuoteDto.PDFUrl);
    }

    [Fact]
    public void PDFUrl_InvalidUrl_HasError()
    {
        var command = ValidCommand() with
        {
            UpdateQuoteDto = ValidCommand().UpdateQuoteDto with { PDFUrl = "not-a-url" }
        };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.UpdateQuoteDto.PDFUrl);
    }
}
