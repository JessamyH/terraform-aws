using FluentValidation.TestHelper;
using SmartCompare.Application.Commands.Quotes.CreateQuote;

namespace SmartCompare.UnitTests.Validators.Quotes;

/// <summary>
/// Tests custom business rules only: decimal precision, regex, cross-field calculation,
/// conditional URL validation, date range logic. Framework rules (NotEmpty, MaxLength) not tested.
/// </summary>
public class CreateQuoteCommandValidatorTests
{
    private readonly CreateQuoteCommandValidator _validator = new();

    private static CreateQuoteCommand ValidCommand() => new(
        ProjectPublicId: Guid.NewGuid(),
        Auth0SubjectId: "auth0|12345",
        QuoteNumber: "QUO-001",
        IssuedDate: DateTime.UtcNow,
        ValidPeriod: 30,
        IssuedTo: "Client Ltd",
        IssuedBy: "Builder Co",
        SubTotal: 1000m,
        GST: 100m,
        ABN: "51824753556",
        LicenseNumber: "LIC-001",
        ContactName: "Test Contact",
        ContactEmail: "contact@test.com",
        ContactPhone: "0400000000",
        PDFUrl: "https://example.com/quote.pdf"
    );

    // ========== QuoteNumber Regex (custom format rule) ==========

    [Theory]
    [InlineData("QUO-001")]
    [InlineData("INV/2025.01")]
    [InlineData("A_B-C/D.E")]
    public void QuoteNumber_ValidFormat_NoError(string quoteNumber)
    {
        var command = ValidCommand() with { QuoteNumber = quoteNumber };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.QuoteNumber);
    }

    [Theory]
    [InlineData("QUO 001")]       // space
    [InlineData("QUO#001")]       // hash
    [InlineData("报价单-001")]     // unicode
    public void QuoteNumber_InvalidFormat_HasError(string quoteNumber)
    {
        var command = ValidCommand() with { QuoteNumber = quoteNumber };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.QuoteNumber)
            .WithErrorCode("QUOTE_NUMBER_INVALID_FORMAT");
    }

    // ========== Decimal Precision (custom Must rule) ==========

    [Theory]
    [InlineData(1000.001)]  // 3 decimal places
    [InlineData(500.999)]
    public void SubTotal_MoreThan2Decimals_HasError(double value)
    {
        var subTotal = (decimal)value;
        var command = ValidCommand() with { SubTotal = subTotal, GST = 100m };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.SubTotal)
            .WithErrorCode("SUBTOTAL_DECIMAL_PLACES_INVALID");
    }

    [Theory]
    [InlineData(100.001)]
    [InlineData(50.555)]
    public void GST_MoreThan2Decimals_HasError(double value)
    {
        var gst = (decimal)value;
        var command = ValidCommand() with { GST = gst, SubTotal = 1000m };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.GST)
            .WithErrorCode("GST_DECIMAL_PLACES_INVALID");
    }

    // ========== SubTotal and GST both zero (custom Custom rule) ==========

    [Fact]
    public void SubTotalAndGst_BothZero_HasError()
    {
        var command = ValidCommand() with { SubTotal = 0m, GST = 0m };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor("SubTotal")
            .WithErrorCode("SUBTOTAL_AND_GST_BOTH_ZERO");
    }

    [Fact]
    public void SubTotalZero_GstNonZero_NoBothZeroError()
    {
        // SubTotal=0 will fail other rules (NotEmpty, GreaterThan), but must NOT trigger BOTH_ZERO
        var command = ValidCommand() with { SubTotal = 0m, GST = 100m };

        var result = _validator.TestValidate(command);

        var subTotalErrors = result.ShouldHaveValidationErrorFor("SubTotal");
        subTotalErrors.WithoutErrorCode("SUBTOTAL_AND_GST_BOTH_ZERO");
    }

    // ========== Conditional PDFUrl validation (When + Must) ==========

    [Fact]
    public void PDFUrl_Null_NoError()
    {
        var command = ValidCommand() with { PDFUrl = null! };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.PDFUrl);
    }

    [Fact]
    public void PDFUrl_Empty_NoError()
    {
        var command = ValidCommand() with { PDFUrl = "" };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.PDFUrl);
    }

    [Fact]
    public void PDFUrl_ValidHttps_NoError()
    {
        var command = ValidCommand() with { PDFUrl = "https://storage.blob.core.windows.net/quotes/q1.pdf" };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.PDFUrl);
    }

    [Fact]
    public void PDFUrl_NotAUrl_HasError()
    {
        var command = ValidCommand() with { PDFUrl = "not-a-url" };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.PDFUrl)
            .WithErrorCode("PDF_URL_INVALID");
    }

    [Fact]
    public void PDFUrl_FtpScheme_HasError()
    {
        // BeValidUrl only allows http/https
        var command = ValidCommand() with { PDFUrl = "ftp://files.example.com/quote.pdf" };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.PDFUrl)
            .WithErrorCode("PDF_URL_INVALID");
    }

    // ========== IssuedDate range (must not be more than 10 years in the past) ==========

    [Fact]
    public void IssuedDate_MoreThan10YearsAgo_HasError()
    {
        var command = ValidCommand() with { IssuedDate = DateTime.UtcNow.AddYears(-10).AddDays(-1) };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.IssuedDate)
            .WithErrorCode("ISSUED_DATE_TOO_OLD");
    }

    [Fact]
    public void IssuedDate_RecentPast_NoError()
    {
        var command = ValidCommand() with { IssuedDate = DateTime.UtcNow.AddDays(-30) };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.IssuedDate);
    }

    // ========== ValidPeriod range ==========

    [Fact]
    public void ValidPeriod_Zero_HasError()
    {
        var command = ValidCommand() with { ValidPeriod = 0 };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.ValidPeriod)
            .WithErrorCode("VALID_PERIOD_TOO_SMALL");
    }

    [Fact]
    public void ValidPeriod_366_HasError()
    {
        var command = ValidCommand() with { ValidPeriod = 366 };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.ValidPeriod)
            .WithErrorCode("VALID_PERIOD_TOO_LARGE");
    }

    [Fact]
    public void ValidPeriod_30_NoError()
    {
        var command = ValidCommand() with { ValidPeriod = 30 };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.ValidPeriod);
    }
}
