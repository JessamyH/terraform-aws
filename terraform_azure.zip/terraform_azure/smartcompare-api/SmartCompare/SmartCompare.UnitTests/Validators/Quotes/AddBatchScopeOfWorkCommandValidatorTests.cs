using FluentValidation.TestHelper;
using SmartCompare.Application.Commands.Quotes.AddBatchScopeOfWork;
using SmartCompare.Application.DTOs.Quote;

namespace SmartCompare.UnitTests.Validators.Quotes;

/// <summary>
/// Tests custom business rules: collection max count (Must &lt;= 100),
/// nested validator wiring (SetValidator). Framework rules not tested.
/// </summary>
public class AddBatchScopeOfWorkCommandValidatorTests
{
    private readonly AddBatchScopeOfWorkCommandValidator _validator = new();

    private static AddBatchScopeOfWorkCommand ValidCommand() => new(
        QuotePublicId: Guid.NewGuid(),
        Auth0SubjectId: "auth0|12345",
        Items: [new AddScopeOfWorkDto { Description = "Valid scope item" }]
    );

    // ========== Collection max count (custom Must rule) ==========

    [Fact]
    public void Items_Exactly100_NoError()
    {
        var items = Enumerable.Range(1, 100)
            .Select(i => new AddScopeOfWorkDto { Description = $"Scope item {i}" })
            .ToList();
        var command = ValidCommand() with { Items = items };

        var result = _validator.TestValidate(command);

        result.ShouldNotHaveValidationErrorFor(x => x.Items);
    }

    [Fact]
    public void Items_Over100_HasError()
    {
        var items = Enumerable.Range(1, 101)
            .Select(i => new AddScopeOfWorkDto { Description = $"Scope item {i}" })
            .ToList();
        var command = ValidCommand() with { Items = items };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor(x => x.Items)
            .WithErrorCode("ITEMS_MAX_COUNT");
    }

    // ========== Nested validator wiring (SetValidator) ==========

    [Fact]
    public void Items_EmptyDescription_HasNestedError()
    {
        var command = ValidCommand() with
        {
            Items = [new AddScopeOfWorkDto { Description = "" }]
        };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor("Items[0].Description")
            .WithErrorCode("DESCRIPTION_REQUIRED");
    }

    [Fact]
    public void Items_DescriptionTooLong_HasNestedError()
    {
        var command = ValidCommand() with
        {
            Items = [new AddScopeOfWorkDto { Description = new string('A', 1001) }]
        };

        var result = _validator.TestValidate(command);

        result.ShouldHaveValidationErrorFor("Items[0].Description")
            .WithErrorCode("DESCRIPTION_MAX_LENGTH");
    }
}
