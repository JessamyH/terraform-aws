using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Auth.QueryDto;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Users.GetCurrentUser;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.QueryTests.UserTests;

public class GetCurrentUserHandlerTests
{
    private readonly Mock<IUserQueries> _mockUserQueries;
    private readonly Mock<ILogger<GetCurrentUserHandler>> _mockLogger;
    private readonly GetCurrentUserHandler _handler;

    public GetCurrentUserHandlerTests()
    {
        _mockUserQueries = new Mock<IUserQueries>();
        _mockLogger = new Mock<ILogger<GetCurrentUserHandler>>();

        _handler = new GetCurrentUserHandler(
            _mockLogger.Object,
            _mockUserQueries.Object);
    }

    [Fact]
    public async Task Handle_WhenUserExists_ShouldReturnCurrentUserDto()
    {
        // Arrange
        var query = TestQueryFactory.CreateGetCurrentUserQuery();
        var expectedDto = new CurrentUserDto(
            Id: Guid.NewGuid(),
            UserName: TestConstants.User.DefaultUserName,
            Email: TestConstants.User.DefaultEmail,
            Roles: ["CompanyAdmin"],
            SubscriptionTier: "Free");

        _mockUserQueries.SetupGetCurrentUserByAuth0SubjectIdAsync(
            query.Auth0SubjectId, expectedDto);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value.Should().Be(expectedDto);
        result.Value.UserName.Should().Be(TestConstants.User.DefaultUserName);
        result.Value.Email.Should().Be(TestConstants.User.DefaultEmail);
        result.Value.Roles.Should().Contain("CompanyAdmin");
        result.Value.SubscriptionTier.Should().Be("Free");

        _mockUserQueries.Verify(
            x => x.GetCurrentUserByAuth0SubjectIdAsync(
                query.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotFound_ShouldReturnNotFoundError()
    {
        // Arrange
        var query = TestQueryFactory.CreateGetCurrentUserQuery();

        _mockUserQueries.SetupGetCurrentUserByAuth0SubjectIdAsync(
            query.Auth0SubjectId, null);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Contain("User not found");

        _mockLogger.Verify(
            x => x.Log(
                LogLevel.Warning,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((o, t) => o.ToString()!.Contains("User not found")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }
}
