using FluentAssertions;
using Moq;
using SmartCompare.Application.DTOs.Dashboard;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Dashboard.GetRecentQuotes;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.QueryTests.DashboardTests;

public class GetRecentQuotesHandlerTests
{
    private readonly Mock<IDashboardQueries> _mockDashboardQueries;
    private readonly GetRecentQuotesHandler _handler;

    public GetRecentQuotesHandlerTests()
    {
        _mockDashboardQueries = new Mock<IDashboardQueries>();
        _handler = new GetRecentQuotesHandler(_mockDashboardQueries.Object);
    }

    [Fact]
    public async Task Handle_WhenQuotesExist_ShouldReturnQuotesList()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var count = 3;
        var query = new GetRecentQuotesQuery(auth0SubjectId, count);

        var projectPublicId = Guid.NewGuid();
        var quotes = new List<RecentQuoteDto>
        {
            new()
            {
                QuoteNumber = "Q-001",
                IssuedTo = "Acme Corp",
                ValidDate = DateTime.UtcNow.AddDays(30),
                Total = 12500,
                ProjectPublicId = projectPublicId
            },
            new()
            {
                QuoteNumber = "Q-002",
                IssuedTo = "Tech Solutions",
                ValidDate = DateTime.UtcNow.AddDays(20),
                Total = 8900,
                ProjectPublicId = projectPublicId
            },
            new()
            {
                QuoteNumber = "Q-003",
                IssuedTo = "BuildRight Inc",
                ValidDate = DateTime.UtcNow.AddDays(15),
                Total = 31000,
                ProjectPublicId = projectPublicId
            }
        };

        _mockDashboardQueries
            .Setup(x => x.GetRecentQuotesAsync(
                auth0SubjectId,
                count,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quotes);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value.Should().HaveCount(3);
        result.Value![0].QuoteNumber.Should().Be("Q-001");
        result.Value[1].IssuedTo.Should().Be("Tech Solutions");
        result.Value[2].Total.Should().Be(31000);

        _mockDashboardQueries.Verify(
            x => x.GetRecentQuotesAsync(
                auth0SubjectId,
                count,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenNoQuotesExist_ShouldReturnEmptyList()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var count = 3;
        var query = new GetRecentQuotesQuery(auth0SubjectId, count);

        _mockDashboardQueries
            .Setup(x => x.GetRecentQuotesAsync(
                auth0SubjectId,
                count,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<RecentQuoteDto>());

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value.Should().BeEmpty();
    }
}
