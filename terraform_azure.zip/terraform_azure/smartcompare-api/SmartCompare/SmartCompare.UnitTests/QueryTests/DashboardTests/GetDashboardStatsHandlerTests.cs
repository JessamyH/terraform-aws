using FluentAssertions;
using Moq;
using SmartCompare.Application.DTOs.Dashboard;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Dashboard.GetDashboardStats;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.QueryTests.DashboardTests;

public class GetDashboardStatsHandlerTests
{
    private readonly Mock<IDashboardQueries> _mockDashboardQueries;
    private readonly GetDashboardStatsHandler _handler;

    public GetDashboardStatsHandlerTests()
    {
        _mockDashboardQueries = new Mock<IDashboardQueries>();
        _handler = new GetDashboardStatsHandler(_mockDashboardQueries.Object);
    }

    [Fact]
    public async Task Handle_WhenUserHasData_ShouldReturnStats()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var query = new GetDashboardStatsQuery(auth0SubjectId);

        var stats = new DashboardStatsDto
        {
            TotalQuotes = 24,
            ActiveProjects = 8,
            CompletedProjects = 5
        };

        _mockDashboardQueries
            .Setup(x => x.GetDashboardStatsAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(stats);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.TotalQuotes.Should().Be(24);
        result.Value.ActiveProjects.Should().Be(8);
        result.Value.CompletedProjects.Should().Be(5);

        _mockDashboardQueries.Verify(
            x => x.GetDashboardStatsAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserHasNoData_ShouldReturnZeroCounts()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var query = new GetDashboardStatsQuery(auth0SubjectId);

        var stats = new DashboardStatsDto
        {
            TotalQuotes = 0,
            ActiveProjects = 0,
            CompletedProjects = 0
        };

        _mockDashboardQueries
            .Setup(x => x.GetDashboardStatsAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(stats);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.TotalQuotes.Should().Be(0);
        result.Value.ActiveProjects.Should().Be(0);
        result.Value.CompletedProjects.Should().Be(0);
    }
}
