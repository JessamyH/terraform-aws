using System.Linq.Expressions;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Quotes.GetScopeOfWorkByQuoteId;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.QueryTests.QuoteTests;

public class GetScopeOfWorkItemsByQuoteIdHandlerTests
{
    private readonly Mock<ILogger<GetScopeOfWorkItemsByQuoteIdHandler>> _mockLogger;
    private readonly Mock<IUserQueries> _mockUserQueries;
    private readonly Mock<IQuoteQueries> _mockQuoteQueries;
    private readonly GetScopeOfWorkItemsByQuoteIdHandler _handler;

    public GetScopeOfWorkItemsByQuoteIdHandlerTests()
    {
        _mockLogger = new Mock<ILogger<GetScopeOfWorkItemsByQuoteIdHandler>>();
        _mockUserQueries = new Mock<IUserQueries>();
        _mockQuoteQueries = new Mock<IQuoteQueries>();

        _handler = new GetScopeOfWorkItemsByQuoteIdHandler(
            _mockLogger.Object,
            _mockUserQueries.Object,
            _mockQuoteQueries.Object);
    }

    [Fact]
    public async Task Handle_WhenUserExistsAndScopeOfWorkItemsExist_ShouldReturnPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetScopeOfWorkItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId);

        var scopeOfWorkItems = new List<ScopeOfWorkDto>
        {
            new() { Id = 1, Description = "Foundation work" },
            new() { Id = 2, Description = "Structural framing" },
            new() { Id = 3, Description = "Roofing" }
        };

        var pagedResult = new PagedResult<ScopeOfWorkDto>
        {
            Items = scopeOfWorkItems,
            TotalCount = 3,
            PageNumber = 1,
            PageSize = 10
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);

        _mockQuoteQueries.SetupGetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(3);
        result.Value.TotalCount.Should().Be(3);
        result.Value.PageNumber.Should().Be(1);
        result.Value.PageSize.Should().Be(10);
        result.Message.Should().Contain($"Successfully retrieved ScopeOfWork items for Quote Id {quotePublicId}");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotFound_ShouldReturnUnauthorizedError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetScopeOfWorkItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, null);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Unauthorized);
        result.Error.Message.Should().Be("User not found.");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                It.IsAny<Pagination>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenNoScopeOfWorkItemsExist_ShouldReturnEmptyPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetScopeOfWorkItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId);

        var pagedResult = new PagedResult<ScopeOfWorkDto>
        {
            Items = new List<ScopeOfWorkDto>(),
            TotalCount = 0,
            PageNumber = 1,
            PageSize = 10
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);

        _mockQuoteQueries.SetupGetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().BeEmpty();
        result.Value.TotalCount.Should().Be(0);
        result.Value.TotalPages.Should().Be(0);
        result.Value.HasPreviousPage.Should().BeFalse();
        result.Value.HasNextPage.Should().BeFalse();

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithSecondPage_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(2, 5);

        var query = TestQueryFactory.CreateGetScopeOfWorkItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = User.Create(
            auth0SubjectId: auth0SubjectId,
            userName: "Test User",
            email: "test@example.com");

        var scopeOfWorkItems = new List<ScopeOfWorkDto>
        {
            new() { Id = 6, Description = "Work Item 6" },
            new() { Id = 7, Description = "Work Item 7" }
        };

        var pagedResult = new PagedResult<ScopeOfWorkDto>
        {
            Items = scopeOfWorkItems,
            TotalCount = 12,
            PageNumber = 2,
            PageSize = 5
        };

        _mockUserQueries
            .Setup(x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);

        _mockQuoteQueries
            .Setup(x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                pagination,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(2);
        result.Value.TotalCount.Should().Be(12);
        result.Value.PageNumber.Should().Be(2);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(3);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeTrue();

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithLastPage_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(3, 5);

        var query = TestQueryFactory.CreateGetScopeOfWorkItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId);

        var scopeOfWorkItems = new List<ScopeOfWorkDto>
        {
            new() { Id = 11, Description = "Final Work Item" }
        };

        var pagedResult = new PagedResult<ScopeOfWorkDto>
        {
            Items = scopeOfWorkItems,
            TotalCount = 11,
            PageNumber = 3,
            PageSize = 5
        };

        _mockUserQueries
            .Setup(x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);

        _mockQuoteQueries
            .Setup(x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                pagination,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(1);
        result.Value.TotalCount.Should().Be(11);
        result.Value.PageNumber.Should().Be(3);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(3);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeFalse();

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithDifferentPageSizes_ShouldReturnCorrectResults()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(1, 25);

        var query = TestQueryFactory.CreateGetScopeOfWorkItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId);

        var scopeOfWorkItems = Enumerable.Range(1, 25)
            .Select(i => new ScopeOfWorkDto
            {
                Id = i,
                Description = $"Work Item {i}"
            })
            .ToList();

        var pagedResult = new PagedResult<ScopeOfWorkDto>
        {
            Items = scopeOfWorkItems,
            TotalCount = 50,
            PageNumber = 1,
            PageSize = 25
        };

        _mockUserQueries
            .Setup(x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);

        _mockQuoteQueries
            .Setup(x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                pagination,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(25);
        result.Value.TotalCount.Should().Be(50);
        result.Value.PageSize.Should().Be(25);
        result.Value.TotalPages.Should().Be(2);

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithDifferentQuoteId_ShouldCallQueriesWithCorrectId()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetScopeOfWorkItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId);

        var pagedResult = new PagedResult<ScopeOfWorkDto>
        {
            Items = new List<ScopeOfWorkDto>(),
            TotalCount = 0,
            PageNumber = 1,
            PageSize = 10
        };

        _mockUserQueries
            .Setup(x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);

        _mockQuoteQueries
            .Setup(x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                pagination,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Message.Should().Contain($"Successfully retrieved ScopeOfWork items for Quote Id {quotePublicId}");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ScopeOfWork, ScopeOfWorkDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ScopeOfWork>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
