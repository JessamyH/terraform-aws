using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Quotes.GetQuoteDetailById;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.QueryTests.QuoteTests;

public class GetQuoteDetailByIdHandlerTests
{
    private readonly Mock<ILogger<GetQuoteDetailByIdHandler>> _mockLogger;
    private readonly Mock<IQuoteQueries> _mockQuoteQueries;
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly GetQuoteDetailByIdHandler _handler;

    public GetQuoteDetailByIdHandlerTests()
    {
        _mockLogger = new Mock<ILogger<GetQuoteDetailByIdHandler>>();
        _mockQuoteQueries = new Mock<IQuoteQueries>();
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();

        _handler = new GetQuoteDetailByIdHandler(
            _mockLogger.Object,
            _mockQuoteQueries.Object,
            _mockAuthorizationService.Object);
    }

    [Fact]
    public async Task Handle_WhenAuthorizedAndQuoteExists_ShouldReturnQuoteDetail()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;

        var query = TestQueryFactory.CreateGetQuoteDetailByIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId);

        var user = TestEntityFactory.CreateUser(auth0SubjectId);

        var quoteDto = new QuoteDto
        {
            PublicId = quotePublicId,
            QuoteNumber = "Q-001",
            IssuedDate = DateTime.UtcNow.AddDays(-5),
            ValidDate = DateTime.UtcNow.AddDays(30),
            IssuedBy = "Company A",
            IssuedTo = "Client B",
            Total = 1100,
            SubTotal = 1000,
            GST = 100,
            PDFUrl = "https://example.com/quote.pdf",
            ScopeOfWorks = new List<ScopeOfWorkDto>
            {
                new() { Id = 1, Description = "Foundation work" },
                new() { Id = 2, Description = "Roofing" }
            },
            Exclusions = new List<ExclusionDto>
            {
                new() { Id = 1, Description = "Exclusion 1" }
            },
            ProgressPayments = new List<ProgressPaymentDto>
            {
                new() { Id = 1, Description = "Deposit", Percentage = 30 }
            }
        };

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(quotePublicId, auth0SubjectId, user);

        _mockQuoteQueries.SetupGetQuoteByIdAsync(
            quotePublicId, user.Id, quoteDto);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.PublicId.Should().Be(quotePublicId);
        result.Value.QuoteNumber.Should().Be("Q-001");
        result.Value.Total.Should().Be(1100);
        result.Value.ScopeOfWorks.Should().HaveCount(2);
        result.Value.Exclusions.Should().HaveCount(1);
        result.Value.ProgressPayments.Should().HaveCount(1);
        result.Message.Should().Contain($"Successfully retrieved Quote with Id {quotePublicId}");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetByIdAsync<QuoteDto>(
                quotePublicId,
                user.Id,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;

        var query = TestQueryFactory.CreateGetQuoteDetailByIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId);

        var forbiddenError = MockSetupHelper.CreateForbiddenError("User doesn't have access to this quote.");

        _mockAuthorizationService.SetupFailedQuoteAuthorization(
            quotePublicId,
            auth0SubjectId,
            forbiddenError);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Forbidden);
        result.Error.Message.Should().Contain("User doesn't have access to this quote");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetByIdAsync<QuoteDto>(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteNotFound_ShouldReturnNotFoundError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;

        var query = TestQueryFactory.CreateGetQuoteDetailByIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quotePublicId, auth0SubjectId, user);
        _mockQuoteQueries.SetupGetQuoteByIdAsync<QuoteDto>(
            quotePublicId, user.Id, null);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Be("Quote not found.");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetByIdAsync<QuoteDto>(
                quotePublicId,
                user.Id,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenQuoteHasNoChildItems_ShouldReturnQuoteWithEmptyCollections()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;

        var query = TestQueryFactory.CreateGetQuoteDetailByIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var quoteDto = new QuoteDto
        {
            PublicId = quotePublicId,
            QuoteNumber = "Q-002",
            IssuedDate = DateTime.UtcNow,
            ValidDate = DateTime.UtcNow.AddDays(30),
            IssuedBy = "Company A",
            IssuedTo = "Client B",
            Total = 1100,
            SubTotal = 1000,
            GST = 100,
            ScopeOfWorks = new List<ScopeOfWorkDto>(),
            Exclusions = new List<ExclusionDto>(),
            ProgressPayments = new List<ProgressPaymentDto>()
        };

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quotePublicId, auth0SubjectId, user);
        _mockQuoteQueries.SetupGetQuoteByIdAsync(
            quotePublicId, user.Id, quoteDto);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.ScopeOfWorks.Should().BeEmpty();
        result.Value.Exclusions.Should().BeEmpty();
        result.Value.ProgressPayments.Should().BeEmpty();

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetByIdAsync<QuoteDto>(
                quotePublicId,
                user.Id,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
