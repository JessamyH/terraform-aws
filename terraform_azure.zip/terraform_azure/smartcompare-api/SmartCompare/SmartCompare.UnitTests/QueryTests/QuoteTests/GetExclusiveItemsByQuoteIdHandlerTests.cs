using System.Linq.Expressions;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Quotes.GetExclusiveItemsByQuoteId;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.QueryTests.QuoteTests;

public class GetExclusiveItemsByQuoteIdHandlerTests
{
    private readonly Mock<ILogger<GetExclusiveItemsByQuoteIdHandler>> _mockLogger;
    private readonly Mock<IQuoteQueries> _mockQuoteQueries;
    private readonly Mock<IUserQueries> _mockUserQueries;
    private readonly GetExclusiveItemsByQuoteIdHandler _handler;

    public GetExclusiveItemsByQuoteIdHandlerTests()
    {
        _mockLogger = new Mock<ILogger<GetExclusiveItemsByQuoteIdHandler>>();
        _mockQuoteQueries = new Mock<IQuoteQueries>();
        _mockUserQueries = new Mock<IUserQueries>();

        _handler = new GetExclusiveItemsByQuoteIdHandler(
            _mockLogger.Object,
            _mockQuoteQueries.Object,
            _mockUserQueries.Object);
    }

    [Fact]
    public async Task Handle_WhenUserExistsAndExclusionsExist_ShouldReturnPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetExclusiveItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var exclusions = new List<ExclusionDto>
        {
            new() { Id = 1, Description = "Exclusion 1" },
            new() { Id = 2, Description = "Exclusion 2" },
            new() { Id = 3, Description = "Exclusion 3" }
        };

        var pagedResult = new PagedResult<ExclusionDto>
        {
            Items = exclusions,
            TotalCount = 3,
            PageNumber = 1,
            PageSize = 10
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<Exclusion, ExclusionDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(3);
        result.Value.TotalCount.Should().Be(3);
        result.Value.PageNumber.Should().Be(1);
        result.Value.PageSize.Should().Be(10);
        result.Message.Should().Contain($"Successfully retrieved Exclusive Items for Quote Id {quotePublicId}");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<Exclusion, ExclusionDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<Exclusion>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotFound_ShouldReturnUnauthorizedError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetExclusiveItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, null);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Unauthorized);
        result.Error.Message.Should().Be("User not found.");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<Exclusion, ExclusionDto>(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<Exclusion>>>>(),
                It.IsAny<Pagination>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenNoExclusionsExist_ShouldReturnEmptyPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetExclusiveItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var pagedResult = new PagedResult<ExclusionDto>
        {
            Items = new List<ExclusionDto>(),
            TotalCount = 0,
            PageNumber = 1,
            PageSize = 10
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<Exclusion, ExclusionDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().BeEmpty();
        result.Value.TotalCount.Should().Be(0);
        result.Value.TotalPages.Should().Be(0);
        result.Value.HasPreviousPage.Should().BeFalse();
        result.Value.HasNextPage.Should().BeFalse();

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<Exclusion, ExclusionDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<Exclusion>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithSecondPage_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageNumber: 2, pageSize: 5);

        var query = TestQueryFactory.CreateGetExclusiveItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var exclusions = new List<ExclusionDto>
        {
            new() { Id = 6, Description = "Exclusion 6" },
            new() { Id = 7, Description = "Exclusion 7" }
        };

        var pagedResult = new PagedResult<ExclusionDto>
        {
            Items = exclusions,
            TotalCount = 12,
            PageNumber = 2,
            PageSize = 5
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<Exclusion, ExclusionDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(2);
        result.Value.TotalCount.Should().Be(12);
        result.Value.PageNumber.Should().Be(2);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(3);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeTrue();

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<Exclusion, ExclusionDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<Exclusion>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithLastPage_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageNumber: 3, pageSize: 5);

        var query = TestQueryFactory.CreateGetExclusiveItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var exclusions = new List<ExclusionDto>
        {
            new() { Id = 11, Description = "Exclusion 11" }
        };

        var pagedResult = new PagedResult<ExclusionDto>
        {
            Items = exclusions,
            TotalCount = 11,
            PageNumber = 3,
            PageSize = 5
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<Exclusion, ExclusionDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(1);
        result.Value.TotalCount.Should().Be(11);
        result.Value.PageNumber.Should().Be(3);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(3);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeFalse();

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<Exclusion, ExclusionDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<Exclusion>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithDifferentPageSizes_ShouldReturnCorrectResults()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageSize: 25);

        var query = TestQueryFactory.CreateGetExclusiveItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var exclusions = Enumerable.Range(1, 25)
            .Select(i => new ExclusionDto
            {
                Id = i,
                Description = $"Exclusion {i}"
            })
            .ToList();

        var pagedResult = new PagedResult<ExclusionDto>
        {
            Items = exclusions,
            TotalCount = 50,
            PageNumber = 1,
            PageSize = 25
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<Exclusion, ExclusionDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(25);
        result.Value.TotalCount.Should().Be(50);
        result.Value.PageSize.Should().Be(25);
        result.Value.TotalPages.Should().Be(2);

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<Exclusion, ExclusionDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<Exclusion>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithDifferentQuoteId_ShouldCallQueriesWithCorrectId()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetExclusiveItemsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var pagedResult = new PagedResult<ExclusionDto>
        {
            Items = new List<ExclusionDto>(),
            TotalCount = 0,
            PageNumber = 1,
            PageSize = 10
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<Exclusion, ExclusionDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Message.Should().Contain($"Successfully retrieved Exclusive Items for Quote Id {quotePublicId}");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<Exclusion, ExclusionDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<Exclusion>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
