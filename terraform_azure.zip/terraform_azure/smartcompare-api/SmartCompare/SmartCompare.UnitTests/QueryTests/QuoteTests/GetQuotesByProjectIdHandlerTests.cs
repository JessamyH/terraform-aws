using FluentAssertions;
using Moq;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Quotes.GetQuotesByProjectId;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.QueryTests.QuoteTests;

public class GetQuotesByProjectIdHandlerTests
{
    private readonly Mock<IQuoteQueries> _mockQuoteQueries;
    private readonly GetQuotesByProjectIdHandler _handler;

    public GetQuotesByProjectIdHandlerTests()
    {
        _mockQuoteQueries = new Mock<IQuoteQueries>();
        _handler = new GetQuotesByProjectIdHandler(_mockQuoteQueries.Object);
    }

    [Fact]
    public async Task Handle_WhenQuotesExist_ShouldReturnPagedResult()
    {
        // Arrange
        var projectPublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetQuotesByProjectIdQuery(
            projectPublicId: projectPublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var quotes = new List<QuoteSummaryDto>
        {
            new()
            {
                QuotePublicId = Guid.NewGuid(),
                QuoteNumber = "Q-001",
                IssuedDate = DateTime.UtcNow.AddDays(-10),
                ValidDate = DateTime.UtcNow.AddDays(20),
                IssuedBy = "Company A",
                IssuedTo = "Client B",
                Total = 1100,
                SubTotal = 1000,
                GST = 100,
                ProjectPublicId = projectPublicId
            },
            new()
            {
                QuotePublicId = Guid.NewGuid(),
                QuoteNumber = "Q-002",
                IssuedDate = DateTime.UtcNow.AddDays(-5),
                ValidDate = DateTime.UtcNow.AddDays(25),
                IssuedBy = "Company A",
                IssuedTo = "Client B",
                Total = 2200,
                SubTotal = 2000,
                GST = 200,
                ProjectPublicId = projectPublicId
            },
            new()
            {
                QuotePublicId = Guid.NewGuid(),
                QuoteNumber = "Q-003",
                IssuedDate = DateTime.UtcNow.AddDays(-2),
                ValidDate = DateTime.UtcNow.AddDays(28),
                IssuedBy = "Company A",
                IssuedTo = "Client B",
                Total = 3300,
                SubTotal = 3000,
                GST = 300,
                ProjectPublicId = projectPublicId
            }
        };

        var pagedResult = new PagedResult<QuoteSummaryDto>
        {
            Items = quotes,
            TotalCount = 3,
            PageNumber = 1,
            PageSize = 10
        };

        _mockQuoteQueries.SetupGetByProjectIdPagedAsync(
            projectPublicId, auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(3);
        result.Value.TotalCount.Should().Be(3);
        result.Value.PageNumber.Should().Be(1);
        result.Value.PageSize.Should().Be(10);
        result.Value.Items.Should().BeEquivalentTo(quotes);

        _mockQuoteQueries.Verify(
            x => x.GetByProjectIdPagedAsync(
                projectPublicId,
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenNoQuotesExist_ShouldReturnEmptyPagedResult()
    {
        // Arrange
        var projectPublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetQuotesByProjectIdQuery(
            projectPublicId: projectPublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var pagedResult = new PagedResult<QuoteSummaryDto>
        {
            Items = new List<QuoteSummaryDto>(),
            TotalCount = 0,
            PageNumber = 1,
            PageSize = 10
        };

        _mockQuoteQueries.SetupGetByProjectIdPagedAsync(
            projectPublicId, auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().BeEmpty();
        result.Value.TotalCount.Should().Be(0);
        result.Value.TotalPages.Should().Be(0);
        result.Value.HasPreviousPage.Should().BeFalse();
        result.Value.HasNextPage.Should().BeFalse();

        _mockQuoteQueries.Verify(
            x => x.GetByProjectIdPagedAsync(
                projectPublicId,
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithSecondPage_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var projectPublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(2, 5);

        var query = TestQueryFactory.CreateGetQuotesByProjectIdQuery(
            projectPublicId: projectPublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var quotes = new List<QuoteSummaryDto>
        {
            new()
            {
                QuotePublicId = Guid.NewGuid(),
                QuoteNumber = "Q-006",
                IssuedDate = DateTime.UtcNow,
                ValidDate = DateTime.UtcNow.AddDays(30),
                IssuedBy = "Company A",
                IssuedTo = "Client B",
                Total = 1100,
                SubTotal = 1000,
                GST = 100,
                ProjectPublicId = projectPublicId
            },
            new()
            {
                QuotePublicId = Guid.NewGuid(),
                QuoteNumber = "Q-007",
                IssuedDate = DateTime.UtcNow,
                ValidDate = DateTime.UtcNow.AddDays(30),
                IssuedBy = "Company A",
                IssuedTo = "Client B",
                Total = 2200,
                SubTotal = 2000,
                GST = 200,
                ProjectPublicId = projectPublicId
            }
        };

        var pagedResult = new PagedResult<QuoteSummaryDto>
        {
            Items = quotes,
            TotalCount = 12,
            PageNumber = 2,
            PageSize = 5
        };

        _mockQuoteQueries.SetupGetByProjectIdPagedAsync(
            projectPublicId, auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(2);
        result.Value.TotalCount.Should().Be(12);
        result.Value.PageNumber.Should().Be(2);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(3);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeTrue();

        _mockQuoteQueries.Verify(
            x => x.GetByProjectIdPagedAsync(
                projectPublicId,
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithLastPage_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var projectPublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageNumber: 3, pageSize: 5);

        var query = TestQueryFactory.CreateGetQuotesByProjectIdQuery(
            projectPublicId: projectPublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var quotes = new List<QuoteSummaryDto>
        {
            new()
            {
                QuotePublicId = Guid.NewGuid(),
                QuoteNumber = "Q-011",
                IssuedDate = DateTime.UtcNow,
                ValidDate = DateTime.UtcNow.AddDays(30),
                IssuedBy = "Company A",
                IssuedTo = "Client B",
                Total = 1100,
                SubTotal = 1000,
                GST = 100,
                ProjectPublicId = projectPublicId
            }
        };

        var pagedResult = new PagedResult<QuoteSummaryDto>
        {
            Items = quotes,
            TotalCount = 11,
            PageNumber = 3,
            PageSize = 5
        };

        _mockQuoteQueries.SetupGetByProjectIdPagedAsync(
            projectPublicId, auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(1);
        result.Value.TotalCount.Should().Be(11);
        result.Value.PageNumber.Should().Be(3);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(3);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeFalse();

        _mockQuoteQueries.Verify(
            x => x.GetByProjectIdPagedAsync(
                projectPublicId,
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithDifferentPageSizes_ShouldReturnCorrectResults()
    {
        // Arrange
        var projectPublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageSize: 25);

        var query = TestQueryFactory.CreateGetQuotesByProjectIdQuery(
            projectPublicId: projectPublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var quotes = Enumerable.Range(1, 25)
            .Select(i => new QuoteSummaryDto
            {
                QuotePublicId = Guid.NewGuid(),
                QuoteNumber = $"Q-{i:000}",
                IssuedDate = DateTime.UtcNow.AddDays(-i),
                ValidDate = DateTime.UtcNow.AddDays(30 - i),
                IssuedBy = "Company A",
                IssuedTo = "Client B",
                Total = 1100 * i,
                SubTotal = 1000 * i,
                GST = 100 * i,
                ProjectPublicId = projectPublicId
            })
            .ToList();

        var pagedResult = new PagedResult<QuoteSummaryDto>
        {
            Items = quotes,
            TotalCount = 50,
            PageNumber = 1,
            PageSize = 25
        };

        _mockQuoteQueries.SetupGetByProjectIdPagedAsync(
            projectPublicId, auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(25);
        result.Value.TotalCount.Should().Be(50);
        result.Value.PageSize.Should().Be(25);
        result.Value.TotalPages.Should().Be(2);

        _mockQuoteQueries.Verify(
            x => x.GetByProjectIdPagedAsync(
                projectPublicId,
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
