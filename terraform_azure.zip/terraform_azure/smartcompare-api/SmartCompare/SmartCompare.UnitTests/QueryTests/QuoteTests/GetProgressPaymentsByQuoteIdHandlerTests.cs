using System.Linq.Expressions;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Quotes.GetProgressPaymentsByQuoteId;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.QueryTests.QuoteTests;

public class GetProgressPaymentsByQuoteIdHandlerTests
{
    private readonly Mock<ILogger<GetProgressPaymentsByQuoteIdHandler>> _mockLogger;
    private readonly Mock<IUserQueries> _mockUserQueries;
    private readonly Mock<IQuoteQueries> _mockQuoteQueries;
    private readonly GetProgressPaymentsByQuoteIdHandler _handler;

    public GetProgressPaymentsByQuoteIdHandlerTests()
    {
        _mockLogger = new Mock<ILogger<GetProgressPaymentsByQuoteIdHandler>>();
        _mockUserQueries = new Mock<IUserQueries>();
        _mockQuoteQueries = new Mock<IQuoteQueries>();

        _handler = new GetProgressPaymentsByQuoteIdHandler(
            _mockLogger.Object,
            _mockUserQueries.Object,
            _mockQuoteQueries.Object);
    }

    [Fact]
    public async Task Handle_WhenUserExistsAndProgressPaymentsExist_ShouldReturnPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetProgressPaymentsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var progressPayments = new List<ProgressPaymentDto>
        {
            new() { Id = 1, Description = "Deposit", Percentage = 30 },
            new() { Id = 2, Description = "Milestone 1", Percentage = 40 },
            new() { Id = 3, Description = "Final Payment", Percentage = 30 }
        };

        var pagedResult = new PagedResult<ProgressPaymentDto>
        {
            Items = progressPayments,
            TotalCount = 3,
            PageNumber = 1,
            PageSize = 10
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(3);
        result.Value.TotalCount.Should().Be(3);
        result.Value.PageNumber.Should().Be(1);
        result.Value.PageSize.Should().Be(10);
        result.Message.Should().Contain($"Successfully retrieved ProgressPayments for Quote Id {quotePublicId}");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ProgressPayment>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotFound_ShouldReturnUnauthorizedError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetProgressPaymentsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, null);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Unauthorized);
        result.Error.Message.Should().Be("User not found.");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetByIdAsync<QuoteDto>(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ProgressPayment>>>>(),
                It.IsAny<Pagination>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenNoProgressPaymentsExist_ShouldReturnEmptyPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();

        var query = TestQueryFactory.CreateGetProgressPaymentsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var pagedResult = new PagedResult<ProgressPaymentDto>
        {
            Items = new List<ProgressPaymentDto>(),
            TotalCount = 0,
            PageNumber = 1,
            PageSize = 10
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().BeEmpty();
        result.Value.TotalCount.Should().Be(0);
        result.Value.TotalPages.Should().Be(0);
        result.Value.HasPreviousPage.Should().BeFalse();
        result.Value.HasNextPage.Should().BeFalse();

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ProgressPayment>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithSecondPage_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageNumber: 2, pageSize: 5);

        var query = TestQueryFactory.CreateGetProgressPaymentsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var progressPayments = new List<ProgressPaymentDto>
        {
            new() { Id = 6, Description = "Payment 6", Percentage = 10 },
            new() { Id = 7, Description = "Payment 7", Percentage = 10 }
        };

        var pagedResult = new PagedResult<ProgressPaymentDto>
        {
            Items = progressPayments,
            TotalCount = 12,
            PageNumber = 2,
            PageSize = 5
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(2);
        result.Value.TotalCount.Should().Be(12);
        result.Value.PageNumber.Should().Be(2);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(3);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeTrue();

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ProgressPayment>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithLastPage_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageNumber: 3, pageSize: 5);

        var query = TestQueryFactory.CreateGetProgressPaymentsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var progressPayments = new List<ProgressPaymentDto>
        {
            new() { Id = 11, Description = "Final Payment", Percentage = 10 }
        };

        var pagedResult = new PagedResult<ProgressPaymentDto>
        {
            Items = progressPayments,
            TotalCount = 11,
            PageNumber = 3,
            PageSize = 5
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(1);
        result.Value.TotalCount.Should().Be(11);
        result.Value.PageNumber.Should().Be(3);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(3);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeFalse();

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ProgressPayment>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithDifferentPageSizes_ShouldReturnCorrectResults()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageNumber: 1, pageSize: 25);

        var query = TestQueryFactory.CreateGetProgressPaymentsByQuoteIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        var progressPayments = Enumerable.Range(1, 25)
            .Select(i => new ProgressPaymentDto
            {
                Id = i,
                Description = $"Payment {i}",
                Percentage = 2m
            })
            .ToList();

        var pagedResult = new PagedResult<ProgressPaymentDto>
        {
            Items = progressPayments,
            TotalCount = 50,
            PageNumber = 1,
            PageSize = 25
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
            quotePublicId, user.Id, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(25);
        result.Value.TotalCount.Should().Be(50);
        result.Value.PageSize.Should().Be(25);
        result.Value.TotalPages.Should().Be(2);

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetChildrenPagedAsync<ProgressPayment, ProgressPaymentDto>(
                quotePublicId,
                It.IsAny<Guid>(),
                It.IsAny<Expression<Func<Quote, IEnumerable<ProgressPayment>>>>(),
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
