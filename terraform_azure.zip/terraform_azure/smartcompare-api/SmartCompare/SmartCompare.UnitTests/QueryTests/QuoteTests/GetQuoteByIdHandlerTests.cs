using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Quotes.GetQuoteById;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.QueryTests.QuoteTests;

public class GetQuoteByIdHandlerTests
{
    private readonly Mock<ILogger<GetQuoteByIdHandler>> _mockLogger;
    private readonly Mock<IQuoteQueries> _mockQuoteQueries;
    private readonly Mock<IUserQueries> _mockUserQueries;
    private readonly GetQuoteByIdHandler _handler;

    public GetQuoteByIdHandlerTests()
    {
        _mockLogger = new Mock<ILogger<GetQuoteByIdHandler>>();
        _mockQuoteQueries = new Mock<IQuoteQueries>();
        _mockUserQueries = new Mock<IUserQueries>();

        _handler = new GetQuoteByIdHandler(
            _mockLogger.Object,
            _mockQuoteQueries.Object,
            _mockUserQueries.Object);
    }

    [Fact]
    public async Task Handle_WhenUserExistsAndQuoteExists_ShouldReturnQuoteSummary()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;

        var query = TestQueryFactory.CreateGetQuoteByIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId);

        var user = TestEntityFactory.CreateUser(auth0SubjectId);

        var quoteSummary = new QuoteSummaryDto
        {
            QuotePublicId = quotePublicId,
            QuoteNumber = "Q-001",
            IssuedDate = DateTime.UtcNow.AddDays(-5),
            ValidDate = DateTime.UtcNow.AddDays(30),
            IssuedBy = "Company A",
            IssuedTo = "Client B",
            Total = 1100,
            SubTotal = 1000,
            GST = 100,
            PDFUrl = "https://example.com/quote.pdf",
            ProjectPublicId = Guid.NewGuid()
        };

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(
            auth0SubjectId,
            user);

        _mockQuoteQueries.SetupGetQuoteByIdAsync(
            quotePublicId,
            user.Id,
            quoteSummary);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.QuotePublicId.Should().Be(quotePublicId);
        result.Value.QuoteNumber.Should().Be("Q-001");
        result.Value.Total.Should().Be(1100);
        result.Value.SubTotal.Should().Be(1000);
        result.Value.GST.Should().Be(100);
        result.Message.Should().Contain($"Successfully retrieved Quote with Id {quotePublicId}");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetByIdAsync<QuoteSummaryDto>(
                quotePublicId,
                user.Id,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotFound_ShouldReturnUnauthorizedError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;

        var query = TestQueryFactory.CreateGetQuoteByIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId);

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, null);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Unauthorized);
        result.Error.Message.Should().Be("User not found.");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetByIdAsync<QuoteSummaryDto>(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteNotFound_ShouldReturnNotFoundError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;

        var query = TestQueryFactory.CreateGetQuoteByIdQuery(
            quotePublicId: quotePublicId,
            auth0SubjectId: auth0SubjectId);

        var user = TestEntityFactory.CreateUser(auth0SubjectId: auth0SubjectId);

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(auth0SubjectId, user);
        _mockQuoteQueries.SetupGetQuoteByIdAsync<QuoteSummaryDto>(
            quotePublicId, user.Id, null);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Be("Quote not found.");

        _mockUserQueries.Verify(
            x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetByIdAsync<QuoteSummaryDto>(
                quotePublicId,
                user.Id,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
