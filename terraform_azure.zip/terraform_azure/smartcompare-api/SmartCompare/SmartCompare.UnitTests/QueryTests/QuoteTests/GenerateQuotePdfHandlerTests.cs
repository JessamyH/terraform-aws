using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Quotes.GenerateQuotePdf;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.QueryTests.QuoteTests;

public class GenerateQuotePdfHandlerTests
{
    private readonly Mock<IQuoteQueries> _mockQuoteQueries;
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly Mock<IPdfGenerationService> _mockPdfService;
    private readonly Mock<ILogoDownloadService> _mockLogoDownloadService;
    private readonly Mock<ILogger<GenerateQuotePdfHandler>> _mockLogger;
    private readonly GenerateQuotePdfHandler _handler;

    public GenerateQuotePdfHandlerTests()
    {
        _mockQuoteQueries = new Mock<IQuoteQueries>();
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();
        _mockPdfService = new Mock<IPdfGenerationService>();
        _mockLogoDownloadService = new Mock<ILogoDownloadService>();
        _mockLogger = new Mock<ILogger<GenerateQuotePdfHandler>>();

        _handler = new GenerateQuotePdfHandler(
            _mockQuoteQueries.Object,
            _mockAuthorizationService.Object,
            _mockPdfService.Object,
            _mockLogoDownloadService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task Handle_WhenAuthorizedAndQuoteExists_ShouldReturnPdfBytes()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var query = TestQueryFactory.CreateGenerateQuotePdfQuery(quotePublicId, auth0SubjectId);
        var user = TestEntityFactory.CreateUser(auth0SubjectId);

        var quoteDto = CreateTestQuoteDto(quotePublicId);
        var expectedPdfBytes = new byte[] { 0x25, 0x50, 0x44, 0x46 }; // %PDF

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(quotePublicId, auth0SubjectId, user);
        _mockQuoteQueries.SetupGetQuoteByIdAsync(quotePublicId, user.Id, quoteDto);
        _mockLogoDownloadService
            .Setup(x => x.DownloadLogoAsync(null, It.IsAny<CancellationToken>()))
            .ReturnsAsync((byte[]?)null);
        _mockPdfService.Setup(x => x.GenerateQuotePdf(quoteDto, null)).Returns(expectedPdfBytes);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().BeEquivalentTo(expectedPdfBytes);

        _mockPdfService.Verify(x => x.GenerateQuotePdf(quoteDto, null), Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnFailure()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var query = TestQueryFactory.CreateGenerateQuotePdfQuery(quotePublicId, auth0SubjectId);
        var error = MockSetupHelper.CreateForbiddenError("User doesn't have access to this quote.");

        _mockAuthorizationService.SetupFailedQuoteAuthorization(quotePublicId, auth0SubjectId, error);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Forbidden);

        _mockQuoteQueries.Verify(
            x => x.GetByIdAsync<QuoteDto>(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<CancellationToken>()),
            Times.Never);
        _mockPdfService.Verify(x => x.GenerateQuotePdf(It.IsAny<QuoteDto>(), It.IsAny<byte[]?>()), Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteNotFound_ShouldReturnNotFoundError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var query = TestQueryFactory.CreateGenerateQuotePdfQuery(quotePublicId, auth0SubjectId);
        var user = TestEntityFactory.CreateUser(auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(quotePublicId, auth0SubjectId, user);
        _mockQuoteQueries.SetupGetQuoteByIdAsync<QuoteDto>(quotePublicId, user.Id, null);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Be("Quote not found.");

        _mockPdfService.Verify(x => x.GenerateQuotePdf(It.IsAny<QuoteDto>(), It.IsAny<byte[]?>()), Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteHasLogoUrl_ShouldPassLogoBytesToPdfService()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var query = TestQueryFactory.CreateGenerateQuotePdfQuery(quotePublicId, auth0SubjectId);
        var user = TestEntityFactory.CreateUser(auth0SubjectId);
        user.AddCompanyProfile("Test Co", "Jane", "jane@test.com", "0400000000", logoUrl: "https://storage.example.com/logo.png");

        var quoteDto = CreateTestQuoteDto(quotePublicId);
        var logoBytes = new byte[] { 0x89, 0x50, 0x4E, 0x47 }; // PNG magic
        var expectedPdfBytes = new byte[] { 0x25, 0x50, 0x44, 0x46 };

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(quotePublicId, auth0SubjectId, user);
        _mockQuoteQueries.SetupGetQuoteByIdAsync(quotePublicId, user.Id, quoteDto);
        _mockLogoDownloadService
            .Setup(x => x.DownloadLogoAsync("https://storage.example.com/logo.png", It.IsAny<CancellationToken>()))
            .ReturnsAsync(logoBytes);
        _mockPdfService.Setup(x => x.GenerateQuotePdf(quoteDto, logoBytes)).Returns(expectedPdfBytes);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().BeEquivalentTo(expectedPdfBytes);

        _mockLogoDownloadService.Verify(
            x => x.DownloadLogoAsync("https://storage.example.com/logo.png", It.IsAny<CancellationToken>()),
            Times.Once);
        _mockPdfService.Verify(x => x.GenerateQuotePdf(quoteDto, logoBytes), Times.Once);
    }

    [Fact]
    public async Task Handle_WhenLogoDownloadReturnsNull_ShouldStillGeneratePdf()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var query = TestQueryFactory.CreateGenerateQuotePdfQuery(quotePublicId, auth0SubjectId);
        var user = TestEntityFactory.CreateUser(auth0SubjectId);

        user.AddCompanyProfile("Test Co", "Jane", "jane@test.com", "0400000000", logoUrl: "https://storage.example.com/missing.png");
        var quoteDto = CreateTestQuoteDto(quotePublicId);
        var expectedPdfBytes = new byte[] { 0x25, 0x50, 0x44, 0x46 };

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(quotePublicId, auth0SubjectId, user);
        _mockQuoteQueries.SetupGetQuoteByIdAsync(quotePublicId, user.Id, quoteDto);
        _mockLogoDownloadService
            .Setup(x => x.DownloadLogoAsync(It.IsAny<string?>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((byte[]?)null);
        _mockPdfService.Setup(x => x.GenerateQuotePdf(quoteDto, null)).Returns(expectedPdfBytes);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        _mockPdfService.Verify(x => x.GenerateQuotePdf(quoteDto, null), Times.Once);
    }

    [Fact]
    public async Task Handle_WhenPdfGenerationThrows_ShouldReturnFailure()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var query = TestQueryFactory.CreateGenerateQuotePdfQuery(quotePublicId, auth0SubjectId);
        var user = TestEntityFactory.CreateUser(auth0SubjectId);
        var quoteDto = CreateTestQuoteDto(quotePublicId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(quotePublicId, auth0SubjectId, user);
        _mockQuoteQueries.SetupGetQuoteByIdAsync(quotePublicId, user.Id, quoteDto);
        _mockLogoDownloadService
            .Setup(x => x.DownloadLogoAsync(It.IsAny<string?>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((byte[]?)null);
        _mockPdfService
            .Setup(x => x.GenerateQuotePdf(It.IsAny<QuoteDto>(), It.IsAny<byte[]?>()))
            .Throws(new InvalidOperationException("SkiaSharp crashed"));

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error!.Type.Should().Be(ErrorType.Unexpected);
    }

    private static QuoteDto CreateTestQuoteDto(Guid publicId) => new()
    {
        PublicId = publicId,
        QuoteNumber = "Q-001",
        IssuedDate = DateTime.UtcNow.AddDays(-5),
        ValidDate = DateTime.UtcNow.AddDays(30),
        ValidPeriod = 35,
        IssuedBy = "Test Company",
        IssuedTo = "Test Client",
        Total = 1100,
        SubTotal = 1000,
        GST = 100,
        ABN = "12345678901",
        LicenseNumber = "LIC-001",
        ContactName = "John Doe",
        ContactEmail = "john@test.com",
        ContactPhone = "0400000000",
        ProjectName = "Test Project",
        ScopeOfWorks = new List<ScopeOfWorkDto>
        {
            new() { Id = 1, Description = "Foundation work" }
        },
        Exclusions = new List<ExclusionDto>
        {
            new() { Id = 1, Description = "Landscaping" }
        },
        ProgressPayments = new List<ProgressPaymentDto>
        {
            new() { Id = 1, Description = "Deposit", Percentage = 30 }
        }
    };
}
