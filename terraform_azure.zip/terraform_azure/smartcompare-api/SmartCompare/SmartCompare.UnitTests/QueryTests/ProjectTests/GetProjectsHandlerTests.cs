using FluentAssertions;
using Moq;
using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Queries.Projects;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;
using static SmartCompare.Application.DTOs.ProjectSummaryDTOs;

namespace SmartCompare.UnitTests.QueryTests.ProjectTests;

public class GetProjectsHandlerTests
{
    private readonly Mock<IProjectQueries> _mockProjectQueries;
    private readonly GetProjectsHandler _handler;

    public GetProjectsHandlerTests()
    {
        _mockProjectQueries = new Mock<IProjectQueries>();
        _handler = new GetProjectsHandler(_mockProjectQueries.Object);
    }

    [Fact]
    public async Task Handle_WhenProjectsExist_ShouldReturnPagedResult()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();
        
        var query = TestQueryFactory.CreateGetProjectsQuery(
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var projects = new List<ProjectSummaryDto>
        {
            new()
            {
                PublicId = Guid.NewGuid(),
                ProjectName = "Project 1",
                Address = "123 Main St",
                SubcontractorType = "Electrical",
                Status = "Active",
                CreatedAt = DateTime.UtcNow.AddDays(-10),
                UpdatedAt = DateTime.UtcNow.AddDays(-5)
            },
            new()
            {
                PublicId = Guid.NewGuid(),
                ProjectName = "Project 2",
                Address = "456 Oak Ave",
                SubcontractorType = "Plumbing",
                Status = "Completed",
                CreatedAt = DateTime.UtcNow.AddDays(-20),
                UpdatedAt = DateTime.UtcNow.AddDays(-2)
            }
        };

        var pagedResult = new PagedResult<ProjectSummaryDto>
        {
            Items = projects,
            TotalCount = 2,
            PageNumber = 1,
            PageSize = 10
        };

        _mockProjectQueries.SetupGetProjectsByUserIdPagedAsync(
            auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(2);
        result.Value.TotalCount.Should().Be(2);
        result.Value.PageNumber.Should().Be(1);
        result.Value.PageSize.Should().Be(10);
        result.Value.Items.Should().BeEquivalentTo(projects);

        _mockProjectQueries.Verify(
            x => x.GetProjectsByUserIdPagedAsync(
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenNoProjectsExist_ShouldReturnEmptyPagedResult()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination();
        
        var query = TestQueryFactory.CreateGetProjectsQuery(
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var pagedResult = new PagedResult<ProjectSummaryDto>
        {
            Items = new List<ProjectSummaryDto>(),
            TotalCount = 0,
            PageNumber = 1,
            PageSize = 10
        };

        _mockProjectQueries.SetupGetProjectsByUserIdPagedAsync(
            auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().BeEmpty();
        result.Value.TotalCount.Should().Be(0);
        result.Value.TotalPages.Should().Be(0);
        result.Value.HasPreviousPage.Should().BeFalse();
        result.Value.HasNextPage.Should().BeFalse();

        _mockProjectQueries.Verify(
            x => x.GetProjectsByUserIdPagedAsync(
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithSecondPage_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageNumber: 2, pageSize: 5);
        
        var query = TestQueryFactory.CreateGetProjectsQuery(
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var projects = new List<ProjectSummaryDto>
        {
            new()
            {
                PublicId = Guid.NewGuid(),
                ProjectName = "Project 6",
                Address = "600 Elm St",
                SubcontractorType = "HVAC",
                Status = "Active",
                CreatedAt = DateTime.UtcNow.AddDays(-5),
                UpdatedAt = null
            },
            new()
            {
                PublicId = Guid.NewGuid(),
                ProjectName = "Project 7",
                Address = "700 Pine St",
                SubcontractorType = "Carpentry",
                Status = "InProgress",
                CreatedAt = DateTime.UtcNow.AddDays(-3),
                UpdatedAt = DateTime.UtcNow.AddDays(-1)
            }
        };

        var pagedResult = new PagedResult<ProjectSummaryDto>
        {
            Items = projects,
            TotalCount = 12,
            PageNumber = 2,
            PageSize = 5
        };

        _mockProjectQueries.SetupGetProjectsByUserIdPagedAsync(
            auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(2);
        result.Value.TotalCount.Should().Be(12);
        result.Value.PageNumber.Should().Be(2);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(3);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeTrue();

        _mockProjectQueries.Verify(
            x => x.GetProjectsByUserIdPagedAsync(
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithLastPage_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageNumber: 3, pageSize: 5);
        
        var query = TestQueryFactory.CreateGetProjectsQuery(
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var projects = new List<ProjectSummaryDto>
        {
            new()
            {
                PublicId = Guid.NewGuid(),
                ProjectName = "Project 11",
                Address = "1100 Cedar St",
                SubcontractorType = "Painting",
                Status = "Completed",
                CreatedAt = DateTime.UtcNow.AddDays(-30),
                UpdatedAt = DateTime.UtcNow.AddDays(-25)
            }
        };

        var pagedResult = new PagedResult<ProjectSummaryDto>
        {
            Items = projects,
            TotalCount = 11,
            PageNumber = 3,
            PageSize = 5
        };

        _mockProjectQueries.SetupGetProjectsByUserIdPagedAsync(
            auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(1);
        result.Value.TotalCount.Should().Be(11);
        result.Value.PageNumber.Should().Be(3);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(3);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeFalse();

        _mockProjectQueries.Verify(
            x => x.GetProjectsByUserIdPagedAsync(
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithDifferentPageSizes_ShouldReturnCorrectResults()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageSize: 25);
        
        var query = TestQueryFactory.CreateGetProjectsQuery(
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var projects = Enumerable.Range(1, 25)
            .Select(i => new ProjectSummaryDto
            {
                PublicId = Guid.NewGuid(),
                ProjectName = $"Project {i}",
                Address = $"{i * 100} Main St",
                SubcontractorType = "General",
                Status = "Active",
                CreatedAt = DateTime.UtcNow.AddDays(-i),
                UpdatedAt = null
            })
            .ToList();

        var pagedResult = new PagedResult<ProjectSummaryDto>
        {
            Items = projects,
            TotalCount = 50,
            PageNumber = 1,
            PageSize = 25
        };

        _mockProjectQueries.SetupGetProjectsByUserIdPagedAsync(
            auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(25);
        result.Value.TotalCount.Should().Be(50);
        result.Value.PageSize.Should().Be(25);
        result.Value.TotalPages.Should().Be(2);

        _mockProjectQueries.Verify(
            x => x.GetProjectsByUserIdPagedAsync(
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithLastPageFullyFilled_ShouldReturnCorrectPagedResult()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var pagination = TestQueryFactory.CreatePagination(pageNumber: 4, pageSize: 5);
        
        var query = TestQueryFactory.CreateGetProjectsQuery(
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var projects = Enumerable.Range(16, 5)
            .Select(i => new ProjectSummaryDto
            {
                PublicId = Guid.NewGuid(),
                ProjectName = $"Project {i}",
                Address = $"{i * 100} Maple Ave",
                SubcontractorType = "Roofing",
                Status = "Active",
                CreatedAt = DateTime.UtcNow.AddDays(-i),
                UpdatedAt = DateTime.UtcNow.AddDays(-i + 2)
            })
            .ToList();

        var pagedResult = new PagedResult<ProjectSummaryDto>
        {
            Items = projects,
            TotalCount = 20,
            PageNumber = 4,
            PageSize = 5
        };

        _mockProjectQueries.SetupGetProjectsByUserIdPagedAsync(
            auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Items.Should().HaveCount(5);
        result.Value.TotalCount.Should().Be(20);
        result.Value.PageNumber.Should().Be(4);
        result.Value.PageSize.Should().Be(5);
        result.Value.TotalPages.Should().Be(4);
        result.Value.HasPreviousPage.Should().BeTrue();
        result.Value.HasNextPage.Should().BeFalse();

        _mockProjectQueries.Verify(
            x => x.GetProjectsByUserIdPagedAsync(
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithDifferentAuth0SubjectId_ShouldCallQueriesWithCorrectId()
    {
        // Arrange
        var auth0SubjectId = TestConstants.Auth0.AlternativeSubjectId;
        var pagination = TestQueryFactory.CreatePagination();
        
        var query = TestQueryFactory.CreateGetProjectsQuery(
            auth0SubjectId: auth0SubjectId,
            pagination: pagination);

        var pagedResult = new PagedResult<ProjectSummaryDto>
        {
            Items = new List<ProjectSummaryDto>(),
            TotalCount = 0,
            PageNumber = 1,
            PageSize = 10
        };

        _mockProjectQueries.SetupGetProjectsByUserIdPagedAsync(
            auth0SubjectId, pagination, pagedResult);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();

        _mockProjectQueries.Verify(
            x => x.GetProjectsByUserIdPagedAsync(
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
