using FluentAssertions;
using MediatR;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Behaviors;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.UnitTests.Behaviors;

public class TransactionBehaviorTests
{
    private readonly Mock<IUnitOfWork> _mockUnitOfWork;
    private readonly TransactionBehavior<TestCommand, Result> _behavior;

    public TransactionBehaviorTests()
    {
        _mockUnitOfWork = new Mock<IUnitOfWork>();
        _mockUnitOfWork
            .Setup(u => u.ExecuteResilientAsync(It.IsAny<Func<CancellationToken, Task<Result>>>(), It.IsAny<CancellationToken>()))
            .Returns<Func<CancellationToken, Task<Result>>, CancellationToken>(async (func, ct) => await func(ct));
        _mockUnitOfWork.Setup(u => u.BeginTransactionAsync()).Returns(Task.CompletedTask);
        _mockUnitOfWork.Setup(u => u.CommitTransactionAsync()).Returns(Task.CompletedTask);
        _mockUnitOfWork.Setup(u => u.RollbackTransactionAsync()).Returns(Task.CompletedTask);
        _mockUnitOfWork.Setup(u => u.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);
        _behavior = new TransactionBehavior<TestCommand, Result>(_mockUnitOfWork.Object);
    }

    [Fact]
    public async Task Handle_WhenHandlerSucceeds_ShouldCommitTransaction()
    {
        var command = new TestCommand();
        var successResult = Result.Success();

        var result = await _behavior.Handle(command, Next(successResult), CancellationToken.None);

        result.Succeed.Should().BeTrue();
        _mockUnitOfWork.Verify(u => u.BeginTransactionAsync(), Times.Once);
        _mockUnitOfWork.Verify(u => u.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
        _mockUnitOfWork.Verify(u => u.CommitTransactionAsync(), Times.Once);
        _mockUnitOfWork.Verify(u => u.RollbackTransactionAsync(), Times.Never);
    }

    [Fact]
    public async Task Handle_WhenHandlerReturnsFailure_ShouldRollbackTransaction()
    {
        var command = new TestCommand();
        var failureResult = Result.Failure(new Error(ErrorType.Validation, "Validation failed"));

        var result = await _behavior.Handle(command, Next(failureResult), CancellationToken.None);

        result.Succeed.Should().BeFalse();
        _mockUnitOfWork.Verify(u => u.BeginTransactionAsync(), Times.Once);
        _mockUnitOfWork.Verify(u => u.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Never);
        _mockUnitOfWork.Verify(u => u.RollbackTransactionAsync(), Times.Once);
        _mockUnitOfWork.Verify(u => u.CommitTransactionAsync(), Times.Never);
    }

    [Fact]
    public async Task Handle_WhenHandlerThrows_ShouldRollbackAndRethrow()
    {
        var command = new TestCommand();

        var act = () => _behavior.Handle(command, NextThrows, CancellationToken.None);

        await act.Should().ThrowAsync<InvalidOperationException>().WithMessage("boom");
        _mockUnitOfWork.Verify(u => u.RollbackTransactionAsync(), Times.Once);
    }

    [Fact]
    public async Task Handle_WhenManagesOwnTransaction_ShouldSkipTransactionWrapping()
    {
        var selfManagedBehavior = new TransactionBehavior<TestSelfManagedCommand, Result>(_mockUnitOfWork.Object);
        var command = new TestSelfManagedCommand();
        var successResult = Result.Success();

        var result = await selfManagedBehavior.Handle(command, Next(successResult), CancellationToken.None);

        result.Succeed.Should().BeTrue();
        _mockUnitOfWork.Verify(u => u.BeginTransactionAsync(), Times.Never);
        _mockUnitOfWork.Verify(u => u.CommitTransactionAsync(), Times.Never);
    }

    // Helpers — MediatR 13 delegate takes CancellationToken
    private static RequestHandlerDelegate<Result> Next(Result result) => (ct) => Task.FromResult(result);
    private static RequestHandlerDelegate<Result> NextThrows => (ct) => throw new InvalidOperationException("boom");

    // Test stubs
    public sealed record TestCommand : ICommand<Result>;
    public sealed record TestSelfManagedCommand : ICommand<Result>, IManagesOwnTransaction;
}
