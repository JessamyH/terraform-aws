using FluentAssertions;
using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Behaviors;
using SmartCompare.Application.Interfaces;
using SmartCompare.SharedKernel.Results;

namespace SmartCompare.UnitTests.Behaviors;

public class ValidationBehaviorTests
{
    [Fact]
    public async Task Handle_WhenNoValidators_ShouldCallNext()
    {
        var behavior = CreateBehavior<TestCommand, Result>();
        var command = new TestCommand("valid");
        var expected = Result.Success();

        var result = await behavior.Handle(command, NextResult(expected), CancellationToken.None);

        result.Succeed.Should().BeTrue();
    }

    [Fact]
    public async Task Handle_WhenValidationPasses_ShouldCallNext()
    {
        var validator = new Mock<IValidator<TestCommand>>();
        validator.Setup(v => v.ValidateAsync(It.IsAny<ValidationContext<TestCommand>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ValidationResult());

        var behavior = CreateBehavior<TestCommand, Result>(validator.Object);
        var expected = Result.Success();

        var result = await behavior.Handle(new TestCommand("valid"), NextResult(expected), CancellationToken.None);

        result.Succeed.Should().BeTrue();
    }

    [Fact]
    public async Task Handle_WhenValidationFails_ShouldReturnResultFailure()
    {
        var validator = new Mock<IValidator<TestCommand>>();
        validator.Setup(v => v.ValidateAsync(It.IsAny<ValidationContext<TestCommand>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ValidationResult(new[] { new ValidationFailure("Name", "Name is required") }));

        var behavior = CreateBehavior<TestCommand, Result>(validator.Object);
        var nextCalled = false;
        RequestHandlerDelegate<Result> next = (ct) => { nextCalled = true; return Task.FromResult(Result.Success()); };

        var result = await behavior.Handle(new TestCommand(""), next, CancellationToken.None);

        result.Succeed.Should().BeFalse();
        result.Error.Type.Should().Be(ErrorType.Validation);
        result.Error.Message.Should().Contain("Name is required");
        nextCalled.Should().BeFalse();
    }

    [Fact]
    public async Task Handle_WhenValidationFailsWithGenericResult_ShouldReturnTypedResultFailure()
    {
        var validator = new Mock<IValidator<TestCommandWithResult>>();
        validator.Setup(v => v.ValidateAsync(It.IsAny<ValidationContext<TestCommandWithResult>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ValidationResult(new[] { new ValidationFailure("Id", "Invalid Id") }));

        var behavior = CreateBehavior<TestCommandWithResult, Result<string>>(validator.Object);
        RequestHandlerDelegate<Result<string>> next = (ct) => Task.FromResult(Result.Success<string>("ok"));

        var result = await behavior.Handle(new TestCommandWithResult(0), next, CancellationToken.None);

        result.Succeed.Should().BeFalse();
        result.Error.Type.Should().Be(ErrorType.Validation);
    }

    [Fact]
    public async Task Handle_WhenMultipleValidationFailures_ShouldAggregateErrors()
    {
        var validator = new Mock<IValidator<TestCommand>>();
        validator.Setup(v => v.ValidateAsync(It.IsAny<ValidationContext<TestCommand>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ValidationResult(new[]
            {
                new ValidationFailure("Name", "Name is required"),
                new ValidationFailure("Name", "Name too short"),
                new ValidationFailure("Email", "Email is invalid")
            }));

        var behavior = CreateBehavior<TestCommand, Result>(validator.Object);

        var result = await behavior.Handle(new TestCommand(""), NextResult(Result.Success()), CancellationToken.None);

        result.Error.Message.Should().Contain("Name is required");
        result.Error.Message.Should().Contain("Name too short");
        result.Error.Message.Should().Contain("Email is invalid");
    }

    [Fact]
    public async Task Handle_WhenRequestIsNotCommandOrQuery_ShouldSkipValidation()
    {
        var validator = new Mock<IValidator<PlainRequest>>();
        var behavior = new ValidationBehavior<PlainRequest, string>(new[] { validator.Object });
        var nextCalled = false;
        RequestHandlerDelegate<string> next = (ct) => { nextCalled = true; return Task.FromResult("ok"); };

        var result = await behavior.Handle(new PlainRequest(), next, CancellationToken.None);

        result.Should().Be("ok");
        nextCalled.Should().BeTrue();
        validator.Verify(v => v.ValidateAsync(It.IsAny<ValidationContext<PlainRequest>>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task Handle_WhenResponseIsNotResult_ShouldThrowInvalidOperationException()
    {
        var validator = new Mock<IValidator<TestQueryBadReturn>>();
        validator.Setup(v => v.ValidateAsync(It.IsAny<ValidationContext<TestQueryBadReturn>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ValidationResult(new[] { new ValidationFailure("X", "fail") }));

        var behavior = new ValidationBehavior<TestQueryBadReturn, string>(new[] { validator.Object });
        RequestHandlerDelegate<string> next = (ct) => Task.FromResult("ok");

        var act = () => behavior.Handle(new TestQueryBadReturn(), next, CancellationToken.None);

        await act.Should().ThrowAsync<InvalidOperationException>()
            .WithMessage("*Result or Result<T>*");
    }

    // Helpers
    private static ValidationBehavior<TRequest, TResponse> CreateBehavior<TRequest, TResponse>(params IValidator<TRequest>[] validators)
        where TRequest : notnull
    {
        return new ValidationBehavior<TRequest, TResponse>(validators);
    }

    private static RequestHandlerDelegate<Result> NextResult(Result result) => (ct) => Task.FromResult(result);

    // Test stubs
    public sealed record TestCommand(string Name) : ICommand<Result>;
    public sealed record TestCommandWithResult(int Id) : ICommand<Result<string>>;
    public sealed record PlainRequest : IRequest<string>;
    public sealed record TestQueryBadReturn : IQuery<string>;
}
