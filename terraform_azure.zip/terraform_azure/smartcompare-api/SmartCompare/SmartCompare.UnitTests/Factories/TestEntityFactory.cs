using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Enums;
using SmartCompare.Domain.ValueObjects;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.Factories;

/// <summary>
/// Factory class for creating test domain entities with sensible defaults
/// </summary>
public static class TestEntityFactory
{
    #region User Factory

    public static User CreateUser(
        string? auth0SubjectId = null,
        string? userName = null,
        string? email = null)
    {
        return User.Create(
            auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            userName: userName ?? TestConstants.User.DefaultUserName,
            email: email ?? TestConstants.User.DefaultEmail);
    }

    public static User CreateUserWithSubscription(
        string? stripeCustomerId = null,
        string? stripeSubscriptionId = null,
        SubscriptionTier tier = SubscriptionTier.Pro,
        SubscriptionDuration duration = SubscriptionDuration.Month)
    {
        var user = CreateUser();
        user.SetStripeCustomerId(stripeCustomerId ?? StripeTestHelper.CustomerId);
        user.AddSubscription(
            subscriptionTier: tier,
            subscriptionDuration: duration,
            subscriptionStatus: SubscriptionStatus.Active,
            startDate: DateTime.UtcNow.AddMonths(-1),
            endDate: DateTime.UtcNow.AddDays(1),
            stripeSubscriptionId: stripeSubscriptionId ?? StripeTestHelper.SubscriptionId);
        return user;
    }

    public static User CreateUserWithExpiredSubscription(
        SubscriptionTier tier = SubscriptionTier.Pro,
        SubscriptionDuration duration = SubscriptionDuration.Month)
    {
        var user = CreateUser();
        user.SetStripeCustomerId(StripeTestHelper.CustomerId);
        user.AddSubscription(
            subscriptionTier: tier,
            subscriptionDuration: duration,
            subscriptionStatus: SubscriptionStatus.Active,
            startDate: DateTime.UtcNow.AddMonths(-2),
            endDate: DateTime.UtcNow.AddDays(-1),
            stripeSubscriptionId: StripeTestHelper.SubscriptionId);
        return user;
    }

    #endregion

    #region Project Factory

    public static Project CreateProject(
        Guid? userId = null,
        string? projectName = null,
        string? address = null,
        HouseType? houseType = null,
        decimal? houseSizeSqm = null,
        int? bedrooms = null,
        int? bathrooms = null,
        int? subcontractorTypeId = null,
        int? id = null)
    {
        var project = Project.Create(
            userId: userId ?? Guid.NewGuid(),
            projectName: projectName ?? TestConstants.Project.DefaultProjectName,
            address: address ?? TestConstants.Project.DefaultAddress,
            houseType: houseType ?? HouseType.House,
            houseSizeSqm: houseSizeSqm ?? TestConstants.Project.DefaultHouseSizeSqm,
            bedrooms: bedrooms ?? TestConstants.Project.DefaultBedrooms,
            bathrooms: bathrooms ?? TestConstants.Project.DefaultBathrooms,
            subcontractorTypeId: subcontractorTypeId ?? TestConstants.Project.DefaultSubcontractorTypeId);

        if (id.HasValue)
        {
            project.WithId(id.Value);
        }

        return project;
    }

    #endregion

    #region Quote Factory

    public static Quote CreateQuote(
        string? quoteNumber = null,
        string? issuedBy = null,
        string? issuedTo = null,
        int? projectId = null,
        decimal? subTotal = null,
        decimal? gst = null,
        DateTime? issuedDate = null,
        int? validPeriod = null,
        string? abn = null,
        string? licenseNumber = null,
        string? contactName = null,
        string? contactEmail = null,
        string? contactPhone = null,
        string? pdfUrl = null,
        int? id = null)
    {
        var quote = Quote.Create(
            quoteNumber: quoteNumber ?? TestConstants.Quote.DefaultQuoteNumber,
            issuedBy: issuedBy ?? TestConstants.Quote.DefaultIssuedBy,
            issuedTo: issuedTo ?? TestConstants.Quote.DefaultIssuedTo,
            projectId: projectId ?? 1,
            subTotal: subTotal ?? TestConstants.Quote.DefaultSubTotal,
            gst: gst ?? TestConstants.Quote.DefaultGST,
            issuedDate: issuedDate ?? DateTime.UtcNow,
            validPeriod: validPeriod ?? TestConstants.Quote.DefaultValidPeriod,
            abn: ABN.Create(abn ?? TestConstants.Quote.DefaultABN),
            licenseNumber: licenseNumber ?? TestConstants.Quote.DefaultLicenseNumber,
            contactName: contactName ?? TestConstants.Quote.DefaultContactName,
            contactEmail: contactEmail ?? TestConstants.Quote.DefaultContactEmail,
            contactPhone: contactPhone ?? TestConstants.Quote.DefaultContactPhone,
            pdfUrl: pdfUrl ?? TestConstants.Quote.DefaultPdfUrl);

        if (id.HasValue)
        {
            quote.WithId(id.Value);
        }

        return quote;
    }

    public static Quote CreateQuoteWithProgressPayments(
        int progressPaymentCount = 3,
        string? quoteNumber = null,
        int? projectId = null,
        int? id = null)
    {
        var quote = CreateQuote(
            quoteNumber: quoteNumber,
            projectId: projectId,
            id: id);

        for (int i = 0; i < progressPaymentCount; i++)
        {
            quote.AddProgressPayment(
                percentage: 30m,
                description: $"Payment {i + 1}");
        }

        return quote;
    }

    public static Quote CreateQuoteWithScopeOfWorks(
        int scopeOfWorkCount = 3,
        string? quoteNumber = null,
        int? projectId = null,
        int? id = null)
    {
        var quote = CreateQuote(
            quoteNumber: quoteNumber,
            projectId: projectId,
            id: id);

        for (int i = 0; i < scopeOfWorkCount; i++)
        {
            quote.AddScopeOfWork($"Scope of Work {i + 1}");
        }

        return quote;
    }

    public static Quote CreateQuoteWithExclusions(
        int exclusionCount = 3,
        string? quoteNumber = null,
        int? projectId = null,
        int? id = null)
    {
        var quote = CreateQuote(
            quoteNumber: quoteNumber,
            projectId: projectId,
            id: id);

        for (int i = 0; i < exclusionCount; i++)
        {
            quote.AddExclusion($"Exclusion {i + 1}");
        }

        return quote;
    }

    #endregion

    #region ProgressPayment Factory

    public static ProgressPayment CreateProgressPayment(
        int quoteId = 1,
        decimal? percentage = null,
        string? description = null)
    {
        return ProgressPayment.Create(
            quoteId: quoteId,
            percentage: percentage ?? TestConstants.ProgressPayment.DefaultPercentage,
            description: description ?? TestConstants.ProgressPayment.DefaultDescription);
    }

    #endregion

    #region ScopeOfWork Factory

    public static ScopeOfWork CreateScopeOfWork(
        int quoteId = 1,
        string? description = null)
    {
        return ScopeOfWork.Create(
            quoteId: quoteId,
            description: description ?? TestConstants.ScopeOfWork.DefaultDescription);
    }

    #endregion

    #region Exclusion Factory

    public static Exclusion CreateExclusion(
        int quoteId = 1,
        string? description = null)
    {
        return Exclusion.Create(
            quoteId: quoteId,
            description: description ?? TestConstants.Exclusion.DefaultDescription);
    }

    #endregion
}
