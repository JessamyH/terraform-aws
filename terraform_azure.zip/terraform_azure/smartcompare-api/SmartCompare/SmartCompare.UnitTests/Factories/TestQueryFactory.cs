using SmartCompare.Application.Common.Paging;
using SmartCompare.Application.Queries.Projects;
using SmartCompare.Application.Queries.Quotes.GetExclusiveItemsByQuoteId;
using SmartCompare.Application.Queries.Quotes.GetProgressPaymentsByQuoteId;
using SmartCompare.Application.Queries.Quotes.GetQuoteById;
using SmartCompare.Application.Queries.Quotes.GetQuoteDetailById;
using SmartCompare.Application.Queries.Quotes.GetQuotesByProjectId;
using SmartCompare.Application.Queries.Quotes.GenerateQuotePdf;
using SmartCompare.Application.Queries.Quotes.GetScopeOfWorkByQuoteId;
using SmartCompare.Application.Queries.Users.GetCurrentUser;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.Factories;

/// <summary>
/// Factory class for creating test queries with sensible defaults
/// </summary>
public static class TestQueryFactory
{
    #region Project Queries

    public static GetProjectsQuery CreateGetProjectsQuery(
        string? auth0SubjectId = null,
        Pagination? pagination = null)
    {
        return new GetProjectsQuery(
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            Pagination: pagination ?? CreatePagination());
    }

    #endregion

    #region Quote Queries

    public static GetQuoteByIdQuery CreateGetQuoteByIdQuery(
        Guid? quotePublicId = null,
        string? auth0SubjectId = null)
    {
        return new GetQuoteByIdQuery(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId);
    }

    public static GetQuoteDetailByIdQuery CreateGetQuoteDetailByIdQuery(
        Guid? quotePublicId = null,
        string? auth0SubjectId = null)
    {
        return new GetQuoteDetailByIdQuery(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId);
    }

    public static GenerateQuotePdfQuery CreateGenerateQuotePdfQuery(
        Guid? quotePublicId = null,
        string? auth0SubjectId = null)
    {
        return new GenerateQuotePdfQuery(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId);
    }

    public static GetQuotesByProjectIdQuery CreateGetQuotesByProjectIdQuery(
        Guid? projectPublicId = null,
        string? auth0SubjectId = null,
        Pagination? pagination = null)
    {
        return new GetQuotesByProjectIdQuery(
            projectPublicId: projectPublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            Pagination: pagination ?? CreatePagination());
    }

    #endregion

    #region Exclusion Queries

    public static GetExclusiveItemsByQuoteIdQuery CreateGetExclusiveItemsByQuoteIdQuery(
        Guid? quotePublicId = null,
        string? auth0SubjectId = null,
        Pagination? pagination = null)
    {
        return new GetExclusiveItemsByQuoteIdQuery(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            Pagination: pagination ?? CreatePagination());
    }

    #endregion

    #region ProgressPayment Queries

    public static GetProgressPaymentsByQuoteIdQuery CreateGetProgressPaymentsByQuoteIdQuery(
        Guid? quotePublicId = null,
        string? auth0SubjectId = null,
        Pagination? pagination = null)
    {
        return new GetProgressPaymentsByQuoteIdQuery(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            Pagination: pagination ?? CreatePagination());
    }

    #endregion

    #region ScopeOfWork Queries

    public static GetScopeOfWorkItemsByQuoteIdQuery CreateGetScopeOfWorkItemsByQuoteIdQuery(
        Guid? quotePublicId = null,
        string? auth0SubjectId = null,
        Pagination? pagination = null)
    {
        return new GetScopeOfWorkItemsByQuoteIdQuery(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            Pagination: pagination ?? CreatePagination());
    }

    #endregion

    #region User Queries

    public static GetCurrentUserQuery CreateGetCurrentUserQuery(
        string? auth0SubjectId = null)
    {
        return new GetCurrentUserQuery(
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId);
    }

    #endregion

    #region Pagination

    public static Pagination CreatePagination(
        int? pageNumber = null,
        int? pageSize = null)
    {
        return new Pagination(
            PageNumber: pageNumber ?? 1,
            PageSize: pageSize ?? 10);
    }

    #endregion
}
