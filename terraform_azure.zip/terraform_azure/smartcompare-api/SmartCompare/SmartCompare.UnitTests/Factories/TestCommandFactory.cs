using SmartCompare.Application.Commands.Projects.DeleteProject;
using SmartCompare.Application.Commands.Projects.UpdateProject;
using SmartCompare.Application.Commands.Quotes.AddExclusions;
using SmartCompare.Application.Commands.Quotes.AddProgressPayments;
using SmartCompare.Application.Commands.Quotes.AddBatchScopeOfWork;
using SmartCompare.Application.Commands.Quotes.AddScopeOfWork;
using SmartCompare.Application.Commands.Quotes.CreateQuote;
using SmartCompare.Application.Commands.Quotes.DeleteExclusion;
using SmartCompare.Application.Commands.Quotes.DeleteProgressPayment;
using SmartCompare.Application.Commands.Quotes.DeleteQuote;
using SmartCompare.Application.Commands.Quotes.DeleteScopeOfWork;
using SmartCompare.Application.Commands.Quotes.UpdateExclusion;
using SmartCompare.Application.Commands.Quotes.UpdateProgressPayment;
using SmartCompare.Application.Commands.Quotes.UpdateQuote;
using SmartCompare.Application.Commands.Quotes.UpdateScopeOfWork;
using SmartCompare.Application.Commands.Users.SyncUser;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Commands.Projects.CreateProject;
using SmartCompare.Domain.Enums;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.Factories;

/// <summary>
/// Factory class for creating test commands with sensible defaults
/// </summary>
public static class TestCommandFactory
{
    #region Project Commands

    public static CreateProjectCommand CreateCreateProjectCommand(
        string? auth0SubjectId = null,
        string? projectName = null,
        string? address = null,
        HouseType? houseType = null,
        decimal? houseSizeSqm = null,
        int? bedrooms = null,
        int? bathrooms = null,
        int? subcontractorTypeId = null)
    {
        return new CreateProjectCommand(
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            ProjectName: projectName ?? TestConstants.Project.DefaultProjectName,
            Address: address ?? TestConstants.Project.DefaultAddress,
            HouseType: houseType ?? HouseType.House,
            HouseSizeSqm: houseSizeSqm ?? TestConstants.Project.DefaultHouseSizeSqm,
            Bedrooms: bedrooms ?? TestConstants.Project.DefaultBedrooms,
            Bathrooms: bathrooms ?? TestConstants.Project.DefaultBathrooms,
            SubcontractorTypeId: subcontractorTypeId ?? TestConstants.Project.DefaultSubcontractorTypeId);
    }

    public static DeleteProjectCommand CreateDeleteProjectCommand(
        Guid? projectId = null,
        string? auth0SubjectId = null)
    {
        return new DeleteProjectCommand(
            ProjectId: projectId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId);
    }

    public static UpdateProjectCommand CreateUpdateProjectCommand(
        Guid? projectId = null,
        UpdateProjectDto? updateDto = null,
        string? auth0SubjectId = null)
    {
        return new UpdateProjectCommand
        {
            ProjectId = projectId ?? Guid.NewGuid(),
            UpdateDto = updateDto ?? CreateUpdateProjectDto(),
            Auth0SubjectId = auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId
        };
    }

    #endregion

    #region User Commands
    public static SyncUserCommand CreateSyncUserCommand(
        string? auth0SubjectId = null,
        string? userName = null,
        string? email = null)
    {
        return new SyncUserCommand
        (
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            UserName: userName ?? TestConstants.User.DefaultUserName,
            Email: email ?? TestConstants.User.DefaultEmail
        );
    }

    #endregion

    #region Quote Commands

    public static CreateQuoteCommand CreateCreateQuoteCommand(
        Guid? projectPublicId = null,
        string? auth0SubjectId = null,
        string? quoteNumber = null,
        DateTime? issuedDate = null,
        int? validPeriod = null,
        string? issuedTo = null,
        string? issuedBy = null,
        decimal? subTotal = null,
        decimal? gst = null,
        string? abn = null,
        string? licenseNumber = null,
        string? contactName = null,
        string? contactEmail = null,
        string? contactPhone = null,
        string? pdfUrl = null)
    {
        return new CreateQuoteCommand(
            ProjectPublicId: projectPublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            QuoteNumber: quoteNumber ?? TestConstants.Quote.DefaultQuoteNumber,
            IssuedDate: issuedDate ?? DateTime.UtcNow,
            ValidPeriod: validPeriod ?? TestConstants.Quote.DefaultValidPeriod,
            IssuedTo: issuedTo ?? TestConstants.Quote.DefaultIssuedTo,
            IssuedBy: issuedBy ?? TestConstants.Quote.DefaultIssuedBy,
            SubTotal: subTotal ?? TestConstants.Quote.DefaultSubTotal,
            GST: gst ?? TestConstants.Quote.DefaultGST,
            ABN: abn ?? TestConstants.Quote.DefaultABN,
            LicenseNumber: licenseNumber ?? TestConstants.Quote.DefaultLicenseNumber,
            ContactName: contactName ?? TestConstants.Quote.DefaultContactName,
            ContactEmail: contactEmail ?? TestConstants.Quote.DefaultContactEmail,
            ContactPhone: contactPhone ?? TestConstants.Quote.DefaultContactPhone,
            PDFUrl: pdfUrl ?? TestConstants.Quote.DefaultPdfUrl);
    }

    public static DeleteQuoteCommand CreateDeleteQuoteCommand(
        Guid? quoteId = null,
        string? auth0SubjectId = null)
    {
        return new DeleteQuoteCommand(
            QuoteId: quoteId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId);
    }

    public static UpdateQuoteCommand CreateUpdateQuoteCommand(
        Guid? quotePublicId = null,
        UpdateQuoteDto? updateQuoteDto = null,
        string? auth0SubjectId = null)
    {
        return new UpdateQuoteCommand(
            quotePublicId: quotePublicId ?? Guid.NewGuid(),
            updateQuoteDto: updateQuoteDto ?? CreateUpdateQuoteDto(),
            auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId);
    }

    #endregion

    #region Exclusion Commands

    public static AddExclusionsCommand CreateAddExclusionsCommand(
        Guid? quotePublicId = null,
        string? auth0SubjectId = null,
        List<AddExclusionsDto>? items = null)
    {
        return new AddExclusionsCommand(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            Items: items ?? new List<AddExclusionsDto>
            {
                new() { Description = TestConstants.Exclusion.DefaultDescription }
            });
    }

    public static DeleteExclusionCommand CreateDeleteExclusionCommand(
        Guid? quotePublicId = null,
        int? exclusionId = null,
        string? auth0SubjectId = null)
    {
        return new DeleteExclusionCommand(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            ExclusionId: exclusionId ?? 1,
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId);
    }

    public static UpdateExclusionCommand CreateUpdateExclusionCommand(
        Guid? quotePublicId = null,
        int? exclusionId = null,
        UpdateExclusionRequest? updateExclusionRequest = null,
        string? auth0SubjectId = null)
    {
        return new UpdateExclusionCommand(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            ExclusionId: exclusionId ?? 1,
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            UpdateExclusionRequest: updateExclusionRequest ?? CreateUpdateExclusionRequest());
    }

    #endregion

    #region ProgressPayment Commands
    public static AddProgressPaymentCommand CreateAddProgressPaymentCommand(
        Guid? quotePublicId = null,
        string? auth0SubjectId = null,
        List<AddProgressPaymentRequestDto>? items = null)
    {
        return new AddProgressPaymentCommand(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            Items: items ?? new List<AddProgressPaymentRequestDto>
            {
                new() { Description = TestConstants.ProgressPayment.DefaultDescription, 
                    Percentage = TestConstants.ProgressPayment.DefaultPercentage }
            });
    }

    public static UpdateProgressPaymentCommand CreateUpdateProgressPaymentCommand(
        Guid? quotePublicId = null,
        int? progressPaymentId = null,
        UpdateProgressPaymentRequest? updateProgressPaymentRequest = null,
        string? auth0SubjectId = null)
    {
        return new UpdateProgressPaymentCommand(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            ProgressPaymentId: progressPaymentId ?? 1,
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            UpdateProgressPaymentRequest: updateProgressPaymentRequest ?? new UpdateProgressPaymentRequest
            {
                Description = TestConstants.ProgressPayment.DefaultDescription,
                Percentage = TestConstants.ProgressPayment.DefaultPercentage
            });
    }

    public static DeleteProgressPaymentCommand CreateDeleteProgressPaymentCommand(
        Guid? quotePublicId = null,
        int? progressPaymentId = null,
        string? auth0SubjectId = null)
    {
        return new DeleteProgressPaymentCommand(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            ProgressPaymentId: progressPaymentId ?? 1,
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId);
    }
    #endregion

    #region ScopeOfWork Commands

    public static AddScopeOfWorkCommand CreateAddScopeOfWorkCommand(
        Guid? quoteId = null,
        string? auth0SubjectId = null,
        string? description = null)
    {
        return new AddScopeOfWorkCommand(
            QuoteId: quoteId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            Description: description ?? TestConstants.ScopeOfWork.DefaultDescription);
    }

    public static UpdateScopeOfWorkCommand CreateUpdateScopeOfWorkCommand(
        Guid? quotePublicId = null,
        int? scopeOfWorkId = null,
        UpdateScopeOfWorkRequestDto? scopeOfWorkRequestDto = null,
        string? auth0SubjectId = null)
    {
        return new UpdateScopeOfWorkCommand(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            ScopeOfWorkId: scopeOfWorkId ?? 1,
            ScopeOfWorkRequestDto: scopeOfWorkRequestDto ?? CreateUpdateScopeOfWorkRequestDto(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId);
    }

    public static AddBatchScopeOfWorkCommand CreateAddBatchScopeOfWorkCommand(
        Guid? quotePublicId = null,
        string? auth0SubjectId = null,
        List<AddScopeOfWorkDto>? items = null)
    {
        return new AddBatchScopeOfWorkCommand(
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            Items: items ?? new List<AddScopeOfWorkDto>
            {
                new() { Description = TestConstants.ScopeOfWork.DefaultDescription }
            });
    }

    public static AddScopeOfWorkDto CreateAddScopeOfWorkDto(
        string? description = null)
    {
        return new AddScopeOfWorkDto
        {
            Description = description ?? TestConstants.ScopeOfWork.DefaultDescription
        };
    }

    public static DeleteScopeOfWorkCommand CreateDeleteScopeOfWorkCommand(
        Guid? quotePublicId = null,
        int? scopeOfWorkId = null,
        string? auth0SubjectId = null)
    {
        return new DeleteScopeOfWorkCommand(
            Auth0SubjectId: auth0SubjectId ?? TestConstants.Auth0.DefaultSubjectId,
            QuotePublicId: quotePublicId ?? Guid.NewGuid(),
            ScopeOfWorkId: scopeOfWorkId ?? 1);
    }

    #endregion

    #region DTOs

    public static UpdateProjectDto CreateUpdateProjectDto(
        string? projectName = null,
        string? address = null,
        HouseType? houseType = null,
        decimal? houseSizeSqm = null,
        int? bedrooms = null,
        int? bathrooms = null,
        int? subcontractorTypeId = null,
        ProjectStatus? status = null)
    {
        return new UpdateProjectDto
        {
            ProjectName = projectName ?? TestConstants.Project.DefaultProjectName,
            Address = address ?? TestConstants.Project.DefaultAddress,
            HouseType = houseType ?? HouseType.House,
            HouseSizeSqm = houseSizeSqm ?? TestConstants.Project.DefaultHouseSizeSqm,
            Bedrooms = bedrooms ?? TestConstants.Project.DefaultBedrooms,
            Bathrooms = bathrooms ?? TestConstants.Project.DefaultBathrooms,
            SubcontractorTypeId = subcontractorTypeId ?? TestConstants.Project.DefaultSubcontractorTypeId,
            Status = status ?? ProjectStatus.InProgress
        };
    }

    public static ProjectDto CreateProjectDto(
        Guid? publicId = null,
        string? projectName = null,
        string? address = null,
        HouseType? houseType = null,
        decimal? houseSizeSqm = null,
        int? bedrooms = null,
        int? bathrooms = null,
        int? subcontractorTypeId = null,
        ProjectStatus? status = null,
        DateTime? createdAt = null,
        DateTime? updatedAt = null)
    {
        return new ProjectDto
        {
            PublicId = publicId ?? Guid.NewGuid(),
            ProjectName = projectName ?? TestConstants.Project.DefaultProjectName,
            Address = address ?? TestConstants.Project.DefaultAddress,
            HouseType = houseType ?? HouseType.House,
            HouseSizeSqm = houseSizeSqm ?? TestConstants.Project.DefaultHouseSizeSqm,
            Bedrooms = bedrooms ?? TestConstants.Project.DefaultBedrooms,
            Bathrooms = bathrooms ?? TestConstants.Project.DefaultBathrooms,
            SubcontractorTypeId = subcontractorTypeId ?? TestConstants.Project.DefaultSubcontractorTypeId,
            Status = status ?? ProjectStatus.InProgress,
            CreatedAt = createdAt ?? DateTime.UtcNow,
            UpdatedAt = updatedAt
        };
    }

    public static UpdateQuoteDto CreateUpdateQuoteDto(
        string? quoteNumber = null,
        DateTime? issuedDate = null,
        int? validPeriod = null,
        string? issuedBy = null,
        string? issuedTo = null,
        decimal? subTotal = null,
        decimal? gst = null,
        string? abn = null,
        string? licenseNumber = null,
        string? contactName = null,
        string? contactEmail = null,
        string? contactPhone = null,
        string? pdfUrl = null)
    {
        return new UpdateQuoteDto
        {
            QuoteNumber = quoteNumber ?? TestConstants.Quote.DefaultQuoteNumber,
            IssuedDate = issuedDate ?? DateTime.UtcNow,
            ValidPeriod = validPeriod ?? TestConstants.Quote.DefaultValidPeriod,
            IssuedBy = issuedBy ?? TestConstants.Quote.DefaultIssuedBy,
            IssuedTo = issuedTo ?? TestConstants.Quote.DefaultIssuedTo,
            SubTotal = subTotal ?? TestConstants.Quote.DefaultSubTotal,
            GST = gst ?? TestConstants.Quote.DefaultGST,
            ABN = abn ?? TestConstants.Quote.DefaultABN,
            LicenseNumber = licenseNumber ?? TestConstants.Quote.DefaultLicenseNumber,
            ContactName = contactName ?? TestConstants.Quote.DefaultContactName,
            ContactEmail = contactEmail ?? TestConstants.Quote.DefaultContactEmail,
            ContactPhone = contactPhone ?? TestConstants.Quote.DefaultContactPhone,
            PDFUrl = pdfUrl ?? TestConstants.Quote.DefaultPdfUrl
        };
    }

    public static QuoteSummaryDto CreateQuoteSummaryDto(
        Guid? quotePublicId = null,
        string? quoteNumber = null,
        DateTime? issuedDate = null,
        DateTime? validDate = null,
        int? validPeriod = null,
        string? issuedBy = null,
        string? issuedTo = null,
        decimal? total = null,
        decimal? subTotal = null,
        decimal? gst = null,
        string? abn = null,
        string? licenseNumber = null,
        string? contactName = null,
        string? contactEmail = null,
        string? contactPhone = null,
        string? pdfUrl = null,
        Guid? projectPublicId = null)
    {
        return new QuoteSummaryDto
        {
            QuotePublicId = quotePublicId ?? Guid.NewGuid(),
            QuoteNumber = quoteNumber ?? TestConstants.Quote.DefaultQuoteNumber,
            IssuedDate = issuedDate ?? DateTime.UtcNow,
            ValidDate = validDate ?? DateTime.UtcNow.AddDays(TestConstants.Quote.DefaultValidDays),
            ValidPeriod = validPeriod ?? TestConstants.Quote.DefaultValidPeriod,
            IssuedBy = issuedBy ?? TestConstants.Quote.DefaultIssuedBy,
            IssuedTo = issuedTo ?? TestConstants.Quote.DefaultIssuedTo,
            Total = total ?? TestConstants.Quote.DefaultTotal,
            SubTotal = subTotal ?? TestConstants.Quote.DefaultSubTotal,
            GST = gst ?? TestConstants.Quote.DefaultGST,
            ABN = abn ?? TestConstants.Quote.DefaultABN,
            LicenseNumber = licenseNumber ?? TestConstants.Quote.DefaultLicenseNumber,
            ContactName = contactName ?? TestConstants.Quote.DefaultContactName,
            ContactEmail = contactEmail ?? TestConstants.Quote.DefaultContactEmail,
            ContactPhone = contactPhone ?? TestConstants.Quote.DefaultContactPhone,
            PDFUrl = pdfUrl ?? TestConstants.Quote.DefaultPdfUrl,
            ProjectPublicId = projectPublicId ?? Guid.NewGuid()
        };
    }

    public static UpdateExclusionRequest CreateUpdateExclusionRequest(
        string? description = null)
    {
        return new UpdateExclusionRequest
        {
            Description = description ?? TestConstants.Exclusion.DefaultDescription
        };
    }

    public static AddExclusionsDto CreateAddExclusionsDto(
        string? description = null)
    {
        return new AddExclusionsDto
        {
            Description = description ?? TestConstants.Exclusion.DefaultDescription
        };
    }

    public static AddProgressPaymentRequestDto CreateAddProgressPaymentRequestDto(
        string? description = null,
        decimal? percentage = null)
    {
        return new AddProgressPaymentRequestDto
        {
            Description = description ?? TestConstants.ProgressPayment.DefaultDescription,
            Percentage = percentage ?? TestConstants.ProgressPayment.DefaultPercentage
        };
    }

    public static UpdateProgressPaymentRequest CreateUpdateProgressPaymentRequest(
        string? description = null,
        decimal? percentage = null)
    {
        return new UpdateProgressPaymentRequest
        {
            Description = description ?? TestConstants.ProgressPayment.DefaultDescription,
            Percentage = percentage ?? TestConstants.ProgressPayment.DefaultPercentage
        };
    }

    public static UpdateScopeOfWorkRequestDto CreateUpdateScopeOfWorkRequestDto(
        string? description = null)
    {
        return new UpdateScopeOfWorkRequestDto
        {
            Description = description ?? TestConstants.ScopeOfWork.DefaultDescription
        };
    }

    #endregion
}
