using FluentAssertions;
using Moq;
using SmartCompare.Application.Commands.Quotes.DeleteQuote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests;

/// <summary>
/// Refactored version using factories and helpers
/// </summary>
public class DeleteQuoteCommandHandlerTests
{
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<IQuoteQueries> _mockQuoteQueries;
    private readonly Mock<IUnitOfWork> _mockUnitOfWork;
    private readonly DeleteQuoteCommandHandler _handler;

    public DeleteQuoteCommandHandlerTests()
    {
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockQuoteQueries = new Mock<IQuoteQueries>();
        _mockUnitOfWork = new Mock<IUnitOfWork>();

        _handler = new DeleteQuoteCommandHandler(
            _mockQuoteRepository.Object,
            _mockQuoteQueries.Object,
            _mockUnitOfWork.Object);
    }

    [Fact]
    public async Task Handle_WhenAuthorizedAndQuoteExists_ShouldDeleteSuccessfully()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;

        var command = TestCommandFactory.CreateDeleteQuoteCommand(
            quoteId: quoteId,
            auth0SubjectId: auth0SubjectId);

        var quote = TestEntityFactory.CreateQuote(id: 1);

        _mockQuoteQueries.SetupGetQuoteOwnerIdAsync(quoteId, auth0SubjectId);
        _mockQuoteRepository.SetupGetQuoteByIdAsync(quoteId, quote);
        _mockQuoteRepository.SetupDelete();

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();

        _mockQuoteRepository.Verify(
            x => x.Delete(quote),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenQuoteNotFound_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var command = TestCommandFactory.CreateDeleteQuoteCommand(quoteId: quoteId);

        _mockQuoteQueries.SetupGetQuoteOwnerIdAsync(quoteId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain($"Quote with {quoteId} not found");

        _mockQuoteRepository.Verify(
            x => x.Delete(It.IsAny<Quote>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var auth0SubjectId = TestConstants.Auth0.DefaultSubjectId;
        var differentAuth0SubjectId = TestConstants.Auth0.AlternativeSubjectId;

        var command = TestCommandFactory.CreateDeleteQuoteCommand(
            quoteId: quoteId,
            auth0SubjectId: auth0SubjectId);

        _mockQuoteQueries.SetupGetQuoteOwnerIdAsync(quoteId, differentAuth0SubjectId);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain("not authorized to delete this quote");

        _mockQuoteRepository.Verify(
            x => x.Delete(It.IsAny<Quote>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteNotFoundAfterAuthCheck_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var command = TestCommandFactory.CreateDeleteQuoteCommand(quoteId: quoteId);

        _mockQuoteQueries.SetupGetQuoteOwnerIdAsync(quoteId, command.Auth0SubjectId);
        _mockQuoteRepository.SetupGetQuoteByIdAsync(quoteId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain($"Quote with {quoteId} not found");

        _mockQuoteRepository.Verify(
            x => x.Delete(It.IsAny<Quote>()),
            Times.Never);
    }
}
