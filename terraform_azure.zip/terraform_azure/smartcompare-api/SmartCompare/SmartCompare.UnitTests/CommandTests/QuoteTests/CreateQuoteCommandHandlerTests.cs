using AutoMapper;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.Application.Commands.Quotes.CreateQuote;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests;

/// <summary>
/// Refactored version of CreateQuoteCommandHandlerTests using TestEntityFactory and MockSetupHelper
/// This demonstrates how to use the factories to reduce code duplication
/// </summary>
public class CreateQuoteCommandHandlerTests
{
    private readonly Mock<IProjectAuthorizationService> _mockAuthorizationService;
    private readonly Mock<IProjectQueries> _mockProjectQueries;
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<ILogger<CreateQuoteCommandHandler>> _mockLogger;
    private readonly IMapper _mapper = TestMapperHelper.Mapper;
    private readonly CreateQuoteCommandHandler _handler;

    public CreateQuoteCommandHandlerTests()
    {
        _mockAuthorizationService = new Mock<IProjectAuthorizationService>();
        _mockProjectQueries = new Mock<IProjectQueries>();
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockLogger = new Mock<ILogger<CreateQuoteCommandHandler>>();

        _handler = new CreateQuoteCommandHandler(
            _mockAuthorizationService.Object,
            _mockProjectQueries.Object,
            _mockQuoteRepository.Object,
            _mockLogger.Object,
            _mapper);
    }

    [Fact]
    public async Task Handle_WhenAuthorizedAndProjectExists_ShouldCreateQuoteSuccessfully()
    {
        // Arrange
        var projectPublicId = Guid.NewGuid();
        var userId = Guid.NewGuid();

        // Use factories to create test data
        var command = TestCommandFactory.CreateCreateQuoteCommand(projectPublicId: projectPublicId);
        var user = TestEntityFactory.CreateUser();
        var project = TestEntityFactory.CreateProject(userId: userId, id: 1);
        // Use setup helpers
        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(
            projectPublicId,
            command.Auth0SubjectId,
            user);

        _mockProjectQueries.SetupGetByIdAsync(projectPublicId, project);
        _mockQuoteRepository.SetupAddAsync();

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.QuotePublicId.Should().NotBeEmpty();
        result.Value.ProjectPublicId.Should().Be(project.PublicId);
        result.Value.QuoteNumber.Should().Be(command.QuoteNumber);
        result.Value.IssuedBy.Should().Be(command.IssuedBy);
        result.Value.IssuedTo.Should().Be(command.IssuedTo);
        result.Value.SubTotal.Should().Be(command.SubTotal);
        result.Value.GST.Should().Be(command.GST);
        result.Value.Total.Should().Be(command.SubTotal + command.GST);
        result.Value.IssuedDate.Should().Be(command.IssuedDate);
        result.Value.ValidPeriod.Should().Be(command.ValidPeriod);
        result.Value.ABN.Should().Be(command.ABN);
        result.Value.LicenseNumber.Should().Be(command.LicenseNumber);
        result.Value.ContactName.Should().Be(command.ContactName);
        result.Value.ContactEmail.Should().Be(command.ContactEmail);
        result.Value.ContactPhone.Should().Be(command.ContactPhone);

        _mockQuoteRepository.Verify(
            x => x.AddAsync(It.IsAny<Quote>(), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var projectPublicId = Guid.NewGuid();
        var command = TestCommandFactory.CreateCreateQuoteCommand(projectPublicId: projectPublicId);
        var error = MockSetupHelper.CreateForbiddenError();

        _mockAuthorizationService.SetupFailedProjectAuthorization(
            projectPublicId, 
            command.Auth0SubjectId, 
            error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(error.Type);
        result.Error.Message.Should().Contain(error.Message);

        _mockProjectQueries.Verify(
            x => x.GetByIdAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()),
            Times.Never);

        _mockQuoteRepository.Verify(
            x => x.AddAsync(It.IsAny<Quote>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenProjectNotFound_ShouldReturnNotFoundError()
    {
        // Arrange
        var projectPublicId = Guid.NewGuid();
        var command = TestCommandFactory.CreateCreateQuoteCommand(projectPublicId: projectPublicId);
        var user = TestEntityFactory.CreateUser();

        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(
            projectPublicId, 
            command.Auth0SubjectId, 
            user);
        
        _mockProjectQueries.SetupGetByIdAsync(projectPublicId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain("Project was not found");

        _mockQuoteRepository.Verify(
            x => x.AddAsync(It.IsAny<Quote>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenAbnChecksumInvalid_ShouldReturnValidationError()
    {
        // Arrange
        var projectPublicId = Guid.NewGuid();
        var command = TestCommandFactory.CreateCreateQuoteCommand(
            projectPublicId: projectPublicId,
            abn: "12345678901"); // valid length, invalid checksum

        var user = TestEntityFactory.CreateUser();
        var project = TestEntityFactory.CreateProject(id: 1);

        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(
            projectPublicId, command.Auth0SubjectId, user);
        _mockProjectQueries.SetupGetByIdAsync(projectPublicId, project);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(global::SharedKernel.Errors.ErrorType.Validation);

        _mockQuoteRepository.Verify(
            x => x.AddAsync(It.IsAny<Quote>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WithCustomValues_ShouldCreateQuoteWithSpecifiedData()
    {
        // Arrange
        var projectPublicId = Guid.NewGuid();
        var customQuoteNumber = "Q-999";
        var customSubTotal = 5000m;
        var customGst = 500m;

        var command = TestCommandFactory.CreateCreateQuoteCommand(
            projectPublicId: projectPublicId,
            quoteNumber: customQuoteNumber,
            subTotal: customSubTotal,
            gst: customGst);

        var user = TestEntityFactory.CreateUser();
        var project = TestEntityFactory.CreateProject(id: 1);
        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(
            projectPublicId,
            command.Auth0SubjectId,
            user);

        _mockProjectQueries.SetupGetByIdAsync(projectPublicId, project);
        _mockQuoteRepository.SetupAddAsync();

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        
        _mockQuoteRepository.Verify(
            x => x.AddAsync(
                It.Is<Quote>(q => 
                    q.QuoteNumber == customQuoteNumber &&
                    q.SubTotal == customSubTotal &&
                    q.GST == customGst),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
