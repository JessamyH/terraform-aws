using AutoMapper;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Commands.Quotes.UpdateProgressPayment;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests.ProgressPaymentTests;

public class UpdateProgressPaymentCommandHandlerTests
{
    private readonly Mock<ILogger<UpdateProgressPaymentCommandHandler>> _mockLogger;
    private readonly IMapper _mapper = TestMapperHelper.Mapper;
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly UpdateProgressPaymentCommandHandler _handler;

    public UpdateProgressPaymentCommandHandlerTests()
    {
        _mockLogger = new Mock<ILogger<UpdateProgressPaymentCommandHandler>>();
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();

        _handler = new UpdateProgressPaymentCommandHandler(
            _mockLogger.Object,
            _mapper,
            _mockQuoteRepository.Object,
            _mockAuthorizationService.Object);
    }

    [Fact]
    public async Task Handle_WhenAuthorizedAndProgressPaymentExists_ShouldUpdateSuccessfully()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuoteWithProgressPayments(progressPaymentCount: 1, id: 1);

        var progressPayment = quote.ProgressPayments.First().WithId(1);
        var progressPaymentId = progressPayment.Id;

        var updatedDescription = "Updated Progress Payment Description";
        var updatedPercentage = 75;

        var requestDto = new UpdateProgressPaymentRequest
        {
            Description = updatedDescription,
            Percentage = updatedPercentage
        };

        var command = TestCommandFactory.CreateUpdateProgressPaymentCommand(
            quotePublicId: quotePublicId,
            progressPaymentId: progressPaymentId,
            auth0SubjectId: user.Auth0SubjectId,
            updateProgressPaymentRequest: requestDto);

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));

        _mockQuoteRepository
            .Setup(x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Description.Should().Be(updatedDescription);
        result.Value.Percentage.Should().Be(updatedPercentage);

        var updatedProgressPayment = quote.ProgressPayments.First();
        updatedProgressPayment.Description.Should().Be(updatedDescription);
        updatedProgressPayment.Percentage.Should().Be(updatedPercentage);


    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var requestDto = new UpdateProgressPaymentRequest
        {
            Description = "Updated Payment",
            Percentage = 50
        };

        var command = TestCommandFactory.CreateUpdateProgressPaymentCommand(
            quotePublicId: quotePublicId,
            progressPaymentId: 1,
            updateProgressPaymentRequest: requestDto);

        var error = MockSetupHelper.CreateForbiddenError("User does not have access to this quote");

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Failure<User>(error));

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Forbidden);

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithProgressPaymentsAsync(
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);

    }

    [Fact]
    public async Task Handle_WhenQuoteDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();

        var requestDto = new UpdateProgressPaymentRequest
        {
            Description = "Updated Payment",
            Percentage = 50
        };

        var command = TestCommandFactory.CreateUpdateProgressPaymentCommand(
            quotePublicId: quotePublicId,
            progressPaymentId: 1,
            auth0SubjectId: user.Auth0SubjectId,
            updateProgressPaymentRequest: requestDto);

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));

        _mockQuoteRepository
            .Setup(x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync((Quote?)null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Contain($"Quote with ID {quotePublicId} not found");


    }

    [Fact]
    public async Task Handle_WhenProgressPaymentDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuote();
        var nonExistentProgressPaymentId = 999;

        var requestDto = new UpdateProgressPaymentRequest
        {
            Description = "Updated Payment",
            Percentage = 50
        };

        var command = TestCommandFactory.CreateUpdateProgressPaymentCommand(
            quotePublicId: quotePublicId,
            progressPaymentId: nonExistentProgressPaymentId,
            auth0SubjectId: user.Auth0SubjectId,
            updateProgressPaymentRequest: requestDto);

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));

        _mockQuoteRepository
            .Setup(x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Contain($"Progress Payment with ID {nonExistentProgressPaymentId} not found");


    }
}
