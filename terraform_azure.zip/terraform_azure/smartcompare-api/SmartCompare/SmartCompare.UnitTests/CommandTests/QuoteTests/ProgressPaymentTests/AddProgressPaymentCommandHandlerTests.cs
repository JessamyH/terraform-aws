using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Commands.Quotes.AddProgressPayments;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests.ProgressPaymentTests;

public class AddProgressPaymentCommandHandlerTests
{
    private readonly Mock<ILogger<AddProgressPaymentHandler>> _mockLogger;
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly AddProgressPaymentHandler _handler;

    public AddProgressPaymentCommandHandlerTests()
    {
        _mockLogger = new Mock<ILogger<AddProgressPaymentHandler>>();
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();

        _handler = new AddProgressPaymentHandler(
            _mockLogger.Object,
            _mockQuoteRepository.Object,
            _mockAuthorizationService.Object);
    }

    [Fact]
    public async Task Handle_WhenAuthorizedAndQuoteExists_ShouldAddProgressPaymentsSuccessfully()
    {
        // Arrange
        var quote = TestEntityFactory.CreateQuote();
        var user = TestEntityFactory.CreateUser();
        var items = new List<AddProgressPaymentRequestDto>
        {
            new() { Description = "Deposit", Percentage = 30 },
            new() { Description = "Milestone 1", Percentage = 40 },
            new() { Description = "Final Payment", Percentage = 30 }
        };

        var command = TestCommandFactory.CreateAddProgressPaymentCommand(
            quotePublicId: quote.PublicId,
            auth0SubjectId: user.Auth0SubjectId,
            items: items);

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quote.PublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));

        _mockQuoteRepository
            .Setup(x => x.GetQuoteWithProgressPaymentsAsync(
                quote.PublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Count.Should().Be(3);
        result.Value.ProgressPayments.Should().HaveCount(3);
        result.Message.Should().Contain("Successfully add 3 progress payments");

        quote.ProgressPayments.Should().HaveCount(3);
        quote.ProgressPayments.Select(p => p.Description).Should().Contain(new[] { "Deposit", "Milestone 1", "Final Payment" });
        quote.ProgressPayments.Select(p => p.Percentage).Should().Contain(new[] { 30m, 40m, 30m });

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quote.PublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithProgressPaymentsAsync(
                quote.PublicId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var command = TestCommandFactory.CreateAddProgressPaymentCommand(quotePublicId: quoteId);
        var error = MockSetupHelper.CreateForbiddenError("User doesn't have quote authority");

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Failure<User>(error));

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Forbidden);
        result.Error.Message.Should().Contain("User doesn't have quote authority");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithProgressPaymentsAsync(
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateAddProgressPaymentCommand(quotePublicId: quotePublicId, auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));

        _mockQuoteRepository
            .Setup(x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync((Quote?)null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Contain("Quote was not found");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithSingleProgressPayment_ShouldAddSuccessfully()
    {
        // Arrange
        var quote = TestEntityFactory.CreateQuote();
        var user = TestEntityFactory.CreateUser();
        var items = new List<AddProgressPaymentRequestDto>
        {
            new() { Description = "Full Payment", Percentage = 100 }
        };

        var command = TestCommandFactory.CreateAddProgressPaymentCommand(
            quotePublicId: quote.PublicId,
            auth0SubjectId: user.Auth0SubjectId,
            items: items);
        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quote.PublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));

        _mockQuoteRepository
            .Setup(x => x.GetQuoteWithProgressPaymentsAsync(
                quote.PublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Count.Should().Be(1);
        result.Value.ProgressPayments.Should().HaveCount(1);
        result.Value.ProgressPayments.First().Description.Should().Be("Full Payment");
        result.Value.ProgressPayments.First().Percentage.Should().Be(100);

        quote.ProgressPayments.Should().HaveCount(1);
    }
}
