using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Commands.Quotes.DeleteProgressPayment;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests.ProgressPaymentTests;

public class DeleteProgressPaymentCommandHandlerTests
{
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly Mock<ILogger<DeleteProgressPaymentHandler>> _mockLogger;
    private readonly DeleteProgressPaymentHandler _handler;

    private static void SetEntityId<T>(T entity, int id)
    {
        var idProperty = typeof(T).GetProperty("Id");
        if (idProperty != null && idProperty.CanWrite)
        {
            idProperty.SetValue(entity, id);
        }
    }

    public DeleteProgressPaymentCommandHandlerTests()
    {
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();
        _mockLogger = new Mock<ILogger<DeleteProgressPaymentHandler>>();

        _handler = new DeleteProgressPaymentHandler(
            _mockQuoteRepository.Object,
            _mockAuthorizationService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task Handle_WhenAuthorizedAndProgressPaymentExists_ShouldDeleteSuccessfully()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuoteWithProgressPayments(progressPaymentCount: 1, id: 1);

        var progressPayment = quote.ProgressPayments.First().WithId(1);
        var progressPaymentId = progressPayment.Id;

        var command = TestCommandFactory.CreateDeleteProgressPaymentCommand(quotePublicId, progressPaymentId, user.Auth0SubjectId);

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));

        _mockQuoteRepository
            .Setup(x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Message.Should().Contain($"Progress Payment with ID {progressPaymentId} deleted successfully");
        quote.ProgressPayments.Should().BeEmpty();

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var command = TestCommandFactory.CreateDeleteProgressPaymentCommand(quotePublicId);

        var error = MockSetupHelper.CreateForbiddenError("User doesn't have quote authority");

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Failure<User>(error));

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Forbidden);

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithProgressPaymentsAsync(
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateDeleteProgressPaymentCommand(quotePublicId, auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));

        _mockQuoteRepository
            .Setup(x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync((Quote?)null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Contain($"Quote with ID {quotePublicId} not found");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenProgressPaymentDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuote();
        var nonExistentProgressPaymentId = 999;

        var command = TestCommandFactory.CreateDeleteProgressPaymentCommand(quotePublicId,
            nonExistentProgressPaymentId, user.Auth0SubjectId);

        _mockAuthorizationService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));

        _mockQuoteRepository
            .Setup(x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Contain($"Progress Payment with ID {nonExistentProgressPaymentId} not found in Quote {quotePublicId}");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
