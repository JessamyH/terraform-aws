using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.Application.Commands.Quotes.DeleteExclusion;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests.ExclusionTests;

/// <summary>
/// Refactored version using factories and helpers
/// </summary>
public class DeleteExclusionCommandHandlerTests
{
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly Mock<ILogger<DeletedExclusionCommandHandler>> _mockLogger;
    private readonly DeletedExclusionCommandHandler _handler;

    public DeleteExclusionCommandHandlerTests()
    {
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();
        _mockLogger = new Mock<ILogger<DeletedExclusionCommandHandler>>();

        _handler = new DeletedExclusionCommandHandler(
            _mockQuoteRepository.Object,
            _mockAuthorizationService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task Handle_WhenAuthorizedAndExclusionExists_ShouldDeleteSuccessfully()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuoteWithExclusions(
            exclusionCount: 1,
            id: 1);

        // Set ID for the exclusion
        var exclusion = quote.Exclusions.First().WithId(1);
        var exclusionId = exclusion.Id;
        
        var command = TestCommandFactory.CreateDeleteExclusionCommand(
            quotePublicId: quoteId,
            exclusionId: exclusionId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Message.Should().Contain("Exclusion deleted successfully");
        quote.Exclusions.Should().BeEmpty();

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithExclusionsAsync(
                quoteId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var command = TestCommandFactory.CreateDeleteExclusionCommand(quotePublicId: quoteId);
        var error = MockSetupHelper.CreateForbiddenError("User doesn't have quote authority");

        _mockAuthorizationService.SetupFailedQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithExclusionsAsync(
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateDeleteExclusionCommand(
            quotePublicId: quoteId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quoteId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain($"Quote with ID {quoteId} not found");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithExclusionsAsync(
                quoteId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenExclusionDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuote();
        var nonExistentExclusionId = 999;

        var command = TestCommandFactory.CreateDeleteExclusionCommand(
            quotePublicId: quoteId,
            exclusionId: nonExistentExclusionId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain($"Exclusion with ID {nonExistentExclusionId} not found in this quote");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithExclusionsAsync(
                quoteId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenDeletingOneOfMultipleExclusions_ShouldOnlyDeleteSpecifiedExclusion()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuoteWithExclusions(
            exclusionCount: 3,
            id: 1);

        // Set IDs for all exclusions
        var exclusions = quote.Exclusions.ToList();
        for (int i = 0; i < exclusions.Count; i++)
        {
            exclusions[i].WithId(i + 1);
        }

        var exclusionToDelete = exclusions[1];
        var exclusionId = exclusionToDelete.Id;

        var command = TestCommandFactory.CreateDeleteExclusionCommand(
            quotePublicId: quoteId,
            exclusionId: exclusionId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        quote.Exclusions.Should().HaveCount(2);
        quote.Exclusions.Should().NotContain(exclusionToDelete);
    }
}
