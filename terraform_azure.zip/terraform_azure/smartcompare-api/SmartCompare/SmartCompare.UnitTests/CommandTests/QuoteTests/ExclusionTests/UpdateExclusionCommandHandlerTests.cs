using AutoMapper;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.Application.Commands.Quotes.UpdateExclusion;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests.ExclusionTests;

/// <summary>
/// Refactored version using factories and helpers
/// </summary>
public class UpdateExclusionCommandHandlerTests
{
    private readonly Mock<ILogger<UpdateExclusionCommandHandler>> _mockLogger;
    private readonly IMapper _mapper = TestMapperHelper.Mapper;
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly UpdateExclusionCommandHandler _handler;

    public UpdateExclusionCommandHandlerTests()
    {
        _mockLogger = new Mock<ILogger<UpdateExclusionCommandHandler>>();
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();

        _handler = new UpdateExclusionCommandHandler(
            _mockLogger.Object,
            _mapper,
            _mockQuoteRepository.Object,
            _mockAuthorizationService.Object);
    }

    [Fact]
    public async Task Handle_WhenAuthorizedAndExclusionExists_ShouldUpdateSuccessfully()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuoteWithExclusions(
            exclusionCount: 1,
            id: 1);

        // Set ID for the exclusion
        var exclusion = quote.Exclusions.First().WithId(1);
        var exclusionId = exclusion.Id;
        
        var updatedDescription = "Completely New Unique Description";

        var updateRequest = TestCommandFactory.CreateUpdateExclusionRequest(updatedDescription);
        var command = TestCommandFactory.CreateUpdateExclusionCommand(
            quotePublicId: quoteId,
            exclusionId: exclusionId,
            updateExclusionRequest: updateRequest,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Description.Should().Be(updatedDescription);

        var updatedExclusion = quote.Exclusions.First();
        updatedExclusion.Description.Should().Be(updatedDescription);
        quote.Exclusions.Should().HaveCount(1);


    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var command = TestCommandFactory.CreateUpdateExclusionCommand(quotePublicId: quoteId);
        var error = MockSetupHelper.CreateForbiddenError("User doesn't have quote authority");

        _mockAuthorizationService.SetupFailedQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithExclusionsAsync(
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);

    }

    [Fact]
    public async Task Handle_WhenQuoteDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateUpdateExclusionCommand(
            quotePublicId: quoteId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quoteId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain($"Quote with ID {quoteId} not found");


    }

    [Fact]
    public async Task Handle_WhenExclusionDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuote();
        var nonExistentExclusionId = 999;

        var command = TestCommandFactory.CreateUpdateExclusionCommand(
            quotePublicId: quoteId,
            exclusionId: nonExistentExclusionId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain($"Exclusion with ID {nonExistentExclusionId} not found in quote {quoteId}");


    }

    [Fact]
    public async Task Handle_WithCustomDescription_ShouldUpdateToNewDescription()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuoteWithExclusions(
            exclusionCount: 1,
            id: 1);

        // Set ID for the exclusion
        var exclusion = quote.Exclusions.First().WithId(1);
        var exclusionId = exclusion.Id;
        
        var customDescription = "My Custom Updated Description";

        var updateRequest = TestCommandFactory.CreateUpdateExclusionRequest(customDescription);
        var command = TestCommandFactory.CreateUpdateExclusionCommand(
            quotePublicId: quoteId,
            exclusionId: exclusionId,
            updateExclusionRequest: updateRequest,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        quote.Exclusions.First().Description.Should().Be(customDescription);
    }
}
