using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.Application.Commands.Quotes.AddExclusions;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests.ExclusionTests;

/// <summary>
/// Refactored version using factories and helpers
/// </summary>
public class AddExclusionsCommandHandlerTests
{
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<ILogger<AddExclusionsCommandHandler>> _mockLogger;
    private readonly AddExclusionsCommandHandler _handler;

    public AddExclusionsCommandHandlerTests()
    {
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockLogger = new Mock<ILogger<AddExclusionsCommandHandler>>();

        _handler = new AddExclusionsCommandHandler(
            _mockAuthorizationService.Object,
            _mockQuoteRepository.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task Handle_WhenQuoteExistsAndAuthorized_ShouldAddExclusionsSuccessfully()
    {
        // Arrange
        var quote = TestEntityFactory.CreateQuote();
        var user = TestEntityFactory.CreateUser();
        
        var items = new List<AddExclusionsDto>
        {
            TestCommandFactory.CreateAddExclusionsDto("Exclusion 1"),
            TestCommandFactory.CreateAddExclusionsDto("Exclusion 2")
        };
        
        var command = TestCommandFactory.CreateAddExclusionsCommand(
            quotePublicId: quote.PublicId,
            auth0SubjectId: user.Auth0SubjectId,
            items: items);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quote.PublicId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quote.PublicId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Count.Should().Be(2);
        result.Value.Exclusions.Should().HaveCount(2);
        result.Value.Exclusions[0].Description.Should().Be("Exclusion 1");
        result.Value.Exclusions[1].Description.Should().Be("Exclusion 2");
        result.Message.Should().Be("Successfully added 2 exclusions");

        quote.Exclusions.Should().HaveCount(2);

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quote.PublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithExclusionsAsync(
                quote.PublicId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var command = TestCommandFactory.CreateAddExclusionsCommand(quotePublicId: quoteId);
        var error = MockSetupHelper.CreateForbiddenError("User doesn't have quote authority");

        _mockAuthorizationService.SetupFailedQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain("User doesn't have quote authority");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithExclusionsAsync(
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateAddExclusionsCommand(
            quotePublicId: quoteId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quoteId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain("Quote was not found");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithExclusionsAsync(
                quoteId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithSingleExclusion_ShouldAddSingleExclusionSuccessfully()
    {
        // Arrange
        var quote = TestEntityFactory.CreateQuote();
        var user = TestEntityFactory.CreateUser();
        
        var items = new List<AddExclusionsDto>
        {
            TestCommandFactory.CreateAddExclusionsDto("Single Exclusion")
        };
        
        var command = TestCommandFactory.CreateAddExclusionsCommand(
            quotePublicId: quote.PublicId,
            auth0SubjectId: user.Auth0SubjectId,
            items: items);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quote.PublicId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quote.PublicId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value!.Count.Should().Be(1);
        result.Value.Exclusions.Should().HaveCount(1);
        result.Value.Exclusions[0].Description.Should().Be("Single Exclusion");
        result.Message.Should().Be("Successfully added 1 exclusions");

        quote.Exclusions.Should().HaveCount(1);
        quote.Exclusions.First().Description.Should().Be("Single Exclusion");
    }

    [Fact]
    public async Task Handle_WithMultipleExclusions_ShouldAddAllExclusions()
    {
        // Arrange
        var quote = TestEntityFactory.CreateQuote();
        var user = TestEntityFactory.CreateUser();
        
        var items = new List<AddExclusionsDto>
        {
            TestCommandFactory.CreateAddExclusionsDto("Exclusion 1"),
            TestCommandFactory.CreateAddExclusionsDto("Exclusion 2"),
            TestCommandFactory.CreateAddExclusionsDto("Exclusion 3"),
            TestCommandFactory.CreateAddExclusionsDto("Exclusion 4")
        };
        
        var command = TestCommandFactory.CreateAddExclusionsCommand(
            quotePublicId: quote.PublicId,
            auth0SubjectId: user.Auth0SubjectId,
            items: items);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quote.PublicId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quote.PublicId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value!.Count.Should().Be(4);
        result.Value.Exclusions.Should().HaveCount(4);
        result.Message.Should().Be("Successfully added 4 exclusions");

        quote.Exclusions.Should().HaveCount(4);
        quote.Exclusions.Select(e => e.Description).Should().Contain("Exclusion 1");
        quote.Exclusions.Select(e => e.Description).Should().Contain("Exclusion 2");
        quote.Exclusions.Select(e => e.Description).Should().Contain("Exclusion 3");
        quote.Exclusions.Select(e => e.Description).Should().Contain("Exclusion 4");
    }

    [Fact]
    public async Task Handle_WhenQuoteHasExistingExclusions_ShouldAddNewExclusionsWithoutDuplication()
    {
        // Arrange
        var quote = TestEntityFactory.CreateQuote();
        quote.AddExclusion("Existing Exclusion");
        
        var user = TestEntityFactory.CreateUser();
        
        var items = new List<AddExclusionsDto>
        {
            TestCommandFactory.CreateAddExclusionsDto("New Exclusion 1"),
            TestCommandFactory.CreateAddExclusionsDto("New Exclusion 2")
        };
        
        var command = TestCommandFactory.CreateAddExclusionsCommand(
            quotePublicId: quote.PublicId,
            auth0SubjectId: user.Auth0SubjectId,
            items: items);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quote.PublicId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithExclusionsAsync(quote.PublicId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value!.Count.Should().Be(2);
        result.Value.Exclusions.Should().HaveCount(2);

        quote.Exclusions.Should().HaveCount(3);
        quote.Exclusions.Select(e => e.Description).Should().Contain("Existing Exclusion");
        quote.Exclusions.Select(e => e.Description).Should().Contain("New Exclusion 1");
        quote.Exclusions.Select(e => e.Description).Should().Contain("New Exclusion 2");
    }
}
