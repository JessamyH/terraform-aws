using AutoMapper;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.Application.Commands.Quotes.UpdateQuote;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests;

/// <summary>
/// Refactored version using factories and helpers
/// </summary>
public class UpdateQuoteCommandHandlerTests
{
    private readonly Mock<ILogger<UpdateQuoteCommandHandler>> _mockLogger;
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<IQuoteAuthorizationService> _mockQuoteAuthorizationService;
    private readonly IMapper _mapper = TestMapperHelper.Mapper;
    private readonly UpdateQuoteCommandHandler _handler;

    public UpdateQuoteCommandHandlerTests()
    {
        _mockLogger = new Mock<ILogger<UpdateQuoteCommandHandler>>();
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockQuoteAuthorizationService = new Mock<IQuoteAuthorizationService>();

        _handler = new UpdateQuoteCommandHandler(
            _mockLogger.Object,
            _mockQuoteRepository.Object,
            _mockQuoteAuthorizationService.Object,
            _mapper);
    }

    [Fact]
    public async Task Handle_WhenAuthorizedAndQuoteExists_ShouldUpdateSuccessfully()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();

        var updateDto = TestCommandFactory.CreateUpdateQuoteDto(
            quoteNumber: "Q-002-Updated",
            subTotal: 2000m,
            gst: 200m);

        var command = TestCommandFactory.CreateUpdateQuoteCommand(
            quotePublicId: quotePublicId,
            updateQuoteDto: updateDto,
            auth0SubjectId: user.Auth0SubjectId);

        var quote = TestEntityFactory.CreateQuote(id: 1);
        _mockQuoteAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quotePublicId, command.Auth0SubjectId, user);
        _mockQuoteRepository.SetupGetQuoteByIdAsync(quotePublicId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert — entity updated
        result.Succeed.Should().BeTrue();
        quote.QuoteNumber.Should().Be(updateDto.QuoteNumber);
        quote.SubTotal.Should().Be(updateDto.SubTotal);
        quote.GST.Should().Be(updateDto.GST);
        quote.Total.Should().Be(updateDto.SubTotal + updateDto.GST);
        quote.IssuedDate.Should().Be(updateDto.IssuedDate);
        quote.ValidPeriod.Should().Be(updateDto.ValidPeriod);
        quote.ABN.Value.Should().Be(updateDto.ABN);
        quote.LicenseNumber.Should().Be(updateDto.LicenseNumber);
        quote.ContactName.Should().Be(updateDto.ContactName);
        quote.ContactEmail.Should().Be(updateDto.ContactEmail);
        quote.ContactPhone.Should().Be(updateDto.ContactPhone);

    }

    [Fact]
    public async Task Handle_WhenNotAuthorized_ShouldReturnFailureError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var command = TestCommandFactory.CreateUpdateQuoteCommand(quotePublicId: quotePublicId);
        var error = MockSetupHelper.CreateForbiddenError("User doesn't have quote authority");

        _mockQuoteAuthorizationService.SetupFailedQuoteAuthorization(
            quotePublicId, command.Auth0SubjectId, error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();

        _mockQuoteRepository.Verify(
            x => x.GetQuoteByIdAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteNotFound_ShouldReturnNotFoundError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateUpdateQuoteCommand(
            quotePublicId: quotePublicId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockQuoteAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quotePublicId, command.Auth0SubjectId, user);
        _mockQuoteRepository.SetupGetQuoteByIdAsync(quotePublicId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain("Quote not found");

    }

    [Fact]
    public async Task Handle_WhenAbnChecksumInvalid_ShouldReturnValidationError()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();

        var updateDto = TestCommandFactory.CreateUpdateQuoteDto(
            abn: "12345678901"); // valid length, invalid checksum

        var command = TestCommandFactory.CreateUpdateQuoteCommand(
            quotePublicId: quotePublicId,
            updateQuoteDto: updateDto,
            auth0SubjectId: user.Auth0SubjectId);

        var quote = TestEntityFactory.CreateQuote(id: 1);
        _mockQuoteAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quotePublicId, command.Auth0SubjectId, user);
        _mockQuoteRepository.SetupGetQuoteByIdAsync(quotePublicId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(global::SharedKernel.Errors.ErrorType.Validation);
    }

    [Fact]
    public async Task Handle_WithCustomValues_ShouldUpdateCorrectly()
    {
        // Arrange
        var quotePublicId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var customQuoteNumber = "Q-CUSTOM-999";
        var customSubTotal = 5000m;
        var customGst = 500m;

        var updateDto = TestCommandFactory.CreateUpdateQuoteDto(
            quoteNumber: customQuoteNumber,
            subTotal: customSubTotal,
            gst: customGst);

        var command = TestCommandFactory.CreateUpdateQuoteCommand(
            quotePublicId: quotePublicId,
            updateQuoteDto: updateDto,
            auth0SubjectId: user.Auth0SubjectId);

        var quote = TestEntityFactory.CreateQuote(id: 1);
        _mockQuoteAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quotePublicId, command.Auth0SubjectId, user);
        _mockQuoteRepository.SetupGetQuoteByIdAsync(quotePublicId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        quote.QuoteNumber.Should().Be(customQuoteNumber);
        quote.SubTotal.Should().Be(customSubTotal);
        quote.GST.Should().Be(customGst);
        quote.Total.Should().Be(5500m);
    }
}
