using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.Application.Commands.Quotes.AddBatchScopeOfWork;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests.ScopeOfWorkTests;

public class AddBatchScopeOfWorkCommandHandlerTests
{
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<ILogger<AddBatchScopeOfWorkCommandHandler>> _mockLogger;
    private readonly AddBatchScopeOfWorkCommandHandler _handler;

    public AddBatchScopeOfWorkCommandHandlerTests()
    {
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockLogger = new Mock<ILogger<AddBatchScopeOfWorkCommandHandler>>();

        _handler = new AddBatchScopeOfWorkCommandHandler(
            _mockAuthorizationService.Object,
            _mockQuoteRepository.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task Handle_WhenQuoteExistsAndAuthorized_ShouldAddScopeOfWorksSuccessfully()
    {
        // Arrange
        var quote = TestEntityFactory.CreateQuote();
        var user = TestEntityFactory.CreateUser();

        var items = new List<AddScopeOfWorkDto>
        {
            TestCommandFactory.CreateAddScopeOfWorkDto("Scope Item 1"),
            TestCommandFactory.CreateAddScopeOfWorkDto("Scope Item 2")
        };

        var command = TestCommandFactory.CreateAddBatchScopeOfWorkCommand(
            quotePublicId: quote.PublicId,
            auth0SubjectId: user.Auth0SubjectId,
            items: items);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quote.PublicId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quote.PublicId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Count.Should().Be(2);
        result.Value.ScopeOfWorks.Should().HaveCount(2);
        result.Value.ScopeOfWorks[0].Description.Should().Be("Scope Item 1");
        result.Value.ScopeOfWorks[1].Description.Should().Be("Scope Item 2");
        result.Message.Should().Be("Successfully added 2 scope of work items");

        quote.ScopeOfWorks.Should().HaveCount(2);

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quote.PublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithScopeOfWorkAsync(
                quote.PublicId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var command = TestCommandFactory.CreateAddBatchScopeOfWorkCommand(quotePublicId: quoteId);
        var error = MockSetupHelper.CreateForbiddenError("User doesn't have quote authority");

        _mockAuthorizationService.SetupFailedQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain("User doesn't have quote authority");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithScopeOfWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateAddBatchScopeOfWorkCommand(
            quotePublicId: quoteId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quoteId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain("Quote was not found");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithScopeOfWorkAsync(
                quoteId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithSingleScopeOfWork_ShouldAddSuccessfully()
    {
        // Arrange
        var quote = TestEntityFactory.CreateQuote();
        var user = TestEntityFactory.CreateUser();

        var items = new List<AddScopeOfWorkDto>
        {
            TestCommandFactory.CreateAddScopeOfWorkDto("Single Scope Item")
        };

        var command = TestCommandFactory.CreateAddBatchScopeOfWorkCommand(
            quotePublicId: quote.PublicId,
            auth0SubjectId: user.Auth0SubjectId,
            items: items);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quote.PublicId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quote.PublicId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value!.Count.Should().Be(1);
        result.Value.ScopeOfWorks.Should().HaveCount(1);
        result.Value.ScopeOfWorks[0].Description.Should().Be("Single Scope Item");
        result.Message.Should().Be("Successfully added 1 scope of work items");

        quote.ScopeOfWorks.Should().HaveCount(1);
        quote.ScopeOfWorks.First().Description.Should().Be("Single Scope Item");
    }

    [Fact]
    public async Task Handle_WhenQuoteHasExistingScopeOfWork_ShouldAddNewWithoutDuplication()
    {
        // Arrange
        var quote = TestEntityFactory.CreateQuote();
        quote.AddScopeOfWork("Existing Scope Item");

        var user = TestEntityFactory.CreateUser();

        var items = new List<AddScopeOfWorkDto>
        {
            TestCommandFactory.CreateAddScopeOfWorkDto("New Scope Item 1"),
            TestCommandFactory.CreateAddScopeOfWorkDto("New Scope Item 2")
        };

        var command = TestCommandFactory.CreateAddBatchScopeOfWorkCommand(
            quotePublicId: quote.PublicId,
            auth0SubjectId: user.Auth0SubjectId,
            items: items);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quote.PublicId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quote.PublicId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value!.Count.Should().Be(2);
        result.Value.ScopeOfWorks.Should().HaveCount(2);

        quote.ScopeOfWorks.Should().HaveCount(3);
        quote.ScopeOfWorks.Select(s => s.Description).Should().Contain("Existing Scope Item");
        quote.ScopeOfWorks.Select(s => s.Description).Should().Contain("New Scope Item 1");
        quote.ScopeOfWorks.Select(s => s.Description).Should().Contain("New Scope Item 2");
    }
}
