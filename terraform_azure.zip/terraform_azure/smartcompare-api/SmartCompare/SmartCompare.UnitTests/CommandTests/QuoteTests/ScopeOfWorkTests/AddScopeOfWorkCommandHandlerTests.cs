using AutoMapper;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.Application.Commands.Quotes.AddScopeOfWork;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests.ScopeOfWorkTests;

/// <summary>
/// Refactored version using factories and helpers
/// </summary>
public class AddScopeOfWorkCommandHandlerTests
{
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly Mock<IQuoteQueries> _mockQuoteQueries;
    private readonly Mock<ILogger<AddScopeOfWorkCommandHandler>> _mockLogger;
    private readonly IMapper _mapper = TestMapperHelper.Mapper;
    private readonly AddScopeOfWorkCommandHandler _handler;

    public AddScopeOfWorkCommandHandlerTests()
    {
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();
        _mockQuoteQueries = new Mock<IQuoteQueries>();
        _mockLogger = new Mock<ILogger<AddScopeOfWorkCommandHandler>>();

        _handler = new AddScopeOfWorkCommandHandler(
            _mockAuthorizationService.Object,
            _mockQuoteQueries.Object,
            _mockLogger.Object,
            _mapper);
    }

    [Fact]
    public async Task Handle_WhenQuoteExistsAndAuthorized_ShouldAddScopeOfWorkSuccessfully()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var description = "Test Scope of Work Description";
        
        var command = TestCommandFactory.CreateAddScopeOfWorkCommand(
            quoteId: quoteId,
            description: description);
        
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuote();


        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteQueries.SetupGetQuoteWithProjectAsync(quoteId, quote);


        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Description.Should().Be(description);

        quote.ScopeOfWorks.Should().HaveCount(1);
        quote.ScopeOfWorks.First().Description.Should().Be(description);


    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var command = TestCommandFactory.CreateAddScopeOfWorkCommand(quoteId: quoteId);
        var error = MockSetupHelper.CreateForbiddenError("User doesn't have quote authority");

        _mockAuthorizationService.SetupFailedQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteQueries.Verify(
            x => x.GetQuoteWithProjectAsync(
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);

    }

    [Fact]
    public async Task Handle_WhenQuoteDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateAddScopeOfWorkCommand(
            quoteId: quoteId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteQueries.SetupGetQuoteWithProjectAsync(quoteId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain($"Quote with ID {quoteId} not found");


    }

    [Fact]
    public async Task Handle_WithMultipleScopeOfWorks_ShouldAddToExistingCollection()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuoteWithScopeOfWorks(
            scopeOfWorkCount: 2,
            id: 1);

        var newDescription = "New Scope of Work";
        var command = TestCommandFactory.CreateAddScopeOfWorkCommand(
            quoteId: quoteId,
            description: newDescription,
            auth0SubjectId: user.Auth0SubjectId);


        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteQueries.SetupGetQuoteWithProjectAsync(quoteId, quote);


        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        quote.ScopeOfWorks.Should().HaveCount(3);
        quote.ScopeOfWorks.Last().Description.Should().Be(newDescription);
    }
}
