using AutoMapper;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.Application.Commands.Quotes.UpdateScopeOfWork;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests.ScopeOfWorkTests;

/// <summary>
/// Refactored version using factories and helpers
/// </summary>
public class UpdateScopeOfWorkCommandHandlerTests
{
    private readonly Mock<ILogger<UpdateScopeOfWorkHandler>> _mockLogger;
    private readonly IMapper _mapper = TestMapperHelper.Mapper;
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly UpdateScopeOfWorkHandler _handler;

    public UpdateScopeOfWorkCommandHandlerTests()
    {
        _mockLogger = new Mock<ILogger<UpdateScopeOfWorkHandler>>();
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();

        _handler = new UpdateScopeOfWorkHandler(
            _mockLogger.Object,
            _mapper,
            _mockQuoteRepository.Object,
            _mockAuthorizationService.Object);
    }

    [Fact]
    public async Task Handle_WhenScopeOfWorkExistsAndAuthorized_ShouldUpdateSuccessfully()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuoteWithScopeOfWorks(
            scopeOfWorkCount: 1,
            id: 1);

        var scopeOfWork = quote.ScopeOfWorks.First().WithId(1);
        var scopeOfWorkId = scopeOfWork.Id;
        var updatedDescription = "Updated Scope of Work Description";

        var requestDto = TestCommandFactory.CreateUpdateScopeOfWorkRequestDto(updatedDescription);
        var command = TestCommandFactory.CreateUpdateScopeOfWorkCommand(
            quotePublicId: quoteId,
            scopeOfWorkId: scopeOfWorkId,
            scopeOfWorkRequestDto: requestDto,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.Description.Should().Be(updatedDescription);

        var updatedScopeOfWork = quote.ScopeOfWorks.First();
        updatedScopeOfWork.Description.Should().Be(updatedDescription);

    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var command = TestCommandFactory.CreateUpdateScopeOfWorkCommand(quotePublicId: quoteId);
        var error = MockSetupHelper.CreateForbiddenError("User doesn't have quote authority");

        _mockAuthorizationService.SetupFailedQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithScopeOfWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateUpdateScopeOfWorkCommand(
            quotePublicId: quoteId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quoteId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain($"Quote with ID {quoteId} not found");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

    }

    [Fact]
    public async Task Handle_WhenScopeOfWorkDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuote();
        var nonExistentScopeOfWorkId = 999;

        var command = TestCommandFactory.CreateUpdateScopeOfWorkCommand(
            quotePublicId: quoteId,
            scopeOfWorkId: nonExistentScopeOfWorkId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain("Scope of work not found");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

    }
}
