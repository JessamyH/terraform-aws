using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SmartCompare.Application.Commands.Quotes.DeleteScopeOfWork;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.QuoteTests.ScopeOfWorkTests;

/// <summary>
/// Refactored version using factories and helpers
/// </summary>
public class DeleteScopeOfWorkCommandHandlerTests
{
    private readonly Mock<IQuoteRepository> _mockQuoteRepository;
    private readonly Mock<IQuoteAuthorizationService> _mockAuthorizationService;
    private readonly Mock<ILogger<DeleteScopeOfWorkHandler>> _mockLogger;
    private readonly DeleteScopeOfWorkHandler _handler;

    public DeleteScopeOfWorkCommandHandlerTests()
    {
        _mockQuoteRepository = new Mock<IQuoteRepository>();
        _mockAuthorizationService = new Mock<IQuoteAuthorizationService>();
        _mockLogger = new Mock<ILogger<DeleteScopeOfWorkHandler>>();

        _handler = new DeleteScopeOfWorkHandler(
            _mockQuoteRepository.Object,
            _mockAuthorizationService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task Handle_WhenScopeOfWorkExistsAndAuthorized_ShouldDeleteSuccessfully()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuoteWithScopeOfWorks(
            scopeOfWorkCount: 1,
            id: 1);

        var scopeOfWork = quote.ScopeOfWorks.First().WithId(1);
        var scopeOfWorkId = scopeOfWork.Id;

        var command = TestCommandFactory.CreateDeleteScopeOfWorkCommand(
            quotePublicId: quoteId,
            scopeOfWorkId: scopeOfWorkId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Message.Should().Contain($"Scope of Work with ID {scopeOfWorkId} deleted successfully");
        quote.ScopeOfWorks.Should().BeEmpty();

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithScopeOfWorkAsync(
                quoteId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var command = TestCommandFactory.CreateDeleteScopeOfWorkCommand(quotePublicId: quoteId);
        var error = MockSetupHelper.CreateForbiddenError("User doesn't have quote authority");

        _mockAuthorizationService.SetupFailedQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithScopeOfWorkAsync(
                It.IsAny<Guid>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenQuoteDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateDeleteScopeOfWorkCommand(
            quotePublicId: quoteId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quoteId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain($"Quote with ID {quoteId} not found");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithScopeOfWorkAsync(
                quoteId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenScopeOfWorkDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuote();
        var nonExistentScopeOfWorkId = 999;

        var command = TestCommandFactory.CreateDeleteScopeOfWorkCommand(
            quotePublicId: quoteId,
            scopeOfWorkId: nonExistentScopeOfWorkId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain($"Scope of Work with ID {nonExistentScopeOfWorkId} not found");

        _mockAuthorizationService.Verify(
            x => x.ValidateQuoteAccessAsync(
                quoteId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockQuoteRepository.Verify(
            x => x.GetQuoteWithScopeOfWorkAsync(
                quoteId,
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenDeletingOneOfMultipleScopeOfWorks_ShouldOnlyDeleteSpecified()
    {
        // Arrange
        var quoteId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var quote = TestEntityFactory.CreateQuoteWithScopeOfWorks(
            scopeOfWorkCount: 3,
            id: 1);

        // Set IDs for all scope of works
        var scopeOfWorks = quote.ScopeOfWorks.ToList();
        for (int i = 0; i < scopeOfWorks.Count; i++)
        {
            scopeOfWorks[i].WithId(i + 1);
        }

        var scopeOfWorkToDelete = scopeOfWorks[1];
        var scopeOfWorkId = scopeOfWorkToDelete.Id;

        var command = TestCommandFactory.CreateDeleteScopeOfWorkCommand(
            quotePublicId: quoteId,
            scopeOfWorkId: scopeOfWorkId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulQuoteAuthorization(
            quoteId,
            command.Auth0SubjectId,
            user);

        _mockQuoteRepository.SetupGetQuoteWithScopeOfWorkAsync(quoteId, quote);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        quote.ScopeOfWorks.Should().HaveCount(2);
        quote.ScopeOfWorks.Should().NotContain(scopeOfWorkToDelete);
    }
}
