﻿using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Commands.Projects.DeleteProject;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.ProjectTests;

public class DeleteProjectCommandHandlerTests
{
    private readonly Mock<IProjectRepository> _mockProjectRepository;
    private readonly Mock<ILogger<DeleteProjectCommandHandler>> _mockLogger;
    private readonly Mock<IProjectAuthorizationService> _mockAuthorizationService;
    private readonly DeleteProjectCommandHandler _handler;

    public DeleteProjectCommandHandlerTests()
    {
        _mockProjectRepository = new Mock<IProjectRepository>();
        _mockLogger = new Mock<ILogger<DeleteProjectCommandHandler>>();
        _mockAuthorizationService = new Mock<IProjectAuthorizationService>();

        _handler = new DeleteProjectCommandHandler(
            _mockProjectRepository.Object,
            _mockLogger.Object,
            _mockAuthorizationService.Object);
    }

    [Fact]
    public async Task Handle_WhenProjectExistsAndAuthorized_ShouldSoftDeleteSuccessfully()
    {
        // Arrange
        var user = TestEntityFactory.CreateUser();
        var project = TestEntityFactory.CreateProject(userId: user.Id);
        var command = TestCommandFactory.CreateDeleteProjectCommand(
            projectId: project.PublicId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(
            project.PublicId, 
            command.Auth0SubjectId, 
            user);

        _mockProjectRepository.SetupGetProjectByPublicIdAsync(project.PublicId, project);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Message.Should().Contain(project.PublicId.ToString());
        project.IsDeleted.Should().BeTrue();
        project.DeletedAt.Should().NotBeNull();

        _mockAuthorizationService.Verify(
            x => x.ValidateProjectOwnershipAsync(
                project.PublicId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockProjectRepository.Verify(
            x => x.GetProjectByPublicIdAsync(project.PublicId, It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var projectId = Guid.NewGuid();
        var command = TestCommandFactory.CreateDeleteProjectCommand(projectId: projectId);
        var error = MockSetupHelper.CreateForbiddenError();

        _mockAuthorizationService.SetupFailedProjectAuthorization(
            projectId,
            command.Auth0SubjectId,
            error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Forbidden);

        _mockAuthorizationService.Verify(
            x => x.ValidateProjectOwnershipAsync(
                projectId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockProjectRepository.Verify(
            x => x.GetProjectByPublicIdAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenProjectNotFoundAfterAuthorization_ShouldReturnNotFoundError()
    {
        // Arrange
        var projectId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var command = TestCommandFactory.CreateDeleteProjectCommand(
            projectId: projectId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(
            projectId,
            command.Auth0SubjectId,
            user);

        _mockProjectRepository.SetupGetProjectByPublicIdAsync(projectId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Contain(projectId.ToString());

        _mockAuthorizationService.Verify(
            x => x.ValidateProjectOwnershipAsync(
                projectId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockProjectRepository.Verify(
            x => x.GetProjectByPublicIdAsync(projectId, It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenProjectAlreadyDeleted_ShouldReturnUnexpectedError()
    {
        // Arrange
        var projectId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var project = TestEntityFactory.CreateProject(userId: user.Id);
        
        // Soft delete the project first
        project.SoftDelete();

        var command = TestCommandFactory.CreateDeleteProjectCommand(
            projectId: projectId,
            auth0SubjectId: user.Auth0SubjectId);

        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(
            projectId,
            command.Auth0SubjectId,
            user);

        _mockProjectRepository.SetupGetProjectByPublicIdAsync(projectId, project);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Unexpected);
        result.Error.Message.Should().Contain("Failed to delete");

        _mockAuthorizationService.Verify(
            x => x.ValidateProjectOwnershipAsync(
                projectId,
                command.Auth0SubjectId,
                It.IsAny<CancellationToken>()),
            Times.Once);

        _mockProjectRepository.Verify(
            x => x.GetProjectByPublicIdAsync(projectId, It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenProjectDeleted_ShouldSetDeletedAtTimestamp()
    {
        // Arrange
        var projectId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();
        var project = TestEntityFactory.CreateProject(userId: user.Id);
        var command = TestCommandFactory.CreateDeleteProjectCommand(
            projectId: projectId,
            auth0SubjectId: user.Auth0SubjectId);

        var beforeDelete = DateTime.UtcNow;

        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(
            projectId,
            command.Auth0SubjectId,
            user);

        _mockProjectRepository.SetupGetProjectByPublicIdAsync(projectId, project);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        project.IsDeleted.Should().BeTrue();
        project.DeletedAt.Should().NotBeNull();
        project.DeletedAt.Should().BeOnOrAfter(beforeDelete);
        var afterDelete = DateTime.UtcNow;
        project.DeletedAt.Should().BeOnOrBefore(afterDelete);
    }
}
