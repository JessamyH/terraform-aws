using AutoMapper;
using FluentAssertions;
using Moq;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Commands.Projects.CreateProject;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Enums;
using SmartCompare.Domain.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.ProjectTests;

/// <summary>
/// Refactored version using factories and helpers
/// </summary>
public class CreateProjectCommandHandlerTests
{
    private readonly Mock<IProjectRepository> _mockProjectRepository;
    private readonly Mock<IUserQueries> _mockUserQueries;
    private readonly IMapper _mapper = TestMapperHelper.Mapper;
    private readonly CreateProjectCommandHandler _handler;

    public CreateProjectCommandHandlerTests()
    {
        _mockProjectRepository = new Mock<IProjectRepository>();
        _mockUserQueries = new Mock<IUserQueries>();

        _handler = new CreateProjectCommandHandler(
            _mockProjectRepository.Object,
            _mockUserQueries.Object,
            _mapper);
    }

    [Fact]
    public async Task Handle_WhenUserExists_ShouldCreateProjectSuccessfully()
    {
        // Arrange
        var command = TestCommandFactory.CreateCreateProjectCommand();
        var user = TestEntityFactory.CreateUser();

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(command.Auth0SubjectId, user);
        _mockProjectRepository.SetupAddProjectAsync();

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value!.ProjectName.Should().Be(command.ProjectName);
        result.Value.Address.Should().Be(command.Address);
        result.Value.HouseType.Should().Be(command.HouseType);
        result.Value.HouseSizeSqm.Should().Be(command.HouseSizeSqm);
        result.Value.Bedrooms.Should().Be(command.Bedrooms);
        result.Value.Bathrooms.Should().Be(command.Bathrooms);
        result.Value.SubcontractorTypeId.Should().Be(command.SubcontractorTypeId);
        result.Value.Status.Should().Be(ProjectStatus.InProgress);

        _mockProjectRepository.Verify(
            x => x.AddAsync(
                It.Is<Project>(p =>
                    p.UserId == user.Id &&
                    p.ProjectName == command.ProjectName &&
                    p.Address == command.Address &&
                    p.HouseType == command.HouseType &&
                    p.HouseSizeSqm == command.HouseSizeSqm &&
                    p.Bedrooms == command.Bedrooms &&
                    p.Bathrooms == command.Bathrooms &&
                    p.SubcontractorTypeId == command.SubcontractorTypeId &&
                    p.Status == ProjectStatus.InProgress),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserDoesNotExist_ShouldReturnUnauthorizedError()
    {
        // Arrange
        var command = TestCommandFactory.CreateCreateProjectCommand();

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(command.Auth0SubjectId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Message.Should().Contain(command.Auth0SubjectId);

        _mockProjectRepository.Verify(
            x => x.AddAsync(It.IsAny<Project>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WithCustomValues_ShouldCreateProjectWithSpecifiedData()
    {
        // Arrange
        var customProjectName = "Custom Project Name";
        var customAddress = "789 Custom Avenue";
        var customHouseType = HouseType.Apartment;
        var customHouseSizeSqm = 85m;
        var customBedrooms = 2;
        var customBathrooms = 1;
        var customSubcontractorTypeId = 5;

        var command = TestCommandFactory.CreateCreateProjectCommand(
            projectName: customProjectName,
            address: customAddress,
            houseType: customHouseType,
            houseSizeSqm: customHouseSizeSqm,
            bedrooms: customBedrooms,
            bathrooms: customBathrooms,
            subcontractorTypeId: customSubcontractorTypeId);

        var user = TestEntityFactory.CreateUser();

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(command.Auth0SubjectId, user);
        _mockProjectRepository.SetupAddProjectAsync();

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value!.ProjectName.Should().Be(customProjectName);
        result.Value.Address.Should().Be(customAddress);
        result.Value.HouseType.Should().Be(customHouseType);
        result.Value.HouseSizeSqm.Should().Be(customHouseSizeSqm);
        result.Value.Bedrooms.Should().Be(customBedrooms);
        result.Value.Bathrooms.Should().Be(customBathrooms);
        result.Value.SubcontractorTypeId.Should().Be(customSubcontractorTypeId);

        _mockProjectRepository.Verify(
            x => x.AddAsync(
                It.Is<Project>(p =>
                    p.ProjectName == customProjectName &&
                    p.Address == customAddress &&
                    p.HouseType == customHouseType &&
                    p.HouseSizeSqm == customHouseSizeSqm &&
                    p.Bedrooms == customBedrooms &&
                    p.Bathrooms == customBathrooms &&
                    p.SubcontractorTypeId == customSubcontractorTypeId),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WithAllHouseTypes_ShouldCreateProjectSuccessfully()
    {
        // Arrange
        var user = TestEntityFactory.CreateUser();

        foreach (var houseType in Enum.GetValues<HouseType>())
        {
            var command = TestCommandFactory.CreateCreateProjectCommand(houseType: houseType);
            _mockUserQueries.SetupGetByAuth0SubjectIdAsync(command.Auth0SubjectId, user);
            _mockProjectRepository.SetupAddProjectAsync();

            // Act
            var result = await _handler.Handle(command, CancellationToken.None);

            // Assert
            result.Succeed.Should().BeTrue();
            _mockProjectRepository.Verify(
                x => x.AddAsync(
                    It.Is<Project>(p => p.HouseType == houseType),
                    It.IsAny<CancellationToken>()),
                Times.Once);

            _mockProjectRepository.Reset();
        }
    }

    [Fact]
    public async Task Handle_WithZeroBedrooms_ShouldCreateProjectSuccessfully()
    {
        // Arrange
        var command = TestCommandFactory.CreateCreateProjectCommand(bedrooms: 0);
        var user = TestEntityFactory.CreateUser();

        _mockUserQueries.SetupGetByAuth0SubjectIdAsync(command.Auth0SubjectId, user);
        _mockProjectRepository.SetupAddProjectAsync();

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        _mockProjectRepository.Verify(
            x => x.AddAsync(
                It.Is<Project>(p => p.Bedrooms == 0),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
