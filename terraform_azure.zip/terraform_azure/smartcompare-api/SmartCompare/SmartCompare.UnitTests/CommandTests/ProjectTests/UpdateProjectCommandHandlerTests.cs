using AutoMapper;
using FluentAssertions;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Commands.Projects.UpdateProject;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Enums;
using SmartCompare.Domain.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.ProjectTests;

public class UpdateProjectCommandHandlerTests
{
    private readonly Mock<IProjectAuthorizationService> _mockAuthorizationService;
    private readonly Mock<IProjectRepository> _mockProjectRepository;
    private readonly IMapper _mapper = TestMapperHelper.Mapper;
    private readonly UpdateProjectCommandHandler _handler;

    public UpdateProjectCommandHandlerTests()
    {
        _mockAuthorizationService = new Mock<IProjectAuthorizationService>();
        _mockProjectRepository = new Mock<IProjectRepository>();
        _handler = new UpdateProjectCommandHandler(
            _mockAuthorizationService.Object,
            _mockProjectRepository.Object,
            _mapper);
    }

    [Fact]
    public async Task Handle_WhenProjectExistsAndAuthorized_ShouldUpdateProjectSuccessfully()
    {
        // Arrange
        var user = TestEntityFactory.CreateUser();
        var project = TestEntityFactory.CreateProject();
        var command = TestCommandFactory.CreateUpdateProjectCommand(project.PublicId, auth0SubjectId: user.Auth0SubjectId);

        _mockProjectRepository.SetupGetProjectByPublicIdAsync(project.PublicId, project);
        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(project.PublicId, command.Auth0SubjectId, user);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value.ProjectName.Should().Be(command.UpdateDto.ProjectName);
        result.Value.Address.Should().Be(command.UpdateDto.Address);
        result.Value.HouseType.Should().Be(command.UpdateDto.HouseType);
        result.Value.HouseSizeSqm.Should().Be(command.UpdateDto.HouseSizeSqm);
        result.Value.Bedrooms.Should().Be(command.UpdateDto.Bedrooms);
        result.Value.Bathrooms.Should().Be(command.UpdateDto.Bathrooms);
        result.Value.SubcontractorTypeId.Should().Be(command.UpdateDto.SubcontractorTypeId);
        result.Value.Status.Should().Be(command.UpdateDto.Status);

        project.ProjectName.Should().Be(command.UpdateDto.ProjectName);
        project.Address.Should().Be(command.UpdateDto.Address);
        project.HouseType.Should().Be(command.UpdateDto.HouseType);
        project.HouseSizeSqm.Should().Be(command.UpdateDto.HouseSizeSqm);
        project.Bedrooms.Should().Be(command.UpdateDto.Bedrooms);
        project.Bathrooms.Should().Be(command.UpdateDto.Bathrooms);
        project.SubcontractorTypeId.Should().Be(command.UpdateDto.SubcontractorTypeId);
        project.Status.Should().Be(command.UpdateDto.Status);

    }

    [Fact]
    public async Task Handle_WhenProjectDoesNotExist_ShouldReturnNotFoundError()
    {
        // Arrange
        var projectId = Guid.NewGuid();
        var user = TestEntityFactory.CreateUser();

        var command = TestCommandFactory.CreateUpdateProjectCommand(projectId, auth0SubjectId: user.Auth0SubjectId);

        _mockProjectRepository.SetupGetProjectByPublicIdAsync(projectId, null);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Contain(projectId.ToString());

    }

    [Fact]
    public async Task Handle_WhenUserNotAuthorized_ShouldReturnForbiddenError()
    {
        // Arrange
        var project = TestEntityFactory.CreateProject();
        var command = TestCommandFactory.CreateUpdateProjectCommand(project.PublicId, auth0SubjectId: "unauthorized-user");
        var error = MockSetupHelper.CreateForbiddenError();

        _mockProjectRepository.SetupGetProjectByPublicIdAsync(project.PublicId, project);

        _mockAuthorizationService.SetupFailedProjectAuthorization(project.PublicId, command.Auth0SubjectId, error);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Forbidden);

    }

    [Fact]
    public async Task Handle_WithCustomValues_ShouldUpdateWithSpecifiedData()
    {
        // Arrange
        var customProjectName = "Updated Custom Project";
        var customAddress = "999 Updated Street";
        var customHouseType = HouseType.Townhouse;
        var customHouseSizeSqm = 180m;
        var customBedrooms = 4;
        var customBathrooms = 2;
        var customSubcontractorTypeId = 10;

        var user = TestEntityFactory.CreateUser();
        var project = TestEntityFactory.CreateProject(userId: user.Id);

        var updateDto = TestCommandFactory.CreateUpdateProjectDto(
            projectName: customProjectName,
            address: customAddress,
            houseType: customHouseType,
            houseSizeSqm: customHouseSizeSqm,
            bedrooms: customBedrooms,
            bathrooms: customBathrooms,
            subcontractorTypeId: customSubcontractorTypeId);

        var command = TestCommandFactory.CreateUpdateProjectCommand(
            projectId: project.PublicId,
            updateDto: updateDto,
            auth0SubjectId: user.Auth0SubjectId);

        _mockProjectRepository.SetupGetProjectByPublicIdAsync(project.PublicId, project);
        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(
            project.PublicId,
            command.Auth0SubjectId,
            user);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        project.ProjectName.Should().Be(customProjectName);
        project.Address.Should().Be(customAddress);
        project.HouseType.Should().Be(customHouseType);
        project.HouseSizeSqm.Should().Be(customHouseSizeSqm);
        project.Bedrooms.Should().Be(customBedrooms);
        project.Bathrooms.Should().Be(customBathrooms);
        project.SubcontractorTypeId.Should().Be(customSubcontractorTypeId);
    }

    [Fact]
    public async Task Handle_WithZeroBathrooms_ShouldUpdateSuccessfully()
    {
        // Arrange
        var user = TestEntityFactory.CreateUser();
        var project = TestEntityFactory.CreateProject(userId: user.Id);

        var updateDto = TestCommandFactory.CreateUpdateProjectDto(bathrooms: 0);
        var command = TestCommandFactory.CreateUpdateProjectCommand(
            projectId: project.PublicId,
            updateDto: updateDto,
            auth0SubjectId: user.Auth0SubjectId);

        _mockProjectRepository.SetupGetProjectByPublicIdAsync(project.PublicId, project);
        _mockAuthorizationService.SetupSuccessfulProjectAuthorization(project.PublicId, command.Auth0SubjectId, user);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        project.Bathrooms.Should().Be(0);
    }
}
