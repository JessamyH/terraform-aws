using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Application.Commands.Users.SyncUser;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.SharedKernel.Results;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.CommandTests.UserTests;

/// <summary>
/// Tests for SyncUserCommandHandler using test factories and helpers
/// </summary>
public class SyncUserCommandHandlerTests
{
    private readonly Mock<IUserRepository> _mockUserRepository;
    private readonly Mock<IRoleRepository> _mockRoleRepository;
    private readonly Mock<IUnitOfWork> _mockUnitOfWork;
    private readonly Mock<ILogger<SyncUserCommandHandler>> _mockLogger;
    private readonly SyncUserCommandHandler _handler;

    public SyncUserCommandHandlerTests()
    {
        _mockUserRepository = new Mock<IUserRepository>();
        _mockRoleRepository = new Mock<IRoleRepository>();
        _mockUnitOfWork = new Mock<IUnitOfWork>();
        _mockLogger = new Mock<ILogger<SyncUserCommandHandler>>();

        _handler = new SyncUserCommandHandler(
            _mockUserRepository.Object,
            _mockRoleRepository.Object,
            _mockUnitOfWork.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task Handle_WhenUserExistsAndNotFirstLogin_ShouldUpdateLastLoginTimestamp()
    {
        // Arrange
        var command = TestCommandFactory.CreateSyncUserCommand();
        var existingUser = TestEntityFactory.CreateUser(auth0SubjectId: command.Auth0SubjectId);
        var originalLastLoginAt = existingUser.LastLoginAt;

        _mockUserRepository.SetupGetBySubjectIdAsync(command.Auth0SubjectId, existingUser);
        _mockUnitOfWork.Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(1);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        existingUser.LastLoginAt.Should().NotBe(originalLastLoginAt);
        existingUser.LastLoginAt.Should().BeAfter(DateTime.UtcNow.AddSeconds(-5));

    }

    [Fact]
    public async Task Handle_WhenUserDoesNotExist_ShouldCreateNewUserWithFreeSubscription()
    {
        // Arrange
        var command = TestCommandFactory.CreateSyncUserCommand();
        var role = CreateCompanyAdminRole();

        _mockUserRepository.SetupGetBySubjectIdAsync(command.Auth0SubjectId, null);
        _mockRoleRepository.Setup(x => x.GetByIdAsync(Role.RoleIds.CompanyAdmin, It.IsAny<CancellationToken>()))
            .ReturnsAsync(role);
        _mockUserRepository.SetupAddUserAsync();
        
        _mockUnitOfWork.Setup(x => x.ExecuteResilientAsync(
            It.IsAny<Func<CancellationToken, Task<Result>>>(),
            It.IsAny<CancellationToken>()))
            .Returns<Func<CancellationToken, Task<Result>>, CancellationToken>(
                async (func, ct) => await func(ct));

        _mockUnitOfWork.Setup(x => x.BeginTransactionAsync()).Returns(Task.CompletedTask);
        _mockUnitOfWork.Setup(x => x.CommitTransactionAsync()).Returns(Task.CompletedTask);
        _mockUnitOfWork.Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        result.Message.Should().Contain(command.Auth0SubjectId);

        _mockUserRepository.Verify(
            x => x.AddAsync(
                It.Is<User>(u =>
                    u.Auth0SubjectId == command.Auth0SubjectId &&
                    u.UserName == command.UserName),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenRoleNotFound_ShouldReturnUnexpectedError()
    {
        // Arrange
        var command = TestCommandFactory.CreateSyncUserCommand();

        _mockUserRepository.SetupGetBySubjectIdAsync(command.Auth0SubjectId, null);
        _mockRoleRepository.Setup(x => x.GetByIdAsync(Role.RoleIds.CompanyAdmin, It.IsAny<CancellationToken>()))
            .ReturnsAsync((Role?)null);

        _mockUnitOfWork.Setup(x => x.ExecuteResilientAsync(
            It.IsAny<Func<CancellationToken, Task<Result>>>(),
            It.IsAny<CancellationToken>()))
            .Returns<Func<CancellationToken, Task<Result>>, CancellationToken>(
                async (func, ct) => await func(ct));

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Unexpected);
        result.Error.Message.Should().Contain("System configuration error");

        _mockUserRepository.Verify(
            x => x.AddAsync(It.IsAny<User>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task Handle_WhenLastLoginUpdateFails_ShouldStillSucceedButLogWarning()
    {
        // Arrange
        var command = TestCommandFactory.CreateSyncUserCommand();
        var existingUser = TestEntityFactory.CreateUser(auth0SubjectId: command.Auth0SubjectId);

        _mockUserRepository.SetupGetBySubjectIdAsync(command.Auth0SubjectId, existingUser);
        _mockUnitOfWork.Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateException("Concurrent update conflict"));

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue(); // Login should still succeed

        _mockLogger.Verify(
            x => x.Log(
                LogLevel.Warning,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((o, t) => o.ToString()!.Contains("last login timestamp could not be updated")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenUserCreationFailsWithUnexpectedException_ShouldReturnFailure()
    {
        // Arrange
        var command = TestCommandFactory.CreateSyncUserCommand();
        var role = CreateCompanyAdminRole();

        _mockUserRepository.SetupGetBySubjectIdAsync(command.Auth0SubjectId, null);
        _mockRoleRepository.Setup(x => x.GetByIdAsync(Role.RoleIds.CompanyAdmin, It.IsAny<CancellationToken>()))
            .ReturnsAsync(role);

        var unexpectedException = new InvalidOperationException("Unexpected database error");

        _mockUnitOfWork.Setup(x => x.ExecuteResilientAsync(
            It.IsAny<Func<CancellationToken, Task<Result>>>(),
            It.IsAny<CancellationToken>()))
            .ThrowsAsync(unexpectedException);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeFalse();
        result.Error.Should().NotBeNull();
        result.Error!.Type.Should().Be(ErrorType.Unexpected);
        result.Error.Message.Should().Contain("unexpected error");

        _mockLogger.Verify(
            x => x.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((o, t) => o.ToString()!.Contains("Unexpected error")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }

    [Fact]
    public async Task Handle_WhenNewUserCreated_ShouldHaveCompanyAdminRoleAndFreeSubscription()
    {
        // Arrange
        var command = TestCommandFactory.CreateSyncUserCommand();
        var role = CreateCompanyAdminRole();
        User? capturedUser = null;

        _mockUserRepository.SetupGetBySubjectIdAsync(command.Auth0SubjectId, null);
        _mockRoleRepository.Setup(x => x.GetByIdAsync(Role.RoleIds.CompanyAdmin, It.IsAny<CancellationToken>()))
            .ReturnsAsync(role);

        _mockUserRepository
            .Setup(x => x.AddAsync(It.IsAny<User>(), It.IsAny<CancellationToken>()))
            .Callback<User, CancellationToken>((user, ct) => capturedUser = user)
            .Returns(Task.CompletedTask);

        _mockUnitOfWork.Setup(x => x.ExecuteResilientAsync(
            It.IsAny<Func<CancellationToken, Task<Result>>>(),
            It.IsAny<CancellationToken>()))
            .Returns<Func<CancellationToken, Task<Result>>, CancellationToken>(
                async (func, ct) => await func(ct));

        _mockUnitOfWork.Setup(x => x.BeginTransactionAsync()).Returns(Task.CompletedTask);
        _mockUnitOfWork.Setup(x => x.CommitTransactionAsync()).Returns(Task.CompletedTask);
        _mockUnitOfWork.Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);

        // Act
        var result = await _handler.Handle(command, CancellationToken.None);

        // Assert
        result.Succeed.Should().BeTrue();
        capturedUser.Should().NotBeNull();
        capturedUser!.Auth0SubjectId.Should().Be(command.Auth0SubjectId);
        capturedUser.UserName.Should().Be(command.UserName);
        // Note: Email comparison skipped as it's a value object type
        
        // Verify role was added (check UserRoles collection or via method call tracking)
        // Note: Actual verification depends on how User.AddRole is implemented
        
        _mockLogger.Verify(
            x => x.Log(
                LogLevel.Information,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((o, t) => o.ToString()!.Contains("New user created with free subscription")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }

    #region Helper Methods

    private static Role CreateCompanyAdminRole()
    {
        var role = Role.Create(Role.RoleNames.CompanyAdmin);
        // Set the ID using reflection to match the expected RoleId
        typeof(Role).GetProperty("Id")!.SetValue(role, Role.RoleIds.CompanyAdmin);
        return role;
    }

    #endregion
}
