using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using SharedKernel.Errors;
using SmartCompare.Domain.Interfaces;
using SmartCompare.Infrastructure.ExternalServices.Stripe;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;
using Stripe;
using User = SmartCompare.Domain.Entities.UserAggregate.User;

namespace SmartCompare.UnitTests.Infrastructure.Stripe;

public class StripeCustomerServiceTests
{
    private readonly Mock<IUserRepository> _mockUserRepository;
    private readonly Mock<IUnitOfWork> _mockUnitOfWork;
    private readonly Mock<ILogger<StripeCustomerService>> _mockLogger;
    private readonly Mock<IStripeClient> _mockStripeClient;
    private readonly StripeCustomerService _sut;

    private const string Auth0SubjectId = "auth0|test-customer-svc";
    private const string FakeStripeCustomerId = "cus_test_abc123";

    public StripeCustomerServiceTests()
    {
        _mockUserRepository = new Mock<IUserRepository>();
        _mockUnitOfWork = new Mock<IUnitOfWork>();
        _mockLogger = new Mock<ILogger<StripeCustomerService>>();
        _mockStripeClient = new Mock<IStripeClient>();

        _sut = new StripeCustomerService(
            _mockUserRepository.Object,
            _mockUnitOfWork.Object,
            _mockLogger.Object,
            _mockStripeClient.Object);
    }

    [Fact]
    public async Task GetOrCreateCustomerAsync_WhenUserNotFound_ShouldReturnNotFoundFailure()
    {
        _mockUserRepository
            .Setup(x => x.GetBySubjectIdAsync(Auth0SubjectId, It.IsAny<CancellationToken>()))
            .ReturnsAsync((User?)null);

        var result = await _sut.GetOrCreateCustomerAsync(Auth0SubjectId);

        result.Succeed.Should().BeFalse();
        result.Error!.Type.Should().Be(ErrorType.NotFound);
        result.Error.Message.Should().Contain(Auth0SubjectId);
    }

    [Fact]
    public async Task GetOrCreateCustomerAsync_WhenUserAlreadyHasStripeCustomerId_ShouldReturnExistingId()
    {
        var user = TestEntityFactory.CreateUser();
        user.SetStripeCustomerId(FakeStripeCustomerId);

        _mockUserRepository
            .Setup(x => x.GetBySubjectIdAsync(Auth0SubjectId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);

        var result = await _sut.GetOrCreateCustomerAsync(Auth0SubjectId);

        result.Succeed.Should().BeTrue();
        result.Value.Should().Be(FakeStripeCustomerId);

        // Should NOT call Stripe API
        _mockStripeClient.Verify(
            x => x.RequestAsync<Customer>(
                It.IsAny<HttpMethod>(),
                It.IsAny<string>(),
                It.IsAny<BaseOptions>(),
                It.IsAny<RequestOptions>(),
                It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task GetOrCreateCustomerAsync_WhenNoStripeCustomer_ShouldCreateAndReturnNewId()
    {
        var user = TestEntityFactory.CreateUser();
        // user.StripeCustomerId is null by default

        _mockUserRepository
            .Setup(x => x.GetBySubjectIdAsync(Auth0SubjectId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);

        var fakeCustomer = new Customer { Id = FakeStripeCustomerId };
        _mockStripeClient
            .Setup(x => x.RequestAsync<Customer>(
                HttpMethod.Post,
                It.Is<string>(s => s.Contains("/v1/customers")),
                It.IsAny<BaseOptions>(),
                It.IsAny<RequestOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(fakeCustomer);

        _mockUnitOfWork
            .Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(1);

        var result = await _sut.GetOrCreateCustomerAsync(Auth0SubjectId);

        result.Succeed.Should().BeTrue();
        result.Value.Should().Be(FakeStripeCustomerId);
        user.StripeCustomerId.Should().Be(FakeStripeCustomerId);
    }

    [Fact]
    public async Task GetOrCreateCustomerAsync_WhenConcurrencyConflict_ShouldRetryAndReturnExistingCustomer()
    {
        var user = TestEntityFactory.CreateUser();

        _mockUserRepository
            .Setup(x => x.GetBySubjectIdAsync(Auth0SubjectId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);

        var fakeCustomer = new Customer { Id = FakeStripeCustomerId };
        _mockStripeClient
            .Setup(x => x.RequestAsync<Customer>(
                HttpMethod.Post,
                It.Is<string>(s => s.Contains("/v1/customers")),
                It.IsAny<BaseOptions>(),
                It.IsAny<RequestOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(fakeCustomer);

        // SaveChanges throws concurrency exception (another request already created the customer)
        _mockUnitOfWork
            .Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateConcurrencyException("Concurrency conflict"));

        // Retry read returns user with StripeCustomerId already set
        var refreshedUser = TestEntityFactory.CreateUser();
        refreshedUser.SetStripeCustomerId("cus_from_other_request");

        var callCount = 0;
        _mockUserRepository
            .Setup(x => x.GetBySubjectIdAsync(Auth0SubjectId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(() =>
            {
                callCount++;
                return callCount == 1 ? user : refreshedUser;
            });

        var result = await _sut.GetOrCreateCustomerAsync(Auth0SubjectId);

        result.Succeed.Should().BeTrue();
        result.Value.Should().Be("cus_from_other_request");
    }

    [Fact]
    public async Task GetOrCreateCustomerAsync_WhenConcurrencyConflictAndRetryFails_ShouldReturnFailure()
    {
        var user = TestEntityFactory.CreateUser();
        var refreshedUserStillNoCustomer = TestEntityFactory.CreateUser(); // fresh object, no StripeCustomerId

        var callCount = 0;
        _mockUserRepository
            .Setup(x => x.GetBySubjectIdAsync(Auth0SubjectId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(() =>
            {
                callCount++;
                return callCount == 1 ? user : refreshedUserStillNoCustomer;
            });

        var fakeCustomer = new Customer { Id = FakeStripeCustomerId };
        _mockStripeClient
            .Setup(x => x.RequestAsync<Customer>(
                HttpMethod.Post,
                It.Is<string>(s => s.Contains("/v1/customers")),
                It.IsAny<BaseOptions>(),
                It.IsAny<RequestOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(fakeCustomer);

        _mockUnitOfWork
            .Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateConcurrencyException("Concurrency conflict"));

        var result = await _sut.GetOrCreateCustomerAsync(Auth0SubjectId);

        result.Succeed.Should().BeFalse();
        result.Error!.Type.Should().Be(ErrorType.Unexpected);
        result.Error.Message.Should().Contain("Concurrency conflict");
    }

    [Fact]
    public async Task GetOrCreateCustomerAsync_WhenStripeApiError_ShouldReturnFailure()
    {
        var user = TestEntityFactory.CreateUser();

        _mockUserRepository
            .Setup(x => x.GetBySubjectIdAsync(Auth0SubjectId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);

        _mockStripeClient
            .Setup(x => x.RequestAsync<Customer>(
                HttpMethod.Post,
                It.Is<string>(s => s.Contains("/v1/customers")),
                It.IsAny<BaseOptions>(),
                It.IsAny<RequestOptions>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new StripeException("Card declined")
            {
                StripeError = new StripeError { Code = "card_declined", Message = "Your card was declined." }
            });

        var result = await _sut.GetOrCreateCustomerAsync(Auth0SubjectId);

        result.Succeed.Should().BeFalse();
        result.Error!.Type.Should().Be(ErrorType.Unexpected);
        result.Error.Message.Should().Contain("Your card was declined.");
    }
}
