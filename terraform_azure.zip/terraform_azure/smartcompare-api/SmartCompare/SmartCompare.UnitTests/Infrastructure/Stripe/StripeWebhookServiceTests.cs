using FluentAssertions;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using SmartCompare.Domain.Entities.PaymentAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Application.Interfaces;
using SmartCompare.Domain.Enums;
using SmartCompare.Domain.Interfaces;
using SmartCompare.Infrastructure.ExternalServices.Stripe;
using SmartCompare.SharedKernel.Interfaces;
using SmartCompare.SharedKernel.Results;
using SmartCompare.UnitTests.Factories;
using SmartCompare.UnitTests.Helpers;
using SharedKernel.Errors;

namespace SmartCompare.UnitTests.Infrastructure.Stripe;

public class StripeWebhookServiceTests
{
    private readonly Mock<IPaymentRepository> _mockPaymentRepo;
    private readonly Mock<IUserRepository> _mockUserRepo;
    private readonly Mock<IUnitOfWork> _mockUnitOfWork;
    private readonly Mock<ILogger<StripeWebhookService>> _mockLogger;
    private readonly StripeOptions _stripeOptions;
    private readonly IStripePriceResolver _priceResolver;
    private readonly StripeWebhookService _sut;

    public StripeWebhookServiceTests()
    {
        _mockPaymentRepo = new Mock<IPaymentRepository>();
        _mockUserRepo = new Mock<IUserRepository>();
        _mockUnitOfWork = new Mock<IUnitOfWork>();
        _mockLogger = new Mock<ILogger<StripeWebhookService>>();

        _mockUnitOfWork.Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(1);

        _stripeOptions = new StripeOptions
        {
            WebhookSecret = StripeTestHelper.WebhookSecret,
            BasicMonthlyPriceId = "price_basic_monthly",
            BasicYearlyPriceId = "price_basic_yearly",
            ProMonthlyPriceId = StripeTestHelper.PriceId,
            ProYearlyPriceId = "price_pro_yearly",
        };

        _priceResolver = new StripePriceResolver(Options.Create(_stripeOptions));

        _sut = new StripeWebhookService(
            Options.Create(_stripeOptions),
            _priceResolver,
            _mockPaymentRepo.Object,
            _mockUserRepo.Object,
            _mockUnitOfWork.Object,
            _mockLogger.Object);
    }

    private Task<Result> InvokeWithSignature(string json)
    {
        var signature = StripeTestHelper.GenerateSignature(json, StripeTestHelper.WebhookSecret);
        return _sut.HandleWebhookAsync(json, signature);
    }

    private void VerifyLog(LogLevel level, string containsMessage, Times times)
    {
        _mockLogger.Verify(
            x => x.Log(
                level,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, _) => v.ToString()!.Contains(containsMessage)),
                It.IsAny<Exception?>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            times);
    }

    // ─── 1. Signature & Routing ─────────────────────────────────────

    [Fact]
    public async Task HandleWebhookAsync_WhenSignatureInvalid_ShouldReturnFailure()
    {
        var json = StripeTestHelper.BuildInvoicePaidEventJson();

        var result = await _sut.HandleWebhookAsync(json, "t=123,v1=bad_signature");

        result.Succeed.Should().BeFalse();
        result.Error!.Type.Should().Be(ErrorType.Validation);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenEventTypeUnhandled_ShouldReturnSuccess()
    {
        var json = StripeTestHelper.BuildUnhandledEventJson();

        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Information, "Unhandled Stripe event type", Times.Once());
    }

    // ─── 2. HandleInvoicePaid ───────────────────────────────────────

    [Fact]
    public async Task HandleWebhookAsync_WhenInvoicePaidNewSubscription_ShouldCreatePaymentAndUpdateSubscription()
    {
        var user = TestEntityFactory.CreateUserWithSubscription(stripeSubscriptionId: "sub_old");
        Payment? capturedPayment = null;

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockPaymentRepo.SetupAddPaymentAsyncWithCapture(p => capturedPayment = p);
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildInvoicePaidEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();

        // Payment created with correct amount (9900 cents → 99.00)
        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Once);
        capturedPayment.Should().NotBeNull();
        capturedPayment!.PaymentAmount.Amount.Should().Be(99.00m);
        capturedPayment.PaymentAmount.Currency.Should().Be("aud");
        capturedPayment.Status.Should().Be(PaymentStatus.Succeeded);
        capturedPayment.Type.Should().Be(PaymentType.Subscription);
        capturedPayment.StripeInvoiceId.Should().Be(StripeTestHelper.InvoiceId);

        // Subscription updated to Pro/Month with new StripeSubscriptionId
        user.Subscription!.SubscriptionTier.Should().Be(SubscriptionTier.Pro);
        user.Subscription.SubscriptionDuration.Should().Be(SubscriptionDuration.Month);
        user.Subscription.StripeSubscriptionId.Should().Be(StripeTestHelper.SubscriptionId);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenInvoicePaidRenewal_ShouldCreatePaymentAndExtendPeriod()
    {
        // Same StripeSubscriptionId → renewal path (Renew, not AddSubscription)
        var user = TestEntityFactory.CreateUserWithSubscription(
            stripeSubscriptionId: StripeTestHelper.SubscriptionId);
        var originalTier = user.Subscription!.SubscriptionTier;
        Payment? capturedPayment = null;

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockPaymentRepo.SetupAddPaymentAsyncWithCapture(p => capturedPayment = p);
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildInvoicePaidEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();

        // Payment created
        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Once);
        capturedPayment.Should().NotBeNull();
        capturedPayment!.Status.Should().Be(PaymentStatus.Succeeded);

        // Renew path: tier stays the same, StripeSubscriptionId unchanged
        user.Subscription!.SubscriptionTier.Should().Be(originalTier);
        user.Subscription.StripeSubscriptionId.Should().Be(StripeTestHelper.SubscriptionId);
        user.Subscription.SubscriptionStatus.Should().Be(SubscriptionStatus.Active);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenInvoicePaidAlreadyProcessed_ShouldSkip()
    {
        var existingPayment = Payment.Create(
            amount: 99.00m, currency: "aud",
            status: PaymentStatus.Succeeded,
            type: PaymentType.Subscription,
            stripeInvoiceId: StripeTestHelper.InvoiceId,
            subscriptionId: Guid.NewGuid());

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, existingPayment);

        var json = StripeTestHelper.BuildInvoicePaidEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Information, "already processed", Times.Once());

        // No new payment, no user lookup
        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Never);
        _mockUserRepo.Verify(
            x => x.GetByStripeCustomerIdWithSubscriptionAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenInvoicePaidExistingFailedPayment_ShouldMarkSucceeded()
    {
        var user = TestEntityFactory.CreateUserWithSubscription(
            stripeSubscriptionId: StripeTestHelper.SubscriptionId);

        var existingPayment = Payment.Create(
            amount: 0m, currency: "aud",
            status: PaymentStatus.Failed,
            type: PaymentType.Subscription,
            stripeInvoiceId: StripeTestHelper.InvoiceId,
            subscriptionId: user.Subscription!.Id);

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, existingPayment);
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildInvoicePaidEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();

        // Existing payment marked as succeeded, no new payment created
        existingPayment.Status.Should().Be(PaymentStatus.Succeeded);
        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenInvoicePaidUserNotFound_ShouldReturnSuccessAndLogError()
    {
        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, null);

        var json = StripeTestHelper.BuildInvoicePaidEventJson();
        var result = await InvokeWithSignature(json);

        // Returns success to prevent Stripe retry storms
        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Error, "No user found", Times.Once());

        // No payment created
        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenInvoicePaidNoSubscriptionLine_ShouldReturnSuccessAndLogWarning()
    {
        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);

        var json = StripeTestHelper.BuildInvoicePaidNoLineEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Warning, "no subscription line item", Times.Once());

        // Should not even look up user
        _mockUserRepo.Verify(
            x => x.GetByStripeCustomerIdWithSubscriptionAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenInvoicePaidUnknownPriceId_ShouldReturnSuccessAndLogWarning()
    {
        // User has different StripeSubscriptionId → enters new-subscription path → needs price resolution
        var user = TestEntityFactory.CreateUserWithSubscription(stripeSubscriptionId: "sub_old");

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildInvoicePaidEventJson(priceId: "price_unknown");
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Warning, "Cannot resolve Price", Times.Once());

        // Validation fails before any writes (C-5 fix)
        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    // ─── 3. HandleInvoicePaymentFailed ──────────────────────────────

    [Fact]
    public async Task HandleWebhookAsync_WhenPaymentFailedNewInvoice_ShouldCreateFailedPaymentWithAmountDue()
    {
        var user = TestEntityFactory.CreateUserWithSubscription();
        Payment? capturedPayment = null;

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockPaymentRepo.SetupAddPaymentAsyncWithCapture(p => capturedPayment = p);
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildInvoicePaymentFailedEventJson(amountDue: 4900);
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();

        // Payment uses AmountDue (not AmountPaid which is 0 on failure)
        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Once);
        capturedPayment.Should().NotBeNull();
        capturedPayment!.PaymentAmount.Amount.Should().Be(49.00m); // 4900 / 100
        capturedPayment.Status.Should().Be(PaymentStatus.Failed);
        capturedPayment.StripeInvoiceId.Should().Be(StripeTestHelper.InvoiceId);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenPaymentFailedAlreadySucceeded_ShouldSkip()
    {
        var existingPayment = Payment.Create(
            amount: 99.00m, currency: "aud",
            status: PaymentStatus.Succeeded,
            type: PaymentType.Subscription,
            stripeInvoiceId: StripeTestHelper.InvoiceId,
            subscriptionId: Guid.NewGuid());

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, existingPayment);

        var json = StripeTestHelper.BuildInvoicePaymentFailedEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Information, "already succeeded", Times.Once());

        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenPaymentFailedExistingPayment_ShouldMarkFailed()
    {
        var user = TestEntityFactory.CreateUserWithSubscription();

        var existingPayment = Payment.Create(
            amount: 99.00m, currency: "aud",
            status: PaymentStatus.Pending,
            type: PaymentType.Subscription,
            stripeInvoiceId: StripeTestHelper.InvoiceId,
            subscriptionId: user.Subscription!.Id);

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, existingPayment);
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildInvoicePaymentFailedEventJson(
            failureMessage: "Insufficient funds");
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();

        // Existing payment marked as failed, no new payment
        existingPayment.Status.Should().Be(PaymentStatus.Failed);
        existingPayment.FailureReason.Should().Be("Insufficient funds");
        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenPaymentFailedUserNotFound_ShouldReturnSuccess()
    {
        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, null);

        var json = StripeTestHelper.BuildInvoicePaymentFailedEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Error, "No user found", Times.Once());

        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    // ─── 4. HandleSubscriptionDeleted ───────────────────────────────

    [Fact]
    public async Task HandleWebhookAsync_WhenSubscriptionDeleted_ShouldCancelAndDowngradeToFree()
    {
        var user = TestEntityFactory.CreateUserWithSubscription(
            stripeSubscriptionId: StripeTestHelper.SubscriptionId,
            tier: SubscriptionTier.Pro);

        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildSubscriptionDeletedEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();

        // Cancel() → Free tier, StripeSubscriptionId cleared
        user.Subscription!.SubscriptionTier.Should().Be(SubscriptionTier.Free);
        user.Subscription.SubscriptionDuration.Should().Be(SubscriptionDuration.None);
        user.Subscription.SubscriptionStatus.Should().Be(SubscriptionStatus.Cancelled);
        user.Subscription.StripeSubscriptionId.Should().BeNull();
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenSubscriptionDeletedAlreadyCancelled_ShouldSkip()
    {
        var user = TestEntityFactory.CreateUserWithSubscription(
            stripeSubscriptionId: StripeTestHelper.SubscriptionId);
        // Simulate already cancelled
        user.Subscription!.Cancel();

        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildSubscriptionDeletedEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Information, "already cancelled", Times.Once());
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenSubscriptionDeletedMismatchedId_ShouldLogWarning()
    {
        // User's subscription has a different StripeSubscriptionId
        var user = TestEntityFactory.CreateUserWithSubscription(
            stripeSubscriptionId: "sub_current_different");

        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        // Event says sub_test_subscription but user has sub_current_different
        var json = StripeTestHelper.BuildSubscriptionDeletedEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Warning, "not matched current", Times.Once());

        // Subscription NOT cancelled — still active
        user.Subscription!.SubscriptionStatus.Should().Be(SubscriptionStatus.Active);
        user.Subscription.StripeSubscriptionId.Should().Be("sub_current_different");
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenSubscriptionDeletedUserNotFound_ShouldReturnSuccess()
    {
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, null);

        var json = StripeTestHelper.BuildSubscriptionDeletedEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Error, "No user found", Times.Once());
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenSubscriptionDeletedUserHasNoSubscription_ShouldReturnSuccess()
    {
        var user = TestEntityFactory.CreateUser();
        user.SetStripeCustomerId(StripeTestHelper.CustomerId);

        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildSubscriptionDeletedEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Warning, "has no subscription", Times.Once());
    }

    // ─── 5. Price Mapping Coverage ────────────────────────────────

    [Theory]
    [InlineData("price_basic_monthly", SubscriptionTier.Basic, SubscriptionDuration.Month)]
    [InlineData("price_basic_yearly", SubscriptionTier.Basic, SubscriptionDuration.Year)]
    [InlineData("price_pro_monthly", SubscriptionTier.Pro, SubscriptionDuration.Month)]
    [InlineData("price_pro_yearly", SubscriptionTier.Pro, SubscriptionDuration.Year)]
    public async Task HandleWebhookAsync_WhenInvoicePaidWithDifferentPriceIds_ShouldResolveCorrectTierAndDuration(
        string priceId, SubscriptionTier expectedTier, SubscriptionDuration expectedDuration)
    {
        var user = TestEntityFactory.CreateUserWithSubscription(stripeSubscriptionId: "sub_old");

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockPaymentRepo.SetupAddPaymentAsync();
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildInvoicePaidEventJson(priceId: priceId);
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        user.Subscription!.SubscriptionTier.Should().Be(expectedTier);
        user.Subscription.SubscriptionDuration.Should().Be(expectedDuration);
        user.Subscription.StripeSubscriptionId.Should().Be(StripeTestHelper.SubscriptionId);
    }

    // ─── 6. Null Subscription Guards (C-6) ─────────────────────────

    [Fact]
    public async Task HandleWebhookAsync_WhenInvoicePaidUserHasNoSubscription_ShouldReturnSuccessAndLogError()
    {
        var user = TestEntityFactory.CreateUser();
        user.SetStripeCustomerId(StripeTestHelper.CustomerId);

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildInvoicePaidEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Error, "has no subscription", Times.Once());

        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task HandleWebhookAsync_WhenPaymentFailedUserHasNoSubscription_ShouldReturnSuccessAndLogError()
    {
        var user = TestEntityFactory.CreateUser();
        user.SetStripeCustomerId(StripeTestHelper.CustomerId);

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildInvoicePaymentFailedEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Error, "has no subscription", Times.Once());

        _mockPaymentRepo.Verify(
            x => x.AddAsync(It.IsAny<Payment>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    // ─── 7. In-place Upgrade/Downgrade (same SubscriptionId, different Price) ──

    [Fact]
    public async Task HandleWebhookAsync_WhenInvoicePaidSameSubIdDifferentPrice_ShouldUpdateTierAndDuration()
    {
        // User is Basic/Month, invoice arrives with same sub ID but Pro/Year price
        var user = TestEntityFactory.CreateUserWithSubscription(
            stripeSubscriptionId: StripeTestHelper.SubscriptionId,
            tier: SubscriptionTier.Basic,
            duration: SubscriptionDuration.Month);

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockPaymentRepo.SetupAddPaymentAsync();
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        var json = StripeTestHelper.BuildInvoicePaidEventJson(priceId: "price_pro_yearly");
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();

        // Tier and duration updated in-place, same SubscriptionId kept
        user.Subscription!.SubscriptionTier.Should().Be(SubscriptionTier.Pro);
        user.Subscription.SubscriptionDuration.Should().Be(SubscriptionDuration.Year);
        user.Subscription.SubscriptionStatus.Should().Be(SubscriptionStatus.Active);
        user.Subscription.StripeSubscriptionId.Should().Be(StripeTestHelper.SubscriptionId);
    }

    // ─── 8. Concurrent Duplicate Key Idempotency (C-7) ────────────

    [Fact]
    public async Task HandleWebhookAsync_WhenInvoicePaidDuplicateKey_ShouldReturnSuccessAsIdempotent()
    {
        // Renewal path (same SubscriptionId) — simplest path that reaches SaveChanges
        var user = TestEntityFactory.CreateUserWithSubscription(
            stripeSubscriptionId: StripeTestHelper.SubscriptionId);

        _mockPaymentRepo.SetupGetByStripeInvoiceIdAsync(StripeTestHelper.InvoiceId, null);
        _mockPaymentRepo.SetupAddPaymentAsync();
        _mockUserRepo.SetupGetByStripeCustomerIdWithSubscriptionAsync(StripeTestHelper.CustomerId, user);

        // Simulate concurrent webhook: second request hits unique index on StripeInvoiceId
        _mockUnitOfWork.Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new DbUpdateException("Duplicate key", SqlExceptionHelper.Create(2627)));

        var json = StripeTestHelper.BuildInvoicePaidEventJson();
        var result = await InvokeWithSignature(json);

        result.Succeed.Should().BeTrue();
        VerifyLog(LogLevel.Warning, "Duplicate payment", Times.Once());
    }
}
