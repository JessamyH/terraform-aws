using System.Net;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using SmartCompare.Infrastructure.Services;

namespace SmartCompare.UnitTests.Infrastructure.Services;

public class LogoDownloadServiceTests
{
    private readonly Mock<IHttpClientFactory> _mockFactory;
    private readonly LogoDownloadService _service;

    public LogoDownloadServiceTests()
    {
        _mockFactory = new Mock<IHttpClientFactory>();
        _service = new LogoDownloadService(
            _mockFactory.Object,
            Mock.Of<ILogger<LogoDownloadService>>());
    }

    // ─── NULL / EMPTY / INVALID URL ────────────────────────────────────

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("not-a-url")]
    [InlineData("ftp://example.com/logo.png")]
    [InlineData("file:///etc/passwd")]
    public async Task DownloadLogoAsync_WithInvalidUrl_ShouldReturnNull(string? url)
    {
        var result = await _service.DownloadLogoAsync(url);
        result.Should().BeNull();
    }

    // ─── PRIVATE / RESERVED IP BLOCKING ────────────────────────────────

    [Theory]
    [InlineData("http://127.0.0.1/logo.png")]               // loopback
    [InlineData("http://10.0.0.1/logo.png")]                 // 10.0.0.0/8
    [InlineData("http://172.16.0.1/logo.png")]               // 172.16.0.0/12
    [InlineData("http://172.31.255.255/logo.png")]            // 172.16.0.0/12 upper bound
    [InlineData("http://192.168.1.1/logo.png")]               // 192.168.0.0/16
    [InlineData("http://169.254.169.254/logo.png")]           // link-local / AWS IMDS
    [InlineData("http://0.0.0.0/logo.png")]                   // 0.0.0.0/8
    [InlineData("http://100.64.0.1/logo.png")]                // CGNAT
    [InlineData("http://100.127.255.255/logo.png")]           // CGNAT upper bound
    [InlineData("http://[::1]/logo.png")]                     // IPv6 loopback
    [InlineData("http://[::ffff:169.254.169.254]/logo.png")]  // IPv4-mapped IPv6 metadata
    [InlineData("http://[::ffff:10.0.0.1]/logo.png")]         // IPv4-mapped IPv6 private
    public async Task DownloadLogoAsync_WithBlockedIp_ShouldReturnNull(string url)
    {
        var result = await _service.DownloadLogoAsync(url);
        result.Should().BeNull();
    }

    // ─── CLOUD METADATA ENDPOINTS ──────────────────────────────────────

    [Theory]
    [InlineData("http://169.254.169.254/latest/meta-data/")]
    [InlineData("http://metadata.google.internal/computeMetadata/v1/")]
    [InlineData("http://metadata.azure.com/metadata/instance")]
    public async Task DownloadLogoAsync_WithMetadataEndpoint_ShouldReturnNull(string url)
    {
        var result = await _service.DownloadLogoAsync(url);
        result.Should().BeNull();
    }

    // ─── ALLOWED IP (not blocked) ──────────────────────────────────────

    [Theory]
    [InlineData("http://8.8.8.8/logo.png")]
    [InlineData("http://100.63.255.255/logo.png")]  // just below CGNAT range
    [InlineData("http://172.15.255.255/logo.png")]   // just below 172.16.0.0/12
    public async Task DownloadLogoAsync_WithAllowedIp_ShouldAttemptDownload(string url)
    {
        // These IPs pass the host check, so we need a mock HttpClient
        var handler = CreateMockHandler(HttpStatusCode.OK, new byte[] { 1, 2, 3 });
        SetupFactory(handler);

        var result = await _service.DownloadLogoAsync(url);
        result.Should().NotBeNull();
    }

    // ─── SUCCESSFUL DOWNLOAD ───────────────────────────────────────────

    [Fact]
    public async Task DownloadLogoAsync_WithValidUrl_ShouldReturnBytes()
    {
        var expectedBytes = new byte[] { 0x89, 0x50, 0x4E, 0x47 }; // PNG magic
        var handler = CreateMockHandler(HttpStatusCode.OK, expectedBytes);
        SetupFactory(handler);

        var result = await _service.DownloadLogoAsync("https://storage.example.com/logo.png");
        result.Should().BeEquivalentTo(expectedBytes);
    }

    // ─── HTTP ERROR ────────────────────────────────────────────────────

    [Fact]
    public async Task DownloadLogoAsync_WhenServerReturns404_ShouldReturnNull()
    {
        var handler = CreateMockHandler(HttpStatusCode.NotFound, Array.Empty<byte>());
        SetupFactory(handler);

        var result = await _service.DownloadLogoAsync("https://storage.example.com/missing.png");
        result.Should().BeNull();
    }

    // ─── OVERSIZE CONTENT-LENGTH ───────────────────────────────────────

    [Fact]
    public async Task DownloadLogoAsync_WhenContentLengthExceedsLimit_ShouldReturnNull()
    {
        var handler = CreateMockHandler(HttpStatusCode.OK, new byte[] { 1 }, contentLength: 10 * 1024 * 1024);
        SetupFactory(handler);

        var result = await _service.DownloadLogoAsync("https://storage.example.com/huge.png");
        result.Should().BeNull();
    }

    // ─── TIMEOUT ───────────────────────────────────────────────────────

    [Fact]
    public async Task DownloadLogoAsync_WhenRequestTimesOut_ShouldReturnNull()
    {
        var handler = new Mock<HttpMessageHandler>();
        handler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ThrowsAsync(new TaskCanceledException("Timeout", new TimeoutException()));
        SetupFactory(handler);

        var result = await _service.DownloadLogoAsync("https://storage.example.com/slow.png");
        result.Should().BeNull();
    }

    // ─── HELPERS ───────────────────────────────────────────────────────

    private static Mock<HttpMessageHandler> CreateMockHandler(
        HttpStatusCode statusCode, byte[] content, long? contentLength = null)
    {
        var response = new HttpResponseMessage(statusCode)
        {
            Content = new ByteArrayContent(content),
        };
        if (contentLength.HasValue)
            response.Content.Headers.ContentLength = contentLength.Value;

        var handler = new Mock<HttpMessageHandler>();
        handler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(response);
        return handler;
    }

    private void SetupFactory(Mock<HttpMessageHandler> handler)
    {
        var client = new HttpClient(handler.Object);
        _mockFactory.Setup(f => f.CreateClient("LogoDownload")).Returns(client);
    }
}
