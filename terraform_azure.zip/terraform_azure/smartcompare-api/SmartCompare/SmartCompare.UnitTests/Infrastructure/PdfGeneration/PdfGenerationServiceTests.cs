using FluentAssertions;
using Microsoft.Extensions.Logging.Abstractions;
using QuestPDF.Infrastructure;
using SmartCompare.Application.DTOs.Quote;
using SmartCompare.Infrastructure.PdfGeneration;

namespace SmartCompare.UnitTests.Infrastructure.PdfGeneration;

public class PdfGenerationServiceTests
{
    private readonly PdfGenerationService _service;

    public PdfGenerationServiceTests()
    {
        QuestPDF.Settings.License = LicenseType.Community;
        _service = new PdfGenerationService(NullLogger<PdfGenerationService>.Instance);
    }

    [Fact]
    public void GenerateQuotePdf_WithValidData_ShouldReturnValidPdfBytes()
    {
        // Arrange
        var quoteDto = CreateFullQuoteDto();

        // Act
        var pdfBytes = _service.GenerateQuotePdf(quoteDto);

        // Assert
        pdfBytes.Should().NotBeEmpty();
        // PDF magic number: %PDF
        pdfBytes[0].Should().Be(0x25); // %
        pdfBytes[1].Should().Be(0x50); // P
        pdfBytes[2].Should().Be(0x44); // D
        pdfBytes[3].Should().Be(0x46); // F
    }

    [Fact]
    public void GenerateQuotePdf_WithEmptyCollections_ShouldReturnValidPdfBytes()
    {
        // Arrange
        var quoteDto = CreateMinimalQuoteDto();

        // Act
        var pdfBytes = _service.GenerateQuotePdf(quoteDto);

        // Assert
        pdfBytes.Should().NotBeEmpty();
        pdfBytes[0].Should().Be(0x25);
    }

    [Fact]
    public void GenerateQuotePdf_WithManyItems_ShouldReturnValidPdfBytes()
    {
        // Arrange — enough items to trigger multi-page
        var quoteDto = CreateFullQuoteDto();
        var scopeItems = Enumerable.Range(1, 50)
            .Select(i => new ScopeOfWorkDto { Id = i, Description = $"Detailed scope of work item number {i} with extended description for testing pagination behavior" })
            .ToList();
        quoteDto = quoteDto with { ScopeOfWorks = scopeItems };

        // Act
        var pdfBytes = _service.GenerateQuotePdf(quoteDto);

        // Assert
        pdfBytes.Should().NotBeEmpty();
        pdfBytes.Length.Should().BeGreaterThan(1000); // Multi-page PDF should be larger
    }

    private static QuoteDto CreateFullQuoteDto() => new()
    {
        PublicId = Guid.NewGuid(),
        QuoteNumber = "Q-2024-001",
        IssuedDate = new DateTime(2024, 6, 15),
        ValidDate = new DateTime(2024, 7, 20),
        ValidPeriod = 35,
        IssuedBy = "SmartCompare Pty Ltd",
        IssuedTo = "ABC Builders",
        Total = 110000m,
        SubTotal = 100000m,
        GST = 10000m,
        ABN = "12 345 678 901",
        LicenseNumber = "BLD-12345",
        ContactName = "Jane Smith",
        ContactEmail = "jane@smartcompare.com",
        ContactPhone = "0412 345 678",
        ProjectName = "123 Main Street Renovation",
        ScopeOfWorks = new List<ScopeOfWorkDto>
        {
            new() { Id = 1, Description = "Site preparation and demolition" },
            new() { Id = 2, Description = "Foundation and concrete works" },
            new() { Id = 3, Description = "Structural framing and roofing" }
        },
        Exclusions = new List<ExclusionDto>
        {
            new() { Id = 1, Description = "Landscaping and external works" },
            new() { Id = 2, Description = "Council approval fees" }
        },
        ProgressPayments = new List<ProgressPaymentDto>
        {
            new() { Id = 1, Description = "Deposit", Percentage = 10 },
            new() { Id = 2, Description = "Frame stage", Percentage = 25 },
            new() { Id = 3, Description = "Lock-up stage", Percentage = 25 },
            new() { Id = 4, Description = "Fixing stage", Percentage = 25 },
            new() { Id = 5, Description = "Completion", Percentage = 15 }
        }
    };

    [Fact]
    public void GenerateQuotePdf_WithSinglePageData_ShouldProduceSinglePage()
    {
        // Arrange
        var quoteDto = CreateFullQuoteDto();

        // Act
        var pdfBytes = _service.GenerateQuotePdf(quoteDto);

        // Assert
        var pageCount = CountPdfPages(pdfBytes);
        pageCount.Should().Be(1);
    }

    [Fact]
    public void GenerateQuotePdf_WithManyItems_ShouldProduceMultiplePages()
    {
        // Arrange
        var quoteDto = CreateFullQuoteDto() with
        {
            ScopeOfWorks = Enumerable.Range(1, 50)
                .Select(i => new ScopeOfWorkDto { Id = i, Description = $"Detailed scope of work item number {i} with extended description for testing" })
                .ToList()
        };

        // Act
        var pdfBytes = _service.GenerateQuotePdf(quoteDto);

        // Assert
        var pageCount = CountPdfPages(pdfBytes);
        pageCount.Should().BeGreaterThan(1);
    }

    [Fact(Skip = "Visual inspection only — run manually, not in CI")]
    [Trait("Category", "Visual")]
    public void GenerateQuotePdf_WriteToFile_ForVisualInspection()
    {
        // Arrange — single page sample
        var singlePageDto = CreateFullQuoteDto();

        // Arrange — multi page sample (50 scope items)
        var multiPageDto = CreateFullQuoteDto() with
        {
            ScopeOfWorks = Enumerable.Range(1, 50)
                .Select(i => new ScopeOfWorkDto { Id = i, Description = $"Scope of work item {i}: detailed description for visual testing" })
                .ToList(),
            Exclusions = Enumerable.Range(1, 25)
                .Select(i => new ExclusionDto { Id = i, Description = $"Exclusion item {i}: not included in this quotation" })
                .ToList()
        };

        // Act
        var singlePagePdf = _service.GenerateQuotePdf(singlePageDto);
        var multiPagePdf = _service.GenerateQuotePdf(multiPageDto);

        // Write to claudedocs for visual inspection
        var outputDir = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "claudedocs"));
        Directory.CreateDirectory(outputDir);

        File.WriteAllBytes(Path.Combine(outputDir, "sample-quote-single-page.pdf"), singlePagePdf);
        File.WriteAllBytes(Path.Combine(outputDir, "sample-quote-multi-page.pdf"), multiPagePdf);

        // Assert — files written
        singlePagePdf.Should().NotBeEmpty();
        multiPagePdf.Should().NotBeEmpty();
    }

    private static int CountPdfPages(byte[] pdfBytes)
    {
        var content = System.Text.Encoding.Latin1.GetString(pdfBytes);
        return System.Text.RegularExpressions.Regex.Matches(content, @"/Type\s*/Page(?!s)").Count;
    }

    private static QuoteDto CreateMinimalQuoteDto() => new()
    {
        PublicId = Guid.NewGuid(),
        QuoteNumber = "Q-MIN-001",
        IssuedDate = DateTime.UtcNow,
        ValidDate = DateTime.UtcNow.AddDays(30),
        ValidPeriod = 30,
        IssuedBy = "Test Co",
        IssuedTo = "Client",
        Total = 100,
        SubTotal = 90.91m,
        GST = 9.09m,
        ABN = "00000000000",
        LicenseNumber = "N/A",
        ContactName = "Test",
        ContactEmail = "test@test.com",
        ContactPhone = "0400000000",
        ProjectName = "Test Project",
        ScopeOfWorks = new List<ScopeOfWorkDto>(),
        Exclusions = new List<ExclusionDto>(),
        ProgressPayments = new List<ProgressPaymentDto>()
    };
}
