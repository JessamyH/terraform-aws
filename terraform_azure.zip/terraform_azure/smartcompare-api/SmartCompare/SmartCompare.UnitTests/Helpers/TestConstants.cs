namespace SmartCompare.UnitTests.Helpers;

/// <summary>
/// Contains commonly used test constants to reduce duplication across test files
/// </summary>
public static class TestConstants
{
    public static class Auth0
    {
        public const string DefaultSubjectId = "auth0|123456";
        public const string AlternativeSubjectId = "auth0|999999";
    }

    public static class User
    {
        public const string DefaultUserName = "Test User";
        public const string DefaultEmail = "test@example.com";
    }

    public static class Quote
    {
        public const string DefaultQuoteNumber = "Q-001";
        public const string DefaultIssuedBy = "Company A";
        public const string DefaultIssuedTo = "Client B";
        public const decimal DefaultSubTotal = 1000m;
        public const decimal DefaultGST = 100m;
        public const decimal DefaultTotal = 1100m;
        public const string DefaultPdfUrl = "http://example.com/quote.pdf";
        public const int DefaultValidDays = 30;
        public const string DefaultABN = "51824753556";
        public const string DefaultLicenseNumber = "LIC-001";
        public const string DefaultContactName = "Test Contact";
        public const string DefaultContactEmail = "contact@test.com";
        public const string DefaultContactPhone = "0400000000";
        public const int DefaultValidPeriod = 30;
    }

    public static class Project
    {
        public const string DefaultProjectName = "Test Project";
        public const string DefaultAddress = "123 Test St";
        public const int DefaultSubcontractorTypeId = 1;
        public const decimal DefaultHouseSizeSqm = 150m;
        public const int DefaultBedrooms = 3;
        public const int DefaultBathrooms = 2;
    }

    public static class ProgressPayment
    {
        public const string DefaultDescription = "Deposit";
        public const decimal DefaultPercentage = 30m;
    }

    public static class ScopeOfWork
    {
        public const string DefaultDescription = "Scope of Work Item";
    }

    public static class Exclusion
    {
        public const string DefaultDescription = "Exclusion Item";
    }
}
