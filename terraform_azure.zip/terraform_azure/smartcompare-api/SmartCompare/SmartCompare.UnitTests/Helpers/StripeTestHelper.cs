using System.Security.Cryptography;
using System.Text;

namespace SmartCompare.UnitTests.Helpers;

/// <summary>
/// Generates valid Stripe webhook signatures and event JSON for testing.
/// Uses HMAC-SHA256 to produce signatures that pass EventUtility.ConstructEvent verification.
/// JSON field paths follow Stripe API v2026-01-28 (clover).
/// </summary>
internal static class StripeTestHelper
{
    internal const string WebhookSecret = "whsec_test_secret_for_unit_tests";
    internal const string CustomerId = "cus_test_customer";
    internal const string SubscriptionId = "sub_test_subscription";
    internal const string InvoiceId = "in_test_invoice";
    internal const string PriceId = "price_pro_monthly";

    internal static string GenerateSignature(string json, string secret)
    {
        var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var signedPayload = $"{timestamp}.{json}";

        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(secret));
        var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(signedPayload));
        var hex = BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();

        return $"t={timestamp},v1={hex}";
    }

    internal static string BuildInvoicePaidEventJson(
        string? invoiceId = null,
        string? customerId = null,
        long amountPaid = 9900,
        string currency = "aud",
        string? subscriptionId = null,
        string? priceId = null,
        long? periodStart = null,
        long? periodEnd = null,
        string description = "Pro Monthly Subscription")
    {
        invoiceId ??= InvoiceId;
        customerId ??= CustomerId;
        subscriptionId ??= SubscriptionId;
        priceId ??= PriceId;
        var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var start = periodStart ?? now;
        var end = periodEnd ?? DateTimeOffset.UtcNow.AddMonths(1).ToUnixTimeSeconds();

        var invoiceJson = $$"""
        {
            "object": "invoice",
            "id": "{{invoiceId}}",
            "customer": "{{customerId}}",
            "amount_paid": {{amountPaid}},
            "amount_due": {{amountPaid}},
            "currency": "{{currency}}",
            "status_transitions": {
                "paid_at": {{now}}
            },
            "lines": {
                "object": "list",
                "data": [
                    {
                        "id": "il_test",
                        "object": "line_item",
                        "description": "{{description}}",
                        "parent": {
                            "type": "subscription_item",
                            "subscription_item_details": {
                                "subscription": "{{subscriptionId}}"
                            }
                        },
                        "pricing": {
                            "type": "unit",
                            "price_details": {
                                "price": "{{priceId}}"
                            }
                        },
                        "period": {
                            "start": {{start}},
                            "end": {{end}}
                        }
                    }
                ]
            }
        }
        """;

        return WrapInEvent("invoice.paid", invoiceJson);
    }

    internal static string BuildInvoicePaidNoLineEventJson(
        string? invoiceId = null,
        string? customerId = null)
    {
        invoiceId ??= InvoiceId;
        customerId ??= CustomerId;

        var invoiceJson = $$"""
        {
            "object": "invoice",
            "id": "{{invoiceId}}",
            "customer": "{{customerId}}",
            "amount_paid": 9900,
            "amount_due": 9900,
            "currency": "aud",
            "lines": {
                "object": "list",
                "data": []
            }
        }
        """;

        return WrapInEvent("invoice.paid", invoiceJson);
    }

    internal static string BuildInvoicePaymentFailedEventJson(
        string? invoiceId = null,
        string? customerId = null,
        long amountDue = 9900,
        string currency = "aud",
        string? failureMessage = "Your card was declined.")
    {
        invoiceId ??= InvoiceId;
        customerId ??= CustomerId;

        string invoiceJson;
        if (failureMessage != null)
        {
            invoiceJson = $$"""
            {
                "object": "invoice",
                "id": "{{invoiceId}}",
                "customer": "{{customerId}}",
                "amount_paid": 0,
                "amount_due": {{amountDue}},
                "currency": "{{currency}}",
                "last_finalization_error": {
                    "message": "{{failureMessage}}"
                },
                "lines": {
                    "object": "list",
                    "data": []
                }
            }
            """;
        }
        else
        {
            invoiceJson = $$"""
            {
                "object": "invoice",
                "id": "{{invoiceId}}",
                "customer": "{{customerId}}",
                "amount_paid": 0,
                "amount_due": {{amountDue}},
                "currency": "{{currency}}",
                "lines": {
                    "object": "list",
                    "data": []
                }
            }
            """;
        }

        return WrapInEvent("invoice.payment_failed", invoiceJson);
    }

    internal static string BuildSubscriptionDeletedEventJson(
        string? subscriptionId = null,
        string? customerId = null)
    {
        subscriptionId ??= SubscriptionId;
        customerId ??= CustomerId;

        var subJson = $$"""
        {
            "object": "subscription",
            "id": "{{subscriptionId}}",
            "customer": "{{customerId}}"
        }
        """;

        return WrapInEvent("customer.subscription.deleted", subJson);
    }

    internal static string BuildUnhandledEventJson()
    {
        var objectJson = """
        {
            "object": "charge",
            "id": "ch_test"
        }
        """;

        return WrapInEvent("charge.succeeded", objectJson);
    }

    private static string WrapInEvent(string eventType, string dataObjectJson)
    {
        var eventId = $"evt_{Guid.NewGuid():N}";
        var created = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

        return $$"""
        {
            "id": "{{eventId}}",
            "object": "event",
            "type": "{{eventType}}",
            "api_version": "{{Stripe.StripeConfiguration.ApiVersion}}",
            "created": {{created}},
            "livemode": false,
            "pending_webhooks": 0,
            "request": {
                "id": null,
                "idempotency_key": null
            },
            "data": {
                "object": {{dataObjectJson}}
            }
        }
        """;
    }
}
