using Microsoft.EntityFrameworkCore;
using SmartCompare.Infrastructure.Persistence.Contexts;

namespace SmartCompare.UnitTests.Helpers;

public static class MockDbContextHelper
{
    public static SmartCompareDbContext CreateInMemoryDbContext(string? databaseName = null)
    {
        databaseName ??= Guid.NewGuid().ToString();

        var options = new DbContextOptionsBuilder<SmartCompareDbContext>()
            .UseInMemoryDatabase(databaseName)
            .Options;

        return new SmartCompareDbContext(options);
    }
}