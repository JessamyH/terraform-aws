using SmartCompare.SharedKernel.Common;

namespace SmartCompare.UnitTests.Helpers;

internal static class EntityIdHelper
{
    /// <summary>
    /// Sets the Id on a BaseEntity via reflection to simulate EF Core persistence.
    /// Required because BaseEntity.Equals returns false when both Ids are default(0).
    /// </summary>
    internal static T WithId<T>(this T entity, int id) where T : BaseEntity<int>
    {
        typeof(BaseEntity<int>)
            .GetProperty(nameof(BaseEntity<int>.Id))!
            .SetValue(entity, id);
        return entity;
    }
}
