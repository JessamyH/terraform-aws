using AutoMapper;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace SmartCompare.UnitTests.Helpers;

internal static class TestMapperHelper
{
    private static readonly Lazy<IMapper> LazyMapper = new(() =>
    {
        var services = new ServiceCollection();
        services.AddLogging();
        services.AddAutoMapper(cfg =>
            cfg.AddMaps(typeof(Application.Mappings.ProjectMappingProfile).Assembly));
        var provider = services.BuildServiceProvider();
        return provider.GetRequiredService<IMapper>();
    });

    internal static IMapper Mapper => LazyMapper.Value;
}
