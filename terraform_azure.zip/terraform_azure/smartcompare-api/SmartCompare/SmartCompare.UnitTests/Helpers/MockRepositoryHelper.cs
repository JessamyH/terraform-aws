using Moq;
using SmartCompare.Domain.Interfaces;

namespace SmartCompare.UnitTests.Helpers;

public static class MockRepositoryHelper
{
    public static Mock<ISampleEntityRepository> CreateMockSampleEntityRepository()
    {
        return new Mock<ISampleEntityRepository>();
    }
}