using Moq;
using SmartCompare.Application.Interfaces;
using SmartCompare.Application.Services.Authorization;
using SmartCompare.Domain.Entities.PaymentAggregate;
using SmartCompare.Domain.Entities.ProjectAggregate;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Interfaces;
using SmartCompare.SharedKernel.Results;
using SharedKernel.Errors;
using SmartCompare.Application.Common.Paging;
using SmartCompare.SharedKernel.Common;
using SmartCompare.Application.DTOs;
using SmartCompare.Application.DTOs.Auth.QueryDto;
using SmartCompare.Application.DTOs.Quote;

namespace SmartCompare.UnitTests.Helpers;

/// <summary>
/// Helper class for setting up common mock configurations in tests
/// </summary>
public static class MockSetupHelper
{
    #region Authorization Service Mocks

    public static void SetupSuccessfulProjectAuthorization(
        this Mock<IProjectAuthorizationService> mockAuthService,
        Guid projectPublicId,
        string auth0SubjectId,
        User user)
    {
        mockAuthService
            .Setup(x => x.ValidateProjectOwnershipAsync(
                projectPublicId,
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));
    }

    public static void SetupFailedProjectAuthorization(
        this Mock<IProjectAuthorizationService> mockAuthService,
        Guid projectPublicId,
        string auth0SubjectId,
        Error error)
    {
        mockAuthService
            .Setup(x => x.ValidateProjectOwnershipAsync(
                projectPublicId,
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Failure<User>(error));
    }

    public static void SetupSuccessfulQuoteAuthorization(
        this Mock<IQuoteAuthorizationService> mockAuthService,
        Guid quotePublicId,
        string auth0SubjectId,
        User user)
    {
        mockAuthService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Success(user));
    }

    public static void SetupFailedQuoteAuthorization(
        this Mock<IQuoteAuthorizationService> mockAuthService,
        Guid quotePublicId,
        string auth0SubjectId,
        Error error)
    {
        mockAuthService
            .Setup(x => x.ValidateQuoteAccessAsync(
                quotePublicId,
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result.Failure<User>(error));
    }

    #endregion

    #region Project Repository Mocks

    public static void SetupGetProjectByPublicIdAsync(
        this Mock<IProjectRepository> mockProjectRepository,
        Guid projectPublicId,
        Project? project)
    {
        mockProjectRepository
            .Setup(x => x.GetProjectByPublicIdAsync(
                projectPublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(project);
    }

    public static void SetupAddProjectAsync(
        this Mock<IProjectRepository> mockProjectRepository)
    {
        mockProjectRepository
            .Setup(x => x.AddAsync(
                It.IsAny<Project>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);
    }

    #endregion

    #region Project Query Mocks

    public static void SetupGetByIdAsync(
        this Mock<IProjectQueries> mockProjectQueries,
        Guid projectPublicId,
        Project? project)
    {
        mockProjectQueries
            .Setup(x => x.GetByIdAsync(
                projectPublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(project);
    }

    public static void SetupGetProjectsByUserIdPagedAsync(
        this Mock<IProjectQueries> mockProjectQueries,
        string auth0SubjectId,
        Pagination pagination,
        PagedResult<ProjectSummaryDTOs.ProjectSummaryDto> pagedResult)
    {
        mockProjectQueries
            .Setup(x => x.GetProjectsByUserIdPagedAsync(
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(pagedResult);
    }

    #endregion

    #region Quote Repository Mocks

    public static void SetupGetQuoteByIdAsync(
        this Mock<IQuoteRepository> mockQuoteRepository,
        Guid quotePublicId,
        Quote? quote)
    {
        mockQuoteRepository
            .Setup(x => x.GetQuoteByIdAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);
    }

    public static void SetupAddAsync(
        this Mock<IQuoteRepository> mockQuoteRepository)
    {
        mockQuoteRepository
            .Setup(x => x.AddAsync(
                It.IsAny<Quote>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);
    }

    public static void SetupDelete(
        this Mock<IQuoteRepository> mockQuoteRepository)
    {
        mockQuoteRepository
            .Setup(x => x.Delete(It.IsAny<Quote>()))
            .Returns(Task.CompletedTask);
    }

    public static void SetupGetQuoteWithExclusionsAsync(
        this Mock<IQuoteRepository> mockQuoteRepository,
        Guid quotePublicId,
        Quote? quote)
    {
        mockQuoteRepository
            .Setup(x => x.GetQuoteWithExclusionsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);
    }

    public static void SetupGetQuoteWithProgressPaymentsAsync(
        this Mock<IQuoteRepository> mockQuoteRepository,
        Guid quotePublicId,
        Quote? quote)
    {
        mockQuoteRepository
            .Setup(x => x.GetQuoteWithProgressPaymentsAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);
    }

    public static void SetupGetQuoteWithScopeOfWorkAsync(
        this Mock<IQuoteRepository> mockQuoteRepository,
        Guid quotePublicId,
        Quote? quote)
    {
        mockQuoteRepository
            .Setup(x => x.GetQuoteWithScopeOfWorkAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);
    }

    #endregion

    #region User Query Mocks

    public static void SetupGetByAuth0SubjectIdAsync(
        this Mock<IUserQueries> mockUserQueries,
        string auth0SubjectId,
        User? user)
    {
        mockUserQueries
            .Setup(x => x.GetByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);
    }

    public static void SetupGetCurrentUserByAuth0SubjectIdAsync(
        this Mock<IUserQueries> mockUserQueries,
        string auth0SubjectId,
        CurrentUserDto? dto)
    {
        mockUserQueries
            .Setup(x => x.GetCurrentUserByAuth0SubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(dto);
    }

    #endregion

    #region Quote Query Mocks

    public static void SetupGetQuoteOwnerIdAsync(
        this Mock<IQuoteQueries> mockQuoteQueries,
        Guid quoteId,
        string? ownerAuth0SubjectId)
    {
        mockQuoteQueries
            .Setup(x => x.GetQuoteOwnerIdAsync(
                quoteId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(ownerAuth0SubjectId);
    }

    public static void SetupGetQuoteWithProjectAsync(
        this Mock<IQuoteQueries> mockQuoteQueries,
        Guid quotePublicId,
        Quote? quote)
    {
        mockQuoteQueries
            .Setup(x => x.GetQuoteWithProjectAsync(
                quotePublicId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(quote);
    }

    public static void SetupGetChildrenPagedAsync<TEntity, TDto>(
        this Mock<IQuoteQueries> mockQuoteQueries,
        Guid quotePublicId,
        Guid userId,
        Pagination pagination,
        PagedResult<TDto> pagedResult)
        where TEntity : BaseEntity<int>
        where TDto : class
    {
        mockQuoteQueries
            .Setup(x => x.GetChildrenPagedAsync<TEntity, TDto>(
                quotePublicId,
                userId,
                It.IsAny<System.Linq.Expressions.Expression<Func<Quote, IEnumerable<TEntity>>>>(),
                pagination,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(pagedResult);
    }

    public static void SetupGetQuoteByIdAsync<TDto>(
        this Mock<IQuoteQueries> mockQuoteQueries,
        Guid quotePublicId,
        Guid userId,
        TDto? dto)
        where TDto : class
    {
        mockQuoteQueries
            .Setup(x => x.GetByIdAsync<TDto>(
                quotePublicId,
                userId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(dto);
    }

    public static void SetupGetByProjectIdPagedAsync(
        this Mock<IQuoteQueries> mockQuoteQueries,
        Guid projectPublicId,
        string auth0SubjectId,
        Pagination pagination,
        PagedResult<QuoteSummaryDto> pagedResult)
    {
        mockQuoteQueries
            .Setup(x => x.GetByProjectIdPagedAsync(
                projectPublicId,
                auth0SubjectId,
                pagination,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(pagedResult);
    }

    #endregion

    #region Payment Repository Mocks

    public static void SetupGetByStripeInvoiceIdAsync(
        this Mock<IPaymentRepository> mockPaymentRepository,
        string invoiceId,
        Payment? payment)
    {
        mockPaymentRepository
            .Setup(x => x.GetByStripeInvoiceIdAsync(
                invoiceId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(payment);
    }

    public static void SetupAddPaymentAsync(
        this Mock<IPaymentRepository> mockPaymentRepository)
    {
        mockPaymentRepository
            .Setup(x => x.AddAsync(
                It.IsAny<Payment>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);
    }

    public static void SetupAddPaymentAsyncWithCapture(
        this Mock<IPaymentRepository> mockPaymentRepository,
        Action<Payment> captureCallback)
    {
        mockPaymentRepository
            .Setup(x => x.AddAsync(
                It.IsAny<Payment>(),
                It.IsAny<CancellationToken>()))
            .Callback<Payment, CancellationToken>((p, _) => captureCallback(p))
            .Returns(Task.CompletedTask);
    }

    #endregion

    #region User Repository Mocks

    public static void SetupGetBySubjectIdAsync(
        this Mock<IUserRepository> mockUserRepository,
        string auth0SubjectId,
        User? user)
    {
        mockUserRepository
            .Setup(x => x.GetBySubjectIdAsync(
                auth0SubjectId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);
    }

    public static void SetupGetByStripeCustomerIdWithSubscriptionAsync(
        this Mock<IUserRepository> mockUserRepository,
        string stripeCustomerId,
        User? user)
    {
        mockUserRepository
            .Setup(x => x.GetByStripeCustomerIdWithSubscriptionAsync(
                stripeCustomerId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(user);
    }

    public static void SetupAddUserAsync(
        this Mock<IUserRepository> mockUserRepository)
    {
        mockUserRepository
            .Setup(x => x.AddAsync(
                It.IsAny<User>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);
    }

    #endregion

    #region Role Repository Mocks

    public static void SetupGetRoleByIdAsync(
        this Mock<IRoleRepository> mockRoleRepository,
        Guid roleId,
        Role? role)
    {
        mockRoleRepository
            .Setup(x => x.GetByIdAsync(
                roleId,
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(role);
    }

    #endregion

    #region Subscription Query Mocks

    public static void SetupIsSubscriptionExpiredAsync(
        this Mock<ISubscriptionQueries> mockSubscriptionQueries,
        string auth0SubjectId,
        bool isExpired)
    {
        mockSubscriptionQueries
            .Setup(x => x.IsSubscriptionExpiredAsync(
                auth0SubjectId,
                It.IsAny<DateTime>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(isExpired);
    }

    #endregion

    #region Common Error Factories

    public static Error CreateForbiddenError(string message = "User doesn't have project authority")
    {
        return new Error(ErrorType.Forbidden, message);
    }

    public static Error CreateNotFoundError(string message = "Resource not found")
    {
        return new Error(ErrorType.NotFound, message);
    }

    public static Error CreateUnauthorizedError(string message = "User not found")
    {
        return new Error(ErrorType.Unauthorized, message);
    }

    #endregion
}
