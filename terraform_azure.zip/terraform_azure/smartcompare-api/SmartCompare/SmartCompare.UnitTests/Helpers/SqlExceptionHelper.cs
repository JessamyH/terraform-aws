using System.Reflection;
using Microsoft.Data.SqlClient;

namespace SmartCompare.UnitTests.Helpers;

/// <summary>
/// Creates <see cref="SqlException"/> instances via reflection for testing,
/// since SqlException has no public constructors.
/// </summary>
internal static class SqlExceptionHelper
{
    /// <summary>
    /// Creates a <see cref="SqlException"/> with the specified error number
    /// (e.g., 2601 for unique index violation, 2627 for unique constraint violation).
    /// </summary>
    internal static SqlException Create(int number)
    {
        var error = CreateSqlError(number);
        var collection = CreateErrorCollection(error);
        return CreateException(collection);
    }

    private static SqlError CreateSqlError(int number)
    {
        var ctor = typeof(SqlError)
            .GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance)
            .OrderByDescending(c => c.GetParameters().Length)
            .First(c => c.GetParameters().Length >= 8);

        var paramCount = ctor.GetParameters().Length;
        object?[] args = paramCount >= 9
            ? [number, (byte)2, (byte)17, "test", "Duplicate key violation", "proc", 1, (uint)0, null]
            : [number, (byte)2, (byte)17, "test", "Duplicate key violation", "proc", 1, (uint)0];

        return (SqlError)ctor.Invoke(args);
    }

    private static SqlErrorCollection CreateErrorCollection(SqlError error)
    {
        var collection = (SqlErrorCollection)Activator.CreateInstance(
            typeof(SqlErrorCollection),
            BindingFlags.NonPublic | BindingFlags.Instance,
            binder: null, args: null, culture: null)!;

        typeof(SqlErrorCollection)
            .GetMethod("Add", BindingFlags.NonPublic | BindingFlags.Instance)!
            .Invoke(collection, [error]);

        return collection;
    }

    private static SqlException CreateException(SqlErrorCollection collection)
    {
        var ctor = typeof(SqlException)
            .GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance)
            .OrderByDescending(c => c.GetParameters().Length)
            .First();

        return ctor.GetParameters().Length switch
        {
            >= 4 => (SqlException)ctor.Invoke(["Duplicate key violation", collection, null, Guid.Empty]),
            3 => (SqlException)ctor.Invoke(["Duplicate key violation", collection, null]),
            _ => (SqlException)ctor.Invoke(["Duplicate key violation", collection])
        };
    }
}
