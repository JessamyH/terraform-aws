using FluentAssertions;
using SmartCompare.Application.Exceptions;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.ValueObjects;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.Domain.Quotes;

public class QuoteExclusionTests
{
    private static readonly ABN TestAbn = ABN.Create("51824753556");

    private static Quote CreateQuote() =>
        Quote.Create("Q-001", "Builder Co", "Client Ltd", 1, 1000m, 100m, DateTime.UtcNow, 30, TestAbn, "LIC-001", "Test Contact", "contact@test.com", "0400000000");

    [Fact]
    public void AddExclusion_ValidDescription_AddsToCollection()
    {
        var quote = CreateQuote();

        quote.AddExclusion("Electrical work");

        quote.Exclusions.Should().ContainSingle()
            .Which.Description.Should().Be("Electrical work");
    }

    [Fact]
    public void DeleteExclusion_Valid_RemovesFromCollection()
    {
        var quote = CreateQuote();
        quote.AddExclusion("To delete");
        quote.Exclusions.First().WithId(1);

        var result = quote.DeleteExclusion(quote.Exclusions.First());

        result.Should().BeTrue();
        quote.Exclusions.Should().BeEmpty();
    }

    [Fact]
    public void UpdateExclusion_Existing_ReturnsTrueAndUpdates()
    {
        var quote = CreateQuote();
        quote.AddExclusion("Original");
        var exclusion = quote.Exclusions.First();

        var result = quote.UpdateExclusion(exclusion.Id, "Updated", out var updated);

        result.Should().BeTrue();
        updated.Should().NotBeNull();
        updated!.Description.Should().Be("Updated");
    }

    [Fact]
    public void UpdateExclusion_NotFound_ReturnsFalse()
    {
        var quote = CreateQuote();

        var result = quote.UpdateExclusion(999, "Updated", out var exclusion);

        result.Should().BeFalse();
        exclusion.Should().BeNull();
    }

    [Fact]
    public void UpdateExclusion_DuplicateDescription_ThrowsDuplicateKeyException()
    {
        var quote = CreateQuote();
        quote.AddExclusion("Existing item");
        quote.Exclusions.First().WithId(1);
        quote.AddExclusion("Another item");
        quote.Exclusions.Last().WithId(2);

        var act = () => quote.UpdateExclusion(2, "Existing item", out _);

        act.Should().Throw<DuplicateKeyException>();
    }

    [Fact]
    public void AddExclusions_ValidBatch_AddsAll()
    {
        var quote = CreateQuote();
        var exclusions = new[]
        {
            Exclusion.Create(quote.Id, "Item A"),
            Exclusion.Create(quote.Id, "Item B"),
            Exclusion.Create(quote.Id, "Item C")
        };

        quote.AddExclusions(exclusions);

        quote.Exclusions.Should().HaveCount(3);
    }

    [Fact]
    public void AddExclusions_Null_ThrowsArgumentNullException()
    {
        var quote = CreateQuote();

        var act = () => quote.AddExclusions(null!);

        act.Should().Throw<ArgumentNullException>();
    }

    [Fact]
    public void AddExclusions_Empty_ThrowsArgumentException()
    {
        var quote = CreateQuote();

        var act = () => quote.AddExclusions(Array.Empty<Exclusion>());

        act.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void AddExclusions_WrongQuoteId_ThrowsInvalidOperationException()
    {
        var quote = CreateQuote();
        var exclusions = new[] { Exclusion.Create(quoteId: 999, description: "Wrong quote") };

        var act = () => quote.AddExclusions(exclusions);

        act.Should().Throw<InvalidOperationException>();
    }

    [Fact]
    public void AddExclusions_DuplicateInRequest_ThrowsDuplicateKeyException()
    {
        var quote = CreateQuote();
        var exclusions = new[]
        {
            Exclusion.Create(quote.Id, "Same"),
            Exclusion.Create(quote.Id, "Same")
        };

        var act = () => quote.AddExclusions(exclusions);

        act.Should().Throw<DuplicateKeyException>();
    }

    [Fact]
    public void AddExclusions_DuplicateWithExisting_ThrowsDuplicateKeyException()
    {
        var quote = CreateQuote();
        quote.AddExclusion("Already exists");
        var exclusions = new[] { Exclusion.Create(quote.Id, "Already exists") };

        var act = () => quote.AddExclusions(exclusions);

        act.Should().Throw<DuplicateKeyException>();
    }
}
