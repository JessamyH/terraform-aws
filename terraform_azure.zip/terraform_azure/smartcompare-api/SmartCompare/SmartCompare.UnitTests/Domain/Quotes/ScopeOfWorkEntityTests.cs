using FluentAssertions;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.ValueObjects;

namespace SmartCompare.UnitTests.Domain.Quotes;

public class ScopeOfWorkEntityTests
{
    private static readonly ABN TestAbn = ABN.Create("51824753556");
    [Fact]
    public void Create_ValidArgs_SetsProperties()
    {
        var sow = ScopeOfWork.Create(quoteId: 1, description: "Install plumbing");

        sow.QuoteId.Should().Be(1);
        sow.Description.Should().Be("Install plumbing");
    }

    [Fact]
    public void Create_NullDescription_ThrowsArgumentNullException()
    {
        var act = () => ScopeOfWork.Create(quoteId: 1, description: null!);

        act.Should().Throw<ArgumentNullException>().WithParameterName("description");
    }

    [Fact]
    public void UpdateDescription_NullOrWhitespace_Throws()
    {
        // UpdateDescription is internal — test via Quote.UpdateScopeOfWork
        var quote = Quote.Create("Q-001", "Builder Co", "Client Ltd", 1, 1000m, 100m, DateTime.UtcNow, 30, TestAbn, "LIC-001", "Test Contact", "contact@test.com", "0400000000");
        quote.AddScopeOfWork("Original");
        var sow = quote.ScopeOfWorks.First();

        var actNull = () => quote.UpdateScopeOfWork(sow.Id, null!, out _);
        var actWhitespace = () => quote.UpdateScopeOfWork(sow.Id, "   ", out _);

        actNull.Should().Throw<ArgumentException>();
        actWhitespace.Should().Throw<ArgumentException>();
    }
}
