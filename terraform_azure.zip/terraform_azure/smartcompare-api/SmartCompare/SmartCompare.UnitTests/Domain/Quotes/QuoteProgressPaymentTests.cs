using FluentAssertions;
using SmartCompare.Application.Exceptions;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.ValueObjects;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.Domain.Quotes;

public class QuoteProgressPaymentTests
{
    private static readonly ABN TestAbn = ABN.Create("51824753556");

    private static Quote CreateQuote() =>
        Quote.Create("Q-001", "Builder Co", "Client Ltd", 1, 1000m, 100m, DateTime.UtcNow, 30, TestAbn, "LIC-001", "Test Contact", "contact@test.com", "0400000000");

    [Fact]
    public void AddProgressPayment_ValidArgs_AddsToCollection()
    {
        var quote = CreateQuote();

        quote.AddProgressPayment(50m, "Milestone 1");

        quote.ProgressPayments.Should().ContainSingle();
        var pp = quote.ProgressPayments.First();
        pp.Percentage.Should().Be(50m);
        pp.Description.Should().Be("Milestone 1");
    }

    [Fact]
    public void DeleteProgressPayment_Existing_ReturnsTrueAndRemoves()
    {
        var quote = CreateQuote();
        quote.AddProgressPayment(50m, "To delete");
        quote.ProgressPayments.First().WithId(1);

        var result = quote.DeleteProgressPayment(1);

        result.Should().BeTrue();
        quote.ProgressPayments.Should().BeEmpty();
    }

    [Fact]
    public void DeleteProgressPayment_NotFound_ReturnsFalse()
    {
        var quote = CreateQuote();

        var result = quote.DeleteProgressPayment(999);

        result.Should().BeFalse();
    }

    [Fact]
    public void UpdateProgressPayment_Existing_ReturnsTrueAndUpdates()
    {
        var quote = CreateQuote();
        quote.AddProgressPayment(50m, "Original");
        var pp = quote.ProgressPayments.First();

        var result = quote.UpdateProgressPayment(pp.Id, 75m, "Updated", out var updated);

        result.Should().BeTrue();
        updated.Should().NotBeNull();
        updated!.Percentage.Should().Be(75m);
        updated.Description.Should().Be("Updated");
    }

    [Fact]
    public void UpdateProgressPayment_NotFound_ReturnsFalse()
    {
        var quote = CreateQuote();

        var result = quote.UpdateProgressPayment(999, 50m, "Updated", out var pp);

        result.Should().BeFalse();
        pp.Should().BeNull();
    }

    [Fact]
    public void UpdateProgressPayment_DuplicateDescription_ThrowsDuplicateKeyException()
    {
        var quote = CreateQuote();
        quote.AddProgressPayment(30m, "Existing milestone");
        quote.ProgressPayments.First().WithId(1);
        quote.AddProgressPayment(70m, "Another milestone");
        quote.ProgressPayments.Last().WithId(2);

        var act = () => quote.UpdateProgressPayment(2, 70m, "Existing milestone", out _);

        act.Should().Throw<DuplicateKeyException>();
    }

    [Fact]
    public void AddProgressPaymentBatch_ValidItems_AddsAll()
    {
        var quote = CreateQuote();
        var items = new[]
        {
            ProgressPayment.Create(quote.Id, 30m, "Phase A"),
            ProgressPayment.Create(quote.Id, 40m, "Phase B"),
            ProgressPayment.Create(quote.Id, 30m, "Phase C")
        };

        quote.AddProgressPayment(items);

        quote.ProgressPayments.Should().HaveCount(3);
    }

    [Fact]
    public void AddProgressPaymentBatch_Null_ThrowsArgumentNullException()
    {
        var quote = CreateQuote();

        var act = () => quote.AddProgressPayment((IEnumerable<ProgressPayment>)null!);

        act.Should().Throw<ArgumentNullException>();
    }

    [Fact]
    public void AddProgressPaymentBatch_Empty_ThrowsArgumentException()
    {
        var quote = CreateQuote();

        var act = () => quote.AddProgressPayment(Array.Empty<ProgressPayment>());

        act.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void AddProgressPaymentBatch_WrongQuoteId_ThrowsInvalidOperationException()
    {
        var quote = CreateQuote();
        var items = new[] { ProgressPayment.Create(quoteId: 999, percentage: 50m, description: "Wrong quote") };

        var act = () => quote.AddProgressPayment(items);

        act.Should().Throw<InvalidOperationException>();
    }

    [Fact]
    public void AddProgressPaymentBatch_DuplicateInRequest_ThrowsDuplicateKeyException()
    {
        var quote = CreateQuote();
        var items = new[]
        {
            ProgressPayment.Create(quote.Id, 50m, "Same"),
            ProgressPayment.Create(quote.Id, 50m, "Same")
        };

        var act = () => quote.AddProgressPayment(items);

        act.Should().Throw<DuplicateKeyException>();
    }
}
