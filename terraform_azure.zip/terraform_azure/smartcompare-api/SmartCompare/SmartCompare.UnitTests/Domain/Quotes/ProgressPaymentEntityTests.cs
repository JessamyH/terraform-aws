using FluentAssertions;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.ValueObjects;

namespace SmartCompare.UnitTests.Domain.Quotes;

public class ProgressPaymentEntityTests
{
    private static readonly ABN TestAbn = ABN.Create("51824753556");
    [Fact]
    public void Create_ValidArgs_SetsProperties()
    {
        var pp = ProgressPayment.Create(quoteId: 1, percentage: 50m, description: "  Milestone 1  ");

        pp.QuoteId.Should().Be(1);
        pp.Percentage.Should().Be(50m);
        pp.Description.Should().Be("Milestone 1");
    }

    [Fact]
    public void Create_NullDescription_ThrowsArgumentNullException()
    {
        var act = () => ProgressPayment.Create(quoteId: 1, percentage: 50m, description: null!);

        act.Should().Throw<ArgumentNullException>().WithParameterName("description");
    }

    [Fact]
    public void UpdateDetails_ValidInput_UpdatesBoth()
    {
        // UpdateDetails is internal — test via Quote.UpdateProgressPayment
        var quote = Quote.Create("Q-001", "Builder Co", "Client Ltd", 1, 1000m, 100m, DateTime.UtcNow, 30, TestAbn, "LIC-001", "Test Contact", "contact@test.com", "0400000000");
        quote.AddProgressPayment(30m, "Original");
        var pp = quote.ProgressPayments.First();

        quote.UpdateProgressPayment(pp.Id, 75m, "  Updated  ", out var updated);

        updated!.Percentage.Should().Be(75m);
        updated.Description.Should().Be("Updated");
    }

    [Fact]
    public void UpdateDetails_NullOrWhitespaceDescription_Throws()
    {
        var quote = Quote.Create("Q-001", "Builder Co", "Client Ltd", 1, 1000m, 100m, DateTime.UtcNow, 30, TestAbn, "LIC-001", "Test Contact", "contact@test.com", "0400000000");
        quote.AddProgressPayment(30m, "Original");
        var pp = quote.ProgressPayments.First();

        var actNull = () => quote.UpdateProgressPayment(pp.Id, 50m, null!, out _);
        var actWhitespace = () => quote.UpdateProgressPayment(pp.Id, 50m, "   ", out _);

        actNull.Should().Throw<ArgumentException>();
        actWhitespace.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void UpdateDetails_NegativePercentage_ThrowsArgumentOutOfRangeException()
    {
        var quote = Quote.Create("Q-001", "Builder Co", "Client Ltd", 1, 1000m, 100m, DateTime.UtcNow, 30, TestAbn, "LIC-001", "Test Contact", "contact@test.com", "0400000000");
        quote.AddProgressPayment(30m, "Original");
        var pp = quote.ProgressPayments.First();

        var act = () => quote.UpdateProgressPayment(pp.Id, -1m, "Valid", out _);

        act.Should().Throw<ArgumentOutOfRangeException>();
    }
}
