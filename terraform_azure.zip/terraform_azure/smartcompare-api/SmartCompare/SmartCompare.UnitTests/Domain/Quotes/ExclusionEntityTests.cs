using FluentAssertions;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.ValueObjects;

namespace SmartCompare.UnitTests.Domain.Quotes;

public class ExclusionEntityTests
{
    private static readonly ABN TestAbn = ABN.Create("51824753556");
    [Fact]
    public void Create_ValidArgs_SetsNormalizedDescription()
    {
        var exclusion = Exclusion.Create(quoteId: 1, description: "  Electrical work  ");

        exclusion.QuoteId.Should().Be(1);
        exclusion.Description.Should().Be("Electrical work");
    }

    [Fact]
    public void Create_NullDescription_ThrowsArgumentNullException()
    {
        var act = () => Exclusion.Create(quoteId: 1, description: null!);

        act.Should().Throw<ArgumentNullException>().WithParameterName("description");
    }

    [Fact]
    public void UpdateDescription_ValidInput_NormalizesAndSets()
    {
        // UpdateDescription is internal — test via Quote.UpdateExclusion
        var quote = Quote.Create("Q-001", "Builder Co", "Client Ltd", 1, 1000m, 100m, DateTime.UtcNow, 30, TestAbn, "LIC-001", "Test Contact", "contact@test.com", "0400000000");
        quote.AddExclusion("Original");
        var exclusion = quote.Exclusions.First();

        quote.UpdateExclusion(exclusion.Id, "  Updated  ", out var updated);

        updated!.Description.Should().Be("Updated");
    }

    [Fact]
    public void UpdateDescription_NullOrWhitespace_Throws()
    {
        var quote = Quote.Create("Q-001", "Builder Co", "Client Ltd", 1, 1000m, 100m, DateTime.UtcNow, 30, TestAbn, "LIC-001", "Test Contact", "contact@test.com", "0400000000");
        quote.AddExclusion("Original");
        var exclusion = quote.Exclusions.First();

        var actNull = () => quote.UpdateExclusion(exclusion.Id, null!, out _);
        var actWhitespace = () => quote.UpdateExclusion(exclusion.Id, "   ", out _);

        actNull.Should().Throw<ArgumentException>();
        actWhitespace.Should().Throw<ArgumentException>();
    }
}
