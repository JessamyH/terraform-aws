using FluentAssertions;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.ValueObjects;

namespace SmartCompare.UnitTests.Domain.Quotes;

public class QuoteCreateUpdateTests
{
    private const string QuoteNumber = "Q-001";
    private const string IssuedBy = "Builder Co";
    private const string IssuedTo = "Client Ltd";
    private const int ProjectId = 1;
    private const decimal SubTotal = 1000m;
    private const decimal Gst = 100m;
    private static readonly DateTime IssuedDate = new(2026, 1, 15, 0, 0, 0, DateTimeKind.Utc);
    private const int ValidPeriod = 30;
    private static readonly ABN TestAbn = ABN.Create("51824753556");
    private const string LicenseNumber = "LIC-001";
    private const string ContactName = "Test Contact";
    private const string ContactEmail = "contact@test.com";
    private const string ContactPhone = "0400000000";

    private static Quote CreateDefaultQuote(string? pdfUrl = null) =>
        Quote.Create(QuoteNumber, IssuedBy, IssuedTo, ProjectId, SubTotal, Gst,
            IssuedDate, ValidPeriod, TestAbn, LicenseNumber, ContactName, ContactEmail, ContactPhone, pdfUrl);

    [Fact]
    public void Create_ValidArgs_SetsAllProperties()
    {
        var quote = CreateDefaultQuote("http://pdf.url");

        quote.QuoteNumber.Should().Be(QuoteNumber);
        quote.IssuedBy.Should().Be(IssuedBy);
        quote.IssuedTo.Should().Be(IssuedTo);
        quote.ProjectId.Should().Be(ProjectId);
        quote.SubTotal.Should().Be(SubTotal);
        quote.GST.Should().Be(Gst);
        quote.ValidPeriod.Should().Be(ValidPeriod);
        quote.ValidDate.Should().Be(IssuedDate.AddDays(ValidPeriod));
        quote.PDFUrl.Should().Be("http://pdf.url");
        quote.PublicId.Should().NotBeEmpty();
        quote.ABN.Value.Should().Be("51824753556");
        quote.LicenseNumber.Should().Be(LicenseNumber);
        quote.ContactName.Should().Be(ContactName);
        quote.ContactEmail.Should().Be(ContactEmail);
        quote.ContactPhone.Should().Be(ContactPhone);
        quote.IssuedDate.Should().Be(IssuedDate);
    }

    [Fact]
    public void Create_NullQuoteNumber_ThrowsArgumentNullException()
    {
        var act = () => Quote.Create(null!, IssuedBy, IssuedTo, ProjectId, SubTotal, Gst,
            IssuedDate, ValidPeriod, TestAbn, LicenseNumber, ContactName, ContactEmail, ContactPhone);

        act.Should().Throw<ArgumentNullException>().WithParameterName("quoteNumber");
    }

    [Fact]
    public void Create_NullIssuedBy_ThrowsArgumentNullException()
    {
        var act = () => Quote.Create(QuoteNumber, null!, IssuedTo, ProjectId, SubTotal, Gst,
            IssuedDate, ValidPeriod, TestAbn, LicenseNumber, ContactName, ContactEmail, ContactPhone);

        act.Should().Throw<ArgumentNullException>().WithParameterName("issuedBy");
    }

    [Fact]
    public void Create_NullIssuedTo_ThrowsArgumentNullException()
    {
        var act = () => Quote.Create(QuoteNumber, IssuedBy, null!, ProjectId, SubTotal, Gst,
            IssuedDate, ValidPeriod, TestAbn, LicenseNumber, ContactName, ContactEmail, ContactPhone);

        act.Should().Throw<ArgumentNullException>().WithParameterName("issuedTo");
    }

    [Fact]
    public void Create_TotalEquals_SubTotalPlusGst()
    {
        var quote = CreateDefaultQuote();

        quote.Total.Should().Be(SubTotal + Gst);
    }

    [Fact]
    public void Create_SetsIssuedDateFromParameter()
    {
        var specificDate = new DateTime(2025, 6, 1, 0, 0, 0, DateTimeKind.Utc);

        var quote = Quote.Create(QuoteNumber, IssuedBy, IssuedTo, ProjectId, SubTotal, Gst,
            specificDate, ValidPeriod, TestAbn, LicenseNumber, ContactName, ContactEmail, ContactPhone);

        quote.IssuedDate.Should().Be(specificDate);
        quote.ValidDate.Should().Be(specificDate.AddDays(ValidPeriod));
    }

    [Fact]
    public void Update_ValidArgs_UpdatesAllProperties()
    {
        var quote = CreateDefaultQuote();
        var newIssuedDate = DateTime.UtcNow.AddDays(-5);
        var newAbn = ABN.Create("51824753556");

        quote.Update("Q-002", "New Builder", "New Client", 2000m, 200m,
            newIssuedDate, 60, newAbn, "LIC-002", "New Contact", "new@email.com", "0411111111", "http://new.pdf");

        quote.QuoteNumber.Should().Be("Q-002");
        quote.IssuedBy.Should().Be("New Builder");
        quote.IssuedTo.Should().Be("New Client");
        quote.SubTotal.Should().Be(2000m);
        quote.GST.Should().Be(200m);
        quote.Total.Should().Be(2200m);
        quote.IssuedDate.Should().Be(newIssuedDate);
        quote.ValidPeriod.Should().Be(60);
        quote.ValidDate.Should().Be(newIssuedDate.AddDays(60));
        quote.PDFUrl.Should().Be("http://new.pdf");
        quote.LicenseNumber.Should().Be("LIC-002");
        quote.ContactName.Should().Be("New Contact");
        quote.ContactEmail.Should().Be("new@email.com");
        quote.ContactPhone.Should().Be("0411111111");
    }

    [Fact]
    public void Update_SetsUpdatedAtToUtcNow()
    {
        var quote = CreateDefaultQuote();
        var before = DateTime.UtcNow;

        quote.Update("Q-002", "New Builder", "New Client", 2000m, 200m,
            IssuedDate, ValidPeriod, TestAbn, LicenseNumber, ContactName, ContactEmail, ContactPhone);

        quote.UpdatedAt.Should().NotBeNull();
        var after = DateTime.UtcNow;
        quote.UpdatedAt!.Value.Should().BeOnOrAfter(before).And.BeOnOrBefore(after);
    }
}
