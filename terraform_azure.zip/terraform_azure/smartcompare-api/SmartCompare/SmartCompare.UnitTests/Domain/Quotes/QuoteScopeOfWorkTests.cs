using FluentAssertions;
using SmartCompare.Application.Exceptions;
using SmartCompare.Domain.Entities.QuoteAggregate;
using SmartCompare.Domain.ValueObjects;
using SmartCompare.UnitTests.Helpers;

namespace SmartCompare.UnitTests.Domain.Quotes;

public class QuoteScopeOfWorkTests
{
    private static readonly ABN TestAbn = ABN.Create("51824753556");

    private static Quote CreateQuote() =>
        Quote.Create("Q-001", "Builder Co", "Client Ltd", 1, 1000m, 100m, DateTime.UtcNow, 30, TestAbn, "LIC-001", "Test Contact", "contact@test.com", "0400000000");

    [Fact]
    public void AddScopeOfWork_ValidDescription_AddsToCollection()
    {
        var quote = CreateQuote();

        quote.AddScopeOfWork("Install plumbing");

        quote.ScopeOfWorks.Should().ContainSingle()
            .Which.Description.Should().Be("Install plumbing");
    }

    [Fact]
    public void UpdateScopeOfWork_Existing_ReturnsTrueAndUpdates()
    {
        var quote = CreateQuote();
        quote.AddScopeOfWork("Original");
        var sow = quote.ScopeOfWorks.First();

        var result = quote.UpdateScopeOfWork(sow.Id, "Updated", out var updated);

        result.Should().BeTrue();
        updated.Should().NotBeNull();
        updated!.Description.Should().Be("Updated");
    }

    [Fact]
    public void UpdateScopeOfWork_NotFound_ReturnsFalse()
    {
        var quote = CreateQuote();

        var result = quote.UpdateScopeOfWork(999, "Updated", out var sow);

        result.Should().BeFalse();
        sow.Should().BeNull();
    }

    [Fact]
    public void AddScopeOfWork_DuplicateDescription_ThrowsDuplicateKeyException()
    {
        var quote = CreateQuote();
        quote.AddScopeOfWork("Install plumbing");

        var act = () => quote.AddScopeOfWork("Install plumbing");

        act.Should().Throw<DuplicateKeyException>();
    }

    [Fact]
    public void UpdateScopeOfWork_DuplicateDescription_ThrowsDuplicateKeyException()
    {
        var quote = CreateQuote();
        quote.AddScopeOfWork("Item A");
        quote.ScopeOfWorks.First().WithId(1);
        quote.AddScopeOfWork("Item B");
        quote.ScopeOfWorks.Last().WithId(2);

        var act = () => quote.UpdateScopeOfWork(2, "Item A", out _);

        act.Should().Throw<DuplicateKeyException>();
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void UpdateScopeOfWork_NullOrWhitespace_ThrowsArgumentException(string? description)
    {
        var quote = CreateQuote();
        quote.AddScopeOfWork("Original");
        var sow = quote.ScopeOfWorks.First();

        var act = () => quote.UpdateScopeOfWork(sow.Id, description!, out _);

        act.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void AddScopeOfWorks_ValidBatch_AddsAllToCollection()
    {
        var quote = CreateQuote();
        var items = new List<ScopeOfWork>
        {
            ScopeOfWork.Create(quote.Id, "Item 1"),
            ScopeOfWork.Create(quote.Id, "Item 2"),
            ScopeOfWork.Create(quote.Id, "Item 3")
        };

        quote.AddScopeOfWorks(items);

        quote.ScopeOfWorks.Should().HaveCount(3);
        quote.ScopeOfWorks.Select(s => s.Description).Should().BeEquivalentTo("Item 1", "Item 2", "Item 3");
    }

    [Fact]
    public void AddScopeOfWorks_EmptyList_ThrowsArgumentException()
    {
        var quote = CreateQuote();

        var act = () => quote.AddScopeOfWorks(new List<ScopeOfWork>());

        act.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void AddScopeOfWorks_NullInput_ThrowsArgumentNullException()
    {
        var quote = CreateQuote();

        var act = () => quote.AddScopeOfWorks(null!);

        act.Should().Throw<ArgumentNullException>();
    }

    [Fact]
    public void AddScopeOfWorks_DuplicateWithinBatch_ThrowsDuplicateKeyException()
    {
        var quote = CreateQuote();
        var items = new List<ScopeOfWork>
        {
            ScopeOfWork.Create(quote.Id, "Same Item"),
            ScopeOfWork.Create(quote.Id, "Same Item")
        };

        var act = () => quote.AddScopeOfWorks(items);

        act.Should().Throw<DuplicateKeyException>();
    }

    [Fact]
    public void AddScopeOfWorks_DuplicateWithExisting_ThrowsDuplicateKeyException()
    {
        var quote = CreateQuote();
        quote.AddScopeOfWork("Existing Item");

        var items = new List<ScopeOfWork>
        {
            ScopeOfWork.Create(quote.Id, "Existing Item")
        };

        var act = () => quote.AddScopeOfWorks(items);

        act.Should().Throw<DuplicateKeyException>();
    }

    [Fact]
    public void AddScopeOfWorks_WrongQuoteId_ThrowsInvalidOperationException()
    {
        var quote = CreateQuote();
        var items = new List<ScopeOfWork>
        {
            ScopeOfWork.Create(999, "Wrong Quote Item")
        };

        var act = () => quote.AddScopeOfWorks(items);

        act.Should().Throw<InvalidOperationException>();
    }

    [Fact]
    public void DeleteScopeOfWork_Existing_ReturnsTrueAndRemoves()
    {
        var quote = CreateQuote();
        quote.AddScopeOfWork("To delete");
        quote.ScopeOfWorks.First().WithId(1);

        var result = quote.DeleteScopeOfWork(1);

        result.Should().BeTrue();
        quote.ScopeOfWorks.Should().BeEmpty();
    }

    [Fact]
    public void DeleteScopeOfWork_NotFound_ReturnsFalse()
    {
        var quote = CreateQuote();

        var result = quote.DeleteScopeOfWork(999);

        result.Should().BeFalse();
    }
}
