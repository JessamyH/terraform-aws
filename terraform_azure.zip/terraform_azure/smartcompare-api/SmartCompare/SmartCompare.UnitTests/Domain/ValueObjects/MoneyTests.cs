using FluentAssertions;
using SmartCompare.Domain.ValueObjects;

namespace SmartCompare.UnitTests.Domain.ValueObjects;

public class MoneyTests
{
    [Fact]
    public void Create_ValidAmountAndCurrency_ReturnsMoney()
    {
        var money = Money.Create(100m, "AUD");

        money.Amount.Should().Be(100m);
        money.Currency.Should().Be("AUD");
    }

    // === Add ===

    [Fact]
    public void ApplyOperation_Add_ReturnsSum()
    {
        var money = Money.Create(100m, "AUD");

        var result = money.ApplyOperation(50m, MoneyOperation.Add);

        result.Amount.Should().Be(150m);
        result.Currency.Should().Be("AUD");
    }

    [Fact]
    public void ApplyOperation_AddWithMoney_ReturnsSum()
    {
        var a = Money.Create(100m, "AUD");
        var b = Money.Create(50m, "AUD");

        var result = a.ApplyOperation(b, MoneyOperation.Add);

        result.Amount.Should().Be(150m);
    }

    // === Subtract ===

    [Fact]
    public void ApplyOperation_Subtract_ReturnsDifference()
    {
        var money = Money.Create(100m, "AUD");

        var result = money.ApplyOperation(30m, MoneyOperation.Subtract);

        result.Amount.Should().Be(70m);
    }

    [Fact]
    public void ApplyOperation_SubtractToZero_ReturnsZero()
    {
        var money = Money.Create(100m, "AUD");

        var result = money.ApplyOperation(100m, MoneyOperation.Subtract);

        result.Amount.Should().Be(0m);
    }

    [Fact]
    public void ApplyOperation_SubtractResultingNegative_ThrowsInvalidOperationException()
    {
        var money = Money.Create(50m, "AUD");

        var act = () => money.ApplyOperation(100m, MoneyOperation.Subtract);

        act.Should().Throw<InvalidOperationException>()
            .WithMessage("*cannot be negative*");
    }

    // === Multiply ===

    [Fact]
    public void ApplyOperation_Multiply_ReturnsProduct()
    {
        var money = Money.Create(100m, "AUD");

        var result = money.ApplyOperation(1.1m, MoneyOperation.Multiply);

        result.Amount.Should().Be(110m);
    }

    [Fact]
    public void ApplyOperation_MultiplyByZero_ReturnsZero()
    {
        var money = Money.Create(100m, "AUD");

        var result = money.ApplyOperation(0m, MoneyOperation.Multiply);

        result.Amount.Should().Be(0m);
    }

    [Fact]
    public void ApplyOperation_MultiplyByNegative_ThrowsInvalidOperationException()
    {
        var money = Money.Create(100m, "AUD");

        var act = () => money.ApplyOperation(-2m, MoneyOperation.Multiply);

        act.Should().Throw<InvalidOperationException>()
            .WithMessage("*negative*");
    }

    // === Divide ===

    [Fact]
    public void ApplyOperation_Divide_ReturnsQuotient()
    {
        var money = Money.Create(100m, "AUD");

        var result = money.ApplyOperation(4m, MoneyOperation.Divide);

        result.Amount.Should().Be(25m);
    }

    [Fact]
    public void ApplyOperation_DivideByZero_ThrowsDivideByZeroException()
    {
        var money = Money.Create(100m, "AUD");

        var act = () => money.ApplyOperation(0m, MoneyOperation.Divide);

        act.Should().Throw<DivideByZeroException>();
    }

    [Fact]
    public void ApplyOperation_DivideByNegative_ThrowsDivideByZeroException()
    {
        var money = Money.Create(100m, "AUD");

        var act = () => money.ApplyOperation(-5m, MoneyOperation.Divide);

        act.Should().Throw<DivideByZeroException>();
    }

    // === Currency mismatch ===

    [Fact]
    public void ApplyOperation_DifferentCurrencies_ThrowsInvalidOperationException()
    {
        var aud = Money.Create(100m, "AUD");
        var usd = Money.Create(50m, "USD");

        var act = () => aud.ApplyOperation(usd, MoneyOperation.Add);

        act.Should().Throw<InvalidOperationException>()
            .WithMessage("*different currencies*");
    }

    [Fact]
    public void ApplyOperation_NullOther_ThrowsArgumentNullException()
    {
        var money = Money.Create(100m, "AUD");

        var act = () => money.ApplyOperation((Money)null!, MoneyOperation.Add);

        act.Should().Throw<ArgumentNullException>();
    }

    // === Unsupported operation ===

    [Fact]
    public void ApplyOperation_UnsupportedOperation_ThrowsArgumentOutOfRangeException()
    {
        var money = Money.Create(100m, "AUD");

        var act = () => money.ApplyOperation(1m, (MoneyOperation)999);

        act.Should().Throw<ArgumentOutOfRangeException>();
    }

    // === Equality ===

    [Fact]
    public void Equals_SameAmountAndCurrency_ReturnsTrue()
    {
        var a = Money.Create(100m, "AUD");
        var b = Money.Create(100m, "AUD");

        a.Should().Be(b);
    }

    [Fact]
    public void Equals_DifferentAmount_ReturnsFalse()
    {
        var a = Money.Create(100m, "AUD");
        var b = Money.Create(200m, "AUD");

        a.Should().NotBe(b);
    }

    [Fact]
    public void Equals_DifferentCurrency_ReturnsFalse()
    {
        var a = Money.Create(100m, "AUD");
        var b = Money.Create(100m, "USD");

        a.Should().NotBe(b);
    }
}
