using FluentAssertions;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Enums;

namespace SmartCompare.UnitTests.Domain.Users;

public class SubscriptionExpireTests
{
    private static Subscription CreateActiveSubscription(
        SubscriptionTier tier = SubscriptionTier.Pro,
        SubscriptionDuration duration = SubscriptionDuration.Month,
        DateTime? startDate = null,
        DateTime? endDate = null,
        string? stripeSubscriptionId = "sub_test123")
    {
        return Subscription.Create(
            userId: Guid.NewGuid(),
            subscriptionTier: tier,
            subscriptionDuration: duration,
            subscriptionStatus: SubscriptionStatus.Active,
            startDate: startDate ?? DateTime.UtcNow.AddMonths(-1),
            endDate: endDate ?? DateTime.UtcNow.AddDays(1),
            stripeSubscriptionId: stripeSubscriptionId,
            isDeleted: false);
    }

    private static Subscription CreateTrialSubscription(
        DateTime? endDate = null)
    {
        return Subscription.Create(
            userId: Guid.NewGuid(),
            subscriptionTier: SubscriptionTier.Basic,
            subscriptionDuration: SubscriptionDuration.Month,
            subscriptionStatus: SubscriptionStatus.Trial,
            startDate: DateTime.UtcNow.AddMonths(-1),
            endDate: endDate ?? DateTime.UtcNow.AddDays(1),
            stripeSubscriptionId: "sub_trial123",
            isDeleted: false);
    }

    #region Expire() Tests

    [Fact]
    public void Expire_WhenActiveSubscription_ShouldSetExpiredAndFree()
    {
        // Arrange
        var subscription = CreateActiveSubscription();

        // Act
        subscription.Expire();

        // Assert
        subscription.SubscriptionStatus.Should().Be(SubscriptionStatus.Expired);
        subscription.SubscriptionTier.Should().Be(SubscriptionTier.Free);
        subscription.SubscriptionDuration.Should().Be(SubscriptionDuration.None);
        subscription.StripeSubscriptionId.Should().BeNull();
        subscription.UpdatedAt.Should().NotBeNull()
            .And.BeAfter(DateTime.UtcNow.AddSeconds(-5));
    }

    [Fact]
    public void Expire_WhenTrialSubscription_ShouldSetExpiredAndFree()
    {
        // Arrange
        var subscription = CreateTrialSubscription();

        // Act
        subscription.Expire();

        // Assert
        subscription.SubscriptionStatus.Should().Be(SubscriptionStatus.Expired);
        subscription.SubscriptionTier.Should().Be(SubscriptionTier.Free);
        subscription.SubscriptionDuration.Should().Be(SubscriptionDuration.None);
        subscription.StripeSubscriptionId.Should().BeNull();
    }

    [Fact]
    public void Expire_ShouldBeIdempotent()
    {
        // Arrange
        var subscription = CreateActiveSubscription();

        // Act
        subscription.Expire();
        var statusAfterFirst = subscription.SubscriptionStatus;
        var tierAfterFirst = subscription.SubscriptionTier;

        subscription.Expire();

        // Assert
        subscription.SubscriptionStatus.Should().Be(statusAfterFirst);
        subscription.SubscriptionTier.Should().Be(tierAfterFirst);
        subscription.SubscriptionDuration.Should().Be(SubscriptionDuration.None);
        subscription.StripeSubscriptionId.Should().BeNull();
    }

    [Fact]
    public void Expire_ShouldPreserveDateRange()
    {
        // Arrange
        var startDate = DateTime.UtcNow.AddMonths(-1);
        var endDate = DateTime.UtcNow.AddDays(-1);
        var subscription = CreateActiveSubscription(startDate: startDate, endDate: endDate);

        var originalStartDate = subscription.DateRange.StartDate;
        var originalEndDate = subscription.DateRange.EndDate;

        // Act
        subscription.Expire();

        // Assert
        subscription.DateRange.StartDate.Should().Be(originalStartDate);
        subscription.DateRange.EndDate.Should().Be(originalEndDate);
    }

    #endregion

    #region IsExpired() Tests

    [Fact]
    public void IsExpired_WhenActiveAndPastEndDate_ShouldReturnTrue()
    {
        // Arrange
        var subscription = CreateActiveSubscription(
            endDate: DateTime.UtcNow.AddDays(-1));

        // Act
        var result = subscription.IsExpired(DateTime.UtcNow);

        // Assert
        result.Should().BeTrue();
    }

    [Fact]
    public void IsExpired_WhenActiveAndBeforeEndDate_ShouldReturnFalse()
    {
        // Arrange
        var subscription = CreateActiveSubscription(
            endDate: DateTime.UtcNow.AddDays(1));

        // Act
        var result = subscription.IsExpired(DateTime.UtcNow);

        // Assert
        result.Should().BeFalse();
    }

    [Fact]
    public void IsExpired_WhenCancelledAndPastEndDate_ShouldReturnFalse()
    {
        // Arrange
        var subscription = CreateActiveSubscription(
            endDate: DateTime.UtcNow.AddDays(-1));
        subscription.Cancel(); // status becomes Cancelled

        // Act
        var result = subscription.IsExpired(DateTime.UtcNow);

        // Assert
        result.Should().BeFalse();
    }

    [Fact]
    public void IsExpired_WhenTrialAndPastEndDate_ShouldReturnTrue()
    {
        // Arrange
        var subscription = CreateTrialSubscription(
            endDate: DateTime.UtcNow.AddDays(-1));

        // Act
        var result = subscription.IsExpired(DateTime.UtcNow);

        // Assert
        result.Should().BeTrue();
    }

    #endregion
}
