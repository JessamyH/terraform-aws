using FluentAssertions;
using SmartCompare.Domain.Entities.UserAggregate;
using SmartCompare.Domain.Enums;

namespace SmartCompare.UnitTests.Domain.Users;

public class UserSubscriptionTests
{
    [Fact]
    public void AddSubscription_WhenSubscriptionExists_ShouldUpdateInPlace()
    {
        var user = User.Create("auth0|test123", "testuser", "test@example.com");

        user.AddSubscription(
            subscriptionTier: SubscriptionTier.Basic,
            subscriptionDuration: SubscriptionDuration.Month,
            subscriptionStatus: SubscriptionStatus.Active,
            startDate: DateTime.UtcNow.AddMonths(-1),
            endDate: DateTime.UtcNow,
            stripeSubscriptionId: "sub_old");

        var originalSubscriptionId = user.Subscription!.Id;

        // Act — should NOT throw, should update in place (same entity, same Id)
        user.AddSubscription(
            subscriptionTier: SubscriptionTier.Pro,
            subscriptionDuration: SubscriptionDuration.Year,
            subscriptionStatus: SubscriptionStatus.Active,
            startDate: DateTime.UtcNow,
            endDate: DateTime.UtcNow.AddYears(1),
            stripeSubscriptionId: "sub_new");

        user.Subscription.Should().NotBeNull();
        user.Subscription!.Id.Should().Be(originalSubscriptionId);
        user.Subscription.SubscriptionTier.Should().Be(SubscriptionTier.Pro);
        user.Subscription.SubscriptionDuration.Should().Be(SubscriptionDuration.Year);
        user.Subscription.StripeSubscriptionId.Should().Be("sub_new");
    }

    [Fact]
    public void AddSubscription_WhenNoSubscription_ShouldCreateNew()
    {
        var user = User.Create("auth0|test456", "testuser2", "test2@example.com");

        user.AddSubscription(
            subscriptionTier: SubscriptionTier.Basic,
            subscriptionDuration: SubscriptionDuration.Month,
            subscriptionStatus: SubscriptionStatus.Active,
            startDate: DateTime.UtcNow,
            endDate: DateTime.UtcNow.AddMonths(1),
            stripeSubscriptionId: "sub_first");

        user.Subscription.Should().NotBeNull();
        user.Subscription!.SubscriptionTier.Should().Be(SubscriptionTier.Basic);
        user.Subscription.StripeSubscriptionId.Should().Be("sub_first");
    }
}
