using FluentAssertions;
using SmartCompare.Domain.Entities.PaymentAggregate;
using SmartCompare.Domain.Enums;

namespace SmartCompare.UnitTests.Domain.Payments;

public class PaymentEntityTests
{
    [Fact]
    public void Create_WithRequiredArgs_SetsProperties()
    {
        var payment = Payment.Create(
            amount: 99.00m,
            currency: "AUD",
            status: PaymentStatus.Succeeded,
            type: PaymentType.Subscription,
            stripeInvoiceId: "in_test123",
            subscriptionId: Guid.NewGuid());

        payment.PaymentAmount.Amount.Should().Be(99.00m);
        payment.PaymentAmount.Currency.Should().Be("AUD");
        payment.Status.Should().Be(PaymentStatus.Succeeded);
        payment.Type.Should().Be(PaymentType.Subscription);
        payment.StripeInvoiceId.Should().Be("in_test123");
        payment.StripePaymentIntentId.Should().BeNull();
        payment.StripeChargeId.Should().BeNull();
        payment.PaidAt.Should().BeNull();
        payment.RefundedAt.Should().BeNull();
        payment.FailureReason.Should().BeNull();
        payment.Description.Should().BeNull();
    }

    [Fact]
    public void Create_WithOptionalArgs_SetsAllProperties()
    {
        var paidAt = DateTime.UtcNow;

        var payment = Payment.Create(
            amount: 99.00m,
            currency: "AUD",
            status: PaymentStatus.Succeeded,
            type: PaymentType.Subscription,
            stripeInvoiceId: "in_test123",
            subscriptionId: Guid.NewGuid(),
            stripePaymentIntentId: "pi_test456",
            stripeChargeId: "ch_test789",
            paidAt: paidAt,
            description: "Monthly subscription");

        payment.StripePaymentIntentId.Should().Be("pi_test456");
        payment.StripeChargeId.Should().Be("ch_test789");
        payment.PaidAt.Should().Be(paidAt);
        payment.Description.Should().Be("Monthly subscription");
    }

    [Fact]
    public void MarkAsSucceeded_SetsPaidAtAndStatus()
    {
        var payment = Payment.Create(
            amount: 99.00m,
            currency: "AUD",
            status: PaymentStatus.Pending,
            type: PaymentType.Subscription,
            stripeInvoiceId: "in_test123",
            subscriptionId: Guid.NewGuid());

        payment.MarkAsSucceeded();

        payment.Status.Should().Be(PaymentStatus.Succeeded);
        payment.PaidAt.Should().NotBeNull();
        payment.PaidAt.Should().NotBeNull()
            .And.BeAfter(DateTime.UtcNow.AddSeconds(-5));
    }

    [Fact]
    public void MarkAsFailed_SetsStatusAndReason()
    {
        var payment = Payment.Create(
            amount: 99.00m,
            currency: "AUD",
            status: PaymentStatus.Pending,
            type: PaymentType.Subscription,
            stripeInvoiceId: "in_test123",
            subscriptionId: Guid.NewGuid());

        payment.MarkAsFailed("Card declined");

        payment.Status.Should().Be(PaymentStatus.Failed);
        payment.FailureReason.Should().Be("Card declined");
    }

    [Fact]
    public void MarkAsFailed_WithoutReason_SetsStatusOnly()
    {
        var payment = Payment.Create(
            amount: 99.00m,
            currency: "AUD",
            status: PaymentStatus.Pending,
            type: PaymentType.Subscription,
            stripeInvoiceId: "in_test123",
            subscriptionId: Guid.NewGuid());

        payment.MarkAsFailed();

        payment.Status.Should().Be(PaymentStatus.Failed);
        payment.FailureReason.Should().BeNull();
    }

    [Fact]
    public void Create_WithBothStripeIdsNull_ThrowsArgumentException()
    {
        var act = () => Payment.Create(
            amount: 99.00m,
            currency: "AUD",
            status: PaymentStatus.Pending,
            type: PaymentType.Subscription,
            subscriptionId: Guid.NewGuid(),
            stripeInvoiceId: null,
            stripePaymentIntentId: null);

        act.Should().Throw<ArgumentException>()
            .WithMessage("*stripeInvoiceId*stripePaymentIntentId*");
    }

    [Fact]
    public void Create_WithOnlyPaymentIntentId_Succeeds()
    {
        var payment = Payment.Create(
            amount: 50.00m,
            currency: "AUD",
            status: PaymentStatus.Succeeded,
            type: PaymentType.Subscription,
            subscriptionId: Guid.NewGuid(),
            stripePaymentIntentId: "pi_test789");

        payment.StripePaymentIntentId.Should().Be("pi_test789");
        payment.StripeInvoiceId.Should().BeNull();
    }
}
