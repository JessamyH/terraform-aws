# SmartCompare API

## Project Overview

SmartCompare is a modern ASP.NET Core Web API solution designed for intelligent comparison and analysis.

## Technology Stack

- **Framework**: ASP.NET Core Web API
- **Language**: C#
- **API Documentation**: Swagger/OpenAPI
- **Database**: SQL Server with Entity Framework Core
- **Logging**: Serilog
- **Error Tracking**: Sentry
- **Object Mapping**: AutoMapper
- **Validation**: FluentValidation
- **CQRS**: MediatR
- **Authentication**: Auth0 (OpenID Connect, Authorization Code Flow)
- **Payments**: Stripe (Checkout Sessions API + Webhooks)

## Project Structure

```
smartcompare-api/
├── SmartCompare/                              # Solution root
│   ├── SmartCompare.API/                      # Presentation layer - Web API
│   │   ├── ApiResponse/                       # Unified API response models
│   │   ├── Constants/                         # API constants and routes
│   │   ├── Controllers/                       # API endpoints (Quotes, Projects, Users, Payments, Dashboard, OCR, SubcontractorTypes)
│   │   ├── Extensions/                        # Service registrations (Auth, CORS, Swagger, Logging)
│   │   ├── Filters/                           # Action filters
│   │   ├── Middleware/                        # Custom middleware (exception handling, claims refresh)
│   │   ├── Program.cs                         # Application entry point
│   │   └── appsettings*.json                  # Configuration files
│   │
│   ├── SmartCompare.Application/              # Application layer - Business logic
│   │   ├── Behaviors/                         # MediatR pipeline behaviors (Logging, Validation, Transaction)
│   │   ├── Commands/                          # CQRS command handlers
│   │   ├── Queries/                           # CQRS query handlers
│   │   ├── DTOs/                              # Data transfer objects
│   │   ├── Interfaces/                        # Application interfaces
│   │   ├── Mappings/                          # AutoMapper profiles
│   │   └── Services/                          # Application services
│   │
│   ├── SmartCompare.Domain/                   # Domain layer - Business entities
│   │   ├── Entities/                          # Aggregates (Quote, User, Project, Payment)
│   │   ├── Enums/                             # Domain enumerations
│   │   ├── ValueObjects/                      # Value objects (Money, EmailAddress, ABN, etc.)
│   │   ├── Interfaces/                        # Repository interfaces
│   │   ├── Specifications/                    # Query specifications
│   │   └── DomainEvents/                      # Domain event definitions
│   │
│   ├── SmartCompare.Infrastructure/           # Infrastructure layer
│   │   ├── ExternalServices/                  # Third-party integrations
│   │   │   └── Stripe/                        # Checkout, Webhooks, Customer, PriceResolver
│   │   ├── Persistence/                       # EF Core
│   │   │   ├── Configurations/                # Entity type configurations
│   │   │   ├── Contexts/                      # DbContext
│   │   │   ├── Migrations/                    # Database migrations
│   │   │   ├── Repositories/                  # Repository implementations
│   │   │   └── SeedData/                      # Database seeding
│   │   ├── Queries/                           # Read-only query implementations (IQuoteQueries, etc.)
│   │   ├── Services/                          # Infrastructure services (UserContext, ClaimsRefresh)
│   │   └── Identity/                          # Auth-related infrastructure
│   │
│   ├── SmartCompare.SharedKernel/             # Shared kernel - Common abstractions
│   │   ├── Common/                            # Base classes (AggregateRoot, BaseEntity, ValueObject)
│   │   ├── Auth/                              # Auth constants and helpers
│   │   ├── Interfaces/                        # Common interfaces (IRepository, IUnitOfWork)
│   │   ├── Results/                           # Result pattern implementation
│   │   └── Errors/                            # Error types and definitions
│   │
│   ├── SmartCompare.UnitTests/                # Unit tests (xUnit + FluentAssertions + Moq)
│   │   ├── CommandTests/                      # Command handler tests
│   │   ├── QueryTests/                        # Query handler tests
│   │   ├── Domain/                            # Domain logic tests (Quotes, Users, Payments)
│   │   ├── Infrastructure/                    # Infrastructure tests (Stripe)
│   │   ├── Validators/                        # Validator tests
│   │   ├── Factories/                         # Test entity factories
│   │   └── Helpers/                           # Test helpers (mock setup, Stripe fixtures, etc.)
│   │
│   ├── IntegrationTests/                      # Integration tests
│   │
│   ├── Dockerfile                             # Multi-stage Docker build
│   └── SmartCompare.slnx                      # Solution file
│
└── README.md                                  # Project documentation
```

**Architecture Pattern**: Clean Architecture (Onion Architecture) with CQRS

**Layer Dependencies**:
- API → Application → Domain
- Application → Infrastructure (DI only)
- All layers can reference SharedKernel

## Prerequisites

Please follow the Technology Document to install the correct version of the environment. If you are unsure which version to use, please contact the project administrator.

Required tools:

- .NET 9.0 SDK
- Visual Studio 2022 or Visual Studio Code
- SQL Server (for database connectivity)

## Getting Started

### 1. Clone the Repository

```bash
git clone <repository-url>
cd smartcompare-api
```

### 2. Restore Dependencies

```bash
cd SmartCompare
dotnet restore
```

### 3. Configure Database and Auth0 Settings

For local development, configure the database connection and Auth0 settings using one of these methods:

**Option 1: User Secrets (Recommended)**

```bash
cd SmartCompare/SmartCompare.API

# Database connection
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Server=your_server;Database=SmartCompare;Trusted_Connection=True;TrustServerCertificate=True"

# Auth0 settings (optional, if you don't use local JSON)
dotnet user-secrets set "Auth0:Domain" "your-tenant.auth0.com"
dotnet user-secrets set "Auth0:ClientId" "YOUR_AUTH0_DEV_CLIENT_ID"
dotnet user-secrets set "Auth0:ClientSecret" "YOUR_AUTH0_DEV_CLIENT_SECRET"
dotnet user-secrets set "Auth0:Audience" "YOUR_AUTH0_DEV_AUDIENCE"
dotnet user-secrets set "Auth0:Callback" "/callback"

# Frontend URL (required for authentication error redirects)
dotnet user-secrets set "Frontend:BaseUrl" "http://localhost:3000"
```

**Option 2: Local Configuration File**
Create `SmartCompare/SmartCompare.API/appsettings.Development.local.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=your_server;Database=SmartCompare;..."
  },
  "Auth0": {
    "Domain": "your-tenant.auth0.com",
    "ClientId": "YOUR_AUTH0_DEV_CLIENT_ID",
    "ClientSecret": "YOUR_AUTH0_DEV_CLIENT_SECRET",
    "Audience": "YOUR_AUTH0_DEV_AUDIENCE",
    "Callback": "/callback"
  },
  "Frontend": {
    "BaseUrl": "http://localhost:3000"
  }
}
```

### 4. Run Database Migrations
To set up the database schema and ensure that the necessary tables are created, follow these steps:

#### 4.1 Database Migration Setup
The migration infrastructure is configured to support the design-time scenario:

**4.1.1 Configuration Loading**:  
- The `SmartCompareDbContextFactory` loads connection strings from environment-specific configuration files.  
    - Base: `appsettings.json`  
    - Environment overrides: `appsettings.{Environment}.json` (Development, Staging, Production)  
    - User Secrets overrides (Highest Priority) : Recommended for Security

**4.1.2 Configuring User Secrets for Connection Strings**:  

**step1**: Initialize user-secrets if you haven't used it:  
```bash
# From the solution root directory
cd SmartCompare

dotnet user-secrets init --project SmartCompare.Infrastructure
```

**step1(Optional)**: If you want to clear and reset all user-secrets:  
```bash
# From the solution root directory
cd SmartCompare

dotnet user-secrets clear --project SmartCompare.Infrastructur
```

**step2**: Configure the connection string via user-secrets:  
```bash
# From the solution root directory
cd SmartCompare

# Replace {server_ip}, {server_port}, {db_name}, {user_id}, {password}, and any other database parameters with actual values when executing the command.
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Server={server_ip},{server_port};Database={db_name};User Id={user_id};Password={password};MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=True;" --project SmartCompare.Infrastructure
```

**step3**: List all configured user-secrets to confirm:  
```bash
# From the solution root directory
cd SmartCompare

dotnet user-secrets list --project SmartCompare.Infrastructure
```

#### 4.2 Add the Migration
From the solution root directory, run the following command to create a migration. Replace {scriptName} with a name that represents your migration:
```bash
# From the solution root directory
cd SmartCompare

# Apply migrations add to create the migration script
dotnet ef migrations add {scriptName} --project SmartCompare.Infrastructure --startup-project SmartCompare.API
```

#### 4.3 Apply the Migration
After confirming the migration script is correct, execute the following command to apply the migration and update the database:
```bash
# From the solution root directory
cd SmartCompare
# Apply migrations to create the database
dotnet ef database update --project SmartCompare.Infrastructure --startup-project SmartCompare.API
```

### 5. Run the Application

```bash
cd SmartCompare.API
dotnet run
```

The API will start on the ports configured in `Properties/launchSettings.json`.

## Configuration

### Environment-Specific Settings

The application uses environment-specific configuration files:

- `appsettings.json` - Base settings for all environments
- `appsettings.Development.json` - Development environment overrides
- `appsettings.Staging.json` - Staging environment overrides
- `appsettings.Production.json` - Production environment overrides


### Configuration Items

#### 1. ApplicationInfo Settings

Application metadata configuration used for logging enrichment and identification:

```json
{
  "ApplicationInfo": {
    "Name": "SmartCompare.API",
    "Version": "1.0.0",
    "Environment": "Development|Staging|Production"
  }
}
```

- **Name**: Identifies the application across all components
- **Version**: Tracks the current application release version
- **Environment**: Specifies the deployment environment context

#### 2. Serilog Logging Settings

Structured logging configuration using Serilog with environment-specific log levels and outputs:

**2.1 Base Configuration** (`appsettings.json`):  
- Minimum log level: `Information` (default)  
- Log context enrichment: Machine name, Thread ID, Environment user name  
- Framework log overrides for Microsoft and System namespaces  

**2.2 Development Environment**:  
- Minimum level: `Debug` (most verbose)  
- Console output with ANSI color theme  
- File rotation: Daily, 7-day retention  
- Separate log files by level: `info-.log`, `warning-.log`, `error-.log`  

**2.3 Staging/Production Environments**:  
- Minimum level: `Information`  
- File output only (no console)  
- File rotation: Daily  
- Log retention: 7 days (Staging), 30 days (Production)  
- Log directory: `/var/log/SMAR/{environment}/`  
- File size limit: 10MB with automatic rollover  

Log output template includes: Timestamp, Log Level, Thread ID, Source Context, Application info, Version, and Environment.

**Note**: These logging configurations can be adjusted based on actual deployment requirements and operational needs as the application evolves. The settings above represent the current recommended defaults.

#### 3. Connection Strings and Frontend Configuration

**CORS Configuration**

Configure allowed frontend origins in `appsettings.Development.json`:

```json
"Cors": {
  "FrontendOrigins": [
    "http://localhost:3000"
  ]
}
```

**Frontend Base URL**

The `Frontend:BaseUrl` configuration specifies the frontend application URL for authentication redirects:

```json
"Frontend": {
  "BaseUrl": "http://localhost:3000"
}
```

This setting is required for:
- Authentication failure redirects (redirects to `{BaseUrl}/auth/error` on auth failures)
- Login returnUrl validation (allows redirecting to frontend after Auth0 callback)
- Post-logout redirect (redirects to frontend home after Auth0 logout)
- Proper separation between backend API and frontend application URLs

**Important**: The frontend application must implement the `/auth/error` route to display authentication error messages to users.

#### 4. Auth0 Settings

Auth0 configuration is defined per environment. Required settings:

| Setting | Description | Example |
|---------|-------------|---------|
| `Auth0:Domain` | Auth0 tenant domain | `your-tenant.auth0.com` |
| `Auth0:ClientId` | Application client ID | From Auth0 Dashboard |
| `Auth0:ClientSecret` | Application client secret | From Auth0 Dashboard |
| `Auth0:Audience` | API identifier | Your Auth0 API identifier |
| `Auth0:Callback` | OAuth callback path | `/callback` |

**Auth0 Dashboard Minimum Setup:**

1. Create a **Regular Web Application**
2. Set **Allowed Callback URLs**: `{API_BASE_URL}{Auth0:Callback}` (e.g., `http://localhost:5207/callback`)
3. Set **Allowed Logout URLs**: `{FRONTEND_BASE_URL}` (e.g., `http://localhost:3000`) — frontend URL, not API URL
4. Set **Allowed Web Origins**: `{FRONTEND_BASE_URL}` (e.g., `http://localhost:3000`)
5. Enable **OIDC Conformant** in Advanced Settings → OAuth
6. In **APIs** → your API → Settings → Access Settings, enable **Allow Skipping User Consent** (skips the "Authorize App" consent prompt for first-party apps; note: consent still appears on `localhost` — this is an Auth0 limitation)

> Multiple URLs can be configured (comma-separated) for different environments.

#### 5. Stripe Settings

Stripe is used for subscription payment processing (Checkout Sessions + Webhooks).

| Setting | Description | Example |
|---------|-------------|---------|
| `Stripe:SecretKey` | Stripe API secret key | `sk_test_...` |
| `Stripe:PublishableKey` | Stripe publishable key | `pk_test_...` |
| `Stripe:WebhookSecret` | Webhook endpoint signing secret | `whsec_...` |
| `Stripe:SuccessUrl` | Redirect URL after successful payment | `http://localhost:3000/payment/success?session_id={CHECKOUT_SESSION_ID}` |
| `Stripe:CancelUrl` | Redirect URL when user cancels payment | `http://localhost:3000/payment/cancel` |
| `Stripe:BasicMonthlyPriceId` | Stripe Price ID for Basic Monthly plan | `price_...` |
| `Stripe:BasicYearlyPriceId` | Stripe Price ID for Basic Yearly plan | `price_...` |
| `Stripe:ProMonthlyPriceId` | Stripe Price ID for Pro Monthly plan | `price_...` |
| `Stripe:ProYearlyPriceId` | Stripe Price ID for Pro Yearly plan | `price_...` |

**Local Development Setup:**

```bash
cd SmartCompare/SmartCompare.API

# Required
dotnet user-secrets set "Stripe:SecretKey" "sk_test_YOUR_SECRET_KEY"
dotnet user-secrets set "Stripe:PublishableKey" "pk_test_YOUR_PUBLISHABLE_KEY"
dotnet user-secrets set "Stripe:WebhookSecret" "whsec_YOUR_WEBHOOK_SECRET"

# Price IDs (from Stripe Dashboard > Products > Pricing)
dotnet user-secrets set "Stripe:BasicMonthlyPriceId" "price_YOUR_BASIC_MONTHLY"
dotnet user-secrets set "Stripe:BasicYearlyPriceId" "price_YOUR_BASIC_YEARLY"
dotnet user-secrets set "Stripe:ProMonthlyPriceId" "price_YOUR_PRO_MONTHLY"
dotnet user-secrets set "Stripe:ProYearlyPriceId" "price_YOUR_PRO_YEARLY"
```

> **Important**: Never commit Stripe secret keys to source control. Always use User Secrets or environment variables for sensitive values.

**Stripe Dashboard Minimum Setup:**

1. Create subscription **Products** with recurring prices (Monthly and Yearly) for Basic and Pro tiers
2. Copy each Price ID (`price_...`) into the corresponding configuration
3. Create a **Webhook Endpoint** in Stripe Dashboard, select events `invoice.paid`, `invoice.payment_failed`, `customer.subscription.deleted`, and copy the signing secret

**Checkout Flow:**

1. Client calls `POST /api/payments/checkout-session` with subscription tier and duration
2. API returns a Stripe Checkout Session URL
3. Client redirects user to the Stripe-hosted payment page
4. After payment, Stripe redirects user back to `SuccessUrl`
5. Client calls `GET /api/payments/checkout-session/{sessionId}/status` to verify payment

**Webhook Flow:**

1. Stripe sends event to `POST /api/payments/webhook` with signature header
2. API verifies signature using `WebhookSecret`, rejects invalid requests with 400
3. Based on event type:
   - `invoice.paid` → Record payment, create/renew/upgrade subscription
   - `invoice.payment_failed` → Record failed payment (subscription status unchanged, Stripe retries automatically)
   - `customer.subscription.deleted` → Cancel subscription, downgrade user to Free tier
4. All handlers are idempotent — duplicate deliveries are safely ignored

**Local Webhook Testing with Stripe CLI:**

```bash
# Install Stripe CLI: https://docs.stripe.com/stripe-cli
# Login to your Stripe account
stripe login

# Forward webhook events to local API
stripe listen --forward-to https://localhost:{port}/api/payments/webhook

# Copy the webhook signing secret (whsec_...) printed by the CLI
dotnet user-secrets set "Stripe:WebhookSecret" "whsec_YOUR_CLI_SECRET"

# Trigger test events
stripe trigger invoice.paid
stripe trigger invoice.payment_failed
stripe trigger customer.subscription.deleted
```

> **Note**: In non-Development environments, the application validates that `SecretKey` and `WebhookSecret` are configured at startup. Empty values will prevent the application from starting.

## API Documentation

When running in Development mode, Swagger UI is available at:

- Swagger UI: `https://localhost:{port}/swagger`
- OpenAPI JSON: `https://localhost:{port}/swagger/v1/swagger.json`

## Building the Project

```bash
dotnet build
```

## Running Tests

```bash
dotnet test
```

## Deployment

Refer to the deployment documentation for environment-specific deployment procedures.

## Contributing

Please follow the project's coding standards and submit pull requests for review.

## Support

For questions or issues, please contact the development team or create an issue in the project repository.
